package com.level3.km.portalsdk;

import java.security.SignatureException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.portalsdk.beans.BusyHourCallVolumeResultRow;
import com.level3.km.portalsdk.beans.BusyHourCallVolumeResultRow.HourlyCallVolumeStats;
import com.level3.km.portalsdk.beans.BusyHourResultRow;
import com.level3.km.portalsdk.beans.BusyHourSearchCriteria;
import com.level3.km.portalsdk.beans.EnvironmentConfig;
import com.sun.jersey.core.util.Base64;

public class TestBusyHourReportManager
{
    private static Logger log = LoggerFactory.getLogger(TestBusyHourReportManager.class); 
    private static String appKey = "APPKEY100562488694302";
    private static String appSecret = "AppKeyInformation100562488694303";
    private static String kmServiceUrl = "http://mediation.level3.com";
    
    private static String digestTime = null;
    private static String digest = null;
    
    private String beginDate = null;
    private String endDate = null;
    
	private static final String SOLJ_DATE_FMT = "yyyy-MM-dd'T'HH:mm:ss'Z'" ; 
	
    @BeforeClass
    public static void init() throws Exception
    {
        digestTime = String.valueOf(System.currentTimeMillis());
        digest = createDigest(digestTime, appSecret);
    }
    
    @Before
    public void setUp()
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat(SOLJ_DATE_FMT);
        
        GregorianCalendar beginCalendarDate = new GregorianCalendar();
        
        beginCalendarDate.add(Calendar.DATE, -9);
        beginCalendarDate.set(Calendar.HOUR_OF_DAY, 0);
        beginCalendarDate.set(Calendar.MINUTE, 0);
        beginCalendarDate.set(Calendar.SECOND, 0);
        
        beginDate = dateFormat.format(beginCalendarDate.getTime());
        
        GregorianCalendar endCalendarDate = new GregorianCalendar();
        
        endCalendarDate.add(Calendar.DATE, -2);
        endCalendarDate.set(Calendar.HOUR_OF_DAY, 0);
        endCalendarDate.set(Calendar.MINUTE, 0);
        endCalendarDate.set(Calendar.SECOND, 0);
        
        endDate = dateFormat.format(endCalendarDate.getTime());
    }
    
    @Test
    public void testBusyHourReportData()
    {
        try
        {
            log.info("Retriving data for busy hour.");

            EnvironmentConfig envConfig = new EnvironmentConfig();
            envConfig.setAppKey(appKey);
            envConfig.setDigestTime(digestTime);
            envConfig.setDigest(digest);
            envConfig.setKmServicesUrl(kmServiceUrl);
            
            log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);
            
            BusyHourSearchCriteria searchCriteria = new BusyHourSearchCriteria();
            
            List<String> customerIds = new ArrayList<String>();
            customerIds.add("1-DYU4P");
            searchCriteria.setCustomerIds(customerIds);
            
            searchCriteria.setStartDate(beginDate);
            searchCriteria.setEndDate(endDate);
            
            List<BusyHourResultRow> resultList = BusyHourReportManager.getBusyHourReportData(searchCriteria, envConfig);
            
            Assert.assertNotNull(resultList);
            Assert.assertFalse("List of BusyHourResultRow is empty.", resultList.isEmpty());
            
            for(BusyHourResultRow resultRow : resultList)
            {
                Assert.assertNotNull("Found null row for BusyHourResultRow", resultRow);
                Assert.assertNotNull(
                        "Busiest Hour check failed for TG ID " + resultRow.getTrunkGroupId(),
                        resultRow.getBusiestHour());
                Assert.assertNotNull(
                        "Highest utilization percentage check failed for TG ID " + resultRow.getTrunkGroupId(),
                        resultRow.getHighestUtilizationPercentage());
                Assert.assertNotNull(
                        "Least Busiest Hour check failed for TG ID " + resultRow.getTrunkGroupId(),
                        resultRow.getLeastBusyHour());
                Assert.assertNotNull(
                        "Lowest utilization percentage check failed for TG ID " + resultRow.getTrunkGroupId(),
                        resultRow.getLowestUtilizationPercentage());
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail();
        }
    }
    
    @Test
    public void testBusyHourCharData()
    {
        boolean hasAvgRow = false;
        try
        {
            log.info("Retriving data for busy hour chart.");

            EnvironmentConfig envConfig = new EnvironmentConfig();
            envConfig.setAppKey(appKey);
            envConfig.setDigestTime(digestTime);
            envConfig.setDigest(digest);
            envConfig.setKmServicesUrl(kmServiceUrl);
            
            BusyHourSearchCriteria searchCriteria = new BusyHourSearchCriteria();
            
            List<String> customerIds = new ArrayList<String>();
            customerIds.add("1-DYU4P");
            searchCriteria.setCustomerIds(customerIds);
            
            searchCriteria.setStartDate(beginDate);
            searchCriteria.setEndDate(endDate);
            
            List<String> trunkGroupIds = new ArrayList<String>();
            trunkGroupIds.add("400010081");
            trunkGroupIds.add("400010390");
            trunkGroupIds.add("400010392");
            trunkGroupIds.add("400010411");
            trunkGroupIds.add("102811105");
            trunkGroupIds.add("102811108");
            trunkGroupIds.add("102814034");
            trunkGroupIds.add("102814035");
            trunkGroupIds.add("102822090");
            trunkGroupIds.add("102822091");
            trunkGroupIds.add("102823570");
            trunkGroupIds.add("102823571");
            trunkGroupIds.add("102824686");
            trunkGroupIds.add("102824687");
            trunkGroupIds.add("102824766");
            trunkGroupIds.add("102824768");
            trunkGroupIds.add("102824874");
            trunkGroupIds.add("102824875");
            trunkGroupIds.add("102827180");
            trunkGroupIds.add("102827182");
            trunkGroupIds.add("102827582");
            trunkGroupIds.add("102827583");
            trunkGroupIds.add("102828190");
            trunkGroupIds.add("102828191");
            trunkGroupIds.add("102829172");
            trunkGroupIds.add("102829173");
            trunkGroupIds.add("102829651");
            trunkGroupIds.add("102829652");
            trunkGroupIds.add("102829890");
            trunkGroupIds.add("102829891");
            trunkGroupIds.add("102829893");
            trunkGroupIds.add("102829894");
            trunkGroupIds.add("102829898");
            trunkGroupIds.add("102829900");
            trunkGroupIds.add("102832882");
            trunkGroupIds.add("102832886");
            trunkGroupIds.add("102833153");
            trunkGroupIds.add("102833154");
            trunkGroupIds.add("102833470");
            trunkGroupIds.add("102833473");
            trunkGroupIds.add("102833481");
            trunkGroupIds.add("102833482");
            trunkGroupIds.add("102834259");
            trunkGroupIds.add("102834260");
            trunkGroupIds.add("102835956");
            trunkGroupIds.add("102835957");
            trunkGroupIds.add("102836476");
            trunkGroupIds.add("102836479");
            trunkGroupIds.add("102836518");
            trunkGroupIds.add("102836539");
            trunkGroupIds.add("102838505");
            trunkGroupIds.add("102838517");
            trunkGroupIds.add("102840328");
            trunkGroupIds.add("102840333");
            trunkGroupIds.add("102840343");
            trunkGroupIds.add("102840344");
            trunkGroupIds.add("102841733");
            trunkGroupIds.add("102841734");
            trunkGroupIds.add("102844137");
            trunkGroupIds.add("102844154");
            trunkGroupIds.add("102844165");
            trunkGroupIds.add("102844166");
            trunkGroupIds.add("102844901");
            trunkGroupIds.add("102844902");
            trunkGroupIds.add("102845126");
            trunkGroupIds.add("102845127");
            trunkGroupIds.add("102845139");
            trunkGroupIds.add("102845141");
            trunkGroupIds.add("102846830");
            trunkGroupIds.add("102846831");
            trunkGroupIds.add("102880338");
            trunkGroupIds.add("102880339");
            trunkGroupIds.add("102928037");
            trunkGroupIds.add("102928039");
            trunkGroupIds.add("102944179");
            trunkGroupIds.add("102944180");
            trunkGroupIds.add("400001046");
            trunkGroupIds.add("400001047");
            trunkGroupIds.add("400003411");
            trunkGroupIds.add("400003412");
            trunkGroupIds.add("400003569");
            trunkGroupIds.add("400003571");
            trunkGroupIds.add("400007607");
            trunkGroupIds.add("400007608");
            trunkGroupIds.add("400007609");
            trunkGroupIds.add("400007610");
            trunkGroupIds.add("400007611");
            trunkGroupIds.add("400007612");
            trunkGroupIds.add("400007614");
            trunkGroupIds.add("400007615");
            trunkGroupIds.add("400010410");
            
            searchCriteria.setTrunkGroupIds(trunkGroupIds);
            
            List<BusyHourCallVolumeResultRow> resultList = BusyHourReportManager.getBusyHourChartData(searchCriteria, envConfig);
            
            Assert.assertNotNull(resultList);
            
            Assert.assertFalse("List of BusyHourCallVolumeResultRow is empty.", resultList.isEmpty());
            
            for(BusyHourCallVolumeResultRow row : resultList)
            {
                Assert.assertNotNull("Found null row for BusyHourResultRow", row);
                
                List<HourlyCallVolumeStats> hourlyStatsList = row.getHourlyStatList();
                
                Assert.assertNotNull(
                    "Hourly stats list check failed for trunk group ID " + row.getTrunkGroupId(),
                    hourlyStatsList);
                
                Assert.assertFalse("Hourly stats list is empty.", hourlyStatsList.isEmpty());
                
                for(HourlyCallVolumeStats hourlyStat : hourlyStatsList)
                {
                    Assert.assertNotNull(
                        "Found null row for Hourly call volume stats for trunk group ID " + row.getTrunkGroupId(),
                        hourlyStat);
                    
                    Assert.assertNotNull(
                        "Call volume not set for trunk group ID " + row.getTrunkGroupId(),
                        hourlyStat.getCallVolume());
                    Assert.assertNotNull(
                        "Interval not set for trunk group ID " + row.getTrunkGroupId(),
                        hourlyStat.getInterval());
                }
                
                log.debug("Results for trunk group ID {}, count of stats {}, hour 19 call volume stats are {}",
                        row.getTrunkGroupId(),
                        row.getHourlyStatList().size(),
                        row.getHourlyStat("19").getCallVolume().toString());
                
                if("AVG".equals(row.getTrunkGroupId()))
                {
                    hasAvgRow = true;
                }
            }
            
            Assert.assertTrue("BusyHourCallVolumeResultRow for AVG not found.", hasAvgRow);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail();
        }
    }
    
    static String createDigest(String digestTime, String digestSecret)
            throws java.security.SignatureException
    {
        String result;

        try
        {
            // get an hmac_sha1 key from the raw key bytes
            SecretKeySpec signingKey = new SecretKeySpec(
                    digestSecret.getBytes(), "macSHA256");
            // get an hmac_sha2 Mac instance and initialize with the signing  key
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(signingKey);
            // compute the hmac on input data bytes
            byte[] rawHmac = mac.doFinal(digestTime.getBytes());
            // base64-encode the hmac
            result = new String(Base64.encode(rawHmac));
        }
        catch (Exception e)
        {
            throw new SignatureException("Failed to generate HMAC : " + e.getMessage());
        }
        return result;
    }
}