package com.level3.km.portalsdk.beans;

import java.util.ArrayList;
import java.util.List;

public class BusyHourResultRow
{
    private String trunkGroupId = null;
    private String busiestHour = null;
    private String leastBusyHour = null;
    private Double highestUtilizationPercentage = null;
    private Double lowestUtilizationPercentage = null;
    private List<HourlyStats> hourlyStatList = null;
    
    private Integer busiestHourCallVolume = null;
    private Integer leastBusyHourCallVolume = null;
    
    public BusyHourResultRow()
    {
        hourlyStatList = new ArrayList<HourlyStats>();
    }
    
    public String getTrunkGroupId()
    {
        return trunkGroupId;
    }

    public void setTrunkGroupId(String trunkGroupId)
    {
        this.trunkGroupId = trunkGroupId;
    }

    public String getBusiestHour()
    {
        return busiestHour;
    }

    public void setBusiestHour(String busiestHour)
    {
        this.busiestHour = busiestHour;
    }

    public String getLeastBusyHour()
    {
        return leastBusyHour;
    }

    public void setLeastBusyHour(String leastBusyHour)
    {
        this.leastBusyHour = leastBusyHour;
    }

    public Double getHighestUtilizationPercentage()
    {
        return highestUtilizationPercentage;
    }

    public void setHighestUtilizationPercentage(Double highestUtilizationPercentage)
    {
        this.highestUtilizationPercentage = highestUtilizationPercentage;
    }

    public Double getLowestUtilizationPercentage()
    {
        return lowestUtilizationPercentage;
    }

    public void setLowestUtilizationPercentage(Double lowestUtilizationPercentage)
    {
        this.lowestUtilizationPercentage = lowestUtilizationPercentage;
    }

    List<HourlyStats> getHourlyStatList()
    {
        return hourlyStatList;
    }
    
    public void addHourlyStats(HourlyStats hourlyStats)
    {
        if(hourlyStats != null && 
           hourlyStats.getInterval() != null &&
           !hourlyStats.getInterval().equals(""))
        {
           this.hourlyStatList.add(hourlyStats); 
           
           // update busiest hour, least busy hour, highest Utilization %, lowest utilization %
           if(busiestHour == null || busiestHour.equals(""))
           {
               this.busiestHourCallVolume = hourlyStats.getCallVolume();
               this.leastBusyHourCallVolume = hourlyStats.getCallVolume();
               
               this.busiestHour = hourlyStats.getInterval();
               this.leastBusyHour = hourlyStats.getInterval();
               
               this.highestUtilizationPercentage = hourlyStats.getPeakUtilizationPercentage();
               this.lowestUtilizationPercentage = hourlyStats.getMinimumUtilizationPercentage();
           }
           else
           {
               // compare busiest hour
               // compare by call volume, use the higher value for busiest hour
               // if both the call volume are same then use the lower hourly value
               if(this.busiestHourCallVolume < hourlyStats.getCallVolume())
               {
                   this.busiestHourCallVolume = hourlyStats.getCallVolume();
                   this.busiestHour = hourlyStats.getInterval();
                   this.highestUtilizationPercentage = hourlyStats.getPeakUtilizationPercentage();
               }
               else if(this.busiestHourCallVolume == hourlyStats.getCallVolume() &&
                       this.busiestHour.compareTo(hourlyStats.getInterval()) > 0)
               {
                   this.busiestHourCallVolume = hourlyStats.getCallVolume();
                   this.busiestHour = hourlyStats.getInterval();
                   this.highestUtilizationPercentage = hourlyStats.getPeakUtilizationPercentage();
               }
               
               // compare least busy hour
               // compare by call volume, use the lower value for least busy hour
               // if both the call volume are same then use the lower hourly value
               if(this.leastBusyHourCallVolume > hourlyStats.getCallVolume())
               {
                   this.leastBusyHourCallVolume = hourlyStats.getCallVolume();
                   this.leastBusyHour = hourlyStats.getInterval();
                   this.lowestUtilizationPercentage = hourlyStats.getMinimumUtilizationPercentage();
               }
               else if(this.leastBusyHourCallVolume == hourlyStats.getCallVolume() &&
                       this.leastBusyHour.compareTo(hourlyStats.getInterval()) > 0)
               {
                   this.leastBusyHourCallVolume = hourlyStats.getCallVolume();
                   this.leastBusyHour = hourlyStats.getInterval();
                   this.lowestUtilizationPercentage = hourlyStats.getMinimumUtilizationPercentage();
               }
           }
        }
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("BusyHourResultRow [trunkGroupId=");
        builder.append(trunkGroupId);
        builder.append(", busisetHour=");
        builder.append(busiestHour);
        builder.append(", leastBusyHour=");
        builder.append(leastBusyHour);
        builder.append(", highestUtilizationPercentage=");
        builder.append(highestUtilizationPercentage);
        builder.append(", lowestUtilizationPercentage=");
        builder.append(lowestUtilizationPercentage);
        builder.append("]");
        return builder.toString();
    }
    
    public static class HourlyStats
    {
        public String interval = null;
        public Integer callVolume = null;
        public Double peakUtilizationPercentage = null;
        public Double minimumUtilizationPercentage = null;
        
        public String getInterval()
        {
            return interval;
        }
        public void setInterval(String interval)
        {
            this.interval = interval;
        }
        public Integer getCallVolume()
        {
            return callVolume;
        }
        public void setCallVolume(Integer callVolume)
        {
            this.callVolume = callVolume;
        }
        public Double getPeakUtilizationPercentage()
        {
            return peakUtilizationPercentage;
        }
        public void setPeakUtilizationPercentage(Double peakUtilizationPercentage)
        {
            this.peakUtilizationPercentage = peakUtilizationPercentage;
        }
        public Double getMinimumUtilizationPercentage()
        {
            return minimumUtilizationPercentage;
        }
        public void setMinimumUtilizationPercentage(Double minimumUtilizationPercentage)
        {
            this.minimumUtilizationPercentage = minimumUtilizationPercentage;
        }
    }
}
