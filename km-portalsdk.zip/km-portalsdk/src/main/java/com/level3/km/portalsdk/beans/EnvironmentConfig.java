package com.level3.km.portalsdk.beans;

public class EnvironmentConfig
{
    private String appKey = null;
    private String digest = null;
    private String digestTime = null;
    private String kmServicesUrl = null;
    
    public String getAppKey()
    {
        return appKey;
    }
    public void setAppKey(String appKey)
    {
        this.appKey = appKey;
    }
    public String getDigest()
    {
        return digest;
    }
    public void setDigest(String digest)
    {
        this.digest = digest;
    }
    public String getDigestTime()
    {
        return digestTime;
    }
    public void setDigestTime(String digestTime)
    {
        this.digestTime = digestTime;
    }
    public String getKmServicesUrl()
    {
        return kmServicesUrl;
    }
    public void setKmServicesUrl(String kmServicesUrl)
    {
        this.kmServicesUrl = kmServicesUrl;
    }
    
    public boolean isValid()
    {
        if(this.appKey == null || this.appKey.equals("") ||
           this.digest == null || this.digest.equals("") ||
           this.digestTime == null || this.digestTime.equals("") ||
           this.kmServicesUrl == null || this.kmServicesUrl.equals(""))
        {
            return false;
        }
        
        return true;
    }
    
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("EnvironmentConfig [appKey=");
        builder.append(appKey);
        builder.append(", digest=");
        builder.append(digest);
        builder.append(", digestTime=");
        builder.append(digestTime);
        builder.append(", kmServicesUrl=");
        builder.append(kmServicesUrl);
        builder.append("]");
        return builder.toString();
    }

}
