package com.level3.km.portalsdk;

import java.util.List;

import com.ecyrd.speed4j.StopWatch;
import com.ecyrd.speed4j.StopWatchFactory;
import com.level3.km.portalsdk.beans.BusyHourCallVolumeResultRow;
import com.level3.km.portalsdk.beans.BusyHourResultRow;
import com.level3.km.portalsdk.beans.BusyHourSearchCriteria;
import com.level3.km.portalsdk.beans.EnvironmentConfig;
import com.level3.km.portalsdk.impl.BusyHourChartDataManager;
import com.level3.km.portalsdk.impl.BusyHourReportDataManager;

public class BusyHourReportManager
{
    public static String KM_SERVICES_END_POINT = "/DataServices/v1/Search/trunkGroupCallVolume/raw";
    
    /**
     * @param searchCriteria - Details the search constraint for the report data 
     * @param environmentConfig - sets environment specification where this search needs to be run
     * @return - Busy hour call volume stats for each trunk group matched by search criteria
     */
    public static List<BusyHourResultRow> getBusyHourReportData(
            BusyHourSearchCriteria searchCriteria, EnvironmentConfig environmentConfig)
    {
        StopWatchFactory speed4jStopWatchFactory = StopWatchFactory.getInstance("loggingFactory");
        StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();

        List<BusyHourResultRow> resultList = null;
        BusyHourReportDataManager dataManager = null;

        try
        {
            dataManager = new BusyHourReportDataManager(searchCriteria, environmentConfig);
            
            resultList = dataManager.process();
            
            return resultList;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            return null;
        }
        finally
        {
            stopWatch.stop("BusyHourReportData", searchCriteria.toString());
        }
    }
    
    /**
     * 
     * @param searchCriteria - Details the search constraint for the report data 
     * @param environmentConfig - sets environment specification where this search needs to be run
     * @return - hourly call volume for each trunk group in search criteria
     * average hourly call volume for all the trunk groups in the search criteria will be denoted by Trunk group Id of "AVG"
     */
    public static List<BusyHourCallVolumeResultRow> getBusyHourChartData(
            BusyHourSearchCriteria searchCriteria, EnvironmentConfig environmentConfig)
    {
        StopWatchFactory speed4jStopWatchFactory = StopWatchFactory.getInstance("loggingFactory");
        StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();

        List<BusyHourCallVolumeResultRow> resultList = null;
        BusyHourChartDataManager dataManager = null;

        try
        {
            dataManager = new BusyHourChartDataManager(searchCriteria, environmentConfig);
            
            resultList = dataManager.process();
            
            return resultList;
        }
        finally
        {
            stopWatch.stop("BusyHourChartData", searchCriteria.toString());
        }
    }
}
