package com.level3.km.portalsdk.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class PooledExecutors
{
    private static PooledExecutors instance = null;
    private static Object mutex = new int[ 1 ];
    
    public static final String BUSY_HOUR_REPORT_EXECUTOR = "busyHourReportExecutor";
    public static final String BUSY_HOUR_CHART_EXECUTOR = "busyHourChartExecutor";
    
    private Map<String, Executor> executorMap = null;
    
    private PooledExecutors()
    {
        executorMap = new HashMap<String, Executor>();
        
        // instantiate a ThreadPool executor for Busy Hour report data
        ThreadPoolExecutor busyHourReportExecutor = 
                new ThreadPoolExecutor(10, 10, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        
        executorMap.put(BUSY_HOUR_REPORT_EXECUTOR, busyHourReportExecutor);
        
        // instantiate a ThreadPool executor for Busy Hour report data
        ThreadPoolExecutor busyHourChartExecutor = 
                new ThreadPoolExecutor(10, 10, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        
        executorMap.put(BUSY_HOUR_CHART_EXECUTOR, busyHourChartExecutor);
    }

    public static PooledExecutors instance()
    {
        PooledExecutors tempInstance = null;
        
        if(instance == null)
        {
            synchronized (mutex)
            {
                if(instance == null)
                {
                    tempInstance = new PooledExecutors();
                    instance = tempInstance;
                }
            }
        }
        
        return instance;
    }
    
    public Executor get(String name)
    {
        return executorMap.get(name);
    }
    
    public void execute(String poolName, Runnable command)
    {
        Executor executor = executorMap.get(poolName);
        
        if(executor != null)
        {
            executor.execute(command);
        }
        else
        {
            throw new RuntimeException("Executor pool: " + poolName + " not found");
        }
        
        return;
    }
}
