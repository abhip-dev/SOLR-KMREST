package com.level3.km.portalsdk.impl;

import java.util.List;

public class QueryHelper
{
    public static String addCriteria(String criteriaString, List<String> criteriaList)
    {
        StringBuilder criteriaBuilder = new StringBuilder();
        criteriaBuilder.append(criteriaString);
        criteriaBuilder.append(":(");

        boolean appendOr = false;
        for(String criteria : criteriaList)
        {
            if(appendOr)
            {
                criteriaBuilder.append(" OR ");
            }

            criteriaBuilder.append(criteria);

            appendOr = true;
        }

        criteriaBuilder.append(")");
        
        return criteriaBuilder.toString();
    }
}
