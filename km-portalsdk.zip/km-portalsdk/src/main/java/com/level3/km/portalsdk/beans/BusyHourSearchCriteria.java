package com.level3.km.portalsdk.beans;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class BusyHourSearchCriteria
{
    private List<String> customerIds = null;
    private List<String> billAccountNumbers = null;
    private List<String> trunkGroupIds = null;
    private String startDate = null;
    private String endDate = null;
    
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    
    public List<String> getCustomerIds()
    {
        return customerIds;
    }
    public void setCustomerIds(List<String> customerIds)
    {
        this.customerIds = customerIds;
    }
    public List<String> getBillAccountNumbers()
    {
        return billAccountNumbers;
    }
    public void setBillAccountNumbers(List<String> billAccountNumbers)
    {
        this.billAccountNumbers = billAccountNumbers;
    }
    
    public String getStartDate()
    {
        return startDate;
    }
    
    /*
     * Must have format of YYYY-MM-DD'T'HH:mm:ss'Z' e.g. 2014-04-11T00:00:00Z
     */
    public void setStartDate(String startDate)
    {
        if(isValidDate(startDate))
        {
            this.startDate = startDate;
        }
        else
        {
            throw new RuntimeException("Date String has invalid format, date must be specified as yyyy-MM-dd'T'HH:mm:ss'Z'");
        }
    }
    
    public String getEndDate()
    {
        return endDate;
    }
    
    /*
     * Must have format of YYYY-MM-DD'T'HH:mm:ss'Z' e.g. 2014-04-11T00:00:00Z
     */
    public void setEndDate(String endDate)
    {
        if(isValidDate(endDate))
        {
            this.endDate = endDate;
        }
        else
        {
            throw new RuntimeException("Date String has invalid format, date must be specified as yyyy-MM-dd'T'HH:mm:ss'Z'");
        }
    }
    
    public List<String> getTrunkGroupIds()
    {
        return trunkGroupIds;
    }
    public void setTrunkGroupIds(List<String> trunkGroupIds)
    {
        this.trunkGroupIds = trunkGroupIds;
    }
    
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("BusyHourSearchCriteria [startDate=");
        builder.append(startDate);
        builder.append(", endDate=");
        builder.append(endDate);
        builder.append("]");
        return builder.toString();
    }
    
    public boolean isValid()
    {
        if((this.customerIds == null || this.customerIds.isEmpty()) &&
           (this.billAccountNumbers == null || this.billAccountNumbers.isEmpty()))
        {
            return false;
        }
        
        if(this.startDate == null || this.startDate.equals("") ||
           this.endDate == null || this.endDate.equals(""))
        {
            return false;
        }
        
        return true;
    }
    
    private boolean isValidDate(String dateString)
    {
        try
        {
            dateFormat.parse(dateString);
        }
        catch (ParseException e)
        {
            return false;
        }
        return true;
    }
    
}
