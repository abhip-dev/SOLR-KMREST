package com.level3.km.portalsdk.impl;

import java.util.concurrent.CountDownLatch;

import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.portalsdk.BusyHourReportManager;
import com.level3.km.portalsdk.beans.BusyHourResultRow;
import com.level3.km.portalsdk.beans.BusyHourResultRow.HourlyStats;
import com.level3.km.portalsdk.beans.BusyHourSearchCriteria;
import com.level3.km.portalsdk.beans.EnvironmentConfig;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class BusyHourTrunkGroupDataRetriever implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(BusyHourTrunkGroupDataRetriever.class); 
    private BusyHourReportDataManager reportDataManager = null;
    private String trunkGroupId = null;
    private CountDownLatch countDownLatch = null;
    
    public BusyHourTrunkGroupDataRetriever(
            BusyHourReportDataManager reportDataManager, String trunkGroupId, CountDownLatch countDownLatch)
    {
        this.reportDataManager = reportDataManager;
        this.trunkGroupId = trunkGroupId;
        this.countDownLatch = countDownLatch;
    }

    public void run()
    {
        BusyHourResultRow resultRow = getBusyHourReportForTrunkGroup();

        this.reportDataManager.addBusyHourResultRow(resultRow);
        
        this.countDownLatch.countDown();
    }

    private BusyHourResultRow getBusyHourReportForTrunkGroup()
    {
        String url = null;
        StringBuilder fqParam = null;
        JSONObject jsonObject = null;
        JSONObject jsonStats = null;
        JSONObject jsonStatsFields = null;
        JSONObject jsonTrunkGroupCallQuantity = null;
        JSONObject jsonTrunkGroupCallQuantityFacets = null;
        JSONObject jsonTrunkGroupCallQuantityStatCollectionHour = null;
        JSONObject jsonTrunkGroupPeakUtilPct = null;
        JSONObject jsonTrunkGroupPeakUtilPctFacets = null;
        JSONObject jsonTrunkGroupPeakUtilPctStatCollectionHour = null;
        JSONObject jsonTrunkGroupMinUtilPct = null;
        JSONObject jsonTrunkGroupMinUtilPctFacets = null;
        JSONObject jsonTrunkGroupMinUtilPctStatCollectionHour = null;
        ClientResponse response = null;
        Client client = null;
        WebResource webResource = null;
        BusyHourResultRow resultRow = new BusyHourResultRow();
        HourlyStats hourlyStat = null;
        BusyHourSearchCriteria searchCriteria = null;
        EnvironmentConfig environmentConfig = null; 
        
        /*
         * execute the second query per tg to get the stats for each trunk group ID
         * http://kmservices-dev/DataServices/v1/Search/trunkGroupCallVolume/raw?q=trunkGroupId:102844231&fq=voiceCompleteTrunkGroupIndicator:true%20AND%20customerNumber:1-dyu4p%20AND%20trunkGroupUtilizationIntervalStartHour:[2014-04-11T00:00:00Z%20TO%202014-04-24T00:00:00Z]&stats=true&stats.facet=statCollectionHour&stats.field=trunkGroupCallQuantity&stats.field=trunkGroupPeakUtilizationPercentage&stats.field=trunkGroupMinUtilizationPercentage&facet.mincount=1&rows=0
         * 
         * params
         * q=trunkGroupId:102844231
         * fq=voiceCompleteTrunkGroupIndicator:true%20AND%20customerNumber:1-dyu4p%20AND%20trunkGroupUtilizationIntervalStartHour:[2014-04-11T00:00:00Z%20TO%202014-04-24T00:00:00Z]
         * stats=true
         * stats.facet=statCollectionHour 
         * stats.field=trunkGroupCallQuantity
         * stats.field=trunkGroupPeakUtilizationPercentage
         * stats.field=trunkGroupMinUtilizationPercentage
         * facet.mincount=1
         * rows=0
         */

        try
        {
            searchCriteria = this.reportDataManager.getSearchCriteria();
            environmentConfig = this.reportDataManager.getEnvironmentConfig();
            
            resultRow.setTrunkGroupId(trunkGroupId);
            
            client = Client.create();
            url = environmentConfig.getKmServicesUrl() + BusyHourReportManager.KM_SERVICES_END_POINT;
            webResource = client.resource(url);
            
            // Build fq param
            fqParam = new StringBuilder();
            fqParam.append("voiceCompleteTrunkGroupIndicator:true");
            
            // add customer numbers
            if(searchCriteria.getCustomerIds() != null && 
                    !searchCriteria.getCustomerIds().isEmpty())
            {
                fqParam.append(" AND ");
                fqParam.append(
                        QueryHelper.addCriteria("customerNumber", searchCriteria.getCustomerIds()));
            }

            // add bill account numbers
            if(searchCriteria.getBillAccountNumbers() != null &&
                    !searchCriteria.getBillAccountNumbers().isEmpty())
            {
                fqParam.append(" AND ");
                fqParam.append(QueryHelper.addCriteria("billAccountNumber", searchCriteria.getBillAccountNumbers()));
            }
            
            // add trunkGroupUtilizationIntervalStartHour
            fqParam.append(" AND trunkGroupUtilizationIntervalStartHour:[");
            fqParam.append(searchCriteria.getStartDate());
            fqParam.append(" TO ");
            fqParam.append(searchCriteria.getEndDate());
            fqParam.append("]");
            
            response =
               webResource.queryParam("q", "trunkGroupId:" + this.trunkGroupId)
                          .queryParam("fq", fqParam.toString())
                          .queryParam("stats", "true")
                          .queryParam("stats.facet", "statCollectionHour")
                          .queryParam("stats.field", "trunkGroupCallQuantity")
                          .queryParam("stats.field", "trunkGroupPeakUtilizationPercentage")
                          .queryParam("stats.field", "trunkGroupMinUtilizationPercentage")
                          .queryParam("facet.mincount", "1")
                          .queryParam("rows", "0")
                          .queryParam("omitHeader", "true")
                          .accept(MediaType.APPLICATION_JSON)
                          .header("X-Level3-Application-Key", environmentConfig.getAppKey())
                          .header("X-Level3-Digest", environmentConfig.getDigest())
                          .header("X-Level3-Digest-Time", environmentConfig.getDigestTime())
                          .get(ClientResponse.class);
            
            jsonObject = new JSONObject(response.getEntity(String.class));
            
            jsonStats = jsonObject.getJSONObject("stats");
            jsonStatsFields = jsonStats.getJSONObject("stats_fields");
            
            jsonTrunkGroupCallQuantity = jsonStatsFields.optJSONObject("trunkGroupCallQuantity");
            
            if(jsonTrunkGroupCallQuantity != null)
            {
                jsonTrunkGroupCallQuantityFacets = jsonTrunkGroupCallQuantity.getJSONObject("facets");
                jsonTrunkGroupCallQuantityStatCollectionHour = jsonTrunkGroupCallQuantityFacets.getJSONObject("statCollectionHour");

                jsonTrunkGroupPeakUtilPct = jsonStatsFields.optJSONObject("trunkGroupPeakUtilizationPercentage");
                if(jsonTrunkGroupPeakUtilPct != null)
                {
                    jsonTrunkGroupPeakUtilPctFacets = jsonTrunkGroupPeakUtilPct.getJSONObject("facets");
                    jsonTrunkGroupPeakUtilPctStatCollectionHour = jsonTrunkGroupPeakUtilPctFacets.getJSONObject("statCollectionHour");
                }

                jsonTrunkGroupMinUtilPct = jsonStatsFields.optJSONObject("trunkGroupMinUtilizationPercentage");
                
                if(jsonTrunkGroupMinUtilPct != null)
                {
                    jsonTrunkGroupMinUtilPctFacets = jsonTrunkGroupMinUtilPct.getJSONObject("facets");
                    jsonTrunkGroupMinUtilPctStatCollectionHour = jsonTrunkGroupMinUtilPctFacets.getJSONObject("statCollectionHour");
                }

                String[] statCollectionHourArray = JSONObject.getNames(jsonTrunkGroupCallQuantityStatCollectionHour);

                for(String statCollectionHour : statCollectionHourArray)
                {
                    hourlyStat = new HourlyStats();

                    hourlyStat.setInterval(statCollectionHour);

                    JSONObject callVolumeCollectioHourJson = jsonTrunkGroupCallQuantityStatCollectionHour.optJSONObject(statCollectionHour);
                    hourlyStat.setCallVolume(callVolumeCollectioHourJson.optInt("sum"));

                    if(jsonTrunkGroupPeakUtilPctStatCollectionHour != null)
                    {
                        JSONObject peakUtilPctCollectioHourJson = jsonTrunkGroupPeakUtilPctStatCollectionHour.optJSONObject(statCollectionHour);
                        hourlyStat.setPeakUtilizationPercentage(peakUtilPctCollectioHourJson.optDouble("mean"));
                    }

                    if(jsonTrunkGroupMinUtilPctStatCollectionHour != null)
                    {
                        JSONObject minUtilPctCollectioHourJson = jsonTrunkGroupMinUtilPctStatCollectionHour.optJSONObject(statCollectionHour);
                        hourlyStat.setMinimumUtilizationPercentage(minUtilPctCollectioHourJson.optDouble("mean"));
                    }

                    resultRow.addHourlyStats(hourlyStat);
                }
            }
            
            log.debug("For Trunk Group Id :{}, busy hour result is {}", trunkGroupId, resultRow.toString());
            
            return resultRow;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            throw new RuntimeException("could not get busy hour result for input criteria.", ex);
        }
    }
}
