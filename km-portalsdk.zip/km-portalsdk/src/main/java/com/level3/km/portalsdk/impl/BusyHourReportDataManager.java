package com.level3.km.portalsdk.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.portalsdk.BusyHourReportManager;
import com.level3.km.portalsdk.beans.BusyHourResultRow;
import com.level3.km.portalsdk.beans.BusyHourSearchCriteria;
import com.level3.km.portalsdk.beans.EnvironmentConfig;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class BusyHourReportDataManager
{
    // this class will act as a control object that 
    // 1. gets the list of TG IDs
    // 2. Sets up a Queue for all the TG IDs to be processed
    // 3. executes the task to retrieve data for each TG IDs
    // 4. collects data for each TG ID and returns the result back to the caller.
    
    private static Logger log = LoggerFactory.getLogger(BusyHourReportDataManager.class); 
    private BusyHourSearchCriteria searchCriteria = null;
    private EnvironmentConfig environmentConfig = null;
    
    private List<BusyHourResultRow> resultList = null;
    
    private final ReentrantLock lock = new ReentrantLock();
    
    public BusyHourReportDataManager(
            BusyHourSearchCriteria searchCriteria, EnvironmentConfig environmentConfig)
    {
        this.resultList = new ArrayList<BusyHourResultRow>();
        
        this.searchCriteria = searchCriteria;
        this.environmentConfig = environmentConfig;
        
        validate();
    }
    
    private void validate()
    {
        if (!searchCriteria.isValid())
        {
            throw new RuntimeException(
                    "Search criteria does not contain the required fields.");
        }
        // validate environment config params
        if (!environmentConfig.isValid())
        {
            throw new RuntimeException(
                    "Environment Config does not contain the required fields.");
        }
    }
    
    public List<BusyHourResultRow> process()
    {
        BusyHourTrunkGroupDataRetriever command = null;
        List<String> trunkGroupIdList = getTrunkGroupIds(searchCriteria, environmentConfig);
        
        CountDownLatch countdownLatch = new CountDownLatch(trunkGroupIdList.size());
        
        // setup a Latch
        // send the requests to the ThreadPool for processing
        // once Latch has counted down to zero, return the list to the caller.
        for(String trunkGroupId : trunkGroupIdList)
        {
            command = new BusyHourTrunkGroupDataRetriever(this, trunkGroupId, countdownLatch);
            
            PooledExecutors.instance().execute(PooledExecutors.BUSY_HOUR_REPORT_EXECUTOR, command);
        }
        
        try
        {
            if(!countdownLatch.await(60L, TimeUnit.SECONDS))
            {
                throw new RuntimeException("could not complete call in 60 seconds, aborting.");
            }
        }
        catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        return resultList;
    }
    
    public void addBusyHourResultRow(BusyHourResultRow resultRow)
    {
        try
        {
            lock.lock();
            this.resultList.add(resultRow);
        }
        finally
        {
            if(lock.isHeldByCurrentThread())
            {
                lock.unlock();
            }
        }
    }

    private List<String> getTrunkGroupIds(
            BusyHourSearchCriteria searchCriteria, EnvironmentConfig environmentConfig)
    {
        List<String> trunkGroupIdList = new ArrayList<String>();
        String url = null;
        StringBuilder fqParam = null;
        JSONObject jsonObject = null;
        JSONObject jsonResponse = null;
        JSONObject jsonFacetFields = null;
        JSONArray jsonTrunkGroupIds = null;
        ClientResponse response = null;
        Client client = null;
        WebResource webResource = null;
        
        /*
         * execute the following query pattern to get trunk group Ids
         * http://kmservices-dev/DataServices/v1/Search/trunkGroupCallVolume/raw?q=*:*&
         * fq=voiceCompleteTrunkGroupIndicator:true%20AND%20customerNumber:1-dyu4p%20AND%20
         * trunkGroupUtilizationIntervalStartHour:[2014-04-11T00:00:00Z%20TO%202014-04-24T00:00:00Z]&
         * facet=true&facet.field=trunkGroupId&rows=0&facet.mincount=1&omitHeader=true
         * 
         * params 
         * q=*:* 
         * fq=voiceCompleteTrunkGroupIndicator:true AND (customerNumber:1-dyu4p) AND trunkGroupUtilizationIntervalStartHour:[2014-04-11T00:00:00Z TO 2014-04-24T00:00:00Z] 
         * facet=true
         * facet.field=trunkGroupId 
         * rows=0
         * facet.mincount=1 
         * facet.limit=1000
         */

        try
        {
            client = Client.create();
            url = environmentConfig.getKmServicesUrl() + BusyHourReportManager.KM_SERVICES_END_POINT;
            webResource = client.resource(url);
            
            // Build fq param
            fqParam = new StringBuilder();
            fqParam.append("voiceCompleteTrunkGroupIndicator:true");
            
            // add customer numbers
            if(searchCriteria.getCustomerIds() != null && 
                    !searchCriteria.getCustomerIds().isEmpty())
            {
                fqParam.append(" AND ");
                fqParam.append(QueryHelper.addCriteria("customerNumber", searchCriteria.getCustomerIds()));
            }

            // add bill account numbers
            if(searchCriteria.getBillAccountNumbers() != null &&
                    !searchCriteria.getBillAccountNumbers().isEmpty())
            {
                fqParam.append(" AND ");
                fqParam.append(QueryHelper.addCriteria("billAccountNumber", searchCriteria.getBillAccountNumbers()));
            }
            
            // add trunkGroupUtilizationIntervalStartHour
            fqParam.append(" AND trunkGroupUtilizationIntervalStartHour:[");
            fqParam.append(searchCriteria.getStartDate());
            fqParam.append(" TO ");
            fqParam.append(searchCriteria.getEndDate());
            fqParam.append("]");
            
            response =
               webResource.queryParam("q", "*:*")
                          .queryParam("fq", fqParam.toString())
                          .queryParam("facet", "true")
                          .queryParam("facet.field", "trunkGroupId")
                          .queryParam("facet.mincount", "1")
                          .queryParam("facet.limit", "1000")
                          .queryParam("rows", "0")
                          .queryParam("omitHeader", "true")
                          .accept(MediaType.APPLICATION_JSON)
                          .header("X-Level3-Application-Key", environmentConfig.getAppKey())
                          .header("X-Level3-Digest", environmentConfig.getDigest())
                          .header("X-Level3-Digest-Time", environmentConfig.getDigestTime())
                          .get(ClientResponse.class);
            
            jsonObject = new JSONObject(response.getEntity(String.class));
            
            log.debug("RESPONSE IS :\n" + jsonObject.toString(3));
            jsonResponse = jsonObject.getJSONObject("facet_counts");
            jsonFacetFields = jsonResponse.getJSONObject("facet_fields");
            jsonTrunkGroupIds = jsonFacetFields.getJSONArray("trunkGroupId");
                
            log.debug("Array count is " + jsonTrunkGroupIds.length());
            
            for(int index = 0; index < jsonTrunkGroupIds.length(); index += 2)
            {
                trunkGroupIdList.add(jsonTrunkGroupIds.optString(index));
            }
            
            log.debug("Count of TGs is " + trunkGroupIdList.size());
            for(String trunkGroupId : trunkGroupIdList)
            {
                log.debug(trunkGroupId);
            }
            
            return trunkGroupIdList;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            throw new RuntimeException("could not get trunk group Ids for input criteria.", ex);
        }
    }
    
    public BusyHourSearchCriteria getSearchCriteria()
    {
        return searchCriteria;
    }

    public EnvironmentConfig getEnvironmentConfig()
    {
        return environmentConfig;
    }
    
}
