package com.level3.km.portalsdk.impl;

import java.util.concurrent.CountDownLatch;

import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.portalsdk.BusyHourReportManager;
import com.level3.km.portalsdk.beans.BusyHourCallVolumeResultRow;
import com.level3.km.portalsdk.beans.BusyHourCallVolumeResultRow.HourlyCallVolumeStats;
import com.level3.km.portalsdk.beans.EnvironmentConfig;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class BusyHourChartTrunkGroupDataRetriever implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(BusyHourChartTrunkGroupDataRetriever.class); 
    
    private BusyHourChartDataManager chartDataManager = null;
    private String trunkGroupId = null;
    private CountDownLatch countDownLatch = null;
    
    public BusyHourChartTrunkGroupDataRetriever(
            BusyHourChartDataManager chartDataManager, String trunkGroupId, CountDownLatch countDownLatch)
    {
        this.chartDataManager = chartDataManager;
        this.trunkGroupId = trunkGroupId;
        this.countDownLatch = countDownLatch;
    }

    public void run()
    {
        // TODO Auto-generated method stub
        BusyHourCallVolumeResultRow resultRow = getBusyHourChartForTrunkGroup();
        
        this.chartDataManager.addBusyHourCallVolumeResultRow(resultRow);

        this.countDownLatch.countDown();
    }

    private BusyHourCallVolumeResultRow getBusyHourChartForTrunkGroup()
    {
        String url = null;
        StringBuilder fqParam = null;
        JSONObject jsonObject = null;
        JSONObject jsonStats = null;
        JSONObject jsonStatsFields = null;
        JSONObject jsonTrunkGroupCallQuantity = null;
        JSONObject jsonTrunkGroupCallQuantityFacets = null;
        JSONObject jsonTrunkGroupCallQuantityStatCollectionHour = null;
        ClientResponse response = null;
        Client client = null;
        WebResource webResource = null;
        BusyHourCallVolumeResultRow resultRow = null;
        HourlyCallVolumeStats hourlyStats = null;
        EnvironmentConfig environmentConfig = null; 
        
        /*
         * execute the second query per tg to get the stats for each trunk group ID
         * http://kmservices-dev/DataServices/v1/Search/trunkGroupCallVolume/raw?q=trunkGroupId:102844231&fq=voiceCompleteTrunkGroupIndicator:true%20AND%20customerNumber:1-dyu4p%20AND%20trunkGroupUtilizationIntervalStartHour:[2014-04-11T00:00:00Z%20TO%202014-04-24T00:00:00Z]&stats=true&stats.facet=statCollectionHour&stats.field=trunkGroupCallQuantity&stats.field=trunkGroupPeakUtilizationPercentage&stats.field=trunkGroupMinUtilizationPercentage&facet.mincount=1&rows=0
         * 
         * params
         * q=trunkGroupId:102844231
         * fq=voiceCompleteTrunkGroupIndicator:true%20AND%20customerNumber:1-dyu4p%20AND%20trunkGroupUtilizationIntervalStartHour:[2014-04-11T00:00:00Z%20TO%202014-04-24T00:00:00Z]
         * stats=true
         * stats.facet=statCollectionHour 
         * stats.field=trunkGroupCallQuantity
         * facet.mincount=1
         * rows=0
         */

        try
        {
            environmentConfig = this.chartDataManager.getEnvironmentConfig();
            client = Client.create();
            url = environmentConfig.getKmServicesUrl() + BusyHourReportManager.KM_SERVICES_END_POINT;
            webResource = client.resource(url);
            
            // Build fq param
            fqParam = new StringBuilder();
            fqParam.append("voiceCompleteTrunkGroupIndicator:true");
            
            // add customer numbers
            if(this.chartDataManager.getSearchCriteria().getCustomerIds() != null && 
                    !this.chartDataManager.getSearchCriteria().getCustomerIds().isEmpty())
            {
                fqParam.append(" AND ");
                fqParam.append(QueryHelper.addCriteria(
                        "customerNumber", this.chartDataManager.getSearchCriteria().getCustomerIds()));
            }

            // add bill account numbers
            if(this.chartDataManager.getSearchCriteria().getBillAccountNumbers() != null &&
                    !this.chartDataManager.getSearchCriteria().getBillAccountNumbers().isEmpty())
            {
                fqParam.append(" AND ");
                fqParam.append(QueryHelper.addCriteria(
                        "billAccountNumber", this.chartDataManager.getSearchCriteria().getBillAccountNumbers()));
            }
            
            // add trunkGroupUtilizationIntervalStartHour
            fqParam.append(" AND trunkGroupUtilizationIntervalStartHour:[");
            fqParam.append(this.chartDataManager.getSearchCriteria().getStartDate());
            fqParam.append(" TO ");
            fqParam.append(this.chartDataManager.getSearchCriteria().getEndDate());
            fqParam.append("]");
            
            response =
               webResource.queryParam("q", "trunkGroupId:" + trunkGroupId)
                          .queryParam("fq", fqParam.toString())
                          .queryParam("stats", "true")
                          .queryParam("stats.facet", "statCollectionHour")
                          .queryParam("stats.field", "trunkGroupCallQuantity")
                          .queryParam("facet.mincount", "1")
                          .queryParam("rows", "0")
                          .queryParam("omitHeader", "true")
                          .accept(MediaType.APPLICATION_JSON)
                          .header("X-Level3-Application-Key", environmentConfig.getAppKey())
                          .header("X-Level3-Digest", environmentConfig.getDigest())
                          .header("X-Level3-Digest-Time", environmentConfig.getDigestTime())
                          .get(ClientResponse.class);
            
            jsonObject = new JSONObject(response.getEntity(String.class));
            
            log.debug("RESPONSE IS:\n" + jsonObject.toString(3));
            jsonStats = jsonObject.getJSONObject("stats");
            jsonStatsFields = jsonStats.getJSONObject("stats_fields");
            
            jsonTrunkGroupCallQuantity = jsonStatsFields.optJSONObject("trunkGroupCallQuantity");
            
            if(jsonTrunkGroupCallQuantity != null)
            {
                jsonTrunkGroupCallQuantityFacets = jsonTrunkGroupCallQuantity.optJSONObject("facets");
                
                if(jsonTrunkGroupCallQuantityFacets != null)
                {
                    jsonTrunkGroupCallQuantityStatCollectionHour = jsonTrunkGroupCallQuantityFacets.optJSONObject("statCollectionHour");

                    if(jsonTrunkGroupCallQuantityStatCollectionHour != null)
                    {
                        String[] statCollectionHourArray = JSONObject.getNames(jsonTrunkGroupCallQuantityStatCollectionHour);

                        resultRow = new BusyHourCallVolumeResultRow();

                        resultRow.setTrunkGroupId(trunkGroupId);
                        for(String statCollectionHour : statCollectionHourArray)
                        {
                            hourlyStats = new HourlyCallVolumeStats();
                            hourlyStats.setInterval(statCollectionHour);

                            JSONObject callVolumeCollectioHourJson = jsonTrunkGroupCallQuantityStatCollectionHour.optJSONObject(statCollectionHour);
                            hourlyStats.setCallVolume(callVolumeCollectioHourJson.optDouble("sum"));

                            resultRow.addHourlyStats(hourlyStats);
                        }
                    }
                }
            }
            
            return resultRow;
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            throw new RuntimeException("could not get busy hour chart result for input criteria.", ex);
        }
    }
}
