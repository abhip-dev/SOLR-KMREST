package com.level3.km.portalsdk.beans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BusyHourCallVolumeResultRow
{
    private String trunkGroupId = null;
    private Map<String, HourlyCallVolumeStats> hourlyCallVolumeMap = null;
    
    public BusyHourCallVolumeResultRow()
    {
        this.hourlyCallVolumeMap = new HashMap<String, HourlyCallVolumeStats>();
    }
    
    public String getTrunkGroupId()
    {
        return trunkGroupId;
    }
    public void setTrunkGroupId(String trunkGroupId)
    {
        this.trunkGroupId = trunkGroupId;
    }
    public List<HourlyCallVolumeStats> getHourlyStatList()
    {
        List<HourlyCallVolumeStats> resultList = new ArrayList<HourlyCallVolumeStats>();
        
        if(!this.hourlyCallVolumeMap.isEmpty())
        {
            resultList.addAll(this.hourlyCallVolumeMap.values());
        }
        
        return resultList;
    }
    
    public HourlyCallVolumeStats getHourlyStat(String interval)
    {
        return this.hourlyCallVolumeMap.get(interval);
    }
    
    public void addHourlyStats(HourlyCallVolumeStats hourlyStats)
    {
        this.hourlyCallVolumeMap.put(hourlyStats.getInterval(), hourlyStats);
    }
    
    public static class HourlyCallVolumeStats
    {
        public String interval = null;
        public Double callVolume = null;
        
        public String getInterval()
        {
            return interval;
        }
        public void setInterval(String interval)
        {
            this.interval = interval;
        }
        public Double getCallVolume()
        {
            return callVolume;
        }
        public void setCallVolume(Double callVolume)
        {
            this.callVolume = callVolume;
        }
    }
}
