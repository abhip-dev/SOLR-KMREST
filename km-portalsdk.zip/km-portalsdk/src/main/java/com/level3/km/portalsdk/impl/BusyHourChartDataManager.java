package com.level3.km.portalsdk.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import com.level3.km.portalsdk.beans.BusyHourCallVolumeResultRow;
import com.level3.km.portalsdk.beans.BusyHourCallVolumeResultRow.HourlyCallVolumeStats;
import com.level3.km.portalsdk.beans.BusyHourSearchCriteria;
import com.level3.km.portalsdk.beans.EnvironmentConfig;

public class BusyHourChartDataManager
{
    private BusyHourSearchCriteria searchCriteria = null;
    private EnvironmentConfig environmentConfig = null;
    
    private List<BusyHourCallVolumeResultRow> resultList = null;
    private BusyHourCallVolumeResultRow averageResultRow = null;
    
    private final ReentrantLock lock = new ReentrantLock();
    
    public BusyHourChartDataManager(
            BusyHourSearchCriteria searchCriteria, EnvironmentConfig environmentConfig)
    {
        this.resultList = new ArrayList<BusyHourCallVolumeResultRow>();
        
        this.searchCriteria = searchCriteria;
        this.environmentConfig = environmentConfig;
        
        validate();
    }
    
    private void validate()
    {
        if (!searchCriteria.isValid())
        {
            throw new RuntimeException(
                    "Search criteria does not contain the required fields.");
        }
        if(searchCriteria.getTrunkGroupIds().isEmpty())
        {
            throw new RuntimeException("At least one trunk group ID is required.");
        }
            
        // validate environment config params
        if (!environmentConfig.isValid())
        {
            throw new RuntimeException(
                    "Environment Config does not contain the required fields.");
        }
    }
    
    public List<BusyHourCallVolumeResultRow> process()
    {
        BusyHourChartTrunkGroupDataRetriever command = null;
        
        CountDownLatch countdownLatch = new CountDownLatch(this.searchCriteria.getTrunkGroupIds().size());
        
        //  execute the query per tg to get the stats for each trunk group ID
        for(String trunkGroupId : searchCriteria.getTrunkGroupIds())
        {
            command = new BusyHourChartTrunkGroupDataRetriever(this, trunkGroupId, countdownLatch);
            
            PooledExecutors.instance().execute(PooledExecutors.BUSY_HOUR_CHART_EXECUTOR, command);
        }
            
        try
        {
            if(!countdownLatch.await(60L, TimeUnit.SECONDS))
            {
                throw new RuntimeException("could not complete call in 60 seconds, aborting.");
            }
        }
        catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        // add average row
        this.resultList.add(averageResultRow);
        
        return resultList;
    }

    public void addBusyHourCallVolumeResultRow(BusyHourCallVolumeResultRow newRow)
    {
        try
        {
            lock.lock();
            
            // IMP - order of operation is important to calculate correct average, do not add the row
            // to the resultList prior to calculating the average.
            if(newRow != null)
            {
                averageResultRow = getAverageCallVolume(newRow);
                
                resultList.add(newRow);
            }
        }
        finally
        {
            if(lock.isHeldByCurrentThread())
            {
                lock.unlock();
            }
        }
    }
    
    private BusyHourCallVolumeResultRow getAverageCallVolume(BusyHourCallVolumeResultRow newRow)
    {
        BusyHourCallVolumeResultRow tempResultRow = new BusyHourCallVolumeResultRow();
        String interval = null;
        Double avgCallVolume = null;
        HourlyCallVolumeStats tempHourlyStat = null;
        HourlyCallVolumeStats newRowHourlyStat = null;
        
        // calculate average call volume for each hour and store results in a row 
        // with trunk group ID as AVG
        tempResultRow.setTrunkGroupId("AVG");
        
        if(resultList.isEmpty())
        {
            for(HourlyCallVolumeStats hourlyStats : newRow.getHourlyStatList())
            {
                tempResultRow.addHourlyStats(hourlyStats);
            }
            return tempResultRow;
        }
        
        // calculate average for each hour and update the average

        for(HourlyCallVolumeStats avgHourlyStats : averageResultRow.getHourlyStatList())
        {
            // for each hour calculate new average
            interval = avgHourlyStats.getInterval();
            
            newRowHourlyStat = newRow.getHourlyStat(interval);

            if(newRowHourlyStat != null)
            {
                avgCallVolume =
                    ((avgHourlyStats.getCallVolume() * resultList.size()) + newRowHourlyStat.getCallVolume()) / (resultList.size() + 1);
            }
            else
            {
                avgCallVolume = avgHourlyStats.getCallVolume();
            }

            tempHourlyStat = new HourlyCallVolumeStats();
            tempHourlyStat.setInterval(interval);
            tempHourlyStat.setCallVolume(avgCallVolume);

            tempResultRow.addHourlyStats(tempHourlyStat);
        }

        return tempResultRow;
    }

    public BusyHourSearchCriteria getSearchCriteria()
    {
        return searchCriteria;
    }

    public EnvironmentConfig getEnvironmentConfig()
    {
        return environmentConfig;
    }
}
