******************* ./scripts/solr_cl_tester.sh  *******************
The program solr_cl_tester.sh is used to run multiple jmeter tests against the KM Solr Rest services.
It can currently only be run through CYGWIN or Linux.
********************************************************************


******************* HOW TO USE solr_cl_tester.sh *******************
1) Make sure you have the environment variable JMETER_HOME set to the location of your apache jmeter. solr_cl_tester.sh will use the default value
of ~/apache-jmeter-2.9 if JMETER_HOME is not set to anything.

2) Inside ./jmeter_conf/KMDataServices_Tests_to_Run.conf change the values of ENV: to whatever environment you wish to run against
and change the values of SERVICES: to whatever specific tests you wish to run.
By default every test will be run against only the dev environment.

3) $ cd ./scripts
$ ./solr_cl_tester.sh -t ../jmeter_tests/ -c ../jmeter_conf/KMDataServices_Tests.conf -r ../jmeter_conf/KMDataServices_Tests_to_Run.conf

After solr_cl_tester.sh finishes it will generate a ./scripts/Results.log file containing stats on which tests passed/failed and details
about which tests failed.
********************************************************************


********************** DIRECTORY EXPLANATIONS **********************
./jars: Holds a jar used for the jmeter test RESTResource_HealthCheckOverMediation.

./jmeter_conf: Holds 2 config files used in solr_cl_tester.sh

                KMDataServices_Tests.conf
                  This is the master config that contains details about every test that solr_cl_tester.sh can possibly run.
                  This file needs to be passed into solr_cl_tester.sh as the -c argument.
                  ONLY EDIT THIS FILE IF YOU KNOW WHAT YOU'RE DOING.

                KMDataServices_Tests_to_Run.conf
                  This is a config file listing the tests that solr_cl_tester.sh will run.
                  Edit this file to change which environment to run against and which tests to run.
                  This file needs to be passed into solr_cl_tester.sh as the -r argument.

./jmeter_tests: Contains the .jmx files for the jmeter tests that solr_cl_tester.sh can run.
                This directory needs to be passed into solr_cl_tester.sh as the -t argument.
********************************************************************
