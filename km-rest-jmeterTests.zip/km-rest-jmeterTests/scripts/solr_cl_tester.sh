#!/bin/bash
START_TIME=$(date +%s)

si=1
spinner='/-\|'
servicesEnvReplaceField="#@$%#"

#Function to explain program usage
usage () {
cat << EOF
  usage: $0 options

  required arguments:
  -t  Directory where .jmx test files are located.
  -c  Master config listing all tests that can be run.
  -r  Config file listing the tests to run. This is a subset of the Mater config.

  optional arguments:
  -h  Show this message.

  DEFAULT VALUES: -t ../jmeter_tests/ -c ../jmeter_conf/KMDataServices_Tests.conf -r ../jmeter_conf/KMDataServices_Tests_to_Run.conf
EOF
}

jmeterDir=${JMETER_HOME:-~/apache-jmeter-2.9}

# Output Logs
jmeterTestResults=JmeterTestResults.log
jmeterLog=Jmeter.log
resultFile=Results.log

testsDir=
testsConf=
testsToRun=

#Parsing command line arguments
while getopts :t::c::r:h option
do
  case "${option}" in
    h) usage
       exit 1
       ;;
    t) testsDir=${OPTARG};;
    c) testsConf=${OPTARG};;
    r) testsToRun=${OPTARG};;
    \?) echo "Invalid option: -$OPTARG"
        usage
        exit 1
        ;;
    :) echo "Option -$OPTARG requires an argument."
       usage
       exit 1
       ;;
  esac
done

#Check if no or only some command line arguments were entered
if [ -z "$testsDir" ] && [ -z "$testsConf" ] && [ -z "$testsToRun" ]; then
  echo "This program requires arguments:"
  usage
  exit
elif [ -z "$testsDir" ] || [ -z "$testsConf" ] || [ -z "$testsToRun" ]; then
  if [ -z "$testsDir" ]; then
    echo "TestsDir was not set with -t."
  fi
  if [ -z "$testsConf" ]; then
    echo "TestsConf was not set with -c."
  fi
  if [ -z "$testsToRun" ]; then
    echo "TestsToRun was not set with -r."
  fi
  usage
  exit 1
fi

#Making sure testsDir has a / at the end
numOfChars=$((${#testsDir}-1))
if [[ ${testsDir:$numOfChars:1} != "/" ]]; then
  testsDir=$testsDir/
fi

#Remove any previously created test logs
rm $jmeterTestResults
rm $resultFile

#Determine which OS the current machine is running (Currently the program will only work through Linux or CYGWIN)
uname=$(uname)
if [[ "$uname" == 'Linux' ]]; then
  jmeterCmd="$jmeterDir/bin/jmeter"
elif [[ "$uname" == *"CYGWIN"* ]]; then
  jmeterCmd="$jmeterDir/bin/jmeter.bat"
elif [[ "$uname" == *"MINGW64_NT"* ]]; then
  jmeterCmd="$jmeterDir/bin/jmeter.bat"
fi

nocomments_testsToRun=$(sed -e '/^#/d' $testsToRun)
#Parsing contents of $testsToRun into variable: services
services=$(sed -e '/^ENVS:/d' <<< "$nocomments_testsToRun" | sed -e 's/SERVICES://' | tr '\n' ',')
#Parsing contents of $testsToRun into variable: envs
envs=$(sed -e '/^SERVICES:/d' <<< "$nocomments_testsToRun" | sed -e 's/ENVS://')

#Making sure services has a , at the end. Used for appending envs to each service.
numOfChars=$((${#services}-1))
if [[ ${services:$numOfChars:1} != "," ]]; then
  services=$services,
fi
services=$(echo $services | sed -e 's/,/$servicesEnvReplaceField/g')

#Appending envs to the end of each service to be used when creating jmeter commands
combined_tests_to_run=""
IFS=$','
for e in $envs; do
  combined_tests_to_run=$combined_tests_to_run$(sed -e 's/$servicesEnvReplaceField/_'"$e"',/g' <<< $services)
done
unset IFS

#Making sure combined_tests_to_run does not have a , at the end.
numOfChars=$((${#combined_tests_to_run}-1))
if [[ ${combined_tests_to_run:$numOfChars:1} == "," ]]; then
  combined_tests_to_run=$(sed -e 's/.$//g' <<< $combined_tests_to_run)
fi

#Parsing conetents of testsConf and creating commands based on the contents of $combined_tests_to_run
echo -ne "\nCreating jmeter commands to run. This may take a few seconds.  "
nocomments_testsConf=$(sed -e '/^#/d' $testsConf)
commandsToRun=""
IFS=$','
for t in $combined_tests_to_run; do
  printf "\b${spinner:si++%${#spinner}:1}"
  cmd=$(echo "$nocomments_testsConf" | awk -v test="$t" \
  -v jmeterCmd="$jmeterCmd" \
  -v jmeterTestResults="$jmeterTestResults" \
  -v jmeterLog="$jmeterLog" \
  -v testsDir="$testsDir" \
  -F ',' \
  ' \
    $1 == test \
    {printf "\n"jmeterCmd" -n -l "jmeterTestResults" -j "jmeterLog" -t "testsDir$2" "$3} \
  ')
  if [[ ! -z "$cmd" ]]; then
    commandsToRun=$commandsToRun$cmd
  fi
done
unset IFS
echo ""

#Running the jmeter commands created in the previous step
IFS=$'\n'
for cmd in $commandsToRun; do
  echo "executing command: $cmd"
  testName=$(cut -d' ' -f8 <<< $cmd | cut -d'/' -f3 | cut -d'.' -f1)
  service=$(cut -d' ' -f9 <<< $cmd)
  echo "#$testName $service" >> $jmeterTestResults
  eval "$cmd"
done
unset IFS

#Creating the result file based on the results of the jmeter commands run
jmeterTestResultsNoComments=$(sed -e '/^#/d' "$jmeterTestResults")
jmeterTestResultsTestStatus=$(cut -d',' -f8 <<< "$jmeterTestResultsNoComments")
totalTests=$(wc -l <<< "$jmeterTestResultsNoComments")
successfulTests=$(grep -o 'true' <<< "$jmeterTestResultsTestStatus" | wc -l)
failedTests=$(grep -o 'false' <<< "$jmeterTestResultsTestStatus" | wc -l)

echo "========FAILED TESTS========" >> $resultFile
$(awk '/^#.*$/{testname=$0}/^.*$/{testresult=$0} {if(testname!=testresult) print testname","testresult}' $jmeterTestResults | \
  awk -v results="$resultFile" -F ',' '{if($9 == "false") {print $1 >> results;$1="";print >> results}}')
echo "============================" >> $resultFile
echo "==========total tests: $totalTests" >> $resultFile
echo "=====successful tests: $successfulTests" >> $resultFile
echo "=========failed tests: $failedTests" >> $resultFile

END_TIME=$(date +%s)
PROGRAM_TIME=$(expr $END_TIME - $START_TIME)
echo "program time: $PROGRAM_TIME"
