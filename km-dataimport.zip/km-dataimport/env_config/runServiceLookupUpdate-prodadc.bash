#/bin/bash

APPROOT=@@kmdi_deploy_dir@@
export APPROOT

CLASSPATH=${APPROOT}/km-dataimport.jar
export CLASSPATH

VMOPTIONS="-d64 -server"
GCOPTIONS="-XX:+UseG1GC -XX:InitiatingHeapOccupancyPercent=35 -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintFlagsFinal"
HEAPOPTIONS="-Xms256m -Xmx6144m"
SSLOPTIONS="-Djavax.net.ssl.trustStore=${APPROOT}/solr_cert.jks -Djavax.net.ssl.trustStorePassword=@@cert_store_passwd@@"

exec $JAVA_HOME/bin/java $VMOPTIONS $GCOPTIONS $HEAPOPTIONS $SSLOPTIONS com.level3.km.dataimport.servicelookup.ServiceLookupDataImporter -d "oracle.jdbc.driver.OracleDriver" -a "jdbc:oracle:thin:@ldap://oid112.idc1.level3.com:389/clarprod,cn=OracleContext,dc=level3,dc=com" -u dwiappl -p read4me -z "ddd7-01:2181,eee7-01:2181,ggg7-01:2181,iii7-01:2181,jjj7-01:2181" -c servicelookup -i id -y -b "jdbc:oracle:thin:@ldap://oid112.idc1.level3.com:389/INFPRD3,cn=OracleContext,dc=level3,dc=com" -s ICSM -w kmds_ro -q sqw_2013_kopl -e @@solr_cloud_username@@ -f @@solr_cloud_passwd@@ > ${APPROOT}/logs/servicelookupupdate-prodadc.log 2>&1&
