package com.level3.km.dataimport.config;

public class ServiceLookupDependencyCheckerConfig implements IConnectionConfig
{
    private DbConnectionConfig dbConnectionConfig = null;
    private String appNameDependency = null;
    private String dependencyName = null;

    public String getAppNameDependency()
    {
        return appNameDependency;
    }

    public void setAppNameDependency(String appNameDependency)
    {
        this.appNameDependency = appNameDependency;
    }

    public String getDependencyName()
    {
        return dependencyName;
    }

    public void setDependencyName(String dependencyName)
    {
        this.dependencyName = dependencyName;
    }

    @Override
    public DbConnectionConfig getDbConnectionConfig()
    {
        // TODO Auto-generated method stub
        return this.dbConnectionConfig;
    }

    public void setDbConnectionConfig(DbConnectionConfig dbConnectionConfig)
    {
        this.dbConnectionConfig = dbConnectionConfig;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ServiceLookupDependencyCheckerConfig [dbConnectionConfig=");
        builder.append(dbConnectionConfig);
        builder.append(", appNameDependency=");
        builder.append(appNameDependency);
        builder.append(", dependencyName=");
        builder.append(dependencyName);
        builder.append("]");
        return builder.toString();
    }
}
