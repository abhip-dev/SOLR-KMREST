package com.level3.km.dataimport.servicelookup;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.solr.common.SolrInputDocument;

public class ServiceLookupIndexer implements Runnable
{
    private ServiceLookupManager manager = null;

    private Collection<SolrInputDocument> documentList = new ArrayList<SolrInputDocument>();
    
    public ServiceLookupIndexer(ServiceLookupManager manager, Collection<SolrInputDocument> documentList) 
    {
        this.manager = manager;
        
        this.documentList = documentList;
    }


    public void run()
    {
        try
        {
            this.manager.addRecords(documentList);
        }
        finally
        {
            documentList.clear();
            
            documentList = null;
        }
    }
}
