package com.level3.km.dataimport.servicelookup;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.PropertyManager;
import com.level3.km.dataimport.db.DbConnection;

public class ServiceLookupDependencyChecker
{
    private static Logger log = LoggerFactory.getLogger(ServiceLookupDependencyChecker.class); 

    private static final int MAX_WAIT_COUNT = 50;
    
    public static boolean checkDependency()
    {
        DbConnection depCheckerConn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try
        {
            Date mydt = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String dtStr = sdf.format(mydt);

            String sqlStr = "SELECT COUNT(*) FROM " 
                    + PropertyManager.instance().getServiceLookupDependencyCheckerConfig().getDbConnectionConfig().getSchema()
                    + ".app_control_status WHERE application_name='" + PropertyManager.instance().getServiceLookupDependencyCheckerConfig().getAppNameDependency()
                    + "' AND dependency_name='" + PropertyManager.instance().getServiceLookupDependencyCheckerConfig().getDependencyName()
                    + "' AND end_dt>=to_date('" + dtStr
                    + "','yyyy-mm-dd hh24:mi:ss')-12/24 AND status_cd='Succeeded'";

            depCheckerConn = new DbConnection(PropertyManager.SLV_DEPENDENCY_CHECKER_CONFIG);
            stmt = depCheckerConn.getPreparedStatement(sqlStr);

            log.info("SQL statement: " + sqlStr);

            int total = 0, timeoutcnt = 0;
            while (total == 0)
            {
                rs = depCheckerConn.executeQuery(stmt);
                while (rs.next())
                {
                    // get total
                    total = rs.getInt(1);
                    log.info("Total record: " + total);
                }

                // timeout after looping MAX_WAIT_COUNT
                if (total == 0)
                {
                    log.info("Sleep 600 seconds");
                    Thread.sleep(600000);
                    timeoutcnt++;
                    if (timeoutcnt == MAX_WAIT_COUNT)
                    {
                        break;
                    }
                }
            }
            
            if(total > 0)
            {
                return true;
            }
            else
            {
                // send notification as well
                return false;
            }
        }
        catch (Exception e)
        {
            log.error("caught exception while checking for dependency to SUCCEED", e);
            
            // send notification as well
            return false;
        }
        finally
        {
            // cleanup
            depCheckerConn.destroy();
        }
    }
}
