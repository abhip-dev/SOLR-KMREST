package com.level3.km.dataimport.config;

public class DbConnectionConfig
{
    private String configName = null;
    private String driver = null;
    private String url = null;
    private String username = null;
    private String password = null;
    private String schema = null;
    
    public DbConnectionConfig(String name)
    {
        this.configName = name;
    }

    public String getConfigName()
    {
        return configName;
    }
    public String getDriver()
    {
        return driver;
    }
    public void setDriver(String driver)
    {
        this.driver = driver;
    }
    public String getUrl()
    {
        return url;
    }
    public void setUrl(String url)
    {
        this.url = url;
    }
    public String getUsername()
    {
        return username;
    }
    public void setUsername(String username)
    {
        this.username = username;
    }
    public String getPassword()
    {
        return password;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public String getSchema()
    {
        return schema;
    }

    public void setSchema(String schema)
    {
        this.schema = schema;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("DbConnectionConfig [configName=");
        builder.append(configName);
        builder.append(", driver=");
        builder.append(driver);
        builder.append(", url=");
        builder.append(url);
        builder.append(", username=");
        builder.append(username);
        builder.append(", password=");
        builder.append(password);
        builder.append(", schema=");
        builder.append(schema);
        builder.append("]");
        return builder.toString();
    }
}
