package com.level3.km.dataimport.servicelookup;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import javax.ws.rs.core.Response;

import org.apache.commons.io.FileUtils;
import org.apache.solr.client.solrj.impl.BinaryRequestWriter;
import org.apache.solr.client.solrj.impl.BinaryResponseParser;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.request.UpdateRequest;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.cloud.SolrZkClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.PropertyManager;
import com.level3.km.dataimport.config.ServiceLookupConfig;
import com.level3.km.dataimport.notify.Notify;
import com.level3.km.dataimport.resource.IDataImport;
import com.level3.km.dataimport.thread.PooledExecutors;
import com.sun.jersey.spi.resource.Singleton;

@Singleton
public class ServiceLookupManager implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(ServiceLookupManager.class); 

    static DateFormat df = null;
	private static final String SOLJ_DATE_FMT = "yyyy-MM-dd'T'HH:mm:ss'Z'" ; 

    public static final String SLV_DATA_READER = "slvDataReader";
    public static final String SLV_INDEXER = "slvIndexer";
    private static final String SLV_CRITERIA_1 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT = 'Business POTS'";
    private static final String SLV_CRITERIA_2 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT = 'Centrex On-Switch Analog'";
//    private static final String SLV_CRITERIA_3 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT = 'ISDN-PRI'";
    private static final String SLV_CRITERIA_3 = "WHERE slv.SOURCE_SYS_NM IN('CPO', 'SWIFT')";
    private static final String SLV_CRITERIA_4 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT NOT IN('Business POTS', 'Centrex On-Switch Analog')";
    private static final String SLV_CRITERIA_5 = "WHERE slv.SOURCE_SYS_NM = 'EON'";
    private static final String SLV_CRITERIA_6 = "WHERE slv.SOURCE_SYS_NM = 'SIEBEL'";
    private static final String SLV_CRITERIA_7 = "WHERE slv.SOURCE_SYS_NM = 'SIEBEL6_LATAM'";
    private static final String SLV_CRITERIA_8 = "WHERE slv.SOURCE_SYS_NM = 'PIPELINE'";
    private static final String SLV_CRITERIA_9 = "WHERE slv.SOURCE_SYS_NM = 'REMEDY_TELCOVE'";
//    private static final String SLV_CRITERIA_10 = "WHERE slv.SOURCE_SYS_NM NOT IN('OEOM_TELCOVE', 'EON', 'SIEBEL', 'SIEBEL6_LATAM', 'PIPELINE', 'REMEDY_TELCOVE')";
    private static final String SLV_CRITERIA_10 = "WHERE slv.SOURCE_SYS_NM NOT IN('OEOM_TELCOVE', 'EON', 'SIEBEL', 'SIEBEL6_LATAM', 'PIPELINE', 'REMEDY_TELCOVE', 'CPO', 'SWIFT')";
    private static final String DATAIMPORT_JSON_ZK_PATH_PREFIX = "/dataimport/";
    private static final String DATAIMPORT_JSON_ZK_PATH_SUFFIX = "dataimport.properties";
    private static final String DATAIMPORT_STATUS_ZK_PATH_PREFIX = "/dataimport/";
    private static final String DATAIMPORT_STATUS_ZK_PATH_SUFFIX = "status.json";

    private String dataImportJsonZKPath = null;
    private String dataImportStatusZKPath = null;
    private CloudSolrClient solrClient = null;
    private SolrZkClient solrZkClient = null;
    private CountDownLatch countdownLatch = null;
    private AtomicBoolean isBusy = null;
    private AtomicBoolean isSuccess = null;
    
    private String documentUpdateDate = null;
    
    private AtomicLong recordCounter = null;
    private Date processStartTime = null;
    private Date processStopTime = null;
    private ScheduledExecutorService statusPool = null;
    
    private BlockingQueue<Runnable> indexerQueue = new ArrayBlockingQueue<Runnable>(10);
    
    private ServiceLookupConfig config = null;
    
    private DataImportStatus status = null;
    
    private IDataImport dataImportProcessor = null;
    
    private ServiceRelationShipManager relationShipManager = null;

    static
    {
        TimeZone tz = TimeZone.getTimeZone("UTC");
        df = new SimpleDateFormat(SOLJ_DATE_FMT);
        df.setTimeZone(tz);
    }

    public ServiceLookupManager(ServiceLookupConfig config, IDataImport dataImportProcessor)
    {
        this.config = config;
        this.dataImportProcessor = dataImportProcessor;

        init();
    }
    
    private void init()
    {
        documentUpdateDate = df.format(new Date());
        log.info("Document Update Date: {}", documentUpdateDate);
        
        dataImportJsonZKPath = DATAIMPORT_JSON_ZK_PATH_PREFIX + config.getCollectionName() + "/" + DATAIMPORT_JSON_ZK_PATH_SUFFIX;
        dataImportStatusZKPath = DATAIMPORT_STATUS_ZK_PATH_PREFIX + config.getCollectionName() + "/" + DATAIMPORT_STATUS_ZK_PATH_SUFFIX;

        this.processStartTime = new Date();
        this.isBusy = new AtomicBoolean(true);
        this.isSuccess = new AtomicBoolean(true);
        
        solrZkClient = new SolrZkClient(config.getZkHost(), 1000);

        recordCounter = new AtomicLong(0L);

        // instantiate a ThreadPool executor for loading slv data
        PooledExecutors.instance().createThreadPool(SLV_DATA_READER, 10, 10, 60L, TimeUnit.SECONDS);
        // instantiate a ThreadPool executor for indexing SLV data into SOLR
        PooledExecutors.instance().createThreadPool(SLV_INDEXER, 10, 10, 60L, TimeUnit.SECONDS, indexerQueue);
        
        // setup Status object, statusPool should be setup once Status object has been instantiated
        status = new DataImportStatus();
        status.setStartTime(this.processStartTime);
        status.setStopTime(processStopTime == null ? new Date() : processStopTime);
        status.setRecordsProcessed(this.recordCounter.get());
        status.setIsBusy(this.isBusy.get());

        // now setup statusPool to report on status every min
        statusPool = Executors.newSingleThreadScheduledExecutor();
        
        statusPool.scheduleAtFixedRate(new StatusReporterTask(this), 0, 60, TimeUnit.SECONDS);
    }
    
    private void setUpSolrCloudClient()
    {
        solrClient = new CloudSolrClient.Builder().withZkHost(config.getZkHostAsList()).sendDirectUpdatesToShardLeadersOnly().withParallelUpdates(true).build();

        solrClient.setDefaultCollection(config.getCollectionName());
        solrClient.setIdField(config.getCollectionIdField());
        solrClient.setZkClientTimeout(1000);
        solrClient.setZkConnectTimeout(1000);
        solrClient.setParser(new BinaryResponseParser());
        solrClient.setRequestWriter(new BinaryRequestWriter());
    }
    
    public DataImportStatus status()
    {
        status.setStopTime(processStopTime == null ? new Date() : processStopTime);
        status.setRecordsProcessed(this.recordCounter.get());
        status.setIsBusy(this.isBusy.get());
        
        if(isBusy.get() == Boolean.FALSE)
        {
            status.setSuccess(this.isSuccess.get());
        }
        
        return status;
    }
    
    public void run()
    {
        process();
    }

    public DataImportStatus cancelUpdate()
    {
        updateFailure();
        
        return status();
    }
    
    private void process()
    {
        int commandCount = 0;
        ServiceLookupDataReader command1 = null;
        ServiceLookupDataReader command2 = null;
        ServiceLookupDataReader command3 = null;
        ServiceLookupDataReader command4 = null;
        ServiceLookupDataReader command5 = null;
        ServiceLookupDataReader command6 = null;
        ServiceLookupDataReader command7 = null;
        ServiceLookupDataReader command8 = null;
        ServiceLookupDataReader command9 = null;
        ServiceLookupDataReader command10 = null;
        
        relationShipManager = new ServiceRelationShipManager();
        
        relationShipManager.process();

        setUpSolrCloudClient();
        
        // query and delete old records
        deleteOldRecords();
        
        // setup a Latch
        // send the requests to the ThreadPool for processing
        // once Latch has counted down to zero, we are ready to load SLV data
        log.info("Starting indexing of Service lookup data in SOLR.");
        
        command1 = new ServiceLookupDataReader(SLV_CRITERIA_1, this);
        commandCount++;

        command2 = new ServiceLookupDataReader(SLV_CRITERIA_2, this);
        commandCount++;
            
        command3 = new ServiceLookupDataReader(SLV_CRITERIA_3, this);
        commandCount++;
            
        command4 = new ServiceLookupDataReader(SLV_CRITERIA_4, this);
        commandCount++;
            
        command5 = new ServiceLookupDataReader(SLV_CRITERIA_5, this);
        commandCount++;
            
        command6 = new ServiceLookupDataReader(SLV_CRITERIA_6, this);
        commandCount++;
            
        command7 = new ServiceLookupDataReader(SLV_CRITERIA_7, this);
        commandCount++;
            
        command8 = new ServiceLookupDataReader(SLV_CRITERIA_8, this);
        commandCount++;
            
        command9 = new ServiceLookupDataReader(SLV_CRITERIA_9, this);
        commandCount++;
            
        command10 = new ServiceLookupDataReader(SLV_CRITERIA_10, this);
        commandCount++;
            
        countdownLatch = new CountDownLatch(commandCount);

        PooledExecutors.instance().execute(SLV_DATA_READER, command1);
        PooledExecutors.instance().execute(SLV_DATA_READER, command2);
        PooledExecutors.instance().execute(SLV_DATA_READER, command3);
        PooledExecutors.instance().execute(SLV_DATA_READER, command4);
        PooledExecutors.instance().execute(SLV_DATA_READER, command5);
        PooledExecutors.instance().execute(SLV_DATA_READER, command6);
        PooledExecutors.instance().execute(SLV_DATA_READER, command7);
        PooledExecutors.instance().execute(SLV_DATA_READER, command8);
        PooledExecutors.instance().execute(SLV_DATA_READER, command9);
        PooledExecutors.instance().execute(SLV_DATA_READER, command10);

        try
        {
            if(!countdownLatch.await(90L, TimeUnit.MINUTES))
            {
                updateFailure();
                throw new RuntimeException("could not complete call in 90 minutes, aborting.");
            }
            
            // this should take place after all the jobs in SLV_INDEXER pool have finished.
            PooledExecutors.instance().shutdown(SLV_INDEXER);
            commit();
            
            // update properties in ZK
            updateDataImportProperties();
        }
        catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally
        {
            cleanup(false);
        }
    }
    
    public synchronized void countLatchDown()
    {
        countdownLatch.countDown();
    }
    
    private long addToRecordCounter(long countOfRecords)
    {
        return recordCounter.addAndGet(countOfRecords);
    }
    
    public String getDocumentUpdateDate()
    {
        return documentUpdateDate;
    }
    
    public void addRecords(Collection<SolrInputDocument> documentList)
    {
        try
        {
            addToRecordCounter(documentList.size());
            
            UpdateRequest updateRequest = new UpdateRequest();
            updateRequest.setBasicAuthCredentials(config.getSolrCloudUsername(), config.getSolrCloudPassword());
            updateRequest.add(documentList);

            UpdateResponse response = updateRequest.process(solrClient);
            
            if(response.getStatus() != 0)
            {
                log.info("Some horrible error has occurred, status is: " + response.getStatus());
            }
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to add records to Solr index.", ex);
            
            for(SolrInputDocument inputDocument : documentList)
            {
                log.info("Document list for batch that had error\nID :{}, content : {}", inputDocument.getFieldValue("id"), inputDocument.toString());
            }
            
            // stop the process or mark run as failure
            updateFailure();
        }
        finally
        {
            documentList.clear();
        }
    }
    
    private void deleteOldRecords()
    {
        String query = "*:*";
        
        try
        {
            log.info("Issuing query to delete old records: {}", query);

            UpdateRequest updateRequest = new UpdateRequest();
            updateRequest.setBasicAuthCredentials(config.getSolrCloudUsername(), config.getSolrCloudPassword());
            updateRequest.deleteByQuery(query);

            UpdateResponse response = updateRequest.process(solrClient);
            
            if(response.getStatus() != 0)
            {
                log.info("Failed to delete old records.");
            }
            
            log.info("DELETE RESPONSE - {}", response);
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to delete old records from Solr index.", ex);
        }
    }
    
    private void commit()
    {
        try
        {
            UpdateRequest updateRequest = new UpdateRequest();
            updateRequest.setBasicAuthCredentials(config.getSolrCloudUsername(), config.getSolrCloudPassword());
            
            UpdateResponse response = updateRequest.commit(solrClient, config.getCollectionName());
            
            if(response.getStatus() != 0)
            {
                log.info("Failed to commit records to Solr.");
            }
            
            log.info("COMMIT RESPONSE - {}", response);
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to commit records to Solr index.", ex);
        }
    }
    
    private void updateDataImportProperties()
    {
        File file = null;
        
        try
        {
            file = new File("dataimport.properties");
            FileUtils.writeStringToFile(file, "last_index_time=" + getDocumentUpdateDate(), "UTF-8");
            
            if(solrZkClient.exists(dataImportJsonZKPath, true))
            {
                solrZkClient.setData(dataImportJsonZKPath, file, true);
            }
            else
            {
                log.info("{} path not found in ZK {}", dataImportJsonZKPath, config.getZkHost());
                solrZkClient.makePath(dataImportJsonZKPath, file, true);
            }
            
            FileUtils.deleteQuietly(file);
        }
        catch (Exception ex)
        {
            log.error("caught exception while trying to update dataimport.json in ZooKeeper", ex);
        }
    }
    
    public void updateDataImportProperties(String status)
    {
        try
        {
            if(solrZkClient.exists(dataImportStatusZKPath, true))
            {
                solrZkClient.setData(dataImportStatusZKPath, status.getBytes("UTF-8"), true);
            }
            else
            {
                log.info("{} path not found in ZK {}", dataImportStatusZKPath, config.getZkHost());
                solrZkClient.makePath(dataImportStatusZKPath, status.getBytes("UTF-8"), true);
            }
        }
        catch (Exception ex)
        {
            log.error("caught exception while trying to update {} in ZooKeeper", dataImportStatusZKPath, ex);
        }
    }
    
    public void updateFailure()
    {
        log.info("Data update failed, shuting down.");
        
        cleanup(true);
        
        // notify dev team a failure has occured
        Notify.sendFailureNotification(config.getZkHost(), config.getCollectionName());
    }

    private void cleanup(boolean rollBackTransaction)
    {
        this.processStopTime = new Date();
        this.isBusy.set(false);
        
        if(rollBackTransaction)
        {
            this.isSuccess.set(false);
        }

        statusPool.execute(new StatusReporterTask(this));
        
        relationShipManager.updateFailure();

        PooledExecutors.instance().shutdown(SLV_DATA_READER);
        PooledExecutors.instance().shutdown(SLV_INDEXER);

        statusPool.shutdown();
        
        try
        {
            if(!statusPool.awaitTermination(30, TimeUnit.SECONDS))
            {
                statusPool.shutdownNow();
            }
        }
        catch (InterruptedException ie)
        {

        }

        if(rollBackTransaction)
        {
            try
            {
                UpdateRequest updateRequest = new UpdateRequest();
                updateRequest.setBasicAuthCredentials(config.getSolrCloudUsername(), config.getSolrCloudPassword());
            
                updateRequest.rollback();
            }
            catch (Exception ex)
            {
                log.error("caught exception while trying to rollback records to Solr index.", ex);
            }
        }

        this.dataImportProcessor.finishDataImport();

        try
        {
            solrZkClient.close();
            solrClient.close();
        }
        catch (IOException e)
        {

        }
    }

    public static void main(String[] args)
    {
        try
        {
            log.info("Starting indexing of Service lookup data.");

            ServiceLookupManager manager = new ServiceLookupManager(PropertyManager.instance().getServiceLookupConfig(), new IDataImport()
                    {

                        @Override
                        public Response dataimport()
                        {
                            // TODO Auto-generated method stub
                            return null;
                        }

                        @Override
                        public void finishDataImport()
                        {
                            // TODO Auto-generated method stub
                            
                        }
                        
                    });
            
            manager.process();

            log.info("Completed indexing of service lookup data.");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            log.error("caught exception while trying to index service lookup data.", ex);
        }
        finally
        {
            System.exit(0);
        }
    }
}
