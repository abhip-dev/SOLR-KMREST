package com.level3.km.dataimport.config;

public class CustomerBillAccountNumberConfig 
{
    private String zkHost = null;
    private String collectionName = null;
    private String collectionIdField = null;

    public String getZkHost()
    {
        return zkHost;
    }
    public void setZkHost(String zkHost)
    {
        this.zkHost = zkHost;
    }
    public String getCollectionName()
    {
        return collectionName;
    }
    public void setCollectionName(String collectionName)
    {
        this.collectionName = collectionName;
    }
    public String getCollectionIdField()
    {
        return collectionIdField;
    }
    public void setCollectionIdField(String collectionIdField)
    {
        this.collectionIdField = collectionIdField;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("CustomerBillAccountNumberConfig [zkHost=");
        builder.append(zkHost);
        builder.append(", collectionName=");
        builder.append(collectionName);
        builder.append(", collectionIdField=");
        builder.append(collectionIdField);
        builder.append("]");
        return builder.toString();
    }
}
