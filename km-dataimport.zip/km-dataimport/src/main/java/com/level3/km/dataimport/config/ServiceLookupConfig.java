package com.level3.km.dataimport.config;

import java.util.Arrays;
import java.util.List;

public class ServiceLookupConfig implements IConnectionConfig
{
    private DbConnectionConfig dbConnectionConfig = null;
    
    public DbConnectionConfig getDbConnectionConfig()
    {
        return dbConnectionConfig;
    }
    public void setDbConnectionConfig(DbConnectionConfig dbConnectionConfig)
    {
        this.dbConnectionConfig = dbConnectionConfig;
    }
    
    private String zkHost = null;
    private List<String> zkHostList = null;
    private String collectionName = null;
    private String collectionIdField = null;
    private String solrCloudUsername = null;
    private String solrCloudPassword = null;

    public List<String> getZkHostAsList()
    {
        return zkHostList;
    }
    public String getZkHost()
    {
        return zkHost;
    }
    public void setZkHost(String zkHost)
    {
        this.zkHost = zkHost;

        this.zkHostList = Arrays.asList(zkHost.split(","));
    }
    public String getCollectionName()
    {
        return collectionName;
    }
    public void setCollectionName(String collectionName)
    {
        this.collectionName = collectionName;
    }
    public String getCollectionIdField()
    {
        return collectionIdField;
    }
    public void setCollectionIdField(String collectionIdField)
    {
        this.collectionIdField = collectionIdField;
    }
    public String getSolrCloudUsername()
    {
        return solrCloudUsername;
    }
    public void setSolrCloudUsername(String solrCloudUsername)
    {
        this.solrCloudUsername = solrCloudUsername;
    }
    public String getSolrCloudPassword()
    {
        return solrCloudPassword;
    }
    public void setSolrCloudPassword(String solrCloudPassword)
    {
        this.solrCloudPassword = solrCloudPassword;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ServiceLookupConfig [dbConnectionConfig=");
        builder.append(dbConnectionConfig);
        builder.append(", zkHost=");
        builder.append(zkHost);
        builder.append(", collectionName=");
        builder.append(collectionName);
        builder.append(", collectionIdField=");
        builder.append(collectionIdField);
        builder.append(", solrCloudUsername=");
        builder.append(solrCloudUsername);
        builder.append(", solrCloudPassword=");
        builder.append(solrCloudPassword);
        builder.append("]");
        return builder.toString();
    }
}
