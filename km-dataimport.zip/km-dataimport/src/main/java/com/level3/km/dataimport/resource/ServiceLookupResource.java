package com.level3.km.dataimport.resource;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.PropertyManager;
import com.level3.km.dataimport.servicelookup.DataImportStatus;
import com.level3.km.dataimport.servicelookup.ServiceLookupManager;
import com.level3.km.dataimport.thread.PooledExecutors;
import com.sun.jersey.spi.resource.Singleton;

@Singleton
@Path("/DataImport/serviceLookup")
public class ServiceLookupResource implements IDataImport
{
    @Context
    protected UriInfo uriInfo;
    
    @Context
    protected Request request;
    
    @Context
    protected HttpHeaders httpHeaders;
    
    private static Logger log = LoggerFactory.getLogger(ServiceLookupResource.class); 
    
    private static final String COMMAND_STR = "command";
    private static final String IMPORT_COMMAND_STR = "import";
    private static final String ABORT_COMMAND_STR = "abort";
    private static final String STATUS_COMMAND_STR = "status";
    public static final String SERVICE_LOOKUP_MANAGER_EXECUTOR = "serviceLookupManagerExecutor";
    
    private ReentrantLock lock = new ReentrantLock();
    private AtomicBoolean isBusy = new AtomicBoolean(Boolean.FALSE);
    private ServiceLookupManager serviceLookupManager = null;
    
    static
    {
        PooledExecutors.instance().createSingleThreadExecutor(SERVICE_LOOKUP_MANAGER_EXECUTOR);
    }
    
    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response dataimport()
    {
        Response response = null;
        
        // get the command from the params
        // command = import, abort, status
        // For import
        // check if a dataimport is already in progress, 
        // if yes then reject the request with a message
        // else, instantiate a ServiceLookupManager and call process(), return last known status
        // For abort
        // check if a dataimport is already in progress, if yes, abort
        // else ignore and inform with a message
        // For status
        // check if an import is in progress, if yes, get the status from import
        // else return the old status
        MultivaluedMap<String, String> queryParams = uriInfo.getQueryParameters();
        
        String command = getCommand(queryParams);
        
        try
        {
            
        // synchronous response
        if(STATUS_COMMAND_STR.equals(command))
        {
            if(isBusy.get() && serviceLookupManager != null)
            {
                return buildResponse(Status.OK, serviceLookupManager.status());
            }
            else
            {
                return buildResponse(Status.OK, new DataImportStatus());
            }
        }
        
        // synchronous response
        if(ABORT_COMMAND_STR.equals(command))
        {
            // if not busy, that means there is nothing to abort, just return the status
            if(isBusy.get() && serviceLookupManager != null)
            {
                lock.lock();

                DataImportStatus statusNow = serviceLookupManager.cancelUpdate();
                
                return buildResponse(Status.OK, statusNow);
            }
            else
            {
                return buildResponse(Status.OK, new DataImportStatus());
            }
        }
        
        // asynchronous processing
        if(IMPORT_COMMAND_STR.equals(command))
        {
            if(isBusy.get() && serviceLookupManager != null)
            {
                return buildResponse(Status.OK, serviceLookupManager.status());
            }
            
            lock.lock();
            if(isBusy.get() && serviceLookupManager != null)
            {
                return buildResponse(Status.OK, serviceLookupManager.status());
            }
            
            isBusy.set(true);
            this.serviceLookupManager = new ServiceLookupManager(PropertyManager.instance().getServiceLookupConfig(), this);
            
            PooledExecutors.instance().execute(SERVICE_LOOKUP_MANAGER_EXECUTOR, this.serviceLookupManager);

            return buildResponse(Status.OK, this.serviceLookupManager.status());
        }
        }
        finally
        {
            if(lock.isHeldByCurrentThread())
            {
                lock.unlock();
            }
        }

        return response;
    }
    
    private String getCommand(MultivaluedMap<String, String> params)
    {
        List<String> rowList = params.get(COMMAND_STR);
        
        if(rowList == null)
        {
            return STATUS_COMMAND_STR;
        }
        
        if(rowList.size() == 1)
        {
            String command = rowList.get(0);
            
            if(command == null)
            {
                throw new RuntimeException("Command not found.");
            }
            
            if(IMPORT_COMMAND_STR.equals(command))
            {
                return IMPORT_COMMAND_STR;
            }
            else if(ABORT_COMMAND_STR.equals(command))
            {
                return ABORT_COMMAND_STR;
            }
            else if(STATUS_COMMAND_STR.equals(command))
            {
                return STATUS_COMMAND_STR;
            }
            else
            {
                // TODO
//                throw new WebApplicationException("Command not found.");
                throw new WebApplicationException();
            }
        }
        else
        {
                // TODO
//                throw new WebApplicationException("multiple commands found, ignoring.");
                throw new WebApplicationException();
        }
    }
    
    private Response buildResponse(Status responseStatus, DataImportStatus diStatus)
    {
        return Response.status(responseStatus).entity(diStatus).build();
    }

    @Override
    public void finishDataImport()
    {
        try
        {
            if(isBusy.get() && this.serviceLookupManager != null)
            {
                lock.lock();

                this.serviceLookupManager = null;

                this.isBusy.set(false);
            }
        }
        finally
        {
            if(lock.isHeldByCurrentThread())
            {
                lock.unlock();
            }
        }
    }
}
