package com.level3.km.dataimport.servicelookup;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.thread.PooledExecutors;

public class ServiceRelationShipManager
{
    private static Logger log = LoggerFactory.getLogger(ServiceRelationShipManager.class); 
    
    private static Map<String, List<String>> relatedSidLevel1 = new HashMap<String, List<String>>();
    private static Map<String, List<String>> relatedSidLevel2 = new HashMap<String, List<String>>();
    private static Map<String, List<String>> relatedSidLevel3 = new HashMap<String, List<String>>();
    private static Map<String, List<String>> relatedSidLevel4 = new HashMap<String, List<String>>();
    private static Map<String, List<String>> relatedSidLevel5 = new HashMap<String, List<String>>();
    
    public static final String RELATED_SID_EXECUTOR = "relatedSidExecutor";
    private static final String RELATED_SID_LEVEL_1_CRITERIA = " WHERE SR.RELATIONSHIP_LEVEL = 1";
    private static final String RELATED_SID_LEVEL_2_CRITERIA = " WHERE SR.RELATIONSHIP_LEVEL = 2";
    private static final String RELATED_SID_LEVEL_3_CRITERIA = " WHERE SR.RELATIONSHIP_LEVEL = 3";
    private static final String RELATED_SID_LEVEL_4_CRITERIA = " WHERE SR.RELATIONSHIP_LEVEL = 4";
    private static final String RELATED_SID_LEVEL_5_CRITERIA = " WHERE SR.RELATIONSHIP_LEVEL = 5";

    private CountDownLatch countdownLatch = null;
    
    public ServiceRelationShipManager()
    {
        // instantiate a ThreadPool executor for loading related sid map
        PooledExecutors.instance().createThreadPool(RELATED_SID_EXECUTOR, 5, 5, 60L, TimeUnit.SECONDS); 
    }

    public void process()
    {
        int counter = 0;
        ServiceRelationShipDataReader command1 = null;
        ServiceRelationShipDataReader command2 = null;
        ServiceRelationShipDataReader command3 = null;
        ServiceRelationShipDataReader command4 = null;
        ServiceRelationShipDataReader command5 = null;
        
        // setup a Latch
        // send the requests to the ThreadPool for processing
        // once Latch has counted down to zero, we are ready to load SLV data
        command1 = new ServiceRelationShipDataReader(RELATED_SID_LEVEL_1_CRITERIA, this, relatedSidLevel1);
        counter++;
        
        command2 = new ServiceRelationShipDataReader(RELATED_SID_LEVEL_2_CRITERIA, this, relatedSidLevel2);
        counter++;
            
        command3 = new ServiceRelationShipDataReader(RELATED_SID_LEVEL_3_CRITERIA, this, relatedSidLevel3);
        counter++;
            
        command4 = new ServiceRelationShipDataReader(RELATED_SID_LEVEL_4_CRITERIA, this, relatedSidLevel4);
        counter++;
            
        command5 = new ServiceRelationShipDataReader(RELATED_SID_LEVEL_5_CRITERIA, this, relatedSidLevel5);
        counter++;
            
        countdownLatch = new CountDownLatch(counter);
        
        PooledExecutors.instance().execute(RELATED_SID_EXECUTOR, command1);
        PooledExecutors.instance().execute(RELATED_SID_EXECUTOR, command2);
        PooledExecutors.instance().execute(RELATED_SID_EXECUTOR, command3);
        PooledExecutors.instance().execute(RELATED_SID_EXECUTOR, command4);
        PooledExecutors.instance().execute(RELATED_SID_EXECUTOR, command5);
        
        try
        {
            if(!countdownLatch.await(30L, TimeUnit.MINUTES))
            {
                throw new RuntimeException("could not complete call in 30 minutes, aborting.");
            }

            log.info("FINAL COUNT !!! filter criteria \"{}\", number of SIDs :{}", RELATED_SID_LEVEL_1_CRITERIA, relatedSidLevel1.size());
            log.info("FINAL COUNT !!! filter criteria \"{}\", number of SIDs :{}", RELATED_SID_LEVEL_2_CRITERIA, relatedSidLevel2.size());
            log.info("FINAL COUNT !!! filter criteria \"{}\", number of SIDs :{}", RELATED_SID_LEVEL_3_CRITERIA, relatedSidLevel3.size());
            log.info("FINAL COUNT !!! filter criteria \"{}\", number of SIDs :{}", RELATED_SID_LEVEL_4_CRITERIA, relatedSidLevel4.size());
            log.info("FINAL COUNT !!! filter criteria \"{}\", number of SIDs :{}", RELATED_SID_LEVEL_5_CRITERIA, relatedSidLevel5.size());
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        finally
        {
            PooledExecutors.instance().shutdown(RELATED_SID_EXECUTOR);
        }
    }
    
    public synchronized void countLatchDown()
    {
        countdownLatch.countDown();
    }
    
    public void updateFailure()
    {
        PooledExecutors.instance().shutdown(RELATED_SID_EXECUTOR);
    }

    public static List<String> getRelatedSidLevel1(String sid)
    {
        return relatedSidLevel1.get(sid);
    }
    
    public static List<String> getRelatedSidLevel2(String sid)
    {
        return relatedSidLevel2.get(sid);
    }
    
    public static List<String> getRelatedSidLevel3(String sid)
    {
        return relatedSidLevel3.get(sid);
    }
    
    public static List<String> getRelatedSidLevel4(String sid)
    {
        return relatedSidLevel4.get(sid);
    }
    
    public static List<String> getRelatedSidLevel5(String sid)
    {
        return relatedSidLevel5.get(sid);
    }
    
    public static void main(String[] args)
    {
        log.info("Starting indexing of Service relationship data.");
        try
        {
            ServiceRelationShipManager manager = new ServiceRelationShipManager();
            
            manager.process();
            
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            log.error("caught exception while trying to index service relationship data.", ex);
        }
        
        log.info("Completed indexing of service relationship data.");
    }
}
