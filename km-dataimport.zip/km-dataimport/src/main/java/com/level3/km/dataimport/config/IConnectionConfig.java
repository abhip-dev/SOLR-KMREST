package com.level3.km.dataimport.config;

public interface IConnectionConfig
{
    public DbConnectionConfig getDbConnectionConfig();
}
