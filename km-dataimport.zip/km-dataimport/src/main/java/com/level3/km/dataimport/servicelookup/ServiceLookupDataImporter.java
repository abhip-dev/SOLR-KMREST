package com.level3.km.dataimport.servicelookup;

import javax.ws.rs.core.Response;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.DbConnectionConfig;
import com.level3.km.dataimport.config.PropertyManager;
import com.level3.km.dataimport.config.ServiceLookupConfig;
import com.level3.km.dataimport.config.ServiceLookupDependencyCheckerConfig;
import com.level3.km.dataimport.config.ServiceRelationShipConfig;
import com.level3.km.dataimport.resource.IDataImport;

public class ServiceLookupDataImporter implements IDataImport
{
    private static Logger log = LoggerFactory.getLogger(ServiceLookupDataImporter.class); 

    private static CommandLine commandLine     = null;
    private String[]           commandLineArgs = null;
    private Options            options         = null;
    
    private static final String DB_URL_CHAR = "a";
    private static final String DB_URL_STRING = "dbUrl";
    
    private static final String DEP_DB_URL_CHAR = "b";
    private static final String DEP_DB_URL_STRING = "depDbUrl";
    
    private static final String SOLR_COLLECTION_CHAR = "c";
    private static final String SOLR_COLLECTION_STRING = "solrCollection";
    
    private static final String DB_DRIVER_CHAR = "d";
    private static final String DB_DRIVER_STRING = "dbDriver";
    
    private static final String SOLR_CLOUD_USERNAME_CHAR = "e";
    private static final String SOLR_CLOUD_USERNAME_STRING = "solrCloudUserName";
    
    private static final String SOLR_CLOUD_PASSWORD_CHAR = "f";
    private static final String SOLR_CLOUD_PASSWORD_STRING = "solrCloudPassword";
    
    private static final String SOLR_COLLECTION_ID_CHAR = "i";
    private static final String SOLR_COLLECTION_ID_STRING = "solrCollectionIdField";

    private static final String PASSWORD_CHAR = "p";
    private static final String PASSWORD_STRING = "password";
    
    private static final String DEP_PASSWORD_CHAR = "q";
    private static final String DEP_PASSWORD_STRING = "depPassword";
    
    private static final String DEP_SCHEMA_CHAR = "s";
    private static final String DEP_SCHEMA_STRING = "depSchema";
    
    private static final String USERNAME_CHAR = "u";
    private static final String USERNAME_STRING = "userName";
    
    private static final String DEP_USERNAME_CHAR = "w";
    private static final String DEP_USERNAME_STRING = "depUserName";
    
    private static final String CHECK_DEPENDENCY_CHAR = "y";
    private static final String CHECK_DEPENDENCY_STRING = "checkDependency";
    
    private static final String ZK_HOST_CHAR = "z";
    private static final String ZK_HOST_STRING = "zkHost";
    
    public ServiceLookupDataImporter(String[] args)
    {
        this.commandLineArgs = args;
        this.options = new Options();
        processCommandLine();
    }
    
    public Response dataimport()
    {
        String dbDriver = commandLine.getOptionValue(DB_DRIVER_CHAR); 
        String dbUrl = commandLine.getOptionValue(DB_URL_CHAR); 
        String dbUserName = commandLine.getOptionValue(USERNAME_CHAR); 
        String dbPassword = commandLine.getOptionValue(PASSWORD_CHAR); 

        String zkHost = commandLine.getOptionValue(ZK_HOST_CHAR); 
        String solrCollectionName = commandLine.getOptionValue(SOLR_COLLECTION_CHAR); 
        String solrCollectionId = commandLine.getOptionValue(SOLR_COLLECTION_ID_CHAR); 
        String solrCloudUserName = commandLine.getOptionValue(SOLR_CLOUD_USERNAME_CHAR); 
        String solrCloudPassword = commandLine.getOptionValue(SOLR_CLOUD_PASSWORD_CHAR); 
        
        String depDbUrl = null;
        String depDbUserName = null;
        String depDbPassword = null;
        String depDbSchema = null;
        boolean checkDependency = commandLine.hasOption(CHECK_DEPENDENCY_CHAR);

        if(checkDependency)
        {
            depDbUrl = commandLine.getOptionValue(DEP_DB_URL_CHAR); 
            depDbUserName = commandLine.getOptionValue(DEP_USERNAME_CHAR); 
            depDbPassword = commandLine.getOptionValue(DEP_PASSWORD_CHAR); 
            depDbSchema = commandLine.getOptionValue(DEP_SCHEMA_CHAR); 
        }
        
        DbConnectionConfig config = new DbConnectionConfig(PropertyManager.SERVICE_RELATIONSHIP_CONFIG);
        config.setDriver(dbDriver);
        config.setUrl(dbUrl);
        config.setUsername(dbUserName);
        config.setPassword(dbPassword);
        
        ServiceRelationShipConfig serviceRelationShipConfig = new ServiceRelationShipConfig();
        serviceRelationShipConfig.setDbConnectionConfig(config);
        
        PropertyManager.instance().setConfig(PropertyManager.SERVICE_RELATIONSHIP_CONFIG, serviceRelationShipConfig);

        ServiceLookupConfig serviceLookupConfig = new ServiceLookupConfig();
        serviceLookupConfig.setDbConnectionConfig(config);
        serviceLookupConfig.setZkHost(zkHost);
        serviceLookupConfig.setCollectionName(solrCollectionName);
        serviceLookupConfig.setCollectionIdField(solrCollectionId);
        serviceLookupConfig.setSolrCloudUsername(solrCloudUserName);
        serviceLookupConfig.setSolrCloudPassword(solrCloudPassword);
        
        PropertyManager.instance().setConfig(PropertyManager.SERVICE_LOOKUP_CONFIG, serviceLookupConfig);
        PropertyManager.instance().setServiceLookupConfig(serviceLookupConfig);
        
        if(checkDependency)
        {
            DbConnectionConfig depDbConnectionConfig = new DbConnectionConfig(PropertyManager.SLV_DEPENDENCY_CHECKER_CONFIG);
            depDbConnectionConfig.setDriver(dbDriver);
            depDbConnectionConfig.setUrl(depDbUrl);
            depDbConnectionConfig.setUsername(depDbUserName);
            depDbConnectionConfig.setPassword(depDbPassword);
            depDbConnectionConfig.setSchema(depDbSchema);
        
            ServiceLookupDependencyCheckerConfig slvDepCheckerConfig = new ServiceLookupDependencyCheckerConfig();
            slvDepCheckerConfig.setAppNameDependency("B_CDW_ERM");
            slvDepCheckerConfig.setDependencyName("wkf_Load_Service_Lookup_Refresh:s_m_Refresh_SERVICE_LOOKUP_VW");
            slvDepCheckerConfig.setDbConnectionConfig(depDbConnectionConfig);

            PropertyManager.instance().setConfig(PropertyManager.SLV_DEPENDENCY_CHECKER_CONFIG, slvDepCheckerConfig);
            PropertyManager.instance().setServiceLookupDependencyCheckerConfig(slvDepCheckerConfig);
        }
        
        
        log.info("Service lookup Dependency Checker config is \n{}", PropertyManager.instance().getServiceLookupDependencyCheckerConfig());

        boolean refreshData = true;

        if(checkDependency)
        {
            refreshData = ServiceLookupDependencyChecker.checkDependency();
        }
        
        if(!refreshData)
        {
            log.info("!!!!!!!! Data refresh failed, source not refreshed yet. !!!!!!!!!!!!");
            
            return null;
        }

        log.info("Service relationship config is \n{}", PropertyManager.instance().getDbConnectionConfig(PropertyManager.SERVICE_RELATIONSHIP_CONFIG));
        log.info("Service lookup config is \n{}", PropertyManager.instance().getServiceLookupConfig());

        ServiceLookupManager serviceLookupManager = new ServiceLookupManager(PropertyManager.instance().getServiceLookupConfig(), this);
            
        serviceLookupManager.run();
        
        return null;
    }

    public static void main(String[] args)
    {
        log.info("Starting indexing of Service lookup data.");

        ServiceLookupDataImporter dataImporter = new ServiceLookupDataImporter(args);
        
        dataImporter.dataimport();

        log.info("Completed indexing of service lookup data.");
    }
    
    private void processCommandLine()
    {
        // Handle command line argument processing
        addOption( DB_DRIVER_CHAR, DB_DRIVER_STRING, "database driver class name", true, true);
        addOption( DB_URL_CHAR, DB_URL_STRING, "database connection url", true, true);
        addOption( USERNAME_CHAR, USERNAME_STRING, "user name for database", true, true);
        addOption( PASSWORD_CHAR, PASSWORD_STRING, "password for database", true, true);
        addOption( ZK_HOST_CHAR, ZK_HOST_STRING, "zookeeper host string", true, true);
        addOption( SOLR_COLLECTION_CHAR, SOLR_COLLECTION_STRING, "solr collection name", true, true);
        addOption( SOLR_COLLECTION_ID_CHAR, SOLR_COLLECTION_ID_STRING, "solr collection ID field", true, true);
        addOption( SOLR_CLOUD_USERNAME_CHAR, SOLR_CLOUD_USERNAME_STRING, "user name for authenticating against SOLR Cloud", true, true);
        addOption( SOLR_CLOUD_PASSWORD_CHAR, SOLR_CLOUD_PASSWORD_STRING, "password for authenticating against SOLR Cloud", true, true);
        addOption( DEP_DB_URL_CHAR, DEP_DB_URL_STRING, "database connection url for dependency check", true, false);
        addOption( DEP_SCHEMA_CHAR, DEP_SCHEMA_STRING, "schame name for database for dependency check", true, false);
        addOption( DEP_USERNAME_CHAR, DEP_USERNAME_STRING, "user name for database for dependency check", true, false);
        addOption( DEP_PASSWORD_CHAR, DEP_PASSWORD_STRING, "password for database for dependency check", true, false);
        addOption( CHECK_DEPENDENCY_CHAR, CHECK_DEPENDENCY_STRING, "enforce dependency check", false, false);
        
        CommandLineParser parser = new GnuParser();
        try
        {
            commandLine = parser.parse( options, commandLineArgs );
        }
        catch ( ParseException e )
        {
            // Automatically generate the help statement
            StringBuffer cli = new StringBuffer();
            for ( String s : commandLineArgs )
            {
                cli.append( s + " " );
            }
            log.info( cli.toString() + "\n" );
            
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("java -jar km-dataimport.jar", null, options, null, true);
            
            System.exit( 1 );
        }
    }

    private void addOption(
            String shortOption, String longOption, String description, boolean hasArg, boolean required)
    {
        Option option = createOption(shortOption, longOption, description, hasArg, required);
        options.addOption(option);
    }

    private Option createOption(
            String shortOption, String longOption, String description, boolean hasArg, boolean required)
    {
        Option option = new Option(shortOption, longOption, hasArg, description);
        option.setRequired(required);

        return option;
    }

    @Override
    public void finishDataImport()
    {
        // TODO Auto-generated method stub
        
    }
}
