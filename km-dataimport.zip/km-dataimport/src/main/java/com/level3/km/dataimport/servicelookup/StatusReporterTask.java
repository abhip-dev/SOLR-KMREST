package com.level3.km.dataimport.servicelookup;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StatusReporterTask implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(StatusReporterTask.class); 

    private static final String NEW_LINE = "\n";
    private static final String STATS = NEW_LINE + "ServiceLookup Data refresh status" + NEW_LINE;
    
    private ServiceLookupManager manager = null;

    private static final String SECTION_SEPRATOR = 
            "=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+==+=+=+=+=\n";
        
    public StatusReporterTask(ServiceLookupManager manager)
    {
        this.manager = manager;
    }

    /**
     * Main Run Loop.
     */
    public void run()
    {
        DataImportStatus status = this.manager.status();
        log.info("{} {} {}", STATS, SECTION_SEPRATOR, status.toString());
        
        JSONObject jsonObject = new JSONObject();
        try
        {
            jsonObject.put("Outcome", status.isSuccess() ? "Success" : "Failed");
            jsonObject.put("status", status.isBusy() ? "Busy" : "Indexing complete");
            jsonObject.put("Import Started", ServiceLookupManager.df.format(status.getStartTime()));
            jsonObject.put("Import Completed", status.isBusy() ? null : ServiceLookupManager.df.format(status.getStopTime()));
            jsonObject.put("recordsProcessed", status.getRecordsProcessed());
            jsonObject.put("Time Taken", status.getTimeElapsed());

            this.manager.updateDataImportProperties(jsonObject.toString(3));
        }
        catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
