package com.level3.km.dataimport.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.level3.km.dataimport.config.DbConnectionConfig;
import com.level3.km.dataimport.config.IConnectionConfig;
import com.level3.km.dataimport.config.PropertyManager;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;


public class DbConnectionPool
{
    private static Object     lock = new int[ 1 ];	// For synchronization
    private static DbConnectionPool instance = null;

    private HikariConfig config = null;
    
    private Map<String, HikariDataSource> dataSourceMap = null;
    
    private DbConnectionPool( )
    {
        dataSourceMap = new HashMap<String, HikariDataSource>();
    }

    private void createDataSource( String poolName, DbConnectionConfig connectionConfig)
    {
        config = new HikariConfig();
        config.setDriverClassName(connectionConfig.getDriver());
        config.setUsername(connectionConfig.getUsername());
        config.setPassword(connectionConfig.getPassword());
        config.setAutoCommit(false);
        config.setJdbcUrl(connectionConfig.getUrl());
        config.setPoolName(poolName);

        HikariDataSource dataSource = new HikariDataSource(config);
        dataSource.setMaximumPoolSize(20);
        
        dataSourceMap.put(poolName, dataSource);
    }
    
    public static DbConnectionPool instance()
    {
        DbConnectionPool tempInstance = null;
        
        if(instance == null)
        {
            synchronized (lock)
            {
                if(instance == null)
                {
                    tempInstance = new DbConnectionPool();
                    instance = tempInstance;
                }
            }
        }
        
        return instance;
    }
    
    public synchronized Connection getConnection(String connectionName)
    {
        try
        {
            if(!dataSourceMap.containsKey(connectionName))
            {
                // let us create a new data source
                IConnectionConfig connConfig = PropertyManager.instance().getDbConnectionConfig(connectionName);
                if(connConfig != null)
                {
                    createDataSource(connectionName, connConfig.getDbConnectionConfig());
                }
            }

            return dataSourceMap.get(connectionName).getConnection();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            throw new RuntimeException(
                "ERROR: unable to open connection: " + " because of " + e.getMessage() );
        }
    }

    public void destroy()
    {
        try
        {
            finalize();
        }
        catch ( Throwable t )
        {
        }
    }
    
    /**
     * System hook for closing the data source.
     */
    protected void finalize()
        throws Throwable
    {

    }
    
}
