package com.level3.km.dataimport.customerBillAccountNumber;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.BinaryRequestWriter;
import org.apache.solr.client.solrj.impl.BinaryResponseParser;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.response.FacetField;
import org.apache.solr.client.solrj.response.FacetField.Count;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.CustomerBillAccountNumberConfig;

public class DataCleaner
{
    // execute a query against SOLR index.
    // parse the response, and for each row
    // capitalize the String and issue delete query
    private static Logger log = LoggerFactory.getLogger(DataCleaner.class); 

    static DateFormat df = null;
	private static final String SOLJ_DATE_FMT = "yyyy-MM-dd'T'HH:mm:ss'Z'" ; 
    private CloudSolrClient solrClient = null;

    private AtomicLong recordCounter = null;
//    private Date processStartTime = null;
//    private Date processStopTime = null;
    private String documentUpdateDate = null;

    private CustomerBillAccountNumberConfig config = null;
    
    static
    {
        TimeZone tz = TimeZone.getTimeZone("UTC");
        df = new SimpleDateFormat(SOLJ_DATE_FMT);
        df.setTimeZone(tz);
    }
    
    public DataCleaner(CustomerBillAccountNumberConfig config)
    {
        this.config = config;
        
        init();
    }

    private void init()
    {
        documentUpdateDate = df.format(new Date());
        log.info("Document Update Date: {}", documentUpdateDate);
        
        solrClient = new CloudSolrClient.Builder().withZkHost(config.getZkHost()).sendDirectUpdatesToShardLeadersOnly().build();

        solrClient.setParallelUpdates(true);
        solrClient.setDefaultCollection(config.getCollectionName());
        solrClient.setIdField(config.getCollectionIdField());
        solrClient.setZkClientTimeout(1000);
        solrClient.setZkConnectTimeout(1000);
        solrClient.setParser(new BinaryResponseParser());
        solrClient.setRequestWriter(new BinaryRequestWriter());
            
        recordCounter = new AtomicLong(0L);
    }
    
    public void getDuplicatedBillAccounts()
    {
        QueryResponse response = null;

        
        try
        {
            SolrQuery query = new SolrQuery();
            query.setQuery("*:*");
            query.setRows(0);
            query.setFilterQueries("preferredSourceRecordIndicator:true");
            query.setFacet(true);
            query.addFacetField("sourceBillAccountKeyId");
            query.setFacetLimit(5000);
            query.setFacetMinCount(2);

            response = solrClient.query(query);
            
            FacetField facetField = response.getFacetField("sourceBillAccountKeyId");
            
            List<Count> facetValues = facetField.getValues();
            
            if(facetValues != null)
            {
                for(Count facetValue : facetValues)
                {
                    log.info("sourceBillAccountKeyId {}, count {}", facetValue.getName().toUpperCase(), facetValue.getCount());
                    
                    deleteDuplicateRecord(facetValue.getName().toUpperCase());
                }
            }
            
            solrClient.commit();
        }
        catch (SolrServerException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    private void deleteDuplicateRecord(String id)
    {
//        String query = "-solrDocumentUpdateDate:[" + getDocumentUpdateDate() + " TO *]";
        String query = "id:" + id;
        
        try
        {
            log.info("Issuing query to delete record with id: {}, {}", id, recordCounter.incrementAndGet());

            UpdateResponse response = solrClient.deleteByQuery(query);
            
            if(response.getStatus() != 0)
            {
                log.info("Failed to delete duplicate record.");
            }
            
            log.info("DELETE RESPONSE - {}", response);
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to delete duplicate record from Solr index.", ex);
        }
    }
    
    public static void main(String[] args)
    {
        try
        {
            CustomerBillAccountNumberConfig config = new CustomerBillAccountNumberConfig();
            
            // DEV
            config.setZkHost("10.5.168.143:2181");
            
            // TEST ADC
//            config.setZkHost("yy7-01:2181,yy7-03:2181,aaa7-04:2181");
            
            // TEST IDC
//            config.setZkHost("m14-15:2181,n14-15:2181,m14-17:2181");
            
            // PROD ADC
//            config.setZkHost("ddd7-01:2181,eee7-01:2181,ggg7-01:2181,iii7-01:2181,jjj7-01:2181");
            
            // PROD IDC
//            config.setZkHost("n14-17:2181,m14-19:2181,n14-19:2181,m14-21:2181,n14-21:2181");

            config.setCollectionName("custban");
            config.setCollectionIdField("id");

            DataCleaner cleaner = new DataCleaner(config);
            cleaner.getDuplicatedBillAccounts();
        }
        catch(Exception ex)
        {
            log.error("caught exception", ex);
        }
    }
    
}
