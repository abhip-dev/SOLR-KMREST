package com.level3.km.dataimport.servicelookup;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
//@XmlAccessorType(XmlAccessType.FIELD)
public class DataImportStatus implements Serializable
{
    private static final long serialVersionUID = -4287508891759652787L;

    private boolean isBusy = true;
    private Date startTime = null;
    private Date stopTime = null;
    private long recordsProcessed = -1;
    private boolean isSuccess = true;

    public Date getStartTime()
    {
        return startTime;
    }
    public void setStartTime(Date startTime)
    {
        this.startTime = startTime;
    }
    @XmlElement(name="stopTime")
    public Date getStopTime()
    {
        if(isBusy())
        {
            return null;
        }

        return stopTime;
    }
    public void setStopTime(Date stopTime)
    {
        this.stopTime = stopTime;
    }
    public long getRecordsProcessed()
    {
        return recordsProcessed;
    }
    public void setRecordsProcessed(long recordsProcessed)
    {
        this.recordsProcessed = recordsProcessed;
    }
    public Boolean isBusy()
    {
        return isBusy;
    }
    public void setIsBusy(boolean isBusy)
    {
        this.isBusy = isBusy;
    }
    public boolean isSuccess()
    {
        return isSuccess;
    }
    public void setSuccess(boolean isSuccess)
    {
        this.isSuccess = isSuccess;
    }

    @XmlElement
    public String getTimeElapsed()
    {
        long diff = 0;
        if(stopTime == null || startTime == null)
        {
            diff = 0;
        }
        else
        {
            diff = stopTime.getTime() - startTime.getTime();
        }
        
        long diffSeconds = diff / 1000 % 60;
        long diffMinutes = diff / (60 * 1000) % 60;
        long diffHours = diff / (60 * 60 * 1000) % 24;
        
        return diffHours + ":" + diffMinutes + ":" + diffSeconds;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("Status [isBusy=");
        builder.append(isBusy);
        builder.append(", startTime=");
        builder.append(ServiceLookupManager.df.format(startTime));
        builder.append(", stopTime=");
        builder.append(isBusy ? null : ServiceLookupManager.df.format(stopTime));
        builder.append(", recordsProcessed=");
        builder.append(recordsProcessed);
        builder.append(", timeElapsed=");
        builder.append(getTimeElapsed());
        builder.append(", isSuccess=");
        builder.append(isSuccess);
        builder.append("]");
        return builder.toString();
    }
}