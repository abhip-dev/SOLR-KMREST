package com.level3.km.dataimport.servicelookup;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.PropertyManager;
import com.level3.km.dataimport.db.DbConnection;

public class ServiceRelationShipDataReader implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(ServiceRelationShipDataReader.class); 

    private Map<String, List<String>> sidRelatedSidMap = null;

    private int documentsCommitted = 0;
    
    private DbConnection slvConn = null;
    
    private String filterCriteria = null;
    
    private ServiceRelationShipManager manager = null;
    
    private static final String relationshipQueryAddFilter = 
            "select SR.SID, " +
            "       SR.RELATED_SID AS RELATEDSERVICEINSTANCEID " +
            " FROM service_relationship SR ";

    public ServiceRelationShipDataReader(String filterCriteria, ServiceRelationShipManager manager, Map<String, List<String>> sidRelatedSidMap)
    {
        this.filterCriteria = filterCriteria;
        this.sidRelatedSidMap = sidRelatedSidMap;
        
        this.manager = manager;

        slvConn = new DbConnection(PropertyManager.SERVICE_RELATIONSHIP_CONFIG);
    }

    public void run()
    {
        process();
        
        this.manager.countLatchDown();
    }

    public void process()
    {
        addToMap(filterCriteria);
    }
    
    private void addToMap(String filterCriteria)
    {
        String sid = null;
        String relatedSid = null;

        try(
               PreparedStatement stmt = slvConn.getPreparedStatement(relationshipQueryAddFilter + filterCriteria);
               ResultSet resultSet = slvConn.executeQuery(stmt);
           )
        {
            while(resultSet != null && resultSet.next())
            {
                documentsCommitted++;
                
                if (documentsCommitted % 10000 == 0)
                {
                    log.info("filter criteria {} - documents processed :{}", filterCriteria, documentsCommitted);
                }

                sid = DbConnection.readString(resultSet, "SID");
                
                List<String> relatedSidList = sidRelatedSidMap.get(sid);
                
                if(relatedSidList == null)
                {
                    relatedSidList = new ArrayList<String>();
                }
                
                relatedSid = DbConnection.readString(resultSet, "RELATEDSERVICEINSTANCEID");
                if(relatedSid != null)
                {
                    relatedSidList.add(relatedSid);
                    sidRelatedSidMap.put(sid, relatedSidList);
                }
            }
        }
        catch (Exception e)
        {
            log.error("caught exception while trying to update map.", e);
            
            // stop the process or mark run as failure
            manager.updateFailure();
        }
        finally
        {
            log.info("FINAL COUNT !!! filter criteria \"{}\" - documents processed :{}, number of SIDs :{}", filterCriteria, documentsCommitted, sidRelatedSidMap.size());
            
            slvConn.destroy();
        }
    }

    public static void main(String[] args)
    {
        log.info("Starting indexing of Service relationship data.");
        try
        {
            ServiceRelationShipDataReader indexer = new ServiceRelationShipDataReader(" WHERE SR.RELATIONSHIP_LEVEL = 1", null, new HashMap<String, List<String>>());
            
            indexer.process();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            log.error("caught exception while trying to index service relationship data.", ex);
        }
        
        log.info("Completed indexing of service relationship data.");
    }
}
