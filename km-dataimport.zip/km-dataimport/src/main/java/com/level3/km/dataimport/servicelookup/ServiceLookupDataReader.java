package com.level3.km.dataimport.servicelookup;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.solr.common.SolrInputDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.PropertyManager;
import com.level3.km.dataimport.db.DbConnection;
import com.level3.km.dataimport.thread.PooledExecutors;

public class ServiceLookupDataReader implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(ServiceLookupDataReader.class); 
    private static int DEFAULT_BATCH_SIZE = 2500;

    private int batchSize = -1;

    private Collection<SolrInputDocument> documentList = new ArrayList<SolrInputDocument>();
    
    private int documentsCommitted = 0;
    
    private DbConnection slvConn = null;
    
    private String filterCriteria = null;
    private ServiceLookupManager manager = null;

    private static final String slvQuery = 
         "SELECT " +
         "REPLACE(slv.SOURCE_SYS_NM || '#' || slv.sid || '#' || slv.scid || '#' || slv.customer_order || '#' || SLV.SERVICE_ORDER || '#' || slv.so_sequence || '#' || component_id  || '#' || sl.service_location_key_id || '#' || slv.BILLING_START_DT, '!', '#') AS id," +
         "slv.SOURCE_SYS_NM AS dwSourceSystemCode, " +
         "slv.ACCOUNT_ID AS customerNumber, " +
         "slv.ACCOUNT AS customerName, " +
         "slv.END_CUSTOMER_ID AS endCustomerNumber, " +
         "slv.END_CUSTOMER AS endCustomerName, " +
         "slv.THIRD_PARTY_ACCOUNT_ID AS thirdPartyCustomerNumber, " +
         "slv.THIRD_PARTY_ACCOUNT AS thirdPartyCustomerName, " +
         "slv.CUSTOMER_ORDER AS customerOrderNumber, " +
         "slv.SERVICE_ORDER AS serviceOrderNumber, " +
         "CASE WHEN slv.SOURCE_SYS_NM IN ('UKDW_CLARIFY_UK', 'SIEBEL', 'SIEBEL6_LATAM', 'SIEBEL8_LATAM', 'EON', 'PIPELINE', 'CPO', 'SWIFT') THEN slv.SID " +
         "ELSE slv.PIID " +
         "END AS productInstanceId, " +
         "slv.CPE_DEVICE_NAME AS cpeDeviceName, " +
         "slv.SCID AS serviceComponentId, " +
         "slv.PRODUCT AS productName, " +
         "slv.PRODUCT_ID AS productCode, " +
         "slv.COMPONENT AS serviceComponentProductName, " +
         "slv.COMPONENT_ID AS serviceComponentProductCode, " +
         "slv.BILLING_START_DT AS BILLSTARTDATE, " +
         "slv.CUST_REQUEST_DT AS CUSTOMERREQUESTDATE, " +
         "slv.MRC AS usdTotalMrcAmount, " +
         "slv.SERVICE_ORDER_TYPE AS serviceOrderType, " +
         "slv.SERVICE_ORDER_STATUS AS serviceOrderStatusCode, " +
         "slv.SERVICE_ORDER_ACTION AS serviceOrderActionType, " +
         "slv.GATEWAY AS gatewayName, " +
         "slv.CUSTOMER_ORDER_CREATE_DT AS CUSTOMERORDERCREATEDATE, " +
         "slv.SERVICE_SITE_LOCATION AS serviceLocationAddress, " +
         "slv.SERVICE_SITE AS serviceLocationName, " +
         "slv.SID AS serviceInstanceId, " +
         "slv.ACTIVE_FLAG AS activeIndicator, " +
         "slv.SO_SEQUENCE AS serviceOrderSequenceNumber, " +
         "slv.SO_NET_IND AS onnetIndicator, " +
         "slv.CUST_CCID AS customerCircuitId, " +
         "slv.INSTALLED_DT AS SERVICEINSTALLDATE, " +
         "slv.TSP_CODE AS tspCode, " +
         "slv.LEGACY_ACCOUNT_ID AS sourceCustomerNumber, " +
         "slv.DIVERSITY_TRAIL_NAME AS diversityTrailName, " +
         "slv.DIVERSITY_SECOND_TRAIL_NAME AS diversitySecondTrailName, " +
         "slv.BANDWIDTH_CODE AS bandwidthCode, " +
         "slv.SUB_BANDWDTH_CD AS subBandwidthCode, " +
         "slv.A_END_NODE_NAME AS aEndClliCode, " +
         "slv.Z_END_NODE_NAME AS zEndClliCode, " +
         "slv.LEGACY_BILL_ACCOUNT_NUMBER AS legacyBillAccountNumber, " +
         "slv.LEGACY_SERVICE_ORDER_NUMBER AS legacyLastServiceOrderNumber, " +
         "slv.LEGACY_ORIGINAL_SYSTEM AS legacySourceSystemCode, " +
         "slv.LEGACY_CIRCUIT_ID AS legacyCircuitId, " +
         "slv.PON AS customerPurchaseOrderNumber, " +
         "slv.ASSOCIATED_SERVICE AS associatedOrderNumber, " +
         "slv.LATENCY_GUARANTEE_FLAG AS latencyGuranteeLevelType, " +
         "slv.LATENCY_GUARANTEE_VALUE AS latencyGuranteeValue, " +
         "slv.LATENCY_ACTUAL_VALUE AS latencyActualValue, " +
         "slv.IP_VERSION_CD AS ipVersionCode, " +
         "slv.EQUIP_CONFIG_DESC AS equipmentConfigDescription, " +
         "slv.EQUIP_MANUF_NAME AS equipmentManufacturerName, " +
         "slv.EQUIP_SERV_PROVIDER_NAME AS equipmentServiceProviderName, " +
         "slv.EQUIP_MAINT_AGREE_TYP AS equipmentMaintAgreementType, " +
         "CASE WHEN slv.CNR_JEOP_IND = 'Y' then 1 " +
         "WHEN slv.CNR_JEOP_IND = 'N' then 0 " +
         "ELSE null END AS cnrJeopIndicator, " +
         "slv.CNR_JEOP_RAISED_DT AS CNRJEOPRAISEDDATE, " +
         "CASE WHEN slv.BUNDLED_SERVICE_IND = 'Y' then 1 " +
         "WHEN slv.BUNDLED_SERVICE_IND = 'N' then 0 " +
         "ELSE null END AS bundledServiceIndicator, " +
         "slv.ULTIMATE_SERVICE_STATE AS ultimateServiceStatusCode, " +
         "slv.BILL_ACCOUNT_NBR AS billAccountNumber, " +
         "slv.PARENT_BILL_ACCOUNT_NBR AS parentBillAccountNumber, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND = 'NF' then null " +
         "ELSE null END AS activeBillIndicator, " +
         "CASE WHEN slv.ENABLE_AUTO_TICKET_IND = 'Y' then 1 " +
         "WHEN slv.ENABLE_AUTO_TICKET_IND = 'N' then 0 " +
         "ELSE null END AS enableAutoTicketIndicator, " +
         "slv.PROTECT_TYP AS protectType, " +
         "slv.SERVICE_LOCATION_ID AS serviceLocationId, " +
         "slv.SPECIALS_ID AS specialsId, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_SID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SID = 'NF' then null " +
         "ELSE null END AS sidActiveBillIndicator, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_SCID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SCID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SCID = 'NF' then null " +
         "ELSE null END AS scidActiveBillIndicator, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_PIID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PIID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PIID = 'NF' then null " +
         "ELSE null END AS piidActiveBillIndicator, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_PCSID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PCSID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PCSID = 'NF' then null " +
         "ELSE null END AS pcsidActiveBillIndicator, " +
         "slv.COMPONENT_SUBTYPE_NAME AS componentSubTypeName, " +
         "slv.BILL_ACCOUNT_NAME AS billAccountName, " +
         "slv.SERVICE_CLASS_LEVEL_TYP AS serviceClassLevelType, " +
         "slv.VPN_ID AS vpnId, " +
         "slv.TICKETING_PRODUCT_NAME AS ticketingProductName, " +
         "slv.TICKETING_PROD_FAMILY_NAME AS ticketingProductFamilyName, " +
         "slv.TICKETING_PARENT_SID AS ticketingParentServiceId, " +
         "slv.COS_CLASS_TYP AS classOfServiceClassType, " +
         "slv.COS_ALLOC_TYP AS classOfServiceAllocationType, " +
         "slv.MULTI_SERV_ALLOC_TYP AS multiServiceAllocationType, " +
         "slv.CDR_MBPS_VALUE AS committedDataRateMbps, " +
         "slv.PIR_MBPS_VALUE AS peakInformationRateMbps, " +
         "slv.PCSID AS parentCircuitServiceId, " +
         "slv.ORDER_PRODUCT_INST_ID AS orderProductInstanceId, " +
         "slv.ORDER_SERV_COMPNT_ID AS orderServiceComponentId, " +
         "slv.EQUIP_SERIAL_NBR AS equipmentSerialNumber, " +
//         "sl.CIRCUIT_ID AS circuitId, " +
//         "sl.SID AS serviceId, " +
         "sl.A_LINE1_ADDR AS aLine1Address, " +
         "sl.A_LINE2_ADDR AS aLine2Address, " +
         "sl.A_CITY_NAME AS aCityName, " +
         "sl.A_STATE_CD AS aStateCode, " +
         "sl.A_POSTAL_CD AS aPostalCode, " +
         "sl.A_COUNTY_NAME AS aCountyName, " +
         "sl.A_COUNTRY_NAME AS aCountryName, " +
         "sl.A_LATITUDE_NBR AS aLatitudeNumber, " +
         "sl.A_LONGITUDE_NBR AS aLongitudeNumber, " +
         "sl.Z_LINE1_ADDR AS zLine1Address, " +
         "sl.Z_LINE2_ADDR AS zLine2Address, " +
         "sl.Z_CITY_NAME AS zCityName, " +
         "sl.Z_STATE_CD AS zStateCode, " +
         "sl.Z_POSTAL_CD AS zPostalCode, " +
         "sl.Z_COUNTY_NAME AS zCountyName, " +
         "sl.Z_COUNTRY_NAME AS zCountryName, " +
         "sl.Z_LATITUDE_NBR AS zLatitudeNumber, " +
         "sl.Z_LONGITUDE_NBR AS zLongitudeNumber, " +
         "sl.A_LOCATION_ID AS aLocationId, " +
         "sl.Z_LOCATION_ID AS zLocationId, " +
         "sl.A_LOCATION_NAME AS aLocationName, " +
         "sl.Z_LOCATION_NAME AS zLocationName, " +
         "sl.A_TIMEZONE_NAME AS aTimezoneName, " +
         "sl.Z_TIMEZONE_NAME AS zTimezoneName, " +
         "sl.A_DOKUVIZ_ID AS aDokuvizId, " +
         "sl.Z_DOKUVIZ_ID AS zDokuvizId, " +
         "sl.A_LOC_NBR AS aLocationNumber, " +
         "sl.Z_LOC_NBR AS zLocationNumber, " +
         "sl.A_REGION_CD AS aRegionCode, " +
         "sl.Z_REGION_CD AS zRegionCode, " +
         "slv.DIVERSE_ROLE_TYP AS diverseRoleType, " +
         "slv.BILL_TYP AS billType, " +
         "slv.VENDOR_NAME as vendorName, " +
         "slv.VENDOR_CIRCUIT_ID as vendorCircuitId, " +
         "slv.PRIMARY_CONTROLLER_NAME as primaryControllerName, " +
         "slv.PRIMARY_DIRECTOR_NAME as primaryDirectorName, "+
         "slv.SERVICE_PROPERTY_LIST_TXT as servicePropertyListTxt, " + 
         "slv.SERVICE_MGMT_TYP as serviceMgmtTyp, " +
         "slv.FINANCE_ACCOUNT_NBR as financeAccountNbr, " +
         "slv.ORDER_SOURCE_SYSTEM_NAME as orderSourceSystemName, " +
         "slv.BILL_ACCT_SOURCE_SYSTEM_CD  as billAcctSourceSystemCd " +
         "FROM service_lookup_mvw slv " +
         "LEFT JOIN service_location sl  " +
         "ON sl.service_location_id = slv.service_location_id ";
    
    public ServiceLookupDataReader(String filterCriteria, ServiceLookupManager manager, int batchSize) 
    {
        this.filterCriteria = filterCriteria;
        this.manager = manager;
        this.batchSize = batchSize;

        slvConn = new DbConnection(PropertyManager.SERVICE_LOOKUP_CONFIG);
    }

    public ServiceLookupDataReader(String filterCriteria, ServiceLookupManager manager) 
    {
        this(filterCriteria, manager, DEFAULT_BATCH_SIZE);
    }

    public static synchronized String generateUUID()
    {
        return UUID.randomUUID().toString();
    }
    
    public void run()
    {
        process();
        
        manager.countLatchDown();
    }
    
    public void process()
    {
        addToSolrIndex();
        
        finishIndexing();
    }
    
    private void addToSolrIndex()
    {
        SolrInputDocument solrInputDocument = null;
        String id = null;
        String dwSourceSystemCode = null;
        String customerNumber = null;
        String customerName = null;
        String endCustomerNumber = null;
        String endCustomerName = null;
        String thirdPartyCustomerNumber = null;
        String thirdPartyCustomerName = null;
        String customerOrderNumber = null;
        String serviceOrderNumber = null;
        String productInstanceId = null;
        String cpeDeviceName = null;
        String serviceComponentId = null;
        String productName = null;
        String productCode = null;
        String serviceComponentProductName = null;
        String serviceComponentProductCode = null;
        Date billStartDate = null;
        Date customerRequestDate = null;
        Double usdTotalMrcAmount = null;
        String serviceOrderType = null;
        String serviceOrderStatusCode = null;
        String serviceOrderActionType = null;
        String gatewayName = null;
        Date customerOrderCreateDate = null;
        String serviceLocationAddress = null;
        String serviceLocationName = null;
        String serviceInstanceId = null;
        String activeIndicator = null;
        String serviceOrderSequenceNumber = null;
        String onnetIndicator = null;
        String customerCircuitId = null;
        Date serviceInstallDate = null;
        String tspCode = null;
        String sourceCustomerNumber = null;
        String diversityTrailName = null;
        String diversitySecondTrailName = null;
        String bandwidthCode = null;
        String subBandwidthCode = null;
        String aEndClliCode = null;
        String zEndClliCode = null;
        String legacyBillAccountNumber = null;
        String legacyLastServiceOrderNumber = null;
        String legacySourceSystemCode = null;
        String legacyCircuitId = null;
        String customerPurchaseOrderNumber = null;
        String associatedOrderNumber = null;
        String latencyGuranteeLevelType = null;
        Long latencyGuranteeValue = null;
        Long latencyActualValue = null;
        String ipVersionCode = null;
        String equipmentConfigDescription = null;
        String equipmentManufacturerName = null;
        String equipmentServiceProviderName = null;
        String equipmentMaintAgreementType = null;
        Boolean cnrJeopIndicator = null;
        Date cnrJeopRaisedDate = null;
        Boolean bundledServiceIndicator = null;
        String ultimateServiceStatusCode = null;
        String billAccountNumber = null;
        String parentBillAccountNumber = null;
        Boolean activeBillIndicator = null;
        Boolean enableAutoTicketIndicator = null;
        String protectType = null;
        Long serviceLocationId = null;
        String specialsId = null;
        Boolean sidActiveBillIndicator = null;
        Boolean scidActiveBillIndicator = null;
        Boolean piidActiveBillIndicator = null;
        Boolean pcsidActiveBillIndicator = null;
        String componentSubTypeName = null;
        String billAccountName = null;
        String serviceClassLevelType = null;
//        String circuitId = null;
//        String serviceId = null;
        String aLine1Address = null;
        String aLine2Address = null;
        String aCityName = null;
        String aStateCode = null;
        String aPostalCode = null;
        String aCountyName = null;
        String aCountryName = null;
        Double aLatitudeNumber = null;
        Double aLongitudeNumber = null;
        String zLine1Address = null;
        String zLine2Address = null;
        String zCityName = null;
        String zStateCode = null;
        String zPostalCode = null;
        String zCountyName = null;
        String zCountryName = null;
        Double zLatitudeNumber = null;
        Double zLongitudeNumber = null;
        String aLocationId = null;
        String zLocationId = null;
        String aLocationName = null;
        String zLocationName = null;
        String aTimezoneName = null;
        String zTimezoneName = null;
        String aDokuvizId = null;
        String zDokuvizId = null;
        Long aLocationNumber = null;
        Long zLocationNumber = null;
        String aRegionCode = null;
        String zRegionCode = null;
        String vpnId = null;
        String ticketingProductName = null;
        String ticketingProductFamilyName = null;
        String ticketingParentServiceId = null;
        String classOfServiceClassType = null;
        String classOfServiceAllocationType = null;
        String multiServiceAllocationType = null;
        Double committedDataRateMbps = null;
        Double peakInformationRateMbps = null;
        String parentCircuitServiceId = null;
        String orderProductInstanceId = null;
        String orderServiceComponentId = null;
        String equipmentSerialNumber = null;
        List<String> relatedServiceInstanceIdLevel1 = null;
        List<String> relatedServiceInstanceIdLevel2 = null;
        List<String> relatedServiceInstanceIdLevel3 = null;
        List<String> relatedServiceInstanceIdLevel4 = null;
        List<String> relatedServiceInstanceIdLevel5 = null;
        ServiceLookupIndexer indexer = null;
        // added column diverseRoleType and billType as per US272260
        String diverseRoleType = null; 
        String billType = null; 
        String vendorName = null;
        String vendorCircuitId = null;
        String primaryControllerName = null;
        String primaryDirectorName = null;
        String servicePropertyListTxt = null;
        String serviceMgmtTyp = null;
        String financeAccountNbr = null;
        String orderSourceSystemName = null;
        String billAcctSourceSystemCd = null;

        try
        (
            PreparedStatement stmt = slvConn.getPreparedStatement(slvQuery + filterCriteria);
            ResultSet resultSet = slvConn.executeQuery(stmt);
        )
        {
            
            while(resultSet != null && resultSet.next())
            {
                solrInputDocument = new SolrInputDocument(); 
                
                id = DbConnection.readString(resultSet, "ID");
                if(id != null)
                {
                    solrInputDocument.addField("id", id);
                }
                dwSourceSystemCode = DbConnection.readString(resultSet, "DWSOURCESYSTEMCODE");
                if(dwSourceSystemCode != null)
                {
                    solrInputDocument.addField("dwSourceSystemCode", dwSourceSystemCode);
                }
                customerNumber = DbConnection.readString(resultSet, "CUSTOMERNUMBER");
                if(customerNumber != null)
                {
                    solrInputDocument.addField("customerNumber", customerNumber);
                }
                customerName = DbConnection.readString(resultSet, "CUSTOMERNAME");
                if(customerName != null)
                {
                    solrInputDocument.addField("customerName", customerName);
                }
                endCustomerNumber = DbConnection.readString(resultSet, "ENDCUSTOMERNUMBER");
                if(endCustomerNumber != null)
                {
                    solrInputDocument.addField("endCustomerNumber", endCustomerNumber);
                }
                endCustomerName = DbConnection.readString(resultSet, "ENDCUSTOMERNAME");
                if(endCustomerName != null)
                {
                    solrInputDocument.addField("endCustomerName", endCustomerName);
                }
                thirdPartyCustomerNumber = DbConnection.readString(resultSet, "THIRDPARTYCUSTOMERNUMBER");
                if(thirdPartyCustomerNumber != null)
                {
                    solrInputDocument.addField("thirdPartyCustomerNumber", thirdPartyCustomerNumber);
                }
                thirdPartyCustomerName = DbConnection.readString(resultSet, "THIRDPARTYCUSTOMERNAME");
                if(thirdPartyCustomerName != null)
                {
                    solrInputDocument.addField("thirdPartyCustomerName", thirdPartyCustomerName);
                }
                customerOrderNumber = DbConnection.readString(resultSet, "CUSTOMERORDERNUMBER");
                if(customerOrderNumber != null)
                {
                    solrInputDocument.addField("customerOrderNumber", customerOrderNumber);
                }
                serviceOrderNumber = DbConnection.readString(resultSet, "SERVICEORDERNUMBER");
                if(serviceOrderNumber != null)
                {
                    solrInputDocument.addField("serviceOrderNumber", serviceOrderNumber);
                }
                productInstanceId = DbConnection.readString(resultSet, "PRODUCTINSTANCEID");
                if(productInstanceId != null)
                {
                    solrInputDocument.addField("productInstanceId", productInstanceId);
                }
                cpeDeviceName = DbConnection.readString(resultSet, "CPEDEVICENAME");
                if(cpeDeviceName != null)
                {
                    solrInputDocument.addField("cpeDeviceName", cpeDeviceName);
                }
                serviceComponentId = DbConnection.readString(resultSet, "SERVICECOMPONENTID");
                if(serviceComponentId != null)
                {
                    solrInputDocument.addField("serviceComponentId", serviceComponentId);
                }
                productName = DbConnection.readString(resultSet, "PRODUCTNAME");
                if(productName != null)
                {
                    solrInputDocument.addField("productName", productName);
                }
                productCode = DbConnection.readString(resultSet, "PRODUCTCODE");
                if(productCode != null)
                {
                    solrInputDocument.addField("productCode", productCode);
                }
                serviceComponentProductName = DbConnection.readString(resultSet, "SERVICECOMPONENTPRODUCTNAME");
                if(serviceComponentProductName != null)
                {
                    solrInputDocument.addField("serviceComponentProductName", serviceComponentProductName);
                }
                serviceComponentProductCode = DbConnection.readString(resultSet, "SERVICECOMPONENTPRODUCTCODE");
                if(serviceComponentProductCode != null)
                {
                    solrInputDocument.addField("serviceComponentProductCode", serviceComponentProductCode);
                }
                billStartDate = DbConnection.readDate(resultSet, "BILLSTARTDATE");
                if(billStartDate != null)
                {
                    solrInputDocument.addField("billStartDate", billStartDate);
                }
                customerRequestDate = DbConnection.readDate(resultSet, "CUSTOMERREQUESTDATE");
                if(customerRequestDate != null)
                {
                    solrInputDocument.addField("customerRequestDate", customerRequestDate);
                }
                usdTotalMrcAmount = DbConnection.readDouble(resultSet, "USDTOTALMRCAMOUNT");
                if(usdTotalMrcAmount != null)
                {
                    solrInputDocument.addField("usdTotalMrcAmount", usdTotalMrcAmount);
                }
                serviceOrderType = DbConnection.readString(resultSet, "SERVICEORDERTYPE");
                if(serviceOrderType != null)
                {
                    solrInputDocument.addField("serviceOrderType", serviceOrderType);
                }
                serviceOrderStatusCode = DbConnection.readString(resultSet, "SERVICEORDERSTATUSCODE");
                if(serviceOrderStatusCode != null)
                {
                    solrInputDocument.addField("serviceOrderStatusCode", serviceOrderStatusCode);
                }
                serviceOrderActionType = DbConnection.readString(resultSet, "SERVICEORDERACTIONTYPE");
                if(serviceOrderActionType != null)
                {
                    solrInputDocument.addField("serviceOrderActionType", serviceOrderActionType);
                }
                gatewayName = DbConnection.readString(resultSet, "GATEWAYNAME");
                if(gatewayName != null)
                {
                    solrInputDocument.addField("gatewayName", gatewayName);
                }
                customerOrderCreateDate = DbConnection.readDate(resultSet, "CUSTOMERORDERCREATEDATE");
                if(customerOrderCreateDate != null)
                {
                    solrInputDocument.addField("customerOrderCreateDate", customerOrderCreateDate);
                }
                serviceLocationAddress = DbConnection.readString(resultSet, "SERVICELOCATIONADDRESS");
                if(serviceLocationAddress != null)
                {
                    solrInputDocument.addField("serviceLocationAddress", serviceLocationAddress);
                }
                serviceLocationName = DbConnection.readString(resultSet, "SERVICELOCATIONNAME");
                if(serviceLocationName != null)
                {
                    solrInputDocument.addField("serviceLocationName", serviceLocationName);
                }
                serviceInstanceId = DbConnection.readString(resultSet, "SERVICEINSTANCEID");
                if(serviceInstanceId != null)
                {
                    solrInputDocument.addField("serviceInstanceId", serviceInstanceId);
                    
                    relatedServiceInstanceIdLevel1 = ServiceRelationShipManager.getRelatedSidLevel1(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel1 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel1", relatedServiceInstanceIdLevel1);
                    }
                    
                    relatedServiceInstanceIdLevel2 = ServiceRelationShipManager.getRelatedSidLevel2(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel2 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel2", relatedServiceInstanceIdLevel2);
                    }
                    
                    relatedServiceInstanceIdLevel3 = ServiceRelationShipManager.getRelatedSidLevel3(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel3 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel3", relatedServiceInstanceIdLevel3);
                    }
                    
                    relatedServiceInstanceIdLevel4 = ServiceRelationShipManager.getRelatedSidLevel4(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel4 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel4", relatedServiceInstanceIdLevel4);
                    }
                    
                    relatedServiceInstanceIdLevel5 = ServiceRelationShipManager.getRelatedSidLevel5(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel5 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel5", relatedServiceInstanceIdLevel5);
                    }
                }
                activeIndicator = DbConnection.readString(resultSet, "ACTIVEINDICATOR");
                if(activeIndicator != null)
                {
                    solrInputDocument.addField("activeIndicator", activeIndicator);
                }
                serviceOrderSequenceNumber = DbConnection.readString(resultSet, "SERVICEORDERSEQUENCENUMBER");
                if(serviceOrderSequenceNumber != null)
                {
                    solrInputDocument.addField("serviceOrderSequenceNumber", serviceOrderSequenceNumber);
                }
                onnetIndicator = DbConnection.readString(resultSet, "ONNETINDICATOR");
                if(onnetIndicator != null)
                {
                    solrInputDocument.addField("onnetIndicator", onnetIndicator);
                }
                customerCircuitId = DbConnection.readString(resultSet, "CUSTOMERCIRCUITID");
                if(customerCircuitId != null)
                {
                    solrInputDocument.addField("customerCircuitId", customerCircuitId);
                }
                serviceInstallDate = DbConnection.readDate(resultSet, "SERVICEINSTALLDATE");
                if(serviceInstallDate != null)
                {
                    solrInputDocument.addField("serviceInstallDate", serviceInstallDate);
                }
                tspCode = DbConnection.readString(resultSet, "TSPCODE");
                if(tspCode != null)
                {
                    solrInputDocument.addField("tspCode", tspCode);
                }
                sourceCustomerNumber = DbConnection.readString(resultSet, "SOURCECUSTOMERNUMBER");
                if(sourceCustomerNumber != null)
                {
                    solrInputDocument.addField("sourceCustomerNumber", sourceCustomerNumber);
                }
                diversityTrailName = DbConnection.readString(resultSet, "DIVERSITYTRAILNAME");
                if(diversityTrailName != null)
                {
                    solrInputDocument.addField("diversityTrailName", diversityTrailName);
                }
                diversitySecondTrailName = DbConnection.readString(resultSet, "DIVERSITYSECONDTRAILNAME");
                if(diversitySecondTrailName != null)
                {
                    solrInputDocument.addField("diversitySecondTrailName", diversitySecondTrailName);
                }
                bandwidthCode = DbConnection.readString(resultSet, "BANDWIDTHCODE");
                if(bandwidthCode != null)
                {
                    solrInputDocument.addField("bandwidthCode", bandwidthCode);
                }
                subBandwidthCode = DbConnection.readString(resultSet, "SUBBANDWIDTHCODE");
                if(subBandwidthCode != null)
                {
                    solrInputDocument.addField("subBandwidthCode", subBandwidthCode);
                }
                aEndClliCode = DbConnection.readString(resultSet, "AENDCLLICODE");
                if(aEndClliCode != null)
                {
                    solrInputDocument.addField("aEndClliCode", aEndClliCode);
                }
                zEndClliCode = DbConnection.readString(resultSet, "ZENDCLLICODE");
                if(zEndClliCode != null)
                {
                    solrInputDocument.addField("zEndClliCode", zEndClliCode);
                }
                legacyBillAccountNumber = DbConnection.readString(resultSet, "LEGACYBILLACCOUNTNUMBER");
                if(legacyBillAccountNumber != null)
                {
                    solrInputDocument.addField("legacyBillAccountNumber", legacyBillAccountNumber);
                }
                legacyLastServiceOrderNumber = DbConnection.readString(resultSet, "LEGACYLASTSERVICEORDERNUMBER");
                if(legacyLastServiceOrderNumber != null)
                {
                    solrInputDocument.addField("legacyLastServiceOrderNumber", legacyLastServiceOrderNumber);
                }
                legacySourceSystemCode = DbConnection.readString(resultSet, "LEGACYSOURCESYSTEMCODE");
                if(legacySourceSystemCode != null)
                {
                    solrInputDocument.addField("legacySourceSystemCode", legacySourceSystemCode);
                }
                legacyCircuitId = DbConnection.readString(resultSet, "LEGACYCIRCUITID");
                if(legacyCircuitId != null)
                {
                    solrInputDocument.addField("legacyCircuitId", legacyCircuitId);
                }
                customerPurchaseOrderNumber = DbConnection.readString(resultSet, "CUSTOMERPURCHASEORDERNUMBER");
                if(customerPurchaseOrderNumber != null)
                {
                    solrInputDocument.addField("customerPurchaseOrderNumber", customerPurchaseOrderNumber);
                }
                associatedOrderNumber = DbConnection.readString(resultSet, "ASSOCIATEDORDERNUMBER");
                if(associatedOrderNumber != null)
                {
                    solrInputDocument.addField("associatedOrderNumber", associatedOrderNumber);
                }
                latencyGuranteeLevelType = DbConnection.readString(resultSet, "LATENCYGURANTEELEVELTYPE");
                if(latencyGuranteeLevelType != null)
                {
                    solrInputDocument.addField("latencyGuranteeLevelType", latencyGuranteeLevelType);
                }
                latencyGuranteeValue = DbConnection.readLong(resultSet, "LATENCYGURANTEEVALUE");
                if(latencyGuranteeValue != null)
                {
                    solrInputDocument.addField("latencyGuranteeValue", latencyGuranteeValue);
                }
                latencyActualValue = DbConnection.readLong(resultSet, "LATENCYACTUALVALUE");
                if(latencyActualValue != null)
                {
                    solrInputDocument.addField("latencyActualValue", latencyActualValue);
                }
                ipVersionCode = DbConnection.readString(resultSet, "IPVERSIONCODE");
                if(ipVersionCode != null)
                {
                    solrInputDocument.addField("ipVersionCode", ipVersionCode);
                }
                equipmentConfigDescription = DbConnection.readString(resultSet, "EQUIPMENTCONFIGDESCRIPTION");
                if(equipmentConfigDescription != null)
                {
                    solrInputDocument.addField("equipmentConfigDescription", equipmentConfigDescription);
                }
                equipmentManufacturerName = DbConnection.readString(resultSet, "EQUIPMENTMANUFACTURERNAME");
                if(equipmentManufacturerName != null)
                {
                    solrInputDocument.addField("equipmentManufacturerName", equipmentManufacturerName);
                }
                equipmentServiceProviderName = DbConnection.readString(resultSet, "EQUIPMENTSERVICEPROVIDERNAME");
                if(equipmentServiceProviderName != null)
                {
                    solrInputDocument.addField("equipmentServiceProviderName", equipmentServiceProviderName);
                }
                equipmentMaintAgreementType = DbConnection.readString(resultSet, "EQUIPMENTMAINTAGREEMENTTYPE");
                if(equipmentMaintAgreementType != null)
                {
                    solrInputDocument.addField("equipmentMaintAgreementType", equipmentMaintAgreementType);
                }
                cnrJeopIndicator = DbConnection.readBoolean(resultSet, "CNRJEOPINDICATOR");
                if(cnrJeopIndicator != null)
                {
                    solrInputDocument.addField("cnrJeopIndicator", cnrJeopIndicator);
                }
                cnrJeopRaisedDate = DbConnection.readDate(resultSet, "CNRJEOPRAISEDDATE");
                if(cnrJeopRaisedDate != null)
                {
                    solrInputDocument.addField("cnrJeopRaisedDate", cnrJeopRaisedDate);
                }
                bundledServiceIndicator = DbConnection.readBoolean(resultSet, "BUNDLEDSERVICEINDICATOR");
                if(bundledServiceIndicator != null)
                {
                    solrInputDocument.addField("bundledServiceIndicator", bundledServiceIndicator);
                }
                ultimateServiceStatusCode = DbConnection.readString(resultSet, "ULTIMATESERVICESTATUSCODE");
                if(ultimateServiceStatusCode != null)
                {
                    solrInputDocument.addField("ultimateServiceStatusCode", ultimateServiceStatusCode);
                }
                billAccountNumber = DbConnection.readString(resultSet, "BILLACCOUNTNUMBER");
                if(billAccountNumber != null)
                {
                    solrInputDocument.addField("billAccountNumber", billAccountNumber);
                }
                parentBillAccountNumber = DbConnection.readString(resultSet, "PARENTBILLACCOUNTNUMBER");
                if(parentBillAccountNumber != null)
                {
                    solrInputDocument.addField("parentBillAccountNumber", parentBillAccountNumber);
                }
                activeBillIndicator = DbConnection.readBoolean(resultSet, "ACTIVEBILLINDICATOR");
                if(activeBillIndicator != null)
                {
                    solrInputDocument.addField("activeBillIndicator", activeBillIndicator);
                }
                enableAutoTicketIndicator = DbConnection.readBoolean(resultSet, "ENABLEAUTOTICKETINDICATOR");
                if(enableAutoTicketIndicator != null)
                {
                    solrInputDocument.addField("enableAutoTicketIndicator", enableAutoTicketIndicator);
                }
                protectType = DbConnection.readString(resultSet, "PROTECTTYPE");
                if(protectType != null)
                {
                    solrInputDocument.addField("protectType", protectType);
                }
                serviceLocationId = DbConnection.readLong(resultSet, "SERVICELOCATIONID");
                if(serviceLocationId != null)
                {
                    solrInputDocument.addField("serviceLocationId", serviceLocationId);
                }
                specialsId = DbConnection.readString(resultSet, "SPECIALSID");
                if(specialsId != null)
                {
                    solrInputDocument.addField("specialsId", specialsId);
                }
                sidActiveBillIndicator = DbConnection.readBoolean(resultSet, "SIDACTIVEBILLINDICATOR");
                if(sidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("sidActiveBillIndicator", sidActiveBillIndicator);
                }
                scidActiveBillIndicator = DbConnection.readBoolean(resultSet, "SCIDACTIVEBILLINDICATOR");
                if(scidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("scidActiveBillIndicator", scidActiveBillIndicator);
                }
                piidActiveBillIndicator = DbConnection.readBoolean(resultSet, "PIIDACTIVEBILLINDICATOR");
                if(piidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("piidActiveBillIndicator", piidActiveBillIndicator);
                }
                pcsidActiveBillIndicator = DbConnection.readBoolean(resultSet, "PCSIDACTIVEBILLINDICATOR");
                if(pcsidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("pcsidActiveBillIndicator", pcsidActiveBillIndicator);
                }
                componentSubTypeName = DbConnection.readString(resultSet, "COMPONENTSUBTYPENAME");
                if(componentSubTypeName != null)
                {
                    solrInputDocument.addField("componentSubTypeName", componentSubTypeName);
                }
                billAccountName = DbConnection.readString(resultSet, "BILLACCOUNTNAME");
                if(billAccountName != null)
                {
                    solrInputDocument.addField("billAccountName", billAccountName);
                }
                serviceClassLevelType = DbConnection.readString(resultSet, "SERVICECLASSLEVELTYPE");
                if(serviceClassLevelType != null)
                {
                    solrInputDocument.addField("serviceClassLevelType", serviceClassLevelType);
                }
                /*
                circuitId = DbConnection.readString(resultSet, "CIRCUITID");
                if(circuitId != null)
                {
                    solrInputDocument.addField("circuitId", circuitId);
                }
                serviceId = DbConnection.readString(resultSet, "SERVICEID");
                if(serviceId != null)
                {
                    solrInputDocument.addField("serviceId", serviceId);
                }
                */
                aLine1Address = DbConnection.readString(resultSet, "ALINE1ADDRESS");
                if(aLine1Address != null)
                {
                    solrInputDocument.addField("aLine1Address", aLine1Address);
                }
                aLine2Address = DbConnection.readString(resultSet, "ALINE2ADDRESS");
                if(aLine2Address != null)
                {
                    solrInputDocument.addField("aLine2Address", aLine2Address);
                }
                aCityName = DbConnection.readString(resultSet, "ACITYNAME");
                if(aCityName != null)
                {
                    solrInputDocument.addField("aCityName", aCityName);
                }
                aStateCode = DbConnection.readString(resultSet, "ASTATECODE");
                if(aStateCode != null)
                {
                    solrInputDocument.addField("aStateCode", aStateCode);
                }
                aPostalCode = DbConnection.readString(resultSet, "APOSTALCODE");
                if(aPostalCode != null)
                {
                    solrInputDocument.addField("aPostalCode", aPostalCode);
                }
                aCountyName = DbConnection.readString(resultSet, "ACOUNTYNAME");
                if(aCountyName != null)
                {
                    solrInputDocument.addField("aCountyName", aCountyName);
                }
                aCountryName = DbConnection.readString(resultSet, "ACOUNTRYNAME");
                if(aCountryName != null)
                {
                    solrInputDocument.addField("aCountryName", aCountryName);
                }
                aLatitudeNumber = DbConnection.readDouble(resultSet, "ALATITUDENUMBER");
                if(aLatitudeNumber != null)
                {
                    solrInputDocument.addField("aLatitudeNumber", aLatitudeNumber);
                }
                aLongitudeNumber = DbConnection.readDouble(resultSet, "ALONGITUDENUMBER");
                if(aLongitudeNumber != null)
                {
                    solrInputDocument.addField("aLongitudeNumber", aLongitudeNumber);
                }
                zLine1Address = DbConnection.readString(resultSet, "ZLINE1ADDRESS");
                if(zLine1Address != null)
                {
                    solrInputDocument.addField("zLine1Address", zLine1Address);
                }
                zLine2Address = DbConnection.readString(resultSet, "ZLINE2ADDRESS");
                if(zLine2Address != null)
                {
                    solrInputDocument.addField("zLine2Address", zLine2Address);
                }
                zCityName = DbConnection.readString(resultSet, "ZCITYNAME");
                if(zCityName != null)
                {
                    solrInputDocument.addField("zCityName", zCityName);
                }
                zStateCode = DbConnection.readString(resultSet, "ZSTATECODE");
                if(zStateCode != null)
                {
                    solrInputDocument.addField("zStateCode", zStateCode);
                }
                zPostalCode = DbConnection.readString(resultSet, "ZPOSTALCODE");
                if(zPostalCode != null)
                {
                    solrInputDocument.addField("zPostalCode", zPostalCode);
                }
                zCountyName = DbConnection.readString(resultSet, "ZCOUNTYNAME");
                if(zCountyName != null)
                {
                    solrInputDocument.addField("zCountyName", zCountyName);
                }
                zCountryName = DbConnection.readString(resultSet, "ZCOUNTRYNAME");
                if(zCountryName != null)
                {
                    solrInputDocument.addField("zCountryName", zCountryName);
                }
                zLatitudeNumber = DbConnection.readDouble(resultSet, "ZLATITUDENUMBER");
                if(zLatitudeNumber != null)
                {
                    solrInputDocument.addField("zLatitudeNumber", zLatitudeNumber);
                }
                zLongitudeNumber = DbConnection.readDouble(resultSet, "ZLONGITUDENUMBER");
                if(zLongitudeNumber != null)
                {
                    solrInputDocument.addField("zLongitudeNumber", zLongitudeNumber);
                }
                aLocationId = DbConnection.readString(resultSet, "ALOCATIONID");
                if(aLocationId != null)
                {
                    solrInputDocument.addField("aLocationId", aLocationId);
                }
                zLocationId = DbConnection.readString(resultSet, "ZLOCATIONID");
                if(zLocationId != null)
                {
                    solrInputDocument.addField("zLocationId", zLocationId);
                }
                aLocationName = DbConnection.readString(resultSet, "ALOCATIONNAME");
                if(aLocationName != null)
                {
                    solrInputDocument.addField("aLocationName", aLocationName);
                }
                zLocationName = DbConnection.readString(resultSet, "ZLOCATIONNAME");
                if(zLocationName != null)
                {
                    solrInputDocument.addField("zLocationName", zLocationName);
                }
                aTimezoneName = DbConnection.readString(resultSet, "ATIMEZONENAME");
                if(aTimezoneName != null)
                {
                    solrInputDocument.addField("aTimezoneName", aTimezoneName);
                }
                zTimezoneName = DbConnection.readString(resultSet, "ZTIMEZONENAME");
                if(zTimezoneName != null)
                {
                    solrInputDocument.addField("zTimezoneName", zTimezoneName);
                }
                aDokuvizId = DbConnection.readString(resultSet, "ADOKUVIZID");
                if(aDokuvizId != null)
                {
                    solrInputDocument.addField("aDokuvizId", aDokuvizId);
                }
                zDokuvizId = DbConnection.readString(resultSet, "ZDOKUVIZID");
                if(zDokuvizId != null)
                {
                    solrInputDocument.addField("zDokuvizId", zDokuvizId);
                }
                aLocationNumber = DbConnection.readLong(resultSet, "ALOCATIONNUMBER");
                if(aLocationNumber != null)
                {
                    solrInputDocument.addField("aLocationNumber", aLocationNumber);
                }
                zLocationNumber = DbConnection.readLong(resultSet, "ZLOCATIONNUMBER");
                if(zLocationNumber != null)
                {
                    solrInputDocument.addField("zLocationNumber", zLocationNumber);
                }
                aRegionCode = DbConnection.readString(resultSet, "AREGIONCODE");
                if(aRegionCode != null)
                {
                    solrInputDocument.addField("aRegionCode", aRegionCode);
                }
                zRegionCode = DbConnection.readString(resultSet, "ZREGIONCODE");
                if(zRegionCode != null)
                {
                    solrInputDocument.addField("zRegionCode", zRegionCode);
                }
                vpnId = DbConnection.readString(resultSet, "VPNID");
                if(vpnId != null)
                {
                    solrInputDocument.addField("vpnId", vpnId);
                }
                ticketingProductName = DbConnection.readString(resultSet, "TICKETINGPRODUCTNAME");
                if(ticketingProductName != null)
                {
                    solrInputDocument.addField("ticketingProductName", ticketingProductName);
                }
                ticketingProductFamilyName = DbConnection.readString(resultSet, "TICKETINGPRODUCTFAMILYNAME");
                if(ticketingProductFamilyName != null)
                {
                    solrInputDocument.addField("ticketingProductFamilyName", ticketingProductFamilyName);
                }
                ticketingParentServiceId = DbConnection.readString(resultSet, "TICKETINGPARENTSERVICEID");
                if(ticketingParentServiceId != null)
                {
                    solrInputDocument.addField("ticketingParentServiceId", ticketingParentServiceId);
                }
                classOfServiceClassType = DbConnection.readString(resultSet, "CLASSOFSERVICECLASSTYPE");
                if(classOfServiceClassType != null)
                {
                    solrInputDocument.addField("classOfServiceClassType", classOfServiceClassType);
                }
                classOfServiceAllocationType = DbConnection.readString(resultSet, "CLASSOFSERVICEALLOCATIONTYPE");
                if(classOfServiceAllocationType != null)
                {
                    solrInputDocument.addField("classOfServiceAllocationType", classOfServiceAllocationType);
                }
                multiServiceAllocationType = DbConnection.readString(resultSet, "MULTISERVICEALLOCATIONTYPE");
                if(multiServiceAllocationType != null)
                {
                    solrInputDocument.addField("multiServiceAllocationType", multiServiceAllocationType);
                }
                committedDataRateMbps = DbConnection.readDouble(resultSet, "COMMITTEDDATARATEMBPS");
                if(committedDataRateMbps != null)
                {
                    solrInputDocument.addField("committedDataRateMbps", committedDataRateMbps);
                }
                peakInformationRateMbps = DbConnection.readDouble(resultSet, "PEAKINFORMATIONRATEMBPS");
                if(peakInformationRateMbps != null)
                {
                    solrInputDocument.addField("peakInformationRateMbps", peakInformationRateMbps);
                }
                parentCircuitServiceId = DbConnection.readString(resultSet, "PARENTCIRCUITSERVICEID");
                if(parentCircuitServiceId != null)
                {
                    solrInputDocument.addField("parentCircuitServiceId", parentCircuitServiceId);
                }
                orderProductInstanceId = DbConnection.readString(resultSet, "ORDERPRODUCTINSTANCEID");
                if(orderProductInstanceId != null)
                {
                    solrInputDocument.addField("orderProductInstanceId", orderProductInstanceId);
                }
                orderServiceComponentId = DbConnection.readString(resultSet, "ORDERSERVICECOMPONENTID");
                if(orderServiceComponentId != null)
                {
                    solrInputDocument.addField("orderServiceComponentId", orderServiceComponentId);
                }
                equipmentSerialNumber = DbConnection.readString(resultSet, "EQUIPMENTSERIALNUMBER");
                if(equipmentSerialNumber != null)
                {
                    solrInputDocument.addField("equipmentSerialNumber", equipmentSerialNumber);
                }
                diverseRoleType = DbConnection.readString(resultSet, "DIVERSEROLETYPE");
                if(diverseRoleType != null)
                {
                    solrInputDocument.addField("diverseRoleType", diverseRoleType);
                }
                billType = DbConnection.readString(resultSet, "BILLTYPE");
                if(billType != null)
                {
                    solrInputDocument.addField("billType", billType);
                }
                vendorName = DbConnection.readString(resultSet, "VENDORNAME");
                if(vendorName != null)
                {
                    solrInputDocument.addField("vendorName", vendorName);
                }
                vendorCircuitId = DbConnection.readString(resultSet, "VENDORCIRCUITID");
                if(vendorCircuitId != null)
                {
                    solrInputDocument.addField("vendorCircuitId", vendorCircuitId);
                }
                primaryControllerName = DbConnection.readString(resultSet, "PRIMARYCONTROLLERNAME");
                if(primaryControllerName != null)
                {
                    solrInputDocument.addField("primaryControllerName", primaryControllerName);
                }
                primaryDirectorName = DbConnection.readString(resultSet, "PRIMARYDIRECTORNAME");
                if(primaryDirectorName != null)
                {
                    solrInputDocument.addField("primaryDirectorName", primaryDirectorName);
                }
                servicePropertyListTxt = DbConnection.readString(resultSet, "SERVICEPROPERTYLISTTXT");
                if(servicePropertyListTxt != null)
                {
                    solrInputDocument.addField("servicePropertyListTxt", servicePropertyListTxt);
                }
                serviceMgmtTyp = DbConnection.readString(resultSet, "SERVICEMGMTTYP");
                if(serviceMgmtTyp != null)
                {
                    solrInputDocument.addField("serviceMgmtTyp", serviceMgmtTyp);
                }
                financeAccountNbr = DbConnection.readString(resultSet, "FINANCEACCOUNTNBR");
                if(financeAccountNbr != null)
                {
                    solrInputDocument.addField("financeAccountNbr", financeAccountNbr);
                }
                orderSourceSystemName = DbConnection.readString(resultSet, "ORDERSOURCESYSTEMNAME");
                if(orderSourceSystemName != null)
                {
                    solrInputDocument.addField("orderSourceSystemName", orderSourceSystemName);
                }
                billAcctSourceSystemCd = DbConnection.readString(resultSet, "BILLACCTSOURCESYSTEMCD");
                if(billAcctSourceSystemCd != null)
                {
                    solrInputDocument.addField("billAcctSourceSystemCd", billAcctSourceSystemCd);
                }		
                
                solrInputDocument.addField("solrDocumentUpdateDate", this.manager.getDocumentUpdateDate());

                documentList.add(solrInputDocument);
                documentsCommitted++;
                
                if (documentList.size() >= this.batchSize)
                {
                    indexer = new ServiceLookupIndexer(this.manager, documentList);
                    
                    // submit this task for execution
                    PooledExecutors.instance().execute(ServiceLookupManager.SLV_INDEXER, indexer);
                    
                    documentList = new ArrayList<SolrInputDocument>();

                    log.info("filter criteria \"{}\", documents committed to Solr :{}", filterCriteria, documentsCommitted);
                }
            }
        }
        catch (Exception e)
        {
            log.error("caught exception while trying to add to Solr index.", e);
            
            for(SolrInputDocument inputDocument : documentList)
            {
                log.info("Document list for batch that had error\nID :{}, content : {}", inputDocument.getFieldValue("id"), inputDocument.toString());
            }
            
            // stop the process or mark run as failure
            manager.updateFailure();
        }
        finally
        {
            slvConn.destroy();
        }
    }

    private void finishIndexing()
    {
        try
        {
            if (documentList.size() > 0)
            {
                ServiceLookupIndexer indexer = new ServiceLookupIndexer(this.manager, documentList);
                    
                // submit this task for execution
                PooledExecutors.instance().execute(ServiceLookupManager.SLV_INDEXER, indexer);
                    
                log.info("filter criteria \"{}\", total documents committed to Solr :{}", filterCriteria, documentsCommitted);
            }
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to finish indexing.", ex);

            for(SolrInputDocument inputDocument : documentList)
            {
                log.info("ID :{}, content : {}", inputDocument.getFieldValue("id"), inputDocument.toString());
            }

            manager.updateFailure();
        }
    }
}
