package com.level3.km.dataimport.resource;

import javax.ws.rs.core.Response;

public interface IDataImport
{
    public Response dataimport();
    
    public void finishDataImport();
}
