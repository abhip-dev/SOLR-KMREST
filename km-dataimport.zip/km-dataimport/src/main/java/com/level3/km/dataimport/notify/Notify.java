package com.level3.km.dataimport.notify;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Notify
{
    private static Logger log = LoggerFactory.getLogger(Notify.class);

    public static void sendFailureNotification(String zkHostName, String collectionName)
    {
        String message = null;

        try
        {
            log.info("Sending failure message.");

            message = constructFailureMessage(zkHostName, collectionName);

            sendMessageUsingEmail(message, zkHostName, collectionName);
        }
        catch (Throwable t)
        {
            log.error("Failed to send email message", t);

            logMessage(message);
        }
    }

    private static String constructFailureMessage(String zkHostName, String collectionName)
    {
        StringBuffer strBuf = new StringBuffer();

        strBuf.append("Service Lookup DataImporter failure.\n");
        strBuf.append("ZK Host Name: ");
        strBuf.append(zkHostName);
        strBuf.append(", Collection Name: ");
        strBuf.append(collectionName);

        return strBuf.toString();
    }
   
    private static void sendMessageUsingEmail(String aMessage, String zkHostName, String collectionName)
    {
        try
        {
            // get the Message object populated with Address fields
            MimeMessage message = setMessage();

            if (message == null)
            {
                log.info("Failed to get a MimeMessage, aborting send.");

                logMessage(aMessage);

                return;
            }

            // set the subject
            message.setSubject("ServiceLookup Data importer failed, please rerun data import - " + zkHostName + " - " + collectionName);

            // set the message
            message.setText(aMessage);

            // send the message
            Transport.send(message);
        }
        catch (Exception e)
        {
            log.error("Caught exception while trying to send mail", e);

            logMessage(aMessage);
        }
    }

    private static MimeMessage setMessage()
    {
        try
        {
            String mailServerName = "intmail.level3.com";
            String fromAddress = "nitin.agarwal@level3.com";
            String toAddress = "DL-KMDatalakeApplicationSupport@level3.com";

            // set up the message and other stuff for sending a message
            MimeMessage message = setupMail(mailServerName);

            if (message == null)
            {
                return null;
            }

            message.setFrom(new InternetAddress(fromAddress));

            // set the to Address List
            message.addRecipients(Message.RecipientType.TO,
                    getAddressArray(toAddress));

            return message;
        }
        catch (MessagingException mesgEx)
        {
            log.error("Exception occured while trying to setup Message object",
                    mesgEx);

            return null;
        }
    }

    private static Address[] getAddressArray(String toAddress)
    {
        String[] addressStringArray = toAddress.split(",");
        Address[] addressArray = new InternetAddress[addressStringArray.length];

        int index = 0;
        for (String address : addressStringArray)
        {
            try
            {
                addressArray[index++] = new InternetAddress(address);
            }
            catch (AddressException ae)
            {
                log.error(
                        "Exception occured while trying to create Address array",
                        ae);
            }
        }

        return addressArray;
    }

    private static MimeMessage setupMail(String mailServerName)
    {
        try
        {
            if (mailServerName == null || mailServerName.equals(""))
            {
                log.info("Mail server not found");

                return null;
            }

            // get properties
            Properties props = new Properties();

            // set up SMTP mail server
            props.put("mail.smtp.host", mailServerName);

            // get Session
            Session session = Session.getDefaultInstance(props, null);

            // Define Message
            MimeMessage message = new MimeMessage(session);

            return message;
        }
        catch (Exception e)
        {
            log.error("Exception occured while initializing Message object", e);

            return null;
        }
    }

    private static void logMessage(String aMessage)
    {
        log.info("Failed to deliver message [" + aMessage + "]");
    }
}
