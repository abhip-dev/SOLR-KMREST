package com.level3.km.dataimport.customerBillAccountNumber;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.dataimport.config.CustomerBillAccountNumberConfig;

public class CustomerBillAccountNumberManager
{
    private static Logger log = LoggerFactory.getLogger(CustomerBillAccountNumberManager.class); 

    private static CommandLine commandLine     = null;
    private String[]           commandLineArgs = null;
    private Options            options         = null;

    private static final String ZK_HOST_CHAR = "z";
    private static final String ZK_HOST_STRING = "zkHost";
    
    private static final String SOLR_COLLECTION_CHAR = "c";
    private static final String SOLR_COLLECTION_STRING = "solrCollection";
    
    private static final String SOLR_COLLECTION_ID_CHAR = "i";
    private static final String SOLR_COLLECTION_ID_STRING = "solrCollectionIdField";
    
    public CustomerBillAccountNumberManager(String[] args)
    {
        this.commandLineArgs = args;
        this.options = new Options();
        processCommandLine();
    }
    
    public void cleanDuplicateBillAccountNumbers()
    {
        String zkHost = commandLine.getOptionValue(ZK_HOST_CHAR); 
        String solrCollectionName = commandLine.getOptionValue(SOLR_COLLECTION_CHAR); 
        String solrCollectionId = commandLine.getOptionValue(SOLR_COLLECTION_ID_CHAR); 

        CustomerBillAccountNumberConfig config = new CustomerBillAccountNumberConfig();
        config.setZkHost(zkHost);
        config.setCollectionName(solrCollectionName);
        config.setCollectionIdField(solrCollectionId);

        DataCleaner cleaner = new DataCleaner(config);
        cleaner.getDuplicatedBillAccounts();
    }

    private void processCommandLine()
    {
        // Handle command line argument processing
        addOption( ZK_HOST_CHAR, ZK_HOST_STRING, "zookeeper host string", true, true);
        addOption( SOLR_COLLECTION_CHAR, SOLR_COLLECTION_STRING, "solr collection name", true, true);
        addOption( SOLR_COLLECTION_ID_CHAR, SOLR_COLLECTION_ID_STRING, "solr collection ID field", true, true);
        
        CommandLineParser parser = new GnuParser();
        try
        {
            commandLine = parser.parse( options, commandLineArgs );
        }
        catch ( ParseException e )
        {
            // Automatically generate the help statement
            StringBuffer cli = new StringBuffer();
            for ( String s : commandLineArgs )
            {
                cli.append( s + " " );
            }
            log.info( cli.toString() + "\n" );
            
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("java -jar km-dataimport.jar", null, options, null, true);
            
            System.exit( 1 );
        }
    }

    private void addOption(
            String shortOption, String longOption, String description, boolean hasArg, boolean required)
    {
        Option option = createOption(shortOption, longOption, description, hasArg, required);
        options.addOption(option);
    }

    private Option createOption(
            String shortOption, String longOption, String description, boolean hasArg, boolean required)
    {
        Option option = new Option(shortOption, longOption, hasArg, description);
        option.setRequired(required);

        return option;
    }

    public static void main(String[] args)
    {
        // DEV
        // config.setZkHost("10.5.168.143:2181");

        // TEST ADC
        //            config.setZkHost("yy7-01:2181,yy7-03:2181,aaa7-04:2181");

        // TEST IDC
        //            config.setZkHost("m14-15:2181,n14-15:2181,m14-17:2181");

        // PROD ADC
        //            config.setZkHost("ddd7-01:2181,eee7-01:2181,ggg7-01:2181,iii7-01:2181,jjj7-01:2181");

        // PROD IDC
        //            config.setZkHost("n14-17:2181,m14-19:2181,n14-19:2181,m14-21:2181,n14-21:2181");

        log.info("Starting cleanup of duplicate bill account numbers in custban data.");

        CustomerBillAccountNumberManager manager = new CustomerBillAccountNumberManager(args);
        
        manager.cleanDuplicateBillAccountNumbers();

        log.info("Completed cleanup of duplicate bill account numbers in custban data.");
    }
}
