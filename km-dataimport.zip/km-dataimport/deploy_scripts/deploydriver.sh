#!/bin/sh
# -------------------------------------------------------------
# This script is a wrapper around the automated deployment process.
# Its job is to control the deployment process and call the necessary
# scripts to get the job done
#
# Arguments:
# $1 - The environment to deploy for
#
# --------------------------------------------------------------


if [ "$#" -lt 2 ]
then
  echo "Incorrect number of arguments."
  echo "Usage: deploydriver.sh environment password"
  exit 1
fi

echo "Environment is $1"

ENVIRONMENT=$(echo $1 | tr "[:upper:]" "[:lower:]")

echo "ENVIRONMENT is $ENVIRONMENT"
PASSWD=$2

DATE_FORMAT=`date +%Y%m%d:%H:%M:%S`

DEPLOY_DIR=${PWD}
SCRIPTSDIR=${PWD}/deploy_scripts

echo "INFO: Preforming dos2unix on env_config files..."

for file in `find ./env_config -type f`; do
   dos2unix $file $file
done

echo "INFO: Preforming dos2unix on deploy script files..."

for file in `find ./deploy_scripts -type f`; do
   dos2unix $file $file
done


#check to see if there is a spcific properties file, if not use default
if [ ! -f "${PWD}/env_config/${ENVIRONMENT}_deploydriver.properties" ]; then
   echo "INFO: No ENV spcific deploydriver.properties file found, using \"default_deploydriver.properties\""
   DEPLOY_PROPERTIES="${PWD}/env_config/default_deploydriver.properties"
else
   echo "INFO: ENV spcific deploydriver.properties file found, using \"${ENVIRONMENT}_deploydriver.properties\""
   DEPLOY_PROPERTIES="${PWD}/env_config/${ENVIRONMENT}_deploydriver.properties"
fi

. ${DEPLOY_PROPERTIES}

if [ -f "${PWD}/env_config/${ENVIRONMENT}_deploydriver.properties" ]; then
   echo "Start property replacement"

   PASSWD1=`echo $PASSWD | awk '{split($0,a,"?"); print a[1]}'`
   PASSWD2=`echo $PASSWD | awk '{split($0,a,"?"); print a[2]}'`

   sed -i "s|@@kmdi_deploy_dir@@|${KMDI_DEPLOY_DIR}|g" ${PWD}/env_config/${RUNFILE_PREFIX}${ENVIRONMENT}${RUNFILE_EXTENSION}
   sed -i "s|@@solr_cloud_username@@|${SOLR_CLOUD_USERNAME}|g" ${PWD}/env_config/${RUNFILE_PREFIX}${ENVIRONMENT}${RUNFILE_EXTENSION}
   sed -i "s|@@solr_cloud_passwd@@|${PASSWD1}|g" ${PWD}/env_config/${RUNFILE_PREFIX}${ENVIRONMENT}${RUNFILE_EXTENSION}
   sed -i "s|@@cert_store_passwd@@|${PASSWD2}|g" ${PWD}/env_config/${RUNFILE_PREFIX}${ENVIRONMENT}${RUNFILE_EXTENSION}
fi

#Start the deployment Tasks
if ! /usr/bin/sudo su - ${UNIX_USER} -c "${SCRIPTSDIR}/deploy.sh ${ENVIRONMENT} ${DEPLOY_DIR} ${DEPLOY_PROPERTIES} "; then
    echo "ERROR: deploydriver.sh: deploy.sh script failed to complete successfully"
    exit 1
fi

echo "deploydriver.sh Done"
echo "exiting..."
exit 0
