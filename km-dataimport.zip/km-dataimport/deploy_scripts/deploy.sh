#!/bin/sh
# -------------------------------------------------------------
# This script is a wrapper around the automated deployment process.
# Its job is to control the deployment process and call the necessary
# scripts to get the job done
#
# Arguments:
# $1 - The environment to deploy for
#
# --------------------------------------------------------------

echo "INFO: Now entering \"${PWD}/deploy.sh\" script"

ENVIRONMENT=$1
DEPLOY_DIR=$2
DEPLOY_PROPERTIES=$3

# Source properties files
. ${DEPLOY_PROPERTIES}

KMDI_DEPLOY_LOG_DIR=${KMDI_DEPLOY_DIR}/logs

# check if KMDI_DEPLOY_DIR exists, if not create it
[ -d ${KMDI_DEPLOY_DIR} ] || mkdir -p ${KMDI_DEPLOY_DIR}

# check if KMDI_DEPLOY_LOG_DIR exists, if not create it
[ -d ${KMDI_DEPLOY_LOG_DIR} ] || mkdir -p ${KMDI_DEPLOY_LOG_DIR}

# remove existing jar files
rm -rf ${KMDI_DEPLOY_DIR}/*.jar
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
   echo "FAILED to REMOVE jars from ${KMDI_DEPLOY_DIR}, exit status ${RETVAL}"
   exit ${RETVAL};
fi

# copy the new jar files over to deployment dir
for ZIP in `ls ${DEPLOY_DIR}/dist/*.zip`
do
   ZIP_FILE_NAME=`echo ${ZIP} | sed -e 's/.*\/dist\///'`
   echo "FOUND zip file ${ZIP_FILE_NAME}"

   unzip $ZIP -d ${KMDI_DEPLOY_DIR}
   if [ $RETVAL -ne 0 ]
   then
      echo "FAILED to deploy jars to ${KMDI_DEPLOY_DIR}, exit status ${RETVAL}"
      exit ${RETVAL};
   fi
done

# copy over run script
cp ${DEPLOY_DIR}/env_config/${RUNFILE_PREFIX}${ENVIRONMENT}${RUNFILE_EXTENSION} ${KMDI_DEPLOY_DIR}
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
   echo "FAILED to COPY run file ${RUNFILE_PREFIX}${ENVIRONMENT}${RUNFILE_EXTENSION} to ${KMDI_DEPLOY_DIR}, exit status ${RETVAL}"
   exit ${RETVAL};
fi

# Deploy other files
for FILE in ${FILES}; do
   echo "INFO: Copying ${FILE} to ${KMDI_DEPLOY_DIR} directory on ${ENVIRONMENT}"
   cp ${DEPLOY_DIR}/env_config/${ENVIRONMENT}_${FILE} ${KMDI_DEPLOY_DIR}/${FILE}
   RETVAL=$?
   if [ $RETVAL -ne 0 ]
   then
      echo "WARN: Was not able to copy \"${FILE}\" to \"${KMDI_DEPLOY_DIR}\", check /tmp/pandaErr.log for more info"
      exit ${RETVAL};
    fi
  done

echo "INFO: Now leaving \"${PWD}/deploy.sh\" script"
