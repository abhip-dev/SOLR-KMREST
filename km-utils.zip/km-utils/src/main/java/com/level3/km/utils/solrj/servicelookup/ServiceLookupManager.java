package com.level3.km.utils.solrj.servicelookup;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.io.FileUtils;
import org.apache.solr.client.solrj.impl.BinaryRequestWriter;
import org.apache.solr.client.solrj.impl.BinaryResponseParser;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.cloud.SolrZkClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.utils.solrj.config.PropertyManager;
import com.level3.km.utils.solrj.config.ServiceLookupConfig;
import com.level3.km.utils.solrj.thread.PooledExecutors;

public class ServiceLookupManager
{
    private static Logger log = LoggerFactory.getLogger(ServiceLookupManager.class); 

    private static DateFormat df = null;
	private static final String SOLJ_DATE_FMT = "yyyy-MM-dd'T'HH:mm:ss'Z'" ; 

    public static final String SLV_EXECUTOR = "slvExecutor";
    public static final String SLV_INDEXER = "slvIndexer";
    private static final String SLV_CRITERIA_1 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT = 'Business POTS'";
    private static final String SLV_CRITERIA_2 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT = 'Centrex On-Switch Analog'";
    private static final String SLV_CRITERIA_3 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT = 'ISDN-PRI'";
    private static final String SLV_CRITERIA_4 = "WHERE slv.SOURCE_SYS_NM = 'OEOM_TELCOVE' AND slv.PRODUCT NOT IN('Business POTS', 'Centrex On-Switch Analog', 'ISDN-PRI')";
    private static final String SLV_CRITERIA_5 = "WHERE slv.SOURCE_SYS_NM = 'EON'";
    private static final String SLV_CRITERIA_6 = "WHERE slv.SOURCE_SYS_NM = 'SIEBEL'";
    private static final String SLV_CRITERIA_7 = "WHERE slv.SOURCE_SYS_NM = 'SIEBEL6_LATAM'";
    private static final String SLV_CRITERIA_8 = "WHERE slv.SOURCE_SYS_NM = 'PIPELINE'";
    private static final String SLV_CRITERIA_9 = "WHERE slv.SOURCE_SYS_NM = 'REMEDY_TELCOVE'";
    private static final String SLV_CRITERIA_10 = "WHERE slv.SOURCE_SYS_NM NOT IN('OEOM_TELCOVE', 'EON', 'SIEBEL', 'SIEBEL6_LATAM', 'PIPELINE', 'REMEDY_TELCOVE')";
    private static final String DATAIMPORT_JSON_ZK_PATH = "/dih/servicelookup/dataimport.properties";
    
    private CloudSolrClient solrClient = null;
    private CountDownLatch countdownLatch = null;
    private AtomicBoolean isBusy = null;
    
    private static String documentUpdateDate = null;
    
    private AtomicLong recordCounter = null;
    private Date processStartTime = null;
    private Date processStopTime = null;
    private ScheduledExecutorService statusPool = null;
    
    private BlockingQueue<Runnable> indexerQueue = new ArrayBlockingQueue<Runnable>(10);
    
    private ServiceLookupConfig config = null;
    
    static
    {
        TimeZone tz = TimeZone.getTimeZone("UTC");
        df = new SimpleDateFormat(SOLJ_DATE_FMT);
        df.setTimeZone(tz);
        documentUpdateDate = df.format(new Date());
        
        log.info("Document Update Date: {}", documentUpdateDate);
    }

    public ServiceLookupManager(ServiceLookupConfig config)
    {
        init(config);
    }
    
    private void init(ServiceLookupConfig config)
    {
        this.processStartTime = new Date();
        this.config = config;
        this.isBusy = new AtomicBoolean(true);

        solrClient = new CloudSolrClient.Builder().withZkHost(config.getZkHostAsList()).sendDirectUpdatesToShardLeadersOnly().build();
        solrClient.setDefaultCollection(config.getCollectionName());
        solrClient.setIdField(config.getCollectionIdField());
        solrClient.setZkClientTimeout(1000);
        solrClient.setZkConnectTimeout(1000);
        solrClient.setParser(new BinaryResponseParser());
        solrClient.setRequestWriter(new BinaryRequestWriter());
            
        recordCounter = new AtomicLong(0L);

        // instantiate a ThreadPool executor for loading slv data
        PooledExecutors.instance().createThreadPool(SLV_EXECUTOR, 10, 10, 60L, TimeUnit.SECONDS);
        // instantiate a ThreadPool executor for indexing SLV data into SOLR
        PooledExecutors.instance().createThreadPool(SLV_INDEXER, 10, 10, 60L, TimeUnit.SECONDS, indexerQueue);
        
        statusPool = Executors.newSingleThreadScheduledExecutor();
        
        statusPool.scheduleAtFixedRate(new StatusReporterTask(this), 0, 60, TimeUnit.SECONDS);
    }
    
    public ServiceLookupConfig getConfig()
    {
        return this.config;
    }
    
    public Status status()
    {
        Status status = new Status();
        status.setStartTime(this.processStartTime);
        status.setStopTime(processStopTime == null ? new Date() : processStopTime);
        status.setRecordsProcessed(this.recordCounter.get());
        status.setIsBusy(this.isBusy.get());
        
        return status;
    }

    public void process()
    {
        int commandCount = 0;
        ServiceLookupDataReader command1 = null;
        ServiceLookupDataReader command2 = null;
        ServiceLookupDataReader command3 = null;
        ServiceLookupDataReader command4 = null;
        ServiceLookupDataReader command5 = null;
        ServiceLookupDataReader command6 = null;
        ServiceLookupDataReader command7 = null;
        ServiceLookupDataReader command8 = null;
        ServiceLookupDataReader command9 = null;
        ServiceLookupDataReader command10 = null;
        
        ServiceRelationShipManager relationShipManager = new ServiceRelationShipManager(PropertyManager.instance().getServiceRelationShipConfig());
        
        relationShipManager.process();

        // query and delete old records
        deleteOldRecords();
        
        // setup a Latch
        // send the requests to the ThreadPool for processing
        // once Latch has counted down to zero, we are ready to load SLV data
        log.info("Starting indexing of Service lookup data in SOLR.");
        
        command1 = new ServiceLookupDataReader(SLV_CRITERIA_1, this);
        commandCount++;

        command2 = new ServiceLookupDataReader(SLV_CRITERIA_2, this);
        commandCount++;
            
        command3 = new ServiceLookupDataReader(SLV_CRITERIA_3, this);
        commandCount++;
            
        command4 = new ServiceLookupDataReader(SLV_CRITERIA_4, this);
        commandCount++;
            
        command5 = new ServiceLookupDataReader(SLV_CRITERIA_5, this);
        commandCount++;
            
        command6 = new ServiceLookupDataReader(SLV_CRITERIA_6, this);
        commandCount++;
            
        command7 = new ServiceLookupDataReader(SLV_CRITERIA_7, this);
        commandCount++;
            
        command8 = new ServiceLookupDataReader(SLV_CRITERIA_8, this);
        commandCount++;
            
        command9 = new ServiceLookupDataReader(SLV_CRITERIA_9, this);
        commandCount++;
            
        command10 = new ServiceLookupDataReader(SLV_CRITERIA_10, this);
        commandCount++;
            
        countdownLatch = new CountDownLatch(commandCount);

        PooledExecutors.instance().execute(SLV_EXECUTOR, command1);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command2);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command3);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command4);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command5);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command6);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command7);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command8);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command9);
        PooledExecutors.instance().execute(SLV_EXECUTOR, command10);

        try
        {
            if(!countdownLatch.await(90L, TimeUnit.MINUTES))
            {
                updateFailure();
                throw new RuntimeException("could not complete call in 90 minutes, aborting.");
            }
            
            // this should take place after all the jobs in SLV_INDEXER pool have finished.
            PooledExecutors.instance().shutdown(SLV_INDEXER);
            commit();
            
            // update properties in ZK
            updateDataImportProperties();
        }
        catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally
        {
            cleanup();
        }
    }
    
    public synchronized void countLatchDown()
    {
        countdownLatch.countDown();
    }
    
    public long addToRecordCounter(long countOfRecords)
    {
        return recordCounter.addAndGet(countOfRecords);
    }
    
    public static String getDocumentUpdateDate()
    {
        return documentUpdateDate;
    }
    
    public void addRecords(Collection<SolrInputDocument> documentList)
    {
        try
        {
            addToRecordCounter(documentList.size());

            UpdateResponse response = solrClient.add(documentList);
            
            if(response.getStatus() != 0)
            {
                log.info("Some horrible error has occurred, status is: " + response.getStatus());
            }
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to add records to Solr index.", ex);
            
            for(SolrInputDocument inputDocument : documentList)
            {
                log.info("Document list for batch that had error\nID :{}, content : {}", inputDocument.getFieldValue("id"), inputDocument.toString());
            }
            
            // stop the process or mark run as failure
            updateFailure();
        }
        finally
        {
            documentList.clear();
        }
    }
    
    private void deleteOldRecords()
    {
        String query = "-solrDocumentUpdateDate:[" + getDocumentUpdateDate() + " TO *]";
        
        try
        {
            log.info("Issuing query to delete old records: {}", query);

            UpdateResponse response = solrClient.deleteByQuery(query);
            
            if(response.getStatus() != 0)
            {
                log.info("Failed to delete old records.");
            }
            
            log.info("DELETE RESPONSE - {}", response);
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to delete old records from Solr index.", ex);
        }
    }
    
    private void commit()
    {
        try
        {
            UpdateResponse response = solrClient.commit();
            
            if(response.getStatus() != 0)
            {
                log.info("Failed to commit records to Solr.");
            }
            
            log.info("COMMIT RESPONSE - {}", response);
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to commit records to Solr index.", ex);
        }
    }
    
    private void updateDataImportProperties()
    {
        File file = null;
        SolrZkClient client = null;
        
        try
        {
            file = new File("dataimport.properties");
            FileUtils.writeStringToFile(file, "last_index_time=" + getDocumentUpdateDate());
            
            client = new SolrZkClient(config.getZkHost(), 1000, 1000);
            
            if(client.exists(DATAIMPORT_JSON_ZK_PATH, true))
            {
                client.setData(DATAIMPORT_JSON_ZK_PATH, file, true);
            }
            else
            {
                log.info("{} path not found in ZK {}", DATAIMPORT_JSON_ZK_PATH, config.getZkHost());
                client.makePath(DATAIMPORT_JSON_ZK_PATH, file, true);
            }
            
            FileUtils.deleteQuietly(file);
        }
        catch (Exception ex)
        {
            log.error("caught exception while trying to update dataimport.json in ZooKeeper", ex);
        }
    }
    
    public void updateFailure()
    {
        log.info("Data update failed, shuting down.");
        
        // TODO - figure out a way to gracefully shutdown threads in progress.
        try
        {
            solrClient.rollback();
            
            cleanup();
        }
        catch (Exception ex)
        {
            log.error("caught exception while trying to rollback records to Solr index.", ex);
        }
        
        System.exit(2);
    }

    private void cleanup()
    {
        this.processStopTime = new Date();
        this.isBusy.set(false);

        statusPool.execute(new StatusReporterTask(this));

        PooledExecutors.instance().shutdown(SLV_EXECUTOR);
        PooledExecutors.instance().shutdown(SLV_INDEXER);

        statusPool.shutdown();

        try
        {
            if(!statusPool.awaitTermination(30, TimeUnit.SECONDS))
            {
                statusPool.shutdownNow();
            }
        }
        catch (InterruptedException e)
        {

        }

    }

    public static void main(String[] args)
    {
        try
        {
            log.info("Starting indexing of Service lookup data.");

            ServiceLookupManager manager = new ServiceLookupManager(PropertyManager.instance().getServiceLookupConfig());
            
            manager.process();

            log.info("Completed indexing of service lookup data.");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            log.error("caught exception while trying to index service lookup data.", ex);
        }
        finally
        {
            System.exit(0);
        }
    }
    
    static class Status
    {
        private boolean isBusy = true;
        private Date startTime = null;
        private Date stopTime = null;
        private long recordsProcessed = -1;

        public Date getStartTime()
        {
            return startTime;
        }
        public void setStartTime(Date startTime)
        {
            this.startTime = startTime;
        }
        public Date getStopTime()
        {
            return stopTime;
        }
        public void setStopTime(Date stopTime)
        {
            this.stopTime = stopTime;
        }
        public long getRecordsProcessed()
        {
            return recordsProcessed;
        }
        public void setRecordsProcessed(long recordsProcessed)
        {
            this.recordsProcessed = recordsProcessed;
        }
        public Boolean isBusy()
        {
            return isBusy;
        }
        public void setIsBusy(boolean isBusy)
        {
            this.isBusy = isBusy;
        }
        
        public String getTimeElapsed()
        {
            long diff = stopTime.getTime() - startTime.getTime();
            
            long diffSeconds = diff / 1000 % 60;
            long diffMinutes = diff / (60 * 1000) % 60;
            long diffHours = diff / (60 * 60 * 1000) % 24;
            
            return diffHours + ":" + diffMinutes + ":" + diffSeconds;
        }

        @Override
        public String toString()
        {
            StringBuilder builder = new StringBuilder();
            builder.append("Status [isBusy=");
            builder.append(isBusy);
            builder.append(", startTime=");
            builder.append(ServiceLookupManager.df.format(startTime));
            builder.append(", stopTime=");
            builder.append(isBusy ? null : ServiceLookupManager.df.format(stopTime));
            builder.append(", recordsProcessed=");
            builder.append(recordsProcessed);
            builder.append(", timeElapsed=");
            builder.append(getTimeElapsed());
            builder.append("]");
            return builder.toString();
        }
    }
}
