package com.level3.km.utils.solrj.thread;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class PooledExecutors
{
    private static PooledExecutors instance = null;
    private static Object mutex = new int[ 1 ];
    
    private Map<String, ExecutorService> executorMap = null;
    
    private PooledExecutors()
    {
        executorMap = new HashMap<String, ExecutorService>();
    }
    
    public static PooledExecutors instance()
    {
        PooledExecutors tempInstance = null;
        
        if(instance == null)
        {
            synchronized (mutex)
            {
                if(instance == null)
                {
                    tempInstance = new PooledExecutors();
                    instance = tempInstance;
                }
            }
        }
        
        return instance;
    }
    
    public void createSingleThreadExecutor(final String threadPoolName)
    {
        ExecutorService executor = 
                Executors.newSingleThreadExecutor(new ThreadFactory()
                {
                    public Thread newThread(Runnable command)
                    {
                        Thread t = new Thread(command);
                        t.setName(threadPoolName + "-" + t.getName());
                        return t;
                    }
                });

        executorMap.put(threadPoolName, executor);
    }

    public void createThreadPool(final String threadPoolName, int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit)
    {
        ThreadPoolExecutor executor = 
                new ThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, unit, new LinkedBlockingQueue<Runnable>());
        
        executor.setThreadFactory(new ThreadFactory()
        {
            public Thread newThread(Runnable command)
            {
                Thread t = new Thread(command);
                t.setName(threadPoolName + "-" + t.getName());
                return t;
            }
        });
        
        executorMap.put(threadPoolName, executor);

        return;
    }

    public void createThreadPool(final String threadPoolName, int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> queue)
    {
        ThreadPoolExecutor executor = 
                new ThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, unit, queue, new ThreadPoolExecutor.CallerRunsPolicy());
        
        executor.setThreadFactory(new ThreadFactory()
        {
            public Thread newThread(Runnable command)
            {
                Thread t = new Thread(command);
                t.setName(threadPoolName + "-" + t.getName());
                return t;
            }
        });
        
        executorMap.put(threadPoolName, executor);

        return;
    }

    public void execute(String poolName, Runnable command)
    {
        Executor executor = executorMap.get(poolName);
        
        if(executor != null)
        {
            executor.execute(command);
        }
        else
        {
            throw new RuntimeException("Executor pool: " + poolName + " not found");
        }
        
        return;
    }
    
    public void shutdown(String poolName)
    {
        try
        {
            ExecutorService executorService = executorMap.remove(poolName);
        
            if(executorService != null)
            {
                executorService.shutdown();

                if(!executorService.awaitTermination(30, TimeUnit.SECONDS))
                {
                    executorService.shutdownNow();
                }
            }
        }
        catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
