package com.level3.km.utils.solrj.config;

public class ServiceRelationShipConfig implements IConnectionConfig
{
    private DbConnectionConfig dbConnectionConfig = null;
    
    public DbConnectionConfig getDbConnectionConfig()
    {
        return dbConnectionConfig;
    }
    public void setDbConnectionConfig(DbConnectionConfig dbConnectionConfig)
    {
        this.dbConnectionConfig = dbConnectionConfig;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ServiceRelationShipConfig [dbConnectionConfig=");
        builder.append(dbConnectionConfig);
        builder.append("]");
        return builder.toString();
    }
}
