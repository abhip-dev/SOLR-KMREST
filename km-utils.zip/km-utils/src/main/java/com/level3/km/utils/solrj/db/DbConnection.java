package com.level3.km.utils.solrj.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;


/**
 * JDBC connection handler.
 * Represets a single, specific, database connection.
 */
public class DbConnection 
{
    private Connection conn = null;
    private Object     lock = new int[ 1 ];	// For synchronization
    
    public static final String STR_TYPE  = "varchar";
    public static final String CHAR_TYPE = "char";
    public static final String INT_TYPE  = "int";
    public static final String LONG_TYPE = "long";
    public static final String DATE_TYPE = "datetime";

    public DbConnection( String  connectionName)
    {
        try
        {
            conn = DbConnectionPool.instance().getConnection(connectionName);
        }
        catch ( Throwable t )
        {
            conn = null;
            
            throw new RuntimeException(
                "ERROR: unable to open connection for " + connectionName + " because of " + t.getMessage() );
        }
    }

    /**
     * Sets the transaction isolation level.
     */
    public void setTransactionIsolation( int level )
        throws Exception
    {
        if ( conn == null )
        {
            throw new RuntimeException(
                "WARN: DbConnection.setTransactionIsolation: " +
                "no db connection" );
        }
        
        conn.setTransactionIsolation( level );
    }
    
    /**
     * Prepares a statement from the sql.
     */
    public PreparedStatement getPreparedStatement( String sql )
        throws Exception
    {
        if ( conn == null )
        {
            throw new RuntimeException( "WARN: DbConnection.getPreparedStatement: " +
                                        "no db connection" );
        }
        
        return conn.prepareStatement( sql );
    }
    
    /**
     * Creates a callable statement from the sql.
     */
    public CallableStatement getCallableStatement( String sql )
        throws Exception
    {
        if ( conn == null )
        {
            throw new RuntimeException( "WARN: DbConnection.getCallableStatement: " +
                                        "no db connection" );
        }
        
        return conn.prepareCall( sql );
    }
    
    /**
     * Executes a prepared statement returning an indicator of success.
     */
    public boolean execute( PreparedStatement ps )
        throws Exception
    {
        if ( conn != null )
        {
            synchronized ( lock )
            {
                return ps.execute();
            }
        }
        else
        {
            throw new RuntimeException( "WARN: DbConnection.execute: " +
                                        "no db connection" );
        }
    }
    
    /**
     * Executes a prepared statement returning a result set.
     */
    public ResultSet executeQuery( PreparedStatement ps )
        throws Exception
    {
        if ( conn != null )
        {
            synchronized ( lock )
            {
                return ps.executeQuery();
            }
        }
        else
        {
            throw new RuntimeException( "WARN: DbConnection.executeQuery: " +
                                        "no db connection" );
        }
    }
    
    /**
     * Executes a bound prepared statement returning the number of rows
     * effected.
     */
    public int executeUpdate( PreparedStatement ps )
        throws Exception
    {
        if ( conn != null )
        {
            synchronized ( lock )
            {
                return ps.executeUpdate();
            }
        }
        else
        {
            throw new RuntimeException( "WARN: DbConnection.executeUpdate: " +
                                        "no db connection" );
        }
    }
    
    /**
     * Executes a bound callable statement.
     */
    public void executeUpdate( CallableStatement cs )
        throws Exception
    {
        if ( conn != null )
        {
            synchronized ( lock )
            {
                cs.executeUpdate();
            }
        }
        else
        {
            throw new RuntimeException( "WARN: DbConnection.executeUpdate: " +
                                        "no db connection" );
        }
    }
    
    /**
     * Commits the current transaction.
     */
    public void commit()
        throws Exception
    {
        if ( conn != null )
        {
            conn.commit();
        }
        else
        {
            throw new RuntimeException( "WARN: DbConnection.commit: " +
                                        "no db connection" );
        }
    }
    
    /**
     * Rolls back the current transaction.
     */
    public void rollback()
        throws Exception
    {
        if ( conn != null )
        {
            conn.rollback();
        }
        else
        {
            throw new RuntimeException( "WARN: DbConnection.rollback: " +
                                        "no db connection" );
        }
    }
    
    /**
     * Closes the connection.
     * CALL THIS BEFORE LOSING YOUR REFERENCE TO THIS OBJECT.
     */
    public void destroy()
    {
        try
        {
            finalize();
        }
        catch ( Throwable t )
        {
        }
    }
    
    /**
     * System hook for closing the connection.
     */
    protected void finalize()
        throws Throwable
    {
        if ( conn != null )
        {
            synchronized ( lock )
            {
                try
                {
                    conn.close();
                }
                catch ( Throwable t )
                {
                    System.out.println( "WARN: closing db conn failed: " +
                                        t.getMessage() );
                }
                finally
                {
                    conn = null;
                }
            }
        }
    }
    
    /**
     * Binds positional parameters on a prepared statement.
     */
    public static void bind( PreparedStatement ps,
                             int               position,
                             String            value,
                             String            columnType )
        throws Exception
    {
        if ( value == null || value.length() == 0 )
        {
            if ( columnType.equals( "char" ) )
            {
                ps.setNull( position, java.sql.Types.CHAR );
            }
            else if ( columnType.equals( "varchar" ) ||
                      columnType.equals( "text" ) )
            {
                ps.setNull( position, java.sql.Types.VARCHAR );
            }
            else if ( columnType.equals( "bit" ) )
            {
                ps.setNull( position, java.sql.Types.BIT );
            }
            else if ( columnType.equals( "long" ) )
            {
                ps.setNull( position, java.sql.Types.INTEGER );
            }
            else if ( columnType.equals( "int" ) )
            {
                ps.setNull( position, java.sql.Types.INTEGER );
            }
            else if ( columnType.equals( "smallint" ) )
            {
                ps.setNull( position, java.sql.Types.SMALLINT );
            }
            else
            {
                throw new Exception( "Unsupported type: " + columnType );
            }
        }
        else
        {
            if ( columnType.equals( "char" ) )
            {
                ps.setString( position, value.toString() );
            }
            else if ( columnType.equals( "varchar" ) ||
                      columnType.equals( "text" ) )
            {
                ps.setString( position, value.toString() );
            }
            else if ( columnType.equals( "bit" ) )
            {
                ps.setString( position, value.toString() );
            }
            else if ( columnType.equals( "long" ) )
            {
                ps.setLong( position,
                            new Long( value.toString() ).longValue() );
            }
            else if ( columnType.equals( "int" ) )
            {
                ps.setInt( position,
                           new Integer( value.toString() ).intValue() );
            }
            else if ( columnType.equals( "smallint" ) )
            {
                ps.setShort( position,
                             new Integer(
                                 value.toString() ).shortValue() );
            }
            else
            {
                throw new Exception( "Unsupported type: " + columnType );
            }
        }
    }

    /**
     * Binds positional timestamp data on a prepared statement.
     */
    public static void bind( PreparedStatement ps,
                             int               position,
                             Timestamp         value,
                             String            columnType )
        throws Exception
    {
        if ( value == null )
        {
            if ( columnType.equals( "datetime" ) )
            {
                ps.setNull( position, java.sql.Types.TIMESTAMP );
            }
            else
            {
                throw new Exception( "Unsupported type: " + columnType );
            }
        }
        else
        {
            if ( columnType.equals( "datetime" ) )
            {
                ps.setTimestamp( position, value );
            }
            else
            {
                throw new Exception( "Unsupported type: " + columnType );
            }
        }
    }

    public static String readString( ResultSet rs, String column )
        throws SQLException
    {
        return rs.getString( column );
    }

    public static Date readDate( ResultSet rs, String column )
        throws SQLException
    {
        return rs.getDate( column );
    }

    public static Timestamp readTimestamp( ResultSet rs, String column )
        throws SQLException
    {
        return new Timestamp( rs.getDate( column ).getTime() );
    }

    public static Long readLong( ResultSet rs, String column )
        throws SQLException
    {
        long val = rs.getLong( column );
        return ( rs.wasNull() ? null : new Long( val ) );
    }

    public static Integer readInteger( ResultSet rs, String column )
        throws SQLException
    {
        int val = rs.getInt( column );
        return ( rs.wasNull() ? null : new Integer( val ) );
    }

    public static Double readDouble( ResultSet rs, String column )
        throws SQLException
    {
        double val = rs.getDouble( column );
        return ( rs.wasNull() ? null : new Double( val ) );
    }

    public static Float readFloat( ResultSet rs, String column )
        throws SQLException
    {
        float val = rs.getFloat( column );
        return ( rs.wasNull() ? null : new Float( val ) );
    }

    public static Boolean readBoolean( ResultSet rs, String column )
        throws SQLException
    {
        String val = rs.getString( column );
        return ( rs.wasNull() ? null : new Boolean( val.equals( "Y" ) || val.equals("1") ) );
    }
}

// EOF $RCSfile: DbConnection.java,v $
