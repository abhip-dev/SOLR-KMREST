package com.level3.km.utils.solrj.tgutil;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.CloudSolrClient;
import org.apache.solr.client.solrj.impl.XMLResponseParser;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.params.ModifiableSolrParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.utils.solrj.legacy.DbConnectionManager;

public class TgUtilIndexer
{
    private static Logger log = LoggerFactory.getLogger(TgUtilIndexer.class); 
    
    private Map<String, BanReference> banRefMap = new HashMap<String, BanReference>();
    private Collection documentList = new ArrayList();
    
    private CloudSolrClient solrClient = null;
    
    private int documentsCommitted = 0;
    
    private static final String banRefData =
            "select DISTINCT TO_CHAR(TRIM(LEADING 0 FROM BA.BILL_ACCOUNT_SYSTEM_ID)) AS KENAN_ACCOUNT_NO, " +
            "       TO_CHAR(TRIM(LEADING 0 FROM SBAX.XREF_ACCOUNT_NBR)) AS LEGACY_ACCOUNT_NBR, " +
            "       TO_CHAR(TRIM(LEADING 0 FROM BA.BILL_ACCOUNT_NBR)) AS INVOICE_ACCOUNT_NBR, " +
            "       BA.BILL_ACCOUNT_NAME AS BILL_ACCOUNT_NAME " +
            "  from CODS.BILLING_ACCOUNT BA " +
            " INNER JOIN CODS.SOURCE_BILLING_ACCOUNT SBA  " +
            "       ON BA.BILL_ACCOUNT_ODS_ID = SBA.BILL_ACCOUNT_ODS_ID " +
            "  LEFT OUTER JOIN (SELECT XREF_ACCOUNT_NBR,SOURCE_BILL_ACCOUNT_ODS_ID " +
            "                     FROM CODS.SOURCE_BILL_ACCT_XREF " +
            "                    WHERE XREF_TYPE_ID = 100)SBAX " +
            "                    ON SBA.SOURCE_BILL_ACCOUNT_ODS_ID = SBAX.SOURCE_BILL_ACCOUNT_ODS_ID"; 
    
    private static final String tgUtilDayData =
            "SELECT C.CUST_NBR AS customerNumber, " +
            "              C.CUST_NAME AS customerName, " +
            "              c.cust_acct_id AS banref, " +
            "              f.intvl_start_dt AS trunkGroupUtilizationInterval, " +
            "              tg.trunkgroup_typ as trunkGroupType, " +
            "              ROUND((f.total_tg_util_pct / f.rec_qty), 2) AS trunkGroupUtilizationPct, " +
            "              fcs.as_ccp_qty AS trunkGroupMaxCallCapacity, " +
            "              f.max_chan_total_used_qty AS trunkGroupPeakCallQuantity, " +
            "              f.chan_total_config_qty AS trunkGroupProvCallCapacity, " +
            "              f.max_tg_util_pct AS trunkGroupPeakUtilizationPct, " +
            "              f.min_tg_util_pct AS trunkGroupMinUtilizationPct, " +
            "              tg.trunkgroup_status AS trunkGroupStatus, " +
            "              tg.trunkgroup_id AS trunkGroupId, " +
            "              tg.switch_id AS switchId, " +
            "              (TO_CHAR(F.INTVL_START_DT, 'YYYY-MM-DDHH24:MI:SS') || '#' || F.M_SWITCH_ID || '#' || F.M_TRUNKGROUP_ID) AS id, " +
            "              CASE WHEN REGEXP_LIKE(TG.IP_ADDR, '[0-9].*$') THEN 'IP' " +
            "                   ELSE 'TDM' END AS trunkGroupTransportType, " +
            "              CASE WHEN tg.li_enabled_yn = 'Y' THEN 1 " +
            "                   WHEN tg.li_enabled_yn = 'N' THEN 0 " +
            "                   ELSE null END AS localInboundTgIndicator, " +
            "              CASE WHEN tg.els_enabled_yn = 'Y' THEN 1 " +
            "                   WHEN tg.els_enabled_yn = 'N' THEN 0 " +
            "                   ELSE null END AS enhancedLocalTgIndicator, " +
            "              CASE WHEN tg.tf_enabled_yn = 'Y' THEN 1 " +
            "                   WHEN tg.tf_enabled_yn = 'N' THEN 0 " +
            "                   ELSE null END AS tollFreeTgIndicator, " +
            "              CASE WHEN tg.e911_enabled_yn = 'Y' THEN 1 " +
            "                   WHEN tg.e911_enabled_yn = 'N' THEN 0 " +
            "                   ELSE null END AS e911TgIndicator, " +
            "              CASE WHEN tg.network_tg_yn = 'Y' THEN 1 " +
            "                   WHEN tg.network_tg_yn = 'N' THEN 0 " +
            "                   ELSE null END AS networkTrunkGroupIndicator, " +
            "              CASE WHEN tg.vt_enabled_yn = 'Y' THEN 1 " +
            "                   WHEN tg.vt_enabled_yn = 'N' THEN 0 " +
            "                   ELSE null END AS voiceTerminationTgIndicator, " +
            "              CASE WHEN tg.vc_enabled_yn = 'Y' THEN 1 " +
            "                   WHEN tg.vc_enabled_yn = 'N' THEN 0 " +
            "                   ELSE null END AS voiceCompleteTgIndicator " +
            "              FROM aspen.f_day_tg_stats F " +
            "             INNER JOIN vsum.d_trunkgroup TG ON (f.m_trunkgroup_id = tg.m_trunkgroup_id AND TG.inv_m_cust_id > 0) " +
            "             INNER JOIN vsum.d_customer C ON (tg.inv_m_cust_id = c.m_cust_id)  " +
            "             LEFT JOIN (SELECT VC.cust_nbr, FS.stats_dt, FS.AS_CCP_QTY " +
            "                          FROM aspen.f_cust_stats FS " +
            "                          INNER JOIN vsum.d_customer VC ON (FS.m_cust_id = VC.m_cust_id) " +
            "                       ) FCS ON (F.INTVL_START_DT = FCS.STATS_DT AND C.cust_nbr = FCS.cust_nbr)";
    
    /*
    private static final String tgUtilDayDataWithBan = 
            "SELECT C.CUST_NBR AS customerNumber, " +
            "C.CUST_NAME AS customerName, " +
            "CASE WHEN BA.INVOICE_ACCOUNT_NBR IS NOT NULL THEN BA.INVOICE_ACCOUNT_NBR " +
            "     ELSE C.CUST_ACCT_ID END AS billAccountNumber, " +
            "CASE WHEN BA.INVOICE_ACCOUNT_NBR IS NOT NULL THEN BA.BILL_ACCOUNT_NAME " +
            "     ELSE NULL END AS billAccountName, " +
    "        f.intvl_start_dt AS trunkGroupUtilizationInterval, " +
            "tg.trunkgroup_typ as trunkGroupType, " +
            "ROUND((f.total_tg_util_pct / f.rec_qty), 2) AS trunkGroupUtilizationPct, " +
            "fcs.as_ccp_qty AS trunkGroupMaxCallCapacity, " +
//    "-- f.max_chan_total_used_qty AS trunkGroupPeakCallQuantity, " +
            "f.max_tg_util_pct AS trunkGroupPeakUtilizationPct, " +
    "f.min_tg_util_pct AS trunkGroupMinUtilizationPct, " +
    "tg.trunkgroup_status AS trunkGroupStatus, " +
    "tg.trunkgroup_id AS trunkGroupId, " +
    "tg.switch_id AS switchId, " +
    "(TO_CHAR(F.INTVL_START_DT, 'YYYY-MM-DDHH24:MI:SS') || '#' || F.M_SWITCH_ID || '#' || F.M_TRUNKGROUP_ID) AS tgUtilKeyId, " +
    "CASE WHEN tg.li_enabled_yn = 'Y' THEN 1 " +
    "     WHEN tg.li_enabled_yn = 'N' THEN 0 " +
    "     ELSE null END AS localInboundTgIndicator, " +
    "CASE WHEN tg.els_enabled_yn = 'Y' THEN 1 " +
    "     WHEN tg.els_enabled_yn = 'N' THEN 0 " +
    "     ELSE null END AS enhancedLocalTgIndicator, " +
    "CASE WHEN tg.tf_enabled_yn = 'Y' THEN 1 " +
    "     WHEN tg.tf_enabled_yn = 'N' THEN 0 " +
    "     ELSE null END AS tollFreeTgIndicator, " +
    "CASE WHEN tg.e911_enabled_yn = 'Y' THEN 1 " +
    "     WHEN tg.e911_enabled_yn = 'N' THEN 0 " +
    "     ELSE null END AS e911TgIndicator, " +
    "CASE WHEN tg.network_tg_yn = 'Y' THEN 1 " +
    "     WHEN tg.network_tg_yn = 'N' THEN 0 " +
    "     ELSE null END AS networkTrunkGroupIndicator, " +
    "CASE WHEN tg.vt_enabled_yn = 'Y' THEN 1 " +
    "     WHEN tg.vt_enabled_yn = 'N' THEN 0 " +
    "     ELSE null END AS voiceTerminationTgIndicator, " +
    "CASE WHEN tg.vc_enabled_yn = 'Y' THEN 1 " +
    "     WHEN tg.vc_enabled_yn = 'N' THEN 0 " +
    "     ELSE null END AS voiceCompleteTgIndicator " +
   "FROM aspen.f_day_tg_stats F " +
  "INNER JOIN vsum.d_trunkgroup TG ON (f.m_trunkgroup_id = tg.m_trunkgroup_id AND TG.inv_m_cust_id > 0) " +
  "INNER JOIN vsum.d_customer C ON (tg.inv_m_cust_id = c.m_cust_id)  " +
  "LEFT JOIN (SELECT VC.cust_nbr, FS.stats_dt, FS.AS_CCP_QTY FROM aspen.f_cust_stats FS INNER JOIN vsum.d_customer VC ON (FS.m_cust_id = VC.m_cust_id) " +
  ") FCS ON (F.INTVL_START_DT = FCS.STATS_DT AND C.cust_nbr = FCS.cust_nbr) " +
  "LEFT JOIN ( " +
  "               select DISTINCT TO_CHAR(TRIM(LEADING 0 FROM BA.BILL_ACCOUNT_SYSTEM_ID)) AS KENAN_ACCOUNT_NO, " +
  "                               TO_CHAR(TRIM(LEADING 0 FROM SBAX.XREF_ACCOUNT_NBR)) AS LEGACY_ACCOUNT_NBR, " +
  "                               TO_CHAR(TRIM(LEADING 0 FROM BA.BILL_ACCOUNT_NBR)) AS INVOICE_ACCOUNT_NBR, " +
  "                               BA.BILL_ACCOUNT_NAME AS BILL_ACCOUNT_NAME " +
  "                from CODS.BILLING_ACCOUNT@CILPD_VSUMPD.LEVEL3.COM BA " +
  "               INNER JOIN CODS.SOURCE_BILLING_ACCOUNT@CILPD_VSUMPD.LEVEL3.COM SBA ON BA.BILL_ACCOUNT_ODS_ID = SBA.BILL_ACCOUNT_ODS_ID " +
  "               LEFT OUTER JOIN (SELECT XREF_ACCOUNT_NBR,SOURCE_BILL_ACCOUNT_ODS_ID " +
  "                                  FROM CODS.SOURCE_BILL_ACCT_XREF@CILPD_VSUMPD.LEVEL3.COM " +
  "                                 WHERE XREF_TYPE_ID = 100)SBAX ON SBA.SOURCE_BILL_ACCOUNT_ODS_ID = SBAX.SOURCE_BILL_ACCOUNT_ODS_ID " +
  "          ) BA ON (C.CUST_ACCT_ID = BA.INVOICE_ACCOUNT_NBR OR C.CUST_ACCT_ID = BA.KENAN_ACCOUNT_NO OR C.CUST_ACCT_ID = LEGACY_ACCOUNT_NBR) ";
//  WHERE ( " +
//           :loadAllData != 'false'  " +
//           OR " +
//           ( " +
//               F.INTVL_START_DT > ( " +
//                                      SELECT MAX(JS.DATA_DT) AS INTVL_START_DT_GREATER_THAN " +
//                                        FROM ASPEN.M_JOB_CONTROL_STATUS JS " +
//                                       WHERE JS.JOB_NAME = 'wkf_Load_F_DAY_TG_STATS' " +
//                                         AND JS.END_DT < TO_DATE(:lastUpdateDate, 'YYYY-MM-DD HH24:MI:SS') " +
//                                   ) " +
//                AND " +
//                F.INTVL_START_DT <= ( " +
//                                        SELECT MAX(JS.DATA_DT) AS INTL_START_DT_LESS_OR_EQUALTO " +
//                                          FROM ASPEN.M_JOB_CONTROL_STATUS JS " +
//                                         WHERE JS.JOB_NAME = 'wkf_Load_F_DAY_TG_STATS' " +
//                                           AND JS.END_DT > TO_DATE(:lastUpdateDate, 'YYYY-MM-DD HH24:MI:SS') " +
//                                     ) " +
//             ) " +
//           )";
 * 
 */
    
    private DbConnectionManager vsumConn = null;
    private DbConnectionManager cildvConn = null;
    
    public TgUtilIndexer()
    {
//        server = new CloudSolrServer("kmdsidc01-dev1:2181");
//        server.setDefaultCollection("tgUtilization");
//        server = new CloudSolrServer("solr01-dev1:2181");
//        server.setDefaultCollection("tgUtilization");
        solrClient = new CloudSolrClient.Builder().withZkHost("m14-13:2181").sendDirectUpdatesToShardLeadersOnly().build();
        solrClient.setDefaultCollection("tgutil");
        solrClient.setIdField("id");
        solrClient.setZkClientTimeout(1000);
        solrClient.setZkConnectTimeout(1000);
        solrClient.setParser(new XMLResponseParser());
        
        vsumConn = 
                new DbConnectionManager("oracle.jdbc.driver.OracleDriver",
                        "jdbc:oracle:thin:@JJ33-SCAN.IDC1.LEVEL3.COM:1521/vsumpd",
//                        "jdbc:oracle:thin:@KK33-SCAN.IDC1.LEVEL3.COM:1521/vsumdv",
                        "kmds_ro",
                        "sqw_2013_kopl",
                        false);
        
        cildvConn = 
                new DbConnectionManager("oracle.jdbc.driver.OracleDriver",
                        "jdbc:oracle:thin:@RACORAP02-SCAN.IDC1.LEVEL3.COM:1521/cilpd",
                        "kmds_ro",
                        "sqw_2013_kopl",
//                        "jdbc:oracle:thin:@KK33-SCAN.IDC1.LEVEL3.COM:1521/cildv",
//                        "infa_ro",
//                        "infa_ro_cildv",
                        false);
    }
    
    public void process()
    {
        fillBanReference();
        
        addToSolrIndex();
        
        finishIndexing();
    }
    
    private void fillBanReference()
    {
        String legacyAccountNumber = null;
        String kenanAccountNumber = null;
        String billAccountNumber = null;
        BanReference banRef = null;
        try
        {
            PreparedStatement stmt = cildvConn.getPreparedStatement(banRefData);
            
            ResultSet resultSet = cildvConn.executeQuery(stmt);
            
            while(resultSet != null && resultSet.next())
            {
                billAccountNumber = cildvConn.readString(resultSet, "INVOICE_ACCOUNT_NBR");
                
                banRef = new BanReference(billAccountNumber, cildvConn.readString(resultSet, "BILL_ACCOUNT_NAME"));
                
                legacyAccountNumber = cildvConn.readString(resultSet, "LEGACY_ACCOUNT_NBR");
                
                if(legacyAccountNumber != null && !legacyAccountNumber.equals(""))
                {
                    banRefMap.put(legacyAccountNumber, banRef);
                }
                
                kenanAccountNumber = cildvConn.readString(resultSet, "KENAN_ACCOUNT_NO");
                
                if(kenanAccountNumber != null && !kenanAccountNumber.equals(""))
                {
                    banRefMap.put(kenanAccountNumber, banRef);
                }
                
                if(billAccountNumber != null && !billAccountNumber.equals(""))
                {
                    banRefMap.put(billAccountNumber, banRef);
                }
            }
        }
        catch (Exception e)
        {
            log.error("caught exception while trying to fill ban reference data.", e);
        }
        finally
        {
            log.info("Size of Map is :" + banRefMap.size());
        }
    }
    
    private void addToSolrIndex()
    {
        SolrInputDocument solrInputDocument = null;
        String id = null;
        String customerNumber = null;
        String customerName = null;
        Date trunkGroupUtilizationInterval = null;
        String trunkGroupType = null;
        String trunkGroupTransportType = null;
        Double trunkGroupUtilizationPercentage = null;
        Integer trunkGroupMaxCallCapacity = null;
        Integer trunkGroupProvisionedCallCapacity = null;
        Integer trunkGroupPeakCallQuantity = null;
        Double trunkGroupPeakUtilizationPercentage = null;
        Double trunkGroupMinUtilizationPercentage = null;
        String trunkGroupStatus = null;
        String trunkGroupId = null;
        String switchId = null;
        Boolean localInboundTrunkGroupIndicator = null;
        Boolean enhancedLocalTrunkGroupIndicator = null;
        Boolean tollFreeTrunkGroupIndicator = null;
        Boolean e911TrunkGroupIndicator = null;
        Boolean voiceTerminationTrunkGroupIndicator = null;
        Boolean voiceCompleteTrunkGroupIndicator = null;
        Boolean networkTrunkGroupIndicator = null;
        String billAccountNumber = null;
        String billAccountName = null;
        String banref = null;

        try
        {
            PreparedStatement stmt = vsumConn.getPreparedStatement(tgUtilDayData);
//            PreparedStatement stmt = vsumConn.getPreparedStatement(tgUtilDayDataWithBan);
            
            ResultSet resultSet = vsumConn.executeQuery(stmt);
            
            while(resultSet != null && resultSet.next())
            {
                solrInputDocument = new SolrInputDocument(); 
                
                id = vsumConn.readString(resultSet, "id");
                if(id != null)
                {
                    solrInputDocument.addField("id", id);
                }
                
                customerNumber = vsumConn.readString(resultSet, "customerNumber");
                if(customerNumber != null)
                {
                    solrInputDocument.addField("customerNumber", customerNumber);
                }
                
                customerName = vsumConn.readString(resultSet, "customerName");
                if(customerName != null)
                {
                    solrInputDocument.addField("customerName", customerName);
                }
                
                trunkGroupUtilizationInterval = vsumConn.readDate(resultSet, "trunkGroupUtilizationInterval");
                if(trunkGroupUtilizationInterval != null)
                {
                    solrInputDocument.addField("trunkGroupUtilizationIntervalStartDate", trunkGroupUtilizationInterval);
                }
                
                trunkGroupType = vsumConn.readString(resultSet, "trunkGroupType");
                if(trunkGroupType != null)
                {
                    solrInputDocument.addField("trunkGroupType", trunkGroupType);
                }
                
                trunkGroupTransportType = vsumConn.readString(resultSet, "trunkGroupTransportType");
                if(trunkGroupTransportType != null)
                {
                    solrInputDocument.addField("trunkGroupTransportType", trunkGroupTransportType);
                }
                
                trunkGroupUtilizationPercentage = vsumConn.readDouble(resultSet, "trunkGroupUtilizationPct");
                if(trunkGroupUtilizationPercentage != null)
                {
                    solrInputDocument.addField("trunkGroupUtilizationPercentage", trunkGroupUtilizationPercentage);
                }
                
                trunkGroupMaxCallCapacity = vsumConn.readInteger(resultSet, "trunkGroupMaxCallCapacity");
                if(trunkGroupMaxCallCapacity != null)
                {
                    solrInputDocument.addField("trunkGroupMaxCallCapacity", trunkGroupMaxCallCapacity);
                }
                
                trunkGroupProvisionedCallCapacity = vsumConn.readInteger(resultSet, "trunkGroupProvCallCapacity");
                if(trunkGroupProvisionedCallCapacity != null)
                {
                    solrInputDocument.addField("trunkGroupProvisionedCallCapacity", trunkGroupProvisionedCallCapacity);
                }
                
                trunkGroupPeakCallQuantity = vsumConn.readInteger(resultSet, "trunkGroupPeakCallQuantity");
                if(trunkGroupPeakCallQuantity != null)
                {
                    solrInputDocument.addField("trunkGroupPeakCallQuantity", trunkGroupPeakCallQuantity);
                }
                
                trunkGroupPeakUtilizationPercentage = vsumConn.readDouble(resultSet, "trunkGroupPeakUtilizationPct");
                if(trunkGroupPeakUtilizationPercentage != null)
                {
                    solrInputDocument.addField("trunkGroupPeakUtilizationPercentage", trunkGroupPeakUtilizationPercentage);
                }
                
                trunkGroupMinUtilizationPercentage = vsumConn.readDouble(resultSet, "trunkGroupMinUtilizationPct");
                if(trunkGroupMinUtilizationPercentage != null)
                {
                    solrInputDocument.addField("trunkGroupMinUtilizationPercentage", trunkGroupMinUtilizationPercentage);
                }
                
                trunkGroupStatus = vsumConn.readString(resultSet, "trunkGroupStatus");
                if(trunkGroupStatus != null)
                {
                    solrInputDocument.addField("trunkGroupStatus", trunkGroupStatus);
                }
                
                trunkGroupId = vsumConn.readString(resultSet, "trunkGroupId");
                if(trunkGroupId != null)
                {
                    solrInputDocument.addField("trunkGroupId", trunkGroupId);
                }
                
                switchId = vsumConn.readString(resultSet, "switchId");
                if(switchId != null)
                {
                    solrInputDocument.addField("switchId", switchId);
                }
                
                localInboundTrunkGroupIndicator = vsumConn.readBoolean(resultSet, "localInboundTgIndicator");
                if(localInboundTrunkGroupIndicator != null)
                {
                    solrInputDocument.addField("localInboundTrunkGroupIndicator", localInboundTrunkGroupIndicator);
                }
                
                enhancedLocalTrunkGroupIndicator = vsumConn.readBoolean(resultSet, "enhancedLocalTgIndicator");
                if(enhancedLocalTrunkGroupIndicator != null)
                {
                    solrInputDocument.addField("enhancedLocalTrunkGroupIndicator", enhancedLocalTrunkGroupIndicator);
                }
                
                tollFreeTrunkGroupIndicator = vsumConn.readBoolean(resultSet, "tollFreeTgIndicator");
                if(tollFreeTrunkGroupIndicator != null)
                {
                    solrInputDocument.addField("tollFreeTrunkGroupIndicator", tollFreeTrunkGroupIndicator);
                }
                
                e911TrunkGroupIndicator = vsumConn.readBoolean(resultSet, "e911TgIndicator");
                if(e911TrunkGroupIndicator != null)
                {
                    solrInputDocument.addField("e911TrunkGroupIndicator", e911TrunkGroupIndicator);
                }
                
                voiceTerminationTrunkGroupIndicator = vsumConn.readBoolean(resultSet, "voiceTerminationTgIndicator");
                if(voiceTerminationTrunkGroupIndicator != null)
                {
                    solrInputDocument.addField("voiceTerminationTrunkGroupIndicator", voiceTerminationTrunkGroupIndicator);
                }
                
                voiceCompleteTrunkGroupIndicator = vsumConn.readBoolean(resultSet, "voiceCompleteTgIndicator");
                if(voiceCompleteTrunkGroupIndicator != null)
                {
                    solrInputDocument.addField("voiceCompleteTrunkGroupIndicator", voiceCompleteTrunkGroupIndicator);
                }
                
                networkTrunkGroupIndicator = vsumConn.readBoolean(resultSet, "networkTrunkGroupIndicator");
                if(networkTrunkGroupIndicator != null)
                {
                    solrInputDocument.addField("networkTrunkGroupIndicator", networkTrunkGroupIndicator);
                }
                
                /*
                billAccountNumber = vsumConn.readString(resultSet, "billAccountNumber");
                if(billAccountNumber != null)
                {
                    solrInputDocument.addField("billAccountNumber", billAccountNumber);
                }
                
                billAccountName = vsumConn.readString(resultSet, "billAccountName");
                if(billAccountName != null)
                {
                    solrInputDocument.addField("billAccountName", billAccountName);
                }
                */
                
                banref = vsumConn.readString(resultSet, "banref");
                if(banRefMap.get(banref) != null)
                {
                    billAccountNumber = banRefMap.get(banref).getBanNumber();
                    if(billAccountNumber != null)
                    {
                        solrInputDocument.addField("billAccountNumber", billAccountNumber);
                    }

                    billAccountName = banRefMap.get(billAccountNumber).getBanName();
                    if(billAccountName != null)
                    {
                        solrInputDocument.addField("billAccountName", billAccountName);
                    }
                }
                
                else
                {
                    solrInputDocument.addField("billAccountNumber", banref);
                }
                
                documentList.add(solrInputDocument);
                documentsCommitted++;
                
                if (documentList.size() > 1000)
                {
                    // Commit within 5 minutes.
                    UpdateResponse resp = solrClient.add(documentList, 300000);
                    if (resp.getStatus() != 0)
                    {
                        log.info("Some horrible error has occurred, status is: " + resp.getStatus());
                    }
                    
                    log.info("documents committed to Solr :" + documentsCommitted);
                    documentList.clear();
                }
            }
        }
        catch (Exception e)
        {
            log.error("caught exception while trying to add to Solr index.", e);
        }
    }
    
    private void finishIndexing()
    {
        try
        {
            if (documentList.size() > 0)
            {
                // Commit within 5 minutes.
                UpdateResponse resp = solrClient.add(documentList, 300000);
                if (resp.getStatus() != 0)
                {
                    log.info("Some horrible error has occurred, status is: "
                            + resp.getStatus());
                }
                
                log.info("Total documents committed to Solr :" + documentsCommitted);
                
                documentList.clear();
            }
            
            solrClient.commit();
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to finish indexing.", ex);
        }
    }
    
    public void query()
    {
        try
        {
            ModifiableSolrParams params = new ModifiableSolrParams();
        
            params.add("q", "*:*");
            
            QueryResponse response = solrClient.query(params);
            
            SolrDocumentList documentList = response.getResults();
            
            log.info("Size of result set " + documentList.size());
        }
        catch (SolrServerException e)
        {
            log.error("exception in query()", e);
        }
        catch (IOException e)
        {
            log.error("exception in query()", e);
        }
    }
    
    public static void main(String[] args)
    {
        log.info("Starting indexing of TgUtil data.");
        try
        {
            TgUtilIndexer indexer = new TgUtilIndexer();
            
            indexer.process();
            
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            log.error("caught exception while trying to index VSUM data.", ex);
        }
        
        log.info("Completed indexing of TgUtil data.");
    }
    
    public static class BanReference
    {
        private String banNumber = null;
        private String banName = null;
        
        public BanReference(String banNumber, String banName)
        {
            this.banNumber = banNumber;
            this.banName = banName;
        }

        public String getBanNumber()
        {
            return banNumber;
        }

        public String getBanName()
        {
            return banName;
        }
    }

}
