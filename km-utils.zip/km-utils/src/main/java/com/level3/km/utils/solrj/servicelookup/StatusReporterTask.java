package com.level3.km.utils.solrj.servicelookup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StatusReporterTask implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(StatusReporterTask.class); 

    private static final String NEW_LINE = "\n";
    private static final String STATS = NEW_LINE + "ServiceLookup Data refresh status" + NEW_LINE;
    
    private ServiceLookupManager manager = null;

    private static final String SECTION_SEPRATOR = 
            "=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+==+=+=+=+=\n";
        
    public StatusReporterTask(ServiceLookupManager manager)
    {
        this.manager = manager;
    }

    /**
     * Main Run Loop.
     */
    public void run()
    {
        log.info("{} {} {}", STATS, SECTION_SEPRATOR, this.manager.status().toString());
    }
}
