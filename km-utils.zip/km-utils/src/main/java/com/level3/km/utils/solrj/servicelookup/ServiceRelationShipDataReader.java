package com.level3.km.utils.solrj.servicelookup;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.utils.solrj.config.PropertyManager;
import com.level3.km.utils.solrj.db.DbConnection;
import com.level3.km.utils.solrj.legacy.DbConnectionManager;

public class ServiceRelationShipDataReader implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(ServiceRelationShipDataReader.class); 

    private Map<String, List<String>> sidRelatedSidMap = null;

    private int documentsCommitted = 0;
    
    private DbConnection slvConn = null;
    
    private String filterCriteria = null;
    
    private ServiceRelationShipManager manager = null;
    
    /*
    private static final String relationshipQuery = 
            "select SR.SID, " +
            "   DECODE(SR.RELATIONSHIP_LEVEL, 1, SR.RELATED_SID, NULL) AS RELATEDSERVICEINSTANCEIDLEVEL1, " +
            "   DECODE(SR.RELATIONSHIP_LEVEL, 2, SR.RELATED_SID, NULL) AS RELATEDSERVICEINSTANCEIDLEVEL2, " +
            "   DECODE(SR.RELATIONSHIP_LEVEL, 3, SR.RELATED_SID, NULL) AS RELATEDSERVICEINSTANCEIDLEVEL3, " +
            "   DECODE(SR.RELATIONSHIP_LEVEL, 4, SR.RELATED_SID, NULL) AS RELATEDSERVICEINSTANCEIDLEVEL4, " +
            "   DECODE(SR.RELATIONSHIP_LEVEL, 5, SR.RELATED_SID, NULL) AS RELATEDSERVICEINSTANCEIDLEVEL5 " +
            " FROM service_relationship SR";
            */

    private static final String relationshipQueryAddFilter = 
            "select SR.SID, " +
            "       SR.RELATED_SID AS RELATEDSERVICEINSTANCEID " +
            " FROM service_relationship SR ";

    public ServiceRelationShipDataReader(String filterCriteria, ServiceRelationShipManager manager, Map<String, List<String>> sidRelatedSidMap)
    {
        this.filterCriteria = filterCriteria;
        this.sidRelatedSidMap = sidRelatedSidMap;
        
        this.manager = manager;

        slvConn = new DbConnection(PropertyManager.SERVICE_RELATIONSHIP_CONFIG);
    }

    public void run()
    {
        process();
        
        this.manager.countLatchDown();
    }

    public void process()
    {
        addToMap(filterCriteria);
    }
    
    private void addToMap(String filterCriteria)
    {
        String sid = null;
        String relatedSid = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;

        try
        {
            stmt = slvConn.getPreparedStatement(relationshipQueryAddFilter + filterCriteria);
            
            resultSet = slvConn.executeQuery(stmt);
            
            while(resultSet != null && resultSet.next())
            {
                documentsCommitted++;
                
                if (documentsCommitted % 10000 == 0)
                {
                    log.info("filter criteria {} - documents processed :{}", filterCriteria, documentsCommitted);
                }

                sid = DbConnectionManager.readString(resultSet, "SID");
                
                List<String> relatedSidList = sidRelatedSidMap.get(sid);
                
                if(relatedSidList == null)
                {
                    relatedSidList = new ArrayList<String>();
                }
                
                relatedSid = DbConnectionManager.readString(resultSet, "RELATEDSERVICEINSTANCEID");
                if(relatedSid != null)
                {
                    relatedSidList.add(relatedSid);
                    sidRelatedSidMap.put(sid, relatedSidList);
                }
            }
        }
        catch (Exception e)
        {
            log.error("caught exception while trying to update map.", e);
            
            // stop the process or mark run as failure
            manager.updateFailure();
        }
        finally
        {
            log.info("FINAL COUNT !!! filter criteria \"{}\" - documents processed :{}, number of SIDs :{}", filterCriteria, documentsCommitted, sidRelatedSidMap.size());
            
            try
            {
                resultSet.close();
            }
            catch (SQLException e)
            {

            }
            
            try
            {
                stmt.close();
            }
            catch (SQLException e)
            {

            }
            
            slvConn.destroy();
        }
    }

    /*
    private void addToMap()
    {
        String sid = null;
        String relatedSidLevel1 = null;
        String relatedSidLevel2 = null;
        String relatedSidLevel3 = null;
        String relatedSidLevel4 = null;
        String relatedSidLevel5 = null;
        RelatedSid relatedSid = null;

        try
        {

            PreparedStatement stmt = slvConn.getPreparedStatement(relationshipQuery);
            
            ResultSet resultSet = slvConn.executeQuery(stmt);
            
            while(resultSet != null && resultSet.next())
            {
                documentsCommitted++;
                
                if (documentsCommitted % 10000 == 0)
                {
                    log.info("documents processed :" + documentsCommitted);
                }

                sid = DbConnection.readString(resultSet, "SID");
                
                relatedSid = sidRefMap.get(sid);
                if(relatedSid == null)
                {
                    relatedSid = new RelatedSid(sid);
                }

                relatedSidLevel1 = DbConnection.readString(resultSet, "RELATEDSERVICEINSTANCEIDLEVEL1");
                if(relatedSidLevel1 != null)
                {
                    relatedSid.addRelatedSidLevel1(relatedSidLevel1);
                    sidRefMap.put(sid, relatedSid);
                    
                    continue;
                }

                relatedSidLevel2 = DbConnection.readString(resultSet, "RELATEDSERVICEINSTANCEIDLEVEL2");
                if(relatedSidLevel2 != null)
                {
                    relatedSid.addRelatedSidLevel2(relatedSidLevel2);
                    sidRefMap.put(sid, relatedSid);
                    
                    continue;
                }

                relatedSidLevel3 = DbConnection.readString(resultSet, "RELATEDSERVICEINSTANCEIDLEVEL3");
                if(relatedSidLevel3 != null)
                {
                    relatedSid.addRelatedSidLevel3(relatedSidLevel3);
                    sidRefMap.put(sid, relatedSid);
                    
                    continue;
                }

                relatedSidLevel4 = DbConnection.readString(resultSet, "RELATEDSERVICEINSTANCEIDLEVEL4");
                if(relatedSidLevel4 != null)
                {
                    relatedSid.addRelatedSidLevel4(relatedSidLevel4);
                    sidRefMap.put(sid, relatedSid);
                    
                    continue;
                }

                relatedSidLevel5 = DbConnection.readString(resultSet, "RELATEDSERVICEINSTANCEIDLEVEL5");
                if(relatedSidLevel5 != null)
                {
                    relatedSid.addRelatedSidLevel5(relatedSidLevel5);
                    sidRefMap.put(sid, relatedSid);
                    
                    continue;
                }

            }
        }
        catch (Exception e)
        {
            log.error("caught exception while trying to update map.", e);
        }
    }

    public static class RelatedSid
    {
        private String sid = null;
        private List<String> relatedServiceInstanceIdLevel1 = null;
        private List<String>relatedServiceInstanceIdLevel2 = null;
        private List<String> relatedServiceInstanceIdLevel3 = null;
        private List<String> relatedServiceInstanceIdLevel4 = null;
        private List<String> relatedServiceInstanceIdLevel5 = null;
        
        public RelatedSid(String sid)
        {
            this.sid = sid;
            this.relatedServiceInstanceIdLevel1 = new ArrayList<String>();
            this.relatedServiceInstanceIdLevel2 = new ArrayList<String>();
            this.relatedServiceInstanceIdLevel3 = new ArrayList<String>();
            this.relatedServiceInstanceIdLevel4 = new ArrayList<String>();
            this.relatedServiceInstanceIdLevel5 = new ArrayList<String>();
        }

        public String getSid()
        {
            return this.sid;
        }

        public List<String> getRelatedSidLevel1()
        {
            return this.relatedServiceInstanceIdLevel1;
        }
        public List<String> getRelatedSidLevel2()
        {
            return this.relatedServiceInstanceIdLevel2;
        }
        public List<String> getRelatedSidLevel3()
        {
            return this.relatedServiceInstanceIdLevel3;
        }
        public List<String> getRelatedSidLevel4()
        {
            return this.relatedServiceInstanceIdLevel4;
        }
        public List<String> getRelatedSidLevel5()
        {
            return this.relatedServiceInstanceIdLevel5;
        }
        
        public void addRelatedSidLevel1(String relatedSid)
        {
            this.relatedServiceInstanceIdLevel1.add(relatedSid);
        }
        public void addRelatedSidLevel2(String relatedSid)
        {
            this.relatedServiceInstanceIdLevel2.add(relatedSid);
        }
        public void addRelatedSidLevel3(String relatedSid)
        {
            this.relatedServiceInstanceIdLevel3.add(relatedSid);
        }
        public void addRelatedSidLevel4(String relatedSid)
        {
            this.relatedServiceInstanceIdLevel4.add(relatedSid);
        }
        public void addRelatedSidLevel5(String relatedSid)
        {
            this.relatedServiceInstanceIdLevel5.add(relatedSid);
        }
    }
    */

    public static void main(String[] args)
    {
        log.info("Starting indexing of Service relationship data.");
        try
        {
            ServiceRelationShipDataReader indexer = new ServiceRelationShipDataReader(" WHERE SR.RELATIONSHIP_LEVEL = 1", null, new HashMap<String, List<String>>());
            
            indexer.process();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            
            log.error("caught exception while trying to index service relationship data.", ex);
        }
        
        log.info("Completed indexing of service relationship data.");
    }
}
