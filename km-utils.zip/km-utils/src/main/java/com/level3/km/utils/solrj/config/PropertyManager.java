package com.level3.km.utils.solrj.config;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyManager
{
    private static Logger log = LoggerFactory.getLogger(PropertyManager.class);
    
    private static PropertyManager instance = null;
    private static Object mutex = new int[ 1 ];
    
    private ServiceRelationShipConfig serviceRelationShipConfig = null;
    private ServiceLookupConfig serviceLookupConfig = null;
    
    private Properties properties = null;
    
    private Map<String, IConnectionConfig> dbConnectionConfigMap = null;
    
    public static final String ENVIRONMENT_STR = "ENVIRONMENT";
    public static final String SERVICE_RELATIONSHIP_CONFIG = "serviceRelationShipConfig";
    public static final String SERVICE_LOOKUP_CONFIG = "serviceLookupConfig";
    
    private PropertyManager()
    {
        try
        {
            dbConnectionConfigMap = new HashMap<String, IConnectionConfig>();
            properties = new Properties();
            
            URL url = this.getClass().getResource("/ServiceLookup.properties");

            if(url != null)
            {
                properties.load(url.openStream());
            }

            loadConfigs();
        }
        catch(IOException ioe)
        {
            log.error("caught exception while trying to read properties file.", ioe);
        }
    }
    
    public static PropertyManager instance()
    {
        PropertyManager tempInstance = null;
        
        if(instance == null)
        {
            synchronized (mutex)
            {
                if(instance == null)
                {
                    tempInstance = new PropertyManager();
                    instance = tempInstance;
                }
            }
        }
        
        return instance;
    }
    
    public ServiceRelationShipConfig getServiceRelationShipConfig()
    {
        return serviceRelationShipConfig;
    }
    
    public ServiceLookupConfig getServiceLookupConfig()
    {
        return serviceLookupConfig;
    }
    
    public IConnectionConfig getDbConnectionConfig(String name)
    {
        return this.dbConnectionConfigMap.get(name);
    }
    
    private void loadConfigs()
    {
        serviceRelationShipConfig = loadServiceRelationShipConfig();
        this.dbConnectionConfigMap.put(SERVICE_RELATIONSHIP_CONFIG, serviceRelationShipConfig);

        serviceLookupConfig = loadServiceLookupConfig();
        this.dbConnectionConfigMap.put(SERVICE_LOOKUP_CONFIG, serviceLookupConfig);
    }
    
    private String getProperty(String attribute)
    {
        return properties.getProperty(attribute);
    }
    
    private ServiceLookupConfig loadServiceLookupConfig()
    {
        DbConnectionConfig config = new DbConnectionConfig("serviceLookup");

        config.setDriver(getProperty("servicelookup.db.driver"));
        config.setUrl(getProperty("servicelookup.db.url"));
        config.setUsername(getProperty("servicelookup.db.username"));
        config.setPassword(getProperty("servicelookup.db.password"));
        
        ServiceLookupConfig slConfig = new ServiceLookupConfig();
        slConfig.setZkHost(getProperty("servicelookup.solr.zkhost"));
        slConfig.setCollectionName(getProperty("servicelookup.solr.collectionname"));
        slConfig.setCollectionIdField(getProperty("servicelookup.solr.collectionfieldid"));
        slConfig.setDbConnectionConfig(config);

        return slConfig;
    }
    
    private ServiceRelationShipConfig loadServiceRelationShipConfig()
    {
        DbConnectionConfig config = new DbConnectionConfig("serviceRelationShip");
        config.setDriver(getProperty("servicerelationship.db.driver"));
        config.setUrl(getProperty("servicerelationship.db.url"));
        config.setUsername(getProperty("servicerelationship.db.username"));
        config.setPassword(getProperty("servicerelationship.db.password"));
        
        ServiceRelationShipConfig srConfig = new ServiceRelationShipConfig();
        srConfig.setDbConnectionConfig(config);
        
        return srConfig;
    }
    
    public static void main(String[] args)
    {
        try
        {
            ServiceRelationShipConfig config = PropertyManager.instance().getServiceRelationShipConfig();

            log.info("Service RelationShip Config - {}", config);

            ServiceLookupConfig slvConfig = PropertyManager.instance().getServiceLookupConfig();

            log.info("Service RelationShip Config - {}", slvConfig);
        }
        catch(Exception ex)
        {
            log.error("caught exception", ex);
            
        }
    }
}
