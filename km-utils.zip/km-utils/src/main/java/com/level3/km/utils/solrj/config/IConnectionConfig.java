package com.level3.km.utils.solrj.config;

public interface IConnectionConfig
{
    public DbConnectionConfig getDbConnectionConfig();
}
