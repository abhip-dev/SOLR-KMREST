package com.level3.km.utils.solrj.servicelookup;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.solr.common.SolrInputDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.utils.solrj.config.PropertyManager;
import com.level3.km.utils.solrj.db.DbConnection;
import com.level3.km.utils.solrj.legacy.DbConnectionManager;
import com.level3.km.utils.solrj.thread.PooledExecutors;

public class ServiceLookupDataReader implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(ServiceLookupDataReader.class); 
    private static int DEFAULT_BATCH_SIZE = 2500;

    private int batchSize = -1;

    private Collection<SolrInputDocument> documentList = new ArrayList<SolrInputDocument>();
    
//    private CloudSolrServer server = null;
    
    private int documentsCommitted = 0;
    
    private DbConnection slvConn = null;
    
    private String filterCriteria = null;
    private ServiceLookupManager manager = null;

    private static final String slvQuery = 
         "SELECT " +
         "slv.SOURCE_SYS_NM || '#' || slv.sid || '#' || slv.scid || '#' || slv.customer_order || '#' || SLV.SERVICE_ORDER || '#' || slv.so_sequence || '#' || component_id  || '#' || sl.service_location_key_id || '#' || slv.BILLING_START_DT AS id," +
         "slv.SOURCE_SYS_NM AS dwSourceSystemCode, " +
         "slv.ACCOUNT_ID AS customerNumber, " +
         "slv.ACCOUNT AS customerName, " +
         "slv.THIRD_PARTY_ACCOUNT_ID AS endCustomerNumber, " +
         "slv.THIRD_PARTY_ACCOUNT AS endCustomerName, " +
         "slv.CUSTOMER_ORDER AS customerOrderNumber, " +
         "slv.SERVICE_ORDER AS serviceOrderNumber, " +
         "slv.PIID AS productInstanceId, " +
         "slv.SCID AS serviceComponentId, " +
         "slv.PRODUCT AS productName, " +
         "slv.PRODUCT_ID AS productCode, " +
         "slv.COMPONENT AS serviceComponentProductName, " +
         "slv.COMPONENT_ID AS serviceComponentProductCode, " +
         "slv.BILLING_START_DT AS BILLSTARTDATE, " +
         "slv.CUST_REQUEST_DT AS CUSTOMERREQUESTDATE, " +
         "slv.MRC AS usdTotalMrcAmount, " +
         "slv.SERVICE_ORDER_TYPE AS serviceOrderType, " +
         "slv.SERVICE_ORDER_STATUS AS serviceOrderStatusCode, " +
         "slv.SERVICE_ORDER_ACTION AS serviceOrderActionType, " +
         "slv.GATEWAY AS gatewayName, " +
         "slv.CUSTOMER_ORDER_CREATE_DT AS CUSTOMERORDERCREATEDATE, " +
         "slv.SERVICE_SITE_LOCATION AS serviceLocationAddress, " +
         "slv.SERVICE_SITE AS serviceLocationName, " +
         "slv.SID AS serviceInstanceId, " +
         "slv.ACTIVE_FLAG AS activeIndicator, " +
         "slv.SO_SEQUENCE AS serviceOrderSequenceNumber, " +
         "slv.SO_NET_IND AS onnetIndicator, " +
         "slv.CUST_CCID AS customerCircuitId, " +
         "slv.INSTALLED_DT AS SERVICEINSTALLDATE, " +
         "slv.TSP_CODE AS tspCode, " +
         "slv.LEGACY_ACCOUNT_ID AS sourceCustomerNumber, " +
         "slv.DIVERSITY_TRAIL_NAME AS diversityTrailName, " +
         "slv.DIVERSITY_SECOND_TRAIL_NAME AS diversitySecondTrailName, " +
         "slv.BANDWIDTH_CODE AS bandwidthCode, " +
         "slv.A_END_NODE_NAME AS aEndClliCode, " +
         "slv.Z_END_NODE_NAME AS zEndClliCode, " +
         "slv.LEGACY_BILL_ACCOUNT_NUMBER AS legacyBillAccountNumber, " +
         "slv.LEGACY_SERVICE_ORDER_NUMBER AS legacyLastServiceOrderNumber, " +
         "slv.LEGACY_ORIGINAL_SYSTEM AS legacySourceSystemCode, " +
         "slv.LEGACY_CIRCUIT_ID AS legacyCircuitId, " +
         "slv.PON AS customerPurchaseOrderNumber, " +
         "slv.ASSOCIATED_SERVICE AS associatedOrderNumber, " +
         "slv.LATENCY_GUARANTEE_FLAG AS latencyGuranteeLevelType, " +
         "slv.LATENCY_GUARANTEE_VALUE AS latencyGuranteeValue, " +
         "slv.LATENCY_ACTUAL_VALUE AS latencyActualValue, " +
         "slv.IP_VERSION_CD AS ipVersionCode, " +
         "slv.EQUIP_CONFIG_DESC AS equipmentConfigDescription, " +
         "slv.EQUIP_MANUF_NAME AS equipmentManufacturerName, " +
         "slv.EQUIP_SERV_PROVIDER_NAME AS equipmentServiceProviderName, " +
         "slv.EQUIP_MAINT_AGREE_TYP AS equipmentMaintAgreementType, " +
         "CASE WHEN slv.CNR_JEOP_IND = 'Y' then 1 " +
         "WHEN slv.CNR_JEOP_IND = 'N' then 0 " +
         "ELSE null END AS cnrJeopIndicator, " +
         "slv.CNR_JEOP_RAISED_DT AS CNRJEOPRAISEDDATE, " +
         "CASE WHEN slv.BUNDLED_SERVICE_IND = 'Y' then 1 " +
         "WHEN slv.BUNDLED_SERVICE_IND = 'N' then 0 " +
         "ELSE null END AS bundledServiceIndicator, " +
         "slv.ULTIMATE_SERVICE_STATE AS ultimateServiceStatusCode, " +
         "slv.BILL_ACCOUNT_NBR AS billAccountNumber, " +
         "slv.PARENT_BILL_ACCOUNT_NBR AS parentBillAccountNumber, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND = 'NF' then null " +
         "ELSE null END AS activeBillIndicator, " +
         "CASE WHEN slv.ENABLE_AUTO_TICKET_IND = 'Y' then 1 " +
         "WHEN slv.ENABLE_AUTO_TICKET_IND = 'N' then 0 " +
         "ELSE null END AS enableAutoTicketIndicator, " +
         "slv.PROTECT_TYP AS protectType, " +
         "slv.SERVICE_LOCATION_ID AS serviceLocationId, " +
         "slv.SPECIALS_ID AS specialsId, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_SID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SID = 'NF' then null " +
         "ELSE null END AS sidActiveBillIndicator, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_SCID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SCID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_SCID = 'NF' then null " +
         "ELSE null END AS scidActiveBillIndicator, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_PIID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PIID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PIID = 'NF' then null " +
         "ELSE null END AS piidActiveBillIndicator, " +
         "CASE WHEN slv.ACTIVE_IN_BILLING_IND_PCSID = 'Y' then 1 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PCSID = 'N' then 0 " +
         "WHEN slv.ACTIVE_IN_BILLING_IND_PCSID = 'NF' then null " +
         "ELSE null END AS pcsidActiveBillIndicator, " +
         "slv.COMPONENT_SUBTYPE_NAME AS componentSubTypeName, " +
         "slv.BILL_ACCOUNT_NAME AS billAccountName, " +
         "slv.SERVICE_CLASS_LEVEL_TYP AS serviceClassLevelType, " +
         "sl.CIRCUIT_ID AS circuitId, " +
         "sl.SID AS serviceId, " +
         "sl.A_LINE1_ADDR AS aLine1Address, " +
         "sl.A_LINE2_ADDR AS aLine2Address, " +
         "sl.A_CITY_NAME AS aCityName, " +
         "sl.A_STATE_CD AS aStateCode, " +
         "sl.A_POSTAL_CD AS aPostalCode, " +
         "sl.A_COUNTY_NAME AS aCountyName, " +
         "sl.A_COUNTRY_NAME AS aCountryName, " +
         "sl.A_LATITUDE_NBR AS aLatitudeNumber, " +
         "sl.A_LONGITUDE_NBR AS aLongitudeNumber, " +
         "sl.Z_LINE1_ADDR AS zLine1Address, " +
         "sl.Z_LINE2_ADDR AS zLine2Address, " +
         "sl.Z_CITY_NAME AS zCityName, " +
         "sl.Z_STATE_CD AS zStateCode, " +
         "sl.Z_POSTAL_CD AS zPostalCode, " +
         "sl.Z_COUNTY_NAME AS zCountyName, " +
         "sl.Z_COUNTRY_NAME AS zCountryName, " +
         "sl.Z_LATITUDE_NBR AS zLatitudeNumber, " +
         "sl.Z_LONGITUDE_NBR AS zLongitudeNumber, " +
         "sl.A_LOCATION_ID AS aLocationId, " +
         "sl.Z_LOCATION_ID AS zLocationId, " +
         "sl.A_LOCATION_NAME AS aLocationName, " +
         "sl.Z_LOCATION_NAME AS zLocationName, " +
         "sl.A_TIMEZONE_NAME AS aTimezoneName, " +
         "sl.Z_TIMEZONE_NAME AS zTimezoneName, " +
         "sl.A_DOKUVIZ_ID AS aDokuvizId, " +
         "sl.Z_DOKUVIZ_ID AS zDokuvizId, " +
         "sl.A_LOC_NBR AS aLocationNumber, " +
         "sl.Z_LOC_NBR AS zLocationNumber, " +
         "sl.A_REGION_CD AS aRegionCode, " +
         "sl.Z_REGION_CD AS zRegionCode " +
         "FROM service_lookup_mvw slv " +
         "LEFT JOIN service_location sl  " +
         "ON sl.service_location_id = slv.service_location_id ";
    
    public ServiceLookupDataReader(String filterCriteria, ServiceLookupManager manager, int batchSize) 
    {
        this.filterCriteria = filterCriteria;
        this.manager = manager;
        this.batchSize = batchSize;

        /*
        server = new CloudSolrServer(this.manager.getConfig().getZkHost());
        server.setDefaultCollection(this.manager.getConfig().getCollectionName());
        server.setIdField(this.manager.getConfig().getCollectionIdField());
        server.setZkClientTimeout(1000);
        server.setZkConnectTimeout(1000);
        server.setParser(new BinaryResponseParser());
        server.setRequestWriter(new BinaryRequestWriter());
        */
        
        slvConn = new DbConnection(PropertyManager.SERVICE_LOOKUP_CONFIG);
    }

    public ServiceLookupDataReader(String filterCriteria, ServiceLookupManager manager) 
    {
        this(filterCriteria, manager, DEFAULT_BATCH_SIZE);
    }

    public static synchronized String generateUUID()
    {
        return UUID.randomUUID().toString();
    }
    
    public void run()
    {
        process();
        
        manager.countLatchDown();
    }
    
    public void process()
    {
        addToSolrIndex();
        
        finishIndexing();
    }
    
    private void addToSolrIndex()
    {
        PreparedStatement stmt = null;
        ResultSet resultSet = null;
        SolrInputDocument solrInputDocument = null;
        String id = null;
        String dwSourceSystemCode = null;
        String customerNumber = null;
        String customerName = null;
        String endCustomerNumber = null;
        String endCustomerName = null;
        String customerOrderNumber = null;
        String serviceOrderNumber = null;
        String productInstanceId = null;
        String serviceComponentId = null;
        String productName = null;
        String productCode = null;
        String serviceComponentProductName = null;
        String serviceComponentProductCode = null;
        Date billStartDate = null;
        Date customerRequestDate = null;
        Double usdTotalMrcAmount = null;
        String serviceOrderType = null;
        String serviceOrderStatusCode = null;
        String serviceOrderActionType = null;
        String gatewayName = null;
        Date customerOrderCreateDate = null;
        String serviceLocationAddress = null;
        String serviceLocationName = null;
        String serviceInstanceId = null;
        String activeIndicator = null;
        String serviceOrderSequenceNumber = null;
        String onnetIndicator = null;
        String customerCircuitId = null;
        Date serviceInstallDate = null;
        String tspCode = null;
        String sourceCustomerNumber = null;
        String diversityTrailName = null;
        String diversitySecondTrailName = null;
        String bandwidthCode = null;
        String aEndClliCode = null;
        String zEndClliCode = null;
        String legacyBillAccountNumber = null;
        String legacyLastServiceOrderNumber = null;
        String legacySourceSystemCode = null;
        String legacyCircuitId = null;
        String customerPurchaseOrderNumber = null;
        String associatedOrderNumber = null;
        String latencyGuranteeLevelType = null;
        Long latencyGuranteeValue = null;
        Long latencyActualValue = null;
        String ipVersionCode = null;
        String equipmentConfigDescription = null;
        String equipmentManufacturerName = null;
        String equipmentServiceProviderName = null;
        String equipmentMaintAgreementType = null;
        Boolean cnrJeopIndicator = null;
        Date cnrJeopRaisedDate = null;
        Boolean bundledServiceIndicator = null;
        String ultimateServiceStatusCode = null;
        String billAccountNumber = null;
        String parentBillAccountNumber = null;
        Boolean activeBillIndicator = null;
        Boolean enableAutoTicketIndicator = null;
        String protectType = null;
        Long serviceLocationId = null;
        String specialsId = null;
        Boolean sidActiveBillIndicator = null;
        Boolean scidActiveBillIndicator = null;
        Boolean piidActiveBillIndicator = null;
        Boolean pcsidActiveBillIndicator = null;
        String componentSubTypeName = null;
        String billAccountName = null;
        String serviceClassLevelType = null;
        String circuitId = null;
        String serviceId = null;
        String aLine1Address = null;
        String aLine2Address = null;
        String aCityName = null;
        String aStateCode = null;
        String aPostalCode = null;
        String aCountyName = null;
        String aCountryName = null;
        Double aLatitudeNumber = null;
        Double aLongitudeNumber = null;
        String zLine1Address = null;
        String zLine2Address = null;
        String zCityName = null;
        String zStateCode = null;
        String zPostalCode = null;
        String zCountyName = null;
        String zCountryName = null;
        Double zLatitudeNumber = null;
        Double zLongitudeNumber = null;
        String aLocationId = null;
        String zLocationId = null;
        String aLocationName = null;
        String zLocationName = null;
        String aTimezoneName = null;
        String zTimezoneName = null;
        String aDokuvizId = null;
        String zDokuvizId = null;
        Long aLocationNumber = null;
        Long zLocationNumber = null;
        String aRegionCode = null;
        String zRegionCode = null;
        List<String> relatedServiceInstanceIdLevel1 = null;
        List<String> relatedServiceInstanceIdLevel2 = null;
        List<String> relatedServiceInstanceIdLevel3 = null;
        List<String> relatedServiceInstanceIdLevel4 = null;
        List<String> relatedServiceInstanceIdLevel5 = null;
        ServiceLookupIndexer indexer = null;

        try
        {
            stmt = slvConn.getPreparedStatement(slvQuery + filterCriteria);
            
            resultSet = slvConn.executeQuery(stmt);
            
            while(resultSet != null && resultSet.next())
            {
                solrInputDocument = new SolrInputDocument(); 
                
//                id = generateUUID();
                id = DbConnectionManager.readString(resultSet, "ID");
                if(id != null)
                {
                    solrInputDocument.addField("id", id);
                }
                dwSourceSystemCode = DbConnectionManager.readString(resultSet, "DWSOURCESYSTEMCODE");
                if(dwSourceSystemCode != null)
                {
                    solrInputDocument.addField("dwSourceSystemCode", dwSourceSystemCode);
                }
                customerNumber = DbConnectionManager.readString(resultSet, "CUSTOMERNUMBER");
                if(customerNumber != null)
                {
                    solrInputDocument.addField("customerNumber", customerNumber);
                }
                customerName = DbConnectionManager.readString(resultSet, "CUSTOMERNAME");
                if(customerName != null)
                {
                    solrInputDocument.addField("customerName", customerName);
                }
                endCustomerNumber = DbConnectionManager.readString(resultSet, "ENDCUSTOMERNUMBER");
                if(endCustomerNumber != null)
                {
                    solrInputDocument.addField("endCustomerNumber", endCustomerNumber);
                }
                endCustomerName = DbConnectionManager.readString(resultSet, "ENDCUSTOMERNAME");
                if(endCustomerName != null)
                {
                    solrInputDocument.addField("endCustomerName", endCustomerName);
                }
                customerOrderNumber = DbConnectionManager.readString(resultSet, "CUSTOMERORDERNUMBER");
                if(customerOrderNumber != null)
                {
                    solrInputDocument.addField("customerOrderNumber", customerOrderNumber);
                }
                serviceOrderNumber = DbConnectionManager.readString(resultSet, "SERVICEORDERNUMBER");
                if(serviceOrderNumber != null)
                {
                    solrInputDocument.addField("serviceOrderNumber", serviceOrderNumber);
                }
                productInstanceId = DbConnectionManager.readString(resultSet, "PRODUCTINSTANCEID");
                if(productInstanceId != null)
                {
                    solrInputDocument.addField("productInstanceId", productInstanceId);
                }
                serviceComponentId = DbConnectionManager.readString(resultSet, "SERVICECOMPONENTID");
                if(serviceComponentId != null)
                {
                    solrInputDocument.addField("serviceComponentId", serviceComponentId);
                }
                productName = DbConnectionManager.readString(resultSet, "PRODUCTNAME");
                if(productName != null)
                {
                    solrInputDocument.addField("productName", productName);
                }
                productCode = DbConnectionManager.readString(resultSet, "PRODUCTCODE");
                if(productCode != null)
                {
                    solrInputDocument.addField("productCode", productCode);
                }
                serviceComponentProductName = DbConnectionManager.readString(resultSet, "SERVICECOMPONENTPRODUCTNAME");
                if(serviceComponentProductName != null)
                {
                    solrInputDocument.addField("serviceComponentProductName", serviceComponentProductName);
                }
                serviceComponentProductCode = DbConnectionManager.readString(resultSet, "SERVICECOMPONENTPRODUCTCODE");
                if(serviceComponentProductCode != null)
                {
                    solrInputDocument.addField("serviceComponentProductCode", serviceComponentProductCode);
                }
                billStartDate = DbConnectionManager.readDate(resultSet, "BILLSTARTDATE");
                if(billStartDate != null)
                {
                    solrInputDocument.addField("billStartDate", billStartDate);
                }
                customerRequestDate = DbConnectionManager.readDate(resultSet, "CUSTOMERREQUESTDATE");
                if(customerRequestDate != null)
                {
                    solrInputDocument.addField("customerRequestDate", customerRequestDate);
                }
                usdTotalMrcAmount = DbConnectionManager.readDouble(resultSet, "USDTOTALMRCAMOUNT");
                if(usdTotalMrcAmount != null)
                {
                    solrInputDocument.addField("usdTotalMrcAmount", usdTotalMrcAmount);
                }
                serviceOrderType = DbConnectionManager.readString(resultSet, "SERVICEORDERTYPE");
                if(serviceOrderType != null)
                {
                    solrInputDocument.addField("serviceOrderType", serviceOrderType);
                }
                serviceOrderStatusCode = DbConnectionManager.readString(resultSet, "SERVICEORDERSTATUSCODE");
                if(serviceOrderStatusCode != null)
                {
                    solrInputDocument.addField("serviceOrderStatusCode", serviceOrderStatusCode);
                }
                serviceOrderActionType = DbConnectionManager.readString(resultSet, "SERVICEORDERACTIONTYPE");
                if(serviceOrderActionType != null)
                {
                    solrInputDocument.addField("serviceOrderActionType", serviceOrderActionType);
                }
                gatewayName = DbConnectionManager.readString(resultSet, "GATEWAYNAME");
                if(gatewayName != null)
                {
                    solrInputDocument.addField("gatewayName", gatewayName);
                }
                customerOrderCreateDate = DbConnectionManager.readDate(resultSet, "CUSTOMERORDERCREATEDATE");
                if(customerOrderCreateDate != null)
                {
                    solrInputDocument.addField("customerOrderCreateDate", customerOrderCreateDate);
                }
                serviceLocationAddress = DbConnectionManager.readString(resultSet, "SERVICELOCATIONADDRESS");
                if(serviceLocationAddress != null)
                {
                    solrInputDocument.addField("serviceLocationAddress", serviceLocationAddress);
                }
                serviceLocationName = DbConnectionManager.readString(resultSet, "SERVICELOCATIONNAME");
                if(serviceLocationName != null)
                {
                    solrInputDocument.addField("serviceLocationName", serviceLocationName);
                }
                serviceInstanceId = DbConnectionManager.readString(resultSet, "SERVICEINSTANCEID");
                if(serviceInstanceId != null)
                {
                    solrInputDocument.addField("serviceInstanceId", serviceInstanceId);
                    
                    relatedServiceInstanceIdLevel1 = ServiceRelationShipManager.getRelatedSidLevel1(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel1 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel1", relatedServiceInstanceIdLevel1);
                    }
                    
                    relatedServiceInstanceIdLevel2 = ServiceRelationShipManager.getRelatedSidLevel2(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel2 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel2", relatedServiceInstanceIdLevel2);
                    }
                    
                    relatedServiceInstanceIdLevel3 = ServiceRelationShipManager.getRelatedSidLevel3(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel3 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel3", relatedServiceInstanceIdLevel3);
                    }
                    
                    relatedServiceInstanceIdLevel4 = ServiceRelationShipManager.getRelatedSidLevel4(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel4 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel4", relatedServiceInstanceIdLevel4);
                    }
                    
                    relatedServiceInstanceIdLevel5 = ServiceRelationShipManager.getRelatedSidLevel5(serviceInstanceId);
                    
                    if(relatedServiceInstanceIdLevel5 != null)
                    {
                        solrInputDocument.addField("relatedServiceInstanceIdLevel5", relatedServiceInstanceIdLevel5);
                    }
                }
                activeIndicator = DbConnectionManager.readString(resultSet, "ACTIVEINDICATOR");
                if(activeIndicator != null)
                {
                    solrInputDocument.addField("activeIndicator", activeIndicator);
                }
                serviceOrderSequenceNumber = DbConnectionManager.readString(resultSet, "SERVICEORDERSEQUENCENUMBER");
                if(serviceOrderSequenceNumber != null)
                {
                    solrInputDocument.addField("serviceOrderSequenceNumber", serviceOrderSequenceNumber);
                }
                onnetIndicator = DbConnectionManager.readString(resultSet, "ONNETINDICATOR");
                if(onnetIndicator != null)
                {
                    solrInputDocument.addField("onnetIndicator", onnetIndicator);
                }
                customerCircuitId = DbConnectionManager.readString(resultSet, "CUSTOMERCIRCUITID");
                if(customerCircuitId != null)
                {
                    solrInputDocument.addField("customerCircuitId", customerCircuitId);
                }
                serviceInstallDate = DbConnectionManager.readDate(resultSet, "SERVICEINSTALLDATE");
                if(serviceInstallDate != null)
                {
                    solrInputDocument.addField("serviceInstallDate", serviceInstallDate);
                }
                tspCode = DbConnectionManager.readString(resultSet, "TSPCODE");
                if(tspCode != null)
                {
                    solrInputDocument.addField("tspCode", tspCode);
                }
                sourceCustomerNumber = DbConnectionManager.readString(resultSet, "SOURCECUSTOMERNUMBER");
                if(sourceCustomerNumber != null)
                {
                    solrInputDocument.addField("sourceCustomerNumber", sourceCustomerNumber);
                }
                diversityTrailName = DbConnectionManager.readString(resultSet, "DIVERSITYTRAILNAME");
                if(diversityTrailName != null)
                {
                    solrInputDocument.addField("diversityTrailName", diversityTrailName);
                }
                diversitySecondTrailName = DbConnectionManager.readString(resultSet, "DIVERSITYSECONDTRAILNAME");
                if(diversitySecondTrailName != null)
                {
                    solrInputDocument.addField("diversitySecondTrailName", diversitySecondTrailName);
                }
                bandwidthCode = DbConnectionManager.readString(resultSet, "BANDWIDTHCODE");
                if(bandwidthCode != null)
                {
                    solrInputDocument.addField("bandwidthCode", bandwidthCode);
                }
                aEndClliCode = DbConnectionManager.readString(resultSet, "AENDCLLICODE");
                if(aEndClliCode != null)
                {
                    solrInputDocument.addField("aEndClliCode", aEndClliCode);
                }
                zEndClliCode = DbConnectionManager.readString(resultSet, "ZENDCLLICODE");
                if(zEndClliCode != null)
                {
                    solrInputDocument.addField("zEndClliCode", zEndClliCode);
                }
                legacyBillAccountNumber = DbConnectionManager.readString(resultSet, "LEGACYBILLACCOUNTNUMBER");
                if(legacyBillAccountNumber != null)
                {
                    solrInputDocument.addField("legacyBillAccountNumber", legacyBillAccountNumber);
                }
                legacyLastServiceOrderNumber = DbConnectionManager.readString(resultSet, "LEGACYLASTSERVICEORDERNUMBER");
                if(legacyLastServiceOrderNumber != null)
                {
                    solrInputDocument.addField("legacyLastServiceOrderNumber", legacyLastServiceOrderNumber);
                }
                legacySourceSystemCode = DbConnectionManager.readString(resultSet, "LEGACYSOURCESYSTEMCODE");
                if(legacySourceSystemCode != null)
                {
                    solrInputDocument.addField("legacySourceSystemCode", legacySourceSystemCode);
                }
                legacyCircuitId = DbConnectionManager.readString(resultSet, "LEGACYCIRCUITID");
                if(legacyCircuitId != null)
                {
                    solrInputDocument.addField("legacyCircuitId", legacyCircuitId);
                }
                customerPurchaseOrderNumber = DbConnectionManager.readString(resultSet, "CUSTOMERPURCHASEORDERNUMBER");
                if(customerPurchaseOrderNumber != null)
                {
                    solrInputDocument.addField("customerPurchaseOrderNumber", customerPurchaseOrderNumber);
                }
                associatedOrderNumber = DbConnectionManager.readString(resultSet, "ASSOCIATEDORDERNUMBER");
                if(associatedOrderNumber != null)
                {
                    solrInputDocument.addField("associatedOrderNumber", associatedOrderNumber);
                }
                latencyGuranteeLevelType = DbConnectionManager.readString(resultSet, "LATENCYGURANTEELEVELTYPE");
                if(latencyGuranteeLevelType != null)
                {
                    solrInputDocument.addField("latencyGuranteeLevelType", latencyGuranteeLevelType);
                }
                latencyGuranteeValue = DbConnectionManager.readLong(resultSet, "LATENCYGURANTEEVALUE");
                if(latencyGuranteeValue != null)
                {
                    solrInputDocument.addField("latencyGuranteeValue", latencyGuranteeValue);
                }
                latencyActualValue = DbConnectionManager.readLong(resultSet, "LATENCYACTUALVALUE");
                if(latencyActualValue != null)
                {
                    solrInputDocument.addField("latencyActualValue", latencyActualValue);
                }
                ipVersionCode = DbConnectionManager.readString(resultSet, "IPVERSIONCODE");
                if(ipVersionCode != null)
                {
                    solrInputDocument.addField("ipVersionCode", ipVersionCode);
                }
                equipmentConfigDescription = DbConnectionManager.readString(resultSet, "EQUIPMENTCONFIGDESCRIPTION");
                if(equipmentConfigDescription != null)
                {
                    solrInputDocument.addField("equipmentConfigDescription", equipmentConfigDescription);
                }
                equipmentManufacturerName = DbConnectionManager.readString(resultSet, "EQUIPMENTMANUFACTURERNAME");
                if(equipmentManufacturerName != null)
                {
                    solrInputDocument.addField("equipmentManufacturerName", equipmentManufacturerName);
                }
                equipmentServiceProviderName = DbConnectionManager.readString(resultSet, "EQUIPMENTSERVICEPROVIDERNAME");
                if(equipmentServiceProviderName != null)
                {
                    solrInputDocument.addField("equipmentServiceProviderName", equipmentServiceProviderName);
                }
                equipmentMaintAgreementType = DbConnectionManager.readString(resultSet, "EQUIPMENTMAINTAGREEMENTTYPE");
                if(equipmentMaintAgreementType != null)
                {
                    solrInputDocument.addField("equipmentMaintAgreementType", equipmentMaintAgreementType);
                }
                cnrJeopIndicator = DbConnectionManager.readBoolean(resultSet, "CNRJEOPINDICATOR");
                if(cnrJeopIndicator != null)
                {
                    solrInputDocument.addField("cnrJeopIndicator", cnrJeopIndicator);
                }
                cnrJeopRaisedDate = DbConnectionManager.readDate(resultSet, "CNRJEOPRAISEDDATE");
                if(cnrJeopRaisedDate != null)
                {
                    solrInputDocument.addField("cnrJeopRaisedDate", cnrJeopRaisedDate);
                }
                bundledServiceIndicator = DbConnectionManager.readBoolean(resultSet, "BUNDLEDSERVICEINDICATOR");
                if(bundledServiceIndicator != null)
                {
                    solrInputDocument.addField("bundledServiceIndicator", bundledServiceIndicator);
                }
                ultimateServiceStatusCode = DbConnectionManager.readString(resultSet, "ULTIMATESERVICESTATUSCODE");
                if(ultimateServiceStatusCode != null)
                {
                    solrInputDocument.addField("ultimateServiceStatusCode", ultimateServiceStatusCode);
                }
                billAccountNumber = DbConnectionManager.readString(resultSet, "BILLACCOUNTNUMBER");
                if(billAccountNumber != null)
                {
                    solrInputDocument.addField("billAccountNumber", billAccountNumber);
                }
                parentBillAccountNumber = DbConnectionManager.readString(resultSet, "PARENTBILLACCOUNTNUMBER");
                if(parentBillAccountNumber != null)
                {
                    solrInputDocument.addField("parentBillAccountNumber", parentBillAccountNumber);
                }
                activeBillIndicator = DbConnectionManager.readBoolean(resultSet, "ACTIVEBILLINDICATOR");
                if(activeBillIndicator != null)
                {
                    solrInputDocument.addField("activeBillIndicator", activeBillIndicator);
                }
                enableAutoTicketIndicator = DbConnectionManager.readBoolean(resultSet, "ENABLEAUTOTICKETINDICATOR");
                if(enableAutoTicketIndicator != null)
                {
                    solrInputDocument.addField("enableAutoTicketIndicator", enableAutoTicketIndicator);
                }
                protectType = DbConnectionManager.readString(resultSet, "PROTECTTYPE");
                if(protectType != null)
                {
                    solrInputDocument.addField("protectType", protectType);
                }
                serviceLocationId = DbConnectionManager.readLong(resultSet, "SERVICELOCATIONID");
                if(serviceLocationId != null)
                {
                    solrInputDocument.addField("serviceLocationId", serviceLocationId);
                }
                specialsId = DbConnectionManager.readString(resultSet, "SPECIALSID");
                if(specialsId != null)
                {
                    solrInputDocument.addField("specialsId", specialsId);
                }
                sidActiveBillIndicator = DbConnectionManager.readBoolean(resultSet, "SIDACTIVEBILLINDICATOR");
                if(sidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("sidActiveBillIndicator", sidActiveBillIndicator);
                }
                scidActiveBillIndicator = DbConnectionManager.readBoolean(resultSet, "SCIDACTIVEBILLINDICATOR");
                if(scidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("scidActiveBillIndicator", scidActiveBillIndicator);
                }
                piidActiveBillIndicator = DbConnectionManager.readBoolean(resultSet, "PIIDACTIVEBILLINDICATOR");
                if(piidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("piidActiveBillIndicator", piidActiveBillIndicator);
                }
                pcsidActiveBillIndicator = DbConnectionManager.readBoolean(resultSet, "PCSIDACTIVEBILLINDICATOR");
                if(pcsidActiveBillIndicator != null)
                {
                    solrInputDocument.addField("pcsidActiveBillIndicator", pcsidActiveBillIndicator);
                }
                componentSubTypeName = DbConnectionManager.readString(resultSet, "COMPONENTSUBTYPENAME");
                if(componentSubTypeName != null)
                {
                    solrInputDocument.addField("componentSubTypeName", componentSubTypeName);
                }
                billAccountName = DbConnectionManager.readString(resultSet, "BILLACCOUNTNAME");
                if(billAccountName != null)
                {
                    solrInputDocument.addField("billAccountName", billAccountName);
                }
                serviceClassLevelType = DbConnectionManager.readString(resultSet, "SERVICECLASSLEVELTYPE");
                if(serviceClassLevelType != null)
                {
                    solrInputDocument.addField("serviceClassLevelType", serviceClassLevelType);
                }
                circuitId = DbConnectionManager.readString(resultSet, "CIRCUITID");
                if(circuitId != null)
                {
                    solrInputDocument.addField("circuitId", circuitId);
                }
                serviceId = DbConnectionManager.readString(resultSet, "SERVICEID");
                if(serviceId != null)
                {
                    solrInputDocument.addField("serviceId", serviceId);
                }
                aLine1Address = DbConnectionManager.readString(resultSet, "ALINE1ADDRESS");
                if(aLine1Address != null)
                {
                    solrInputDocument.addField("aLine1Address", aLine1Address);
                }
                aLine2Address = DbConnectionManager.readString(resultSet, "ALINE2ADDRESS");
                if(aLine2Address != null)
                {
                    solrInputDocument.addField("aLine2Address", aLine2Address);
                }
                aCityName = DbConnectionManager.readString(resultSet, "ACITYNAME");
                if(aCityName != null)
                {
                    solrInputDocument.addField("aCityName", aCityName);
                }
                aStateCode = DbConnectionManager.readString(resultSet, "ASTATECODE");
                if(aStateCode != null)
                {
                    solrInputDocument.addField("aStateCode", aStateCode);
                }
                aPostalCode = DbConnectionManager.readString(resultSet, "APOSTALCODE");
                if(aPostalCode != null)
                {
                    solrInputDocument.addField("aPostalCode", aPostalCode);
                }
                aCountyName = DbConnectionManager.readString(resultSet, "ACOUNTYNAME");
                if(aCountyName != null)
                {
                    solrInputDocument.addField("aCountyName", aCountyName);
                }
                aCountryName = DbConnectionManager.readString(resultSet, "ACOUNTRYNAME");
                if(aCountryName != null)
                {
                    solrInputDocument.addField("aCountryName", aCountryName);
                }
                aLatitudeNumber = DbConnectionManager.readDouble(resultSet, "ALATITUDENUMBER");
                if(aLatitudeNumber != null)
                {
                    solrInputDocument.addField("aLatitudeNumber", aLatitudeNumber);
                }
                aLongitudeNumber = DbConnectionManager.readDouble(resultSet, "ALONGITUDENUMBER");
                if(aLongitudeNumber != null)
                {
                    solrInputDocument.addField("aLongitudeNumber", aLongitudeNumber);
                }
                zLine1Address = DbConnectionManager.readString(resultSet, "ZLINE1ADDRESS");
                if(zLine1Address != null)
                {
                    solrInputDocument.addField("zLine1Address", zLine1Address);
                }
                zLine2Address = DbConnectionManager.readString(resultSet, "ZLINE2ADDRESS");
                if(zLine2Address != null)
                {
                    solrInputDocument.addField("zLine2Address", zLine2Address);
                }
                zCityName = DbConnectionManager.readString(resultSet, "ZCITYNAME");
                if(zCityName != null)
                {
                    solrInputDocument.addField("zCityName", zCityName);
                }
                zStateCode = DbConnectionManager.readString(resultSet, "ZSTATECODE");
                if(zStateCode != null)
                {
                    solrInputDocument.addField("zStateCode", zStateCode);
                }
                zPostalCode = DbConnectionManager.readString(resultSet, "ZPOSTALCODE");
                if(zPostalCode != null)
                {
                    solrInputDocument.addField("zPostalCode", zPostalCode);
                }
                zCountyName = DbConnectionManager.readString(resultSet, "ZCOUNTYNAME");
                if(zCountyName != null)
                {
                    solrInputDocument.addField("zCountyName", zCountyName);
                }
                zCountryName = DbConnectionManager.readString(resultSet, "ZCOUNTRYNAME");
                if(zCountryName != null)
                {
                    solrInputDocument.addField("zCountryName", zCountryName);
                }
                zLatitudeNumber = DbConnectionManager.readDouble(resultSet, "ZLATITUDENUMBER");
                if(zLatitudeNumber != null)
                {
                    solrInputDocument.addField("zLatitudeNumber", zLatitudeNumber);
                }
                zLongitudeNumber = DbConnectionManager.readDouble(resultSet, "ZLONGITUDENUMBER");
                if(zLongitudeNumber != null)
                {
                    solrInputDocument.addField("zLongitudeNumber", zLongitudeNumber);
                }
                aLocationId = DbConnectionManager.readString(resultSet, "ALOCATIONID");
                if(aLocationId != null)
                {
                    solrInputDocument.addField("aLocationId", aLocationId);
                }
                zLocationId = DbConnectionManager.readString(resultSet, "ZLOCATIONID");
                if(zLocationId != null)
                {
                    solrInputDocument.addField("zLocationId", zLocationId);
                }
                aLocationName = DbConnectionManager.readString(resultSet, "ALOCATIONNAME");
                if(aLocationName != null)
                {
                    solrInputDocument.addField("aLocationName", aLocationName);
                }
                zLocationName = DbConnectionManager.readString(resultSet, "ZLOCATIONNAME");
                if(zLocationName != null)
                {
                    solrInputDocument.addField("zLocationName", zLocationName);
                }
                aTimezoneName = DbConnectionManager.readString(resultSet, "ATIMEZONENAME");
                if(aTimezoneName != null)
                {
                    solrInputDocument.addField("aTimezoneName", aTimezoneName);
                }
                zTimezoneName = DbConnectionManager.readString(resultSet, "ZTIMEZONENAME");
                if(zTimezoneName != null)
                {
                    solrInputDocument.addField("zTimezoneName", zTimezoneName);
                }
                aDokuvizId = DbConnectionManager.readString(resultSet, "ADOKUVIZID");
                if(aDokuvizId != null)
                {
                    solrInputDocument.addField("aDokuvizId", aDokuvizId);
                }
                zDokuvizId = DbConnectionManager.readString(resultSet, "ZDOKUVIZID");
                if(zDokuvizId != null)
                {
                    solrInputDocument.addField("zDokuvizId", zDokuvizId);
                }
                aLocationNumber = DbConnectionManager.readLong(resultSet, "ALOCATIONNUMBER");
                if(aLocationNumber != null)
                {
                    solrInputDocument.addField("aLocationNumber", aLocationNumber);
                }
                zLocationNumber = DbConnectionManager.readLong(resultSet, "ZLOCATIONNUMBER");
                if(zLocationNumber != null)
                {
                    solrInputDocument.addField("zLocationNumber", zLocationNumber);
                }
                aRegionCode = DbConnectionManager.readString(resultSet, "AREGIONCODE");
                if(aRegionCode != null)
                {
                    solrInputDocument.addField("aRegionCode", aRegionCode);
                }
                zRegionCode = DbConnectionManager.readString(resultSet, "ZREGIONCODE");
                if(zRegionCode != null)
                {
                    solrInputDocument.addField("zRegionCode", zRegionCode);
                }
                
                solrInputDocument.addField("solrDocumentUpdateDate", ServiceLookupManager.getDocumentUpdateDate());

                documentList.add(solrInputDocument);
                documentsCommitted++;
                
                if (documentList.size() >= this.batchSize)
                {
                    indexer = new ServiceLookupIndexer(this.manager, documentList);
                    
                    // submit this task for execution
                    PooledExecutors.instance().execute(ServiceLookupManager.SLV_INDEXER, indexer);
                    
                    documentList = new ArrayList<SolrInputDocument>();

                    log.info("filter criteria \"{}\", documents committed to Solr :{}", filterCriteria, documentsCommitted);

                    /*
                    this.manager.addToRecordCounter(documentList.size());

                    UpdateResponse resp = server.add(documentList);
                    if (resp.getStatus() != 0)
                    {
                        log.info("Some horrible error has occurred, status is: " + resp.getStatus());
                    }
                    
                    log.info("filter criteria \"{}\", documents committed to Solr :{}", filterCriteria, documentsCommitted);
                    documentList.clear();
                    */
                }
            }
        }
        catch (Exception e)
        {
            log.error("caught exception while trying to add to Solr index.", e);
            
            for(SolrInputDocument inputDocument : documentList)
            {
                log.info("Document list for batch that had error\nID :{}, content : {}", inputDocument.getFieldValue("id"), inputDocument.toString());
            }
            
            // stop the process or mark run as failure
            manager.updateFailure();
        }
        finally
        {
            try
            {
                resultSet.close();
            }
            catch (SQLException e)
            {

            }
            
            try
            {
                stmt.close();
            }
            catch (SQLException e)
            {

            }
            
            slvConn.destroy();
        }
    }

    private void finishIndexing()
    {
        try
        {
            if (documentList.size() > 0)
            {
                ServiceLookupIndexer indexer = new ServiceLookupIndexer(this.manager, documentList);
                    
                // submit this task for execution
                PooledExecutors.instance().execute(ServiceLookupManager.SLV_INDEXER, indexer);
                    
                log.info("filter criteria \"{}\", total documents committed to Solr :{}", filterCriteria, documentsCommitted);

                /*
                this.manager.addToRecordCounter(documentList.size());

                UpdateResponse resp = server.add(documentList);
                if (resp.getStatus() != 0)
                {
                    log.info("Some horrible error has occurred, status is: "
                            + resp.getStatus());
                }
                
                log.info("filter criteria \"{}\", total documents committed to Solr :{}", filterCriteria, documentsCommitted);
                
                documentList.clear();
                */
            }
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to finish indexing.", ex);

            for(SolrInputDocument inputDocument : documentList)
            {
                log.info("ID :{}, content : {}", inputDocument.getFieldValue("id"), inputDocument.toString());
            }

            manager.updateFailure();
        }
        finally
        {
//            server.shutdown();
        }
    }
}
