#!/bin/bash

INDEX=$1
DIRS=`ls /app/solr_indexes | grep $INDEX`

if [ -z "$DIRS" ] 
then
    echo "WARN: Index $INDEX not on server $HOSTNAME"
else
    echo "INFO: RESTARTING Jetty instances running on $HOSTNAME for index ${INDEX}/"
    for dir in ${DIRS}; do
        /app/solr_indexes/$dir/stop_solr
        sleep 30
        /app/solr_indexes/$dir/start_solr
    done 
fi
rm /app/index_dir_check.sh
