#!/bin/bash
##########################################################################
# This Script runs all commands as the unix user specified in the        #
# deploydriver.properties file                                           #
#                                                                        #
#                                                                        #
# Created by: Greg Wobermin 4/20/2011                                    #
#                                                                        #
#########################################################################


echo "INFO: Now entering \"${PWD}/deploy.sh\" script"

ENVIRONMENT=$1
PASSWD=$2
DEPLOY_PROPERTIES=$3
PANDA_DIR=$4
INDEX=$5

DIRS=`ls /app/solr_indexes | grep $INDEX`

echo "INFO: Inside deploy.sh"
echo "INFO: ENVIRONMENT is ${ENVIRONMENT}"
echo "INFO: PANDA_DIR is ${PANDA_DIR}"
echo "INFO: DEPLOY_PROPERTIES is ${DEPLOY_PROPERTIES}"
echo "INFO: INDEX is ${INDEX}"


# Source properties files
. ${DEPLOY_PROPERTIES}

# change RESTART var to upper case if applicable
RESTART=`echo ${RESTART} | tr "[a-z]" "[A-Z]"`

#Copy confs to primary server & run ZK upconfig
for FILE in ${FILES}; do
  echo "INFO: Copying ${FILE} to conf directory on $:/app/solr_indexes/${INDEX}/conf/"
  if ! cp ${PANDA_DIR}/dist/${FILE} /app/solr_indexes/${INDEX}/conf/ 1>>/tmp/pandaErr.log 2>&1 ;
then
  echo "WARN: Was not able to copy \"${FILE}\" to \"$HOSTNAME:/app/solr_indexes/${INDEX}/conf/${FILE}\", check /tmp/pandaErr.log for more info"
  exit 1
  fi

done

#Running zk upconfig
  echo "Running zk_upconfig on $HOSTNAME"
  /app/solr_indexes/${INDEX}/zk_upconfig.sh

# Restart the required servers
for (( n=1; n <= ${NUM_NODES}; n++ )); do
  if [ "${n}" -lt "10" ]; then
    NODE=0${n}
  else
    NODE=${n}
  fi

  # Restart Required Servers
  if [ ${RESTART} == "TRUE" ]; then
    echo "INFO: Checking to RESTART Jetty Indexes running on ${DNSROOT}${NODE}-${ENVIRONMENT}"
    if ! scp ${PANDA_DIR}/deploy_scripts/index_dir_check.sh ${DNSROOT}${NODE}-${ENVIRONMENT}:/app 1>>/tmp/pandaErr.log 2>&1 ; then
      echo "ERROR: Was not able to copy index_dir_check.sh to \"${DNSROOT}${NODE}-${ENVIRONMENT}\". Check /tmp/pandaErr.log for more info"
      exit 1
    fi
    ssh ${DNSROOT}${NODE}-${ENVIRONMENT} ". /app/.profile; /app/index_dir_check.sh $DIRS" 2>>/tmp/pandaErr.log |tee -a /tmp/pandaErr.log
  fi

done

echo "INFO: Now leaving \"${PWD}/deploy.sh\" script"
