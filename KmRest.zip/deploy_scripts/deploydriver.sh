#!/bin/bash
################################################################################
#                                                                              #
# This script is a wrapper script for the steps to complete a deployment       #
#  of an instance of an enterprise services.  This wrapper will call the       #
#  following scripts as the UNIX_USER:                                         #
#    deploy                                                                    #
#                                                                              #
# Arguments:                                                                   #
#  $1 - The environment to deploy to                                           #
#  $2 - Password for the administrative account (tomcat)                       #
#                                                                              #
# Modified: Greg Wobermin - 4/8/2011                                           #
#                                                                              #
################################################################################

# --------------------------------------------------------------
# functions
# --------------------------------------------------------------

function join_domain_args() {
  JOINED=
  PINDEX=1

  # arguments 3..N are service names
  for p in "$@"; do
    if [ ${PINDEX} -ge 3 ]; then
      JOINED="${JOINED}${p}";
    fi
    PINDEX=`expr ${PINDEX} + 1`
  done
  RESULT=${JOINED}
}


# --------------------------------------------------------------
# end functions
# --------------------------------------------------------------

if [ $# -lt 2 ]; then
  echo "usage: $0 environment password"
  exit 1
fi

ENVIRONMENT=$1
PASSWD=$2
PANDA_DIR=${PWD}
SCRIPTSDIR=${PWD}/deploy_scripts

echo "INFO: Environment is ${ENVIRONMENT}..."

# Create std error file and change perms so any user can write to it
if [ -f /tmp/pandaErr.log ]; then
  rm /tmp/pandaErr.log
fi
touch /tmp/pandaErr.log
chmod 666 /tmp/pandaErr.log

echo "INFO: Preforming dos2unix on properties files..."

for file in `find ./env_config -type f`; do
  dos2unix $file $file 1>>/tmp/pandaErr.log 2>&1
done

echo "INFO: Preforming dos2unix on deploy script files..."

for file in `find ./deploy_scripts -type f`; do
  dos2unix $file $file 1>>/tmp/pandaErr.log 2>&1
done

## CREATE THE LIST OF EXTRA PARAMS
if [ $# -ge 3 ]; then
  join_domain_args "$@"
fi

## CHECK THE CONTENTS OF THE LIST
if [ ${RESULT} ]; then
  EXTRAPARAMS="${RESULT}"
  echo "INFO: EXTRAPARAMS ${EXTRAPARAMS}"
else
  EXTRAPARAMS="${ENVIRONMENT}"
fi

#check to see if there is a spcific properties file, if not use default
if [ ! -f "${PWD}/env_config/${EXTRAPARAMS}_deploydriver.properties" ]; then
  echo "INFO: No ENV spcific deploydriver.properties file found, using \"default_deploydriver.properties\""
  DEPLOY_PROPERTIES="${PWD}/env_config/default_deploydriver.properties"
else
  echo "INFO: ENV spcific deploydriver.properties file found, using \"${EXTRAPARAMS}_deploydriver.properties\""
  DEPLOY_PROPERTIES="${PWD}/env_config/${EXTRAPARAMS}_deploydriver.properties"
fi

. ${DEPLOY_PROPERTIES}

# Do property replacement
if [ -f ${PANDA_DIR}/env_config/${EXTRAPARAMS}_EnvironmentSelector.properties ]; then
   echo "Start property replacement"

   PASSWD1=`echo $PASSWD | awk '{split($0,a,"?"); print a[1]}'`
   PASSWD2=`echo $PASSWD | awk '{split($0,a,"?"); print a[2]}'`

   sed -i "s/@@solr_cloud_passwd@@/${PASSWD1}/g" ${PANDA_DIR}/env_config/${EXTRAPARAMS}_EnvironmentSelector.properties
   sed -i "s/@@cert_store_passwd@@/${PASSWD2}/g" ${PANDA_DIR}/env_config/${EXTRAPARAMS}_EnvironmentSelector.properties
fi

# Changing Permissions so $UNIX_USER can access
chmod -R +r ${PWD}
chmod +x ${SCRIPTSDIR}/deploy.sh

# Check for pre,deploy,and post scripts
if [ ! -f ${SCRIPTSDIR}/deploy.sh ]; then
  echo "ERROR: ${SCRIPTSDIR}/deploy.sh does not exist. Exiting..."
fi

#Start the deployment Tasks
if ! /usr/bin/sudo su - ${UNIX_USER} -c "${SCRIPTSDIR}/deploy.sh ${ENVIRONMENT} ${PASSWD} ${DEPLOY_PROPERTIES} ${PANDA_DIR} ${EXTRAPARAMS}"; then
  echo "ERROR: deploydriver.sh: deploy.sh script failed to complete successfully"
  exit 1
fi
