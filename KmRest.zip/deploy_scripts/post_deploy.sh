#!/bin/bash
################################################################################
#                                                                              #
# This script simply deletes the current directory                             #
#                                                                              #
# Arguments:                                                                   #
#  $1 - The environment to deploy to                                           #
#  $2 - The panda directory                                                    #
#                                                                              #
# Author: Ken Rumer - 10/4/2010                                                #
#                                                                              #
################################################################################

  ENVIRONMENT=$1
  PANDA_DIR=$2

  cd ..
  if [ -n "${PANDA_DIR}" ]; then
    #rm -rf ${PANDA_DIR}
    exit 0
  else
    echo "$0: PANDA_DIR is not defined..."
    exit 1
  fi
