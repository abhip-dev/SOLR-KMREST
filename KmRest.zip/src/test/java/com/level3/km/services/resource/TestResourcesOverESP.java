package com.level3.km.services.resource;

import java.security.SignatureException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.ws.rs.core.MediaType;

import org.junit.Assert;
import org.junit.Assume;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;

public class TestResourcesOverESP
{
    private static String appKey = "APPKEY100562488694302";
    private static String appSecret = "AppKeyInformation100562488694303";
    
    private static Logger log = LoggerFactory.getLogger(TestResourcesOverESP.class); 
    
    private static final String BASE_URL = "http://mediation-dev2.level3.com/DataServices/v1/Search/";
    // private static final String BASE_URL = "http://kmservices-test.level3.com/DataServices/v1/Search/";
    
    private static String digestTime = null;
    private static String digest = null;
    
    @BeforeClass
    public static void setUp() throws Exception
    {
        digestTime = String.valueOf(System.currentTimeMillis());
        digest = createDigest(digestTime, appSecret);
    }
    
    @Before
    public void init()
    {
        // This test is executed against BASE_URL defined above, when executing it against External setup,
        // we do not run this test
        String testContainerFactory = System.getProperty("jersey.test.containerFactory");
        Assume.assumeFalse(
                testContainerFactory != null && testContainerFactory.endsWith("ExternalTestContainerFactory"));
    }

    @Test
    public void testTn_JSON()
    {
        ClientResponse response = null;
        

        Client client = Client.create();
        WebResource webResource = client.resource(BASE_URL + "tn");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "tnNumber:7208888021")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        */
    }

    @Test
    public void testServiceLookup_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = client.resource(BASE_URL + "serviceLookup/raw");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "customerNumber:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        */
    }

    @Test
    public void testCustomerBillAccountNumber_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "customerBillAccountNumber/raw");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("rows", "0")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        */
    }

    @Test
    public void testTrunkGroupUtilization_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "trunkGroupUtilization");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        
        for(Entry<String, List<String>> entry : headerMap.entrySet())
        {
            log.debug("Header: {}, value:{}", entry.getKey().toString(), entry.getValue().get(0));
        }
        */
    }

    @Test
    public void testTrunkGroupCallVolume_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "trunkGroupCallVolume");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        
        for(Entry<String, List<String>> entry : headerMap.entrySet())
        {
            log.debug("Header: {}, value:{}", entry.getKey().toString(), entry.getValue().get(0));
        }
        */
    }

    @Test
    public void testOrder_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "order");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        
        for(Entry<String, List<String>> entry : headerMap.entrySet())
        {
            log.debug("Header: {}, value:{}", entry.getKey().toString(), entry.getValue().get(0));
        }
        */
    }

    @Test
    public void testContact_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "contact");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        
        for(Entry<String, List<String>> entry : headerMap.entrySet())
        {
            log.debug("Header: {}, value:{}", entry.getKey().toString(), entry.getValue().get(0));
        }
        */
    }

    @Test
    public void testLocation_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "location");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        /*
        MultivaluedMap<String, String> headerMap = response.getHeaders();
        
        // validate jersey tracing info in headers
        headerMap.containsKey("x-jersey-trace-001");
        
        for(Entry<String, List<String>> entry : headerMap.entrySet())
        {
            log.debug("Header: {}, value:{}", entry.getKey().toString(), entry.getValue().get(0));
        }
        */
    }

    @Test
    public void testTask_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "task");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testExchangeRate_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "exchangeRate");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testCountry_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "country");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testCustomerContractTerm_JSON()
    {
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "customerContractTerm");

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        response = webResource.queryParam("q", "*:*")
                .queryParam("indent", "true")
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        log.debug(response.getEntity(String.class));

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    /*
    @Test
    public void testExchangeRate_JSON_Perf()
    {
        StopWatchFactory speed4jStopWatchFactory = StopWatchFactory.getInstance("loggingFactory");
        DateFormat df = new SimpleDateFormat("yyy-MM-dd'T'00\\:00\\:00'Z'");
        Calendar cal = new GregorianCalendar(2015, 0, 1);
        ClientResponse response = null;
        Client client = Client.create();
        WebResource webResource = 
                client.resource(BASE_URL + "exchangeRate/raw");
        String convDateStrPrefix = "conversionDate:";

        log.debug("AppKey :[{}], digest :[{}], digestTime :[{}]", appKey, digest, digestTime);

        Date date = new Date();
        while(cal.getTimeInMillis() < date.getTime())
        {
            StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();
            response = webResource
                    .queryParam("q", "*:*")
                    .queryParam("fq", "toCurrencyCode:USD")
                    .queryParam("fq", "fromCurrencyCode:AED")
                    .queryParam("fq", convDateStrPrefix + df.format(cal.getTime()))
                    .queryParam("fl", "exchangeRate")
                    .accept(MediaType.APPLICATION_JSON)
                    .header("X-Level3-Application-Key", appKey)
                    .header("X-Level3-Digest", digest)
                    .header("X-Level3-Digest-Time", digestTime)
                    .get(ClientResponse.class);
            stopWatch.stop("Time to execute");
        
            log.debug(response.getEntity(String.class));

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
            
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
    }
    */

    static String createDigest(String digestTime, String digestSecret)
            throws java.security.SignatureException
    {
        String result;

        try
        {
            // get an hmac_sha1 key from the raw key bytes
            SecretKeySpec signingKey = new SecretKeySpec(
                    digestSecret.getBytes(), "macSHA256");
            // get an hmac_sha2 Mac instance and initialize with the signing key
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(signingKey);
            // compute the hmac on input data bytes
            byte[] rawHmac = mac.doFinal(digestTime.getBytes());
            // base64-encode the hmac
            result = new String(Base64.encode(rawHmac));
        }
        catch (Exception e)
        {
            throw new SignatureException("Failed to generate HMAC : " + e.getMessage());
        }
        return result;
    }
}
