package com.level3.km.services.resource;

import com.sun.jersey.api.core.PackagesResourceConfig;
import com.sun.jersey.test.framework.AppDescriptor;
import com.sun.jersey.test.framework.WebAppDescriptor;

public class GenericAppDescriptor
{
    private static WebAppDescriptor descriptor = null;
    private static Object lock = new int [ 1 ];
    
    public static AppDescriptor getAppDescriptor()
    {
        WebAppDescriptor tempDescriptor = null;
        
        if(descriptor == null)
        {
            synchronized(lock)
            {
                if(descriptor == null)
                {
                    WebAppDescriptor.Builder builder = new WebAppDescriptor.Builder();

                    builder.initParam(
                            PackagesResourceConfig.PROPERTY_PACKAGES,
                            "com.level3.km.services.resource;com.level3.km.services.exception");

                    String testContainerFactory = System.getProperty("jersey.test.containerFactory");
                    if(testContainerFactory != null && testContainerFactory.endsWith("ExternalTestContainerFactory"))
                    {
                        builder.contextPath("DataServices/v1");
                    }

                    tempDescriptor = builder.build();
                    descriptor = tempDescriptor;
                }
            }
        }
        
        return descriptor;
    }
}
