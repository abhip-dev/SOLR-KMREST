package com.level3.km.services.perftest;

import java.util.concurrent.CountDownLatch;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response.Status;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


public class TestConcurrentOverload implements Runnable
{
    private static Logger log = LoggerFactory.getLogger(TestConcurrentOverload.class); 
    
    private static String appKey = "APPKEY100562488694302";

    private String digestTime = null;
    private String digest = null;
    private WebResource webResource = null;
    
    private MultivaluedMap<String, String> paramMap = null;
    private CountDownLatch countdownLatch = null;
    
    public TestConcurrentOverload(WebResource webResource, MultivaluedMap<String, String> paramMap, String digest, String digestTime, CountDownLatch countdownLatch)
    {
        this.webResource = webResource;
        this.paramMap = paramMap;
        this.digest = digest;
        this.digestTime = digestTime;
        this.countdownLatch = countdownLatch;
    }

    public void run()
    {
        String start = paramMap.getFirst("start");

        try
        {
            ClientResponse response = 
                    webResource.queryParams(paramMap)
                    .accept(MediaType.APPLICATION_JSON)
                    .header("X-Level3-Application-Key", appKey)
                    .header("X-Level3-Digest", digest)
                    .header("X-Level3-Digest-Time", digestTime)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
            
            log.info("Processed START " + start);
        }
        catch(AssertionError ae)
        {
		    log.info("Failure at START :" + start, ae);
        }

        countdownLatch.countDown();
    }
}
