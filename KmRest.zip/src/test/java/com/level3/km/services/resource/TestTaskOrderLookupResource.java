package com.level3.km.services.resource;

import com.sun.jersey.test.framework.JerseyTest;
import com.sun.jersey.test.framework.spi.container.TestContainerException;
import com.sun.jersey.test.framework.spi.container.TestContainerFactory;
import com.sun.jersey.test.framework.spi.container.grizzly2.web.GrizzlyWebTestContainerFactory;

public class TestTaskOrderLookupResource extends JerseyTest
{
    public TestTaskOrderLookupResource() throws TestContainerException
    {
        super("com.level3.km.services.resource", "com.level3.km.services.exception");
    }

    @Override
    public void setUp() throws Exception
    {
        super.setUp();
    }

    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
    }

    @Override
    protected TestContainerFactory getTestContainerFactory() 
    {
        return new GrizzlyWebTestContainerFactory();
    }
    
    /**
     * Tests have been commented out as the service is not available.
    @Test
    public void testTaskOrderLookup_XML()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }

    @Test
    public void testTaskOrderLookup_JSON()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testTaskOrderLookup_JSONPrefered()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .accept("application/xml;q=0.8, application/json")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        Assert.assertFalse(MediaType.APPLICATION_XML_TYPE.equals(response.getType()));
    }

    @Test
    public void testTaskOrderLookup_XMLPrefered()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .accept("application/json;q=0.8, application/xml")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertFalse(MediaType.APPLICATION_JSON_TYPE.equals(response.getType()));
    }

    @Test
    public void testTaskOrderLookupPing()
    {
        String xmlResponseExpected = 
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><level3Response><status>OK</status></level3Response>";
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("ping")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertEquals(xmlResponseExpected, response.getEntity(String.class));
    }

    @Test
    public void testTaskOrderLookupPing_JSON()
    {
        String jsonResponseExpected = "{\"status\":\"OK\"}";
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("ping")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        Assert.assertEquals(jsonResponseExpected, response.getEntity(String.class));
    }
    
    @Test
    public void testTaskOrderLookup_UnsupportedMediaType()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .accept(MediaType.APPLICATION_ATOM_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.NOT_ACCEPTABLE.getStatusCode(), response.getStatus());
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(406, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(406001, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Not Acceptable", details.getExceptionDetails().getMessage());
    }
    
    @Test
    public void testTaskOrderLookup_LimitRows()
    {
        String rowCount = "5";
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .queryParam("fl", "customerName")
                .queryParam("rows", rowCount)
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject jsonResponse = jsonObject.getJSONObject("response");
            JSONArray jsonDocs = jsonResponse.getJSONArray("docs");
            
            Assert.assertEquals(Long.parseLong(rowCount), jsonDocs.length());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail();
        }
    }

    @Test
    public void testTaskOrderLookup_LimitTo500Rows()
    {
        String rowCount = "600";
        long rowCountExpected = 500;
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .queryParam("fl", "customerName")
                .queryParam("rows", rowCount)     // asking for 600 rows, but we should get 500 only                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject jsonResponse = jsonObject.getJSONObject("response");
            JSONArray jsonDocs = jsonResponse.getJSONArray("docs");
            
            Assert.assertNotEquals(Long.parseLong(rowCount), jsonDocs.length());
            Assert.assertEquals(rowCountExpected, jsonDocs.length());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response cannot have more than 500 rows " + ex.getClass());
        }
    }

    @Test
    public void testTaskOrderLookup_NullQueryParam()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Invalid Query String", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testTaskOrderLookupRaw_Level3Response()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .queryParam("q", "customerOrderNumber:ORDER0212180")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTaskOrderLookup_Level3Response()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search")
                .queryParam("q", "customerOrderNumber:*")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
            Assert.assertTrue("numFound greater than zero", Long.parseLong(document.getDocumentElement().getAttribute("numFound")) > 0);
            Assert.assertEquals(0, Long.parseLong(document.getDocumentElement().getAttribute("start")));
            
            NodeList nodeList = document.getDocumentElement().getElementsByTagName("taskOrderLookup");
            
            Assert.assertNotNull("taskOrderLookup elements exist", nodeList);
            Assert.assertTrue("non zero taskOrderLookup elements found", nodeList.getLength() > 0);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTaskOrderLookup_Level3ResponseException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search/raw")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify error response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTaskOrderLookup_startTooHigh()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search")
                .queryParam("q", "taskId:6650682")
                .queryParam("start", "20")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );
            
            NodeList nodeList = document.getDocumentElement().getElementsByTagName("taskOrderLookup");
            
            Assert.assertTrue("taskOrderLookup elements does not exist", nodeList.getLength() == 0);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTaskOrderLookup_facetQueryPOJOException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path("TaskOrderLookup").path("search")
                .queryParam("q", "*:*")
                .queryParam("facet.query", "true")
                .queryParam("facet.field", "dwSourceSystemCode")
                .queryParam("facet.method", "enum")
                .queryParam("rows", "0")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }
    */
}
