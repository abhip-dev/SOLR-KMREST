package com.level3.km.services.perftest;

import java.security.SignatureException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response.Status;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.services.resource.GenericAppDescriptor;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.sun.jersey.test.framework.AppDescriptor;
import com.sun.jersey.test.framework.JerseyTest;
import com.sun.jersey.test.framework.spi.container.TestContainerException;


public class TestTnOverload extends JerseyTest
{
    private static Logger log = LoggerFactory.getLogger(TestTnOverload.class); 
    
    private static String appKey = "APPKEY100562488694302";
    private static String appSecret = "AppKeyInformation100562488694303";

    private static final String BASE_URL = "http://kmservices-test-gslb.level3.com/DataServices/v1/Search/";
//    private static final String BASE_URL = "http://mediation-env4.level3.com/DataServices/v1/Search/";

    private String digestTime = null;
    private String digest = null;
    private Client client = null;
    
    public TestTnOverload() throws TestContainerException
    {
        super();
    }

    @Override
    protected AppDescriptor configure()
    {
        return GenericAppDescriptor.getAppDescriptor();
    }
    
    @Override
    public void setUp() throws Exception
    {
        super.setUp();

        digestTime = String.valueOf(System.currentTimeMillis());
        digest = createDigest(digestTime, appSecret);
        client = Client.create();
    }

    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
    }

    @Test
    public void testTnDeepPaging()
    {
		MultivaluedMap<String, String> paramMap = null;
		paramMap = new MultivaluedMapImpl();
		paramMap.add("q", "*:*");
		paramMap.add("fq", "productCode:(\"Voice Complete\" OR \"2025\") AND statusDescription:Active");
		paramMap.add("rows", "500");
		
		int start = 0;
		
		try
		{
		    while(start < 1000000)
		    {
		        paramMap.putSingle("start", "" + start);

		        log.info("Processing START " + start);
		        
		        getTn(paramMap);
		        
		        try
                {
                    Thread.sleep(100);
                }
                catch (InterruptedException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

		        start += 500;
		    }
		}
		catch(AssertionError ae)
		{
		    log.info("START :" + start, ae);
		}
    }

    @Test
    public void testTnDeepPagingConcurrent()
    {
        TestConcurrentOverload command = null;
		MultivaluedMap<String, String> paramMap = null;
		WebResource webResource = null;
		CountDownLatch countdownLatch = null;
		int maxStartValue = 1000000;
		
		int start = 0;
		
		try
		{
		    ThreadPoolExecutor deepPagingExecutor = 
                new ThreadPoolExecutor(5, 5, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());

		    countdownLatch = new CountDownLatch(maxStartValue / 500);

		    while(start < maxStartValue)
		    {
		        paramMap = new MultivaluedMapImpl();
		        paramMap.add("q", "*:*");
		        paramMap.add("fq", "productCode:(\"Voice Complete\" OR \"2025\") AND statusDescription:Active");
		        paramMap.add("rows", "500");
		        paramMap.putSingle("start", "" + start);

		        webResource = client.resource(BASE_URL + "tn");
		        
		        command = new TestConcurrentOverload(webResource, paramMap, digest, digestTime, countdownLatch);
		        
		        deepPagingExecutor.execute(command);

		        try
                {
                    Thread.sleep(50);
                }
                catch (InterruptedException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

		        start += 500;
		    }
		    
		    try
            {
                countdownLatch.await();
            }
            catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
		    
		    log.info("COMPLETED!!!");
		}
		catch(AssertionError ae)
		{
		    log.info("START :" + start, ae);
		}
		catch(Throwable th)
		{
		    log.error("Failure occured", th);
		}
    }

    @Test
    public void testDeepPagingConcurrent()
    {
        TestConcurrentOverload command = null;
		MultivaluedMap<String, String> paramMap = null;
		WebResource webResource = null;
		CountDownLatch countdownLatch = null;
		int maxStartValue = 600000;
		
		int start = 0;
		
		try
		{
		    ThreadPoolExecutor deepPagingExecutor = 
                new ThreadPoolExecutor(5, 5, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());

		    countdownLatch = new CountDownLatch(maxStartValue / 500);

		    while(start < maxStartValue)
		    {
		        paramMap = new MultivaluedMapImpl();
		        paramMap.add("q", "*:*");
//		        paramMap.add("fq", "productCode:(\"Voice Complete\" OR \"2025\") AND statusDescription:Active");
		        paramMap.add("rows", "500");
		        paramMap.putSingle("start", "" + start);

		        webResource = client.resource(BASE_URL + "location");
		        
		        command = new TestConcurrentOverload(webResource, paramMap, digest, digestTime, countdownLatch);
		        
		        deepPagingExecutor.execute(command);

		        try
                {
                    Thread.sleep(50);
                }
                catch (InterruptedException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

		        start += 500;
		    }
		    
		    try
            {
                countdownLatch.await();
            }
            catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
		    
		    log.info("COMPLETED!!!");
		}
		catch(AssertionError ae)
		{
		    log.info("START :" + start, ae);
		}
		catch(Throwable th)
		{
		    log.error("Failure occured", th);
		}
    }

    private void getTn(MultivaluedMap<String, String>paramMap)
    {
        WebResource webResource = 
                client.resource(BASE_URL + "tn");

        ClientResponse response = 
                webResource.queryParams(paramMap)
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    static String createDigest(String digestTime, String digestSecret)
            throws java.security.SignatureException
    {
        String result;

        try
        {
            // get an hmac_sha1 key from the raw key bytes
            SecretKeySpec signingKey = new SecretKeySpec(
                    digestSecret.getBytes(), "macSHA256");
            // get an hmac_sha2 Mac instance and initialize with the signing key
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(signingKey);
            // compute the hmac on input data bytes
            byte[] rawHmac = mac.doFinal(digestTime.getBytes());
            // base64-encode the hmac
            result = new String(Base64.encode(rawHmac));
        }
        catch (Exception e)
        {
            throw new SignatureException("Failed to generate HMAC : " + e.getMessage());
        }
        return result;
    }
}
