package com.level3.km.services.resource.beans;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "billInvoice")
@XmlAccessorType(XmlAccessType.FIELD)
public class BillInvoice {

	@Field("id")
	private String id;

	@Field("financeAccountNbr")
	private String financeAccountNbr;

	@Field("billingAccountNbr")
	private String billingAccountNbr;

	@Field("kenanAccountNbr")
	private String kenanAccountNbr;

	@Field("accountName")
	private String accountName;

	@Field("invoiceStatus")
	private String invoiceStatus;

	@Field("invoiceNbr")
	private String invoiceNbr;

	@Field("invoiceDt")
	private Date invoiceDt;

	@Field("invoiceDueDt")
	private Date invoiceDueDt;

	@Field("amtDue")
	private Double amtDue;

	@Field("amtDueRemaining")
	private Double amtDueRemaining;

	@Field("invoiceCurrencyCode")
	private String invoiceCurrencyCode;

	@Field("invoiceCurrencyDesc")
	private String invoiceCurrencyDesc;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFinanceAccountNbr() {
		return financeAccountNbr;
	}

	public void setFinanceAccountNbr(String financeAccountNbr) {
		this.financeAccountNbr = financeAccountNbr;
	}

	public String getBillingAccountNbr() {
		return billingAccountNbr;
	}

	public void setBillingAccountNbr(String billingAccountNbr) {
		this.billingAccountNbr = billingAccountNbr;
	}

	public String getKenanAccountNbr() {
		return kenanAccountNbr;
	}

	public void setKenanAccountNbr(String kenanAccountNbr) {
		this.kenanAccountNbr = kenanAccountNbr;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}

	public String getInvoiceNbr() {
		return invoiceNbr;
	}

	public void setInvoiceNbr(String invoiceNbr) {
		this.invoiceNbr = invoiceNbr;
	}

	public Date getInvoiceDt() {
		return invoiceDt;
	}

	public void setInvoiceDt(Date invoiceDt) {
		this.invoiceDt = invoiceDt;
	}

	public Date getInvoiceDueDt() {
		return invoiceDueDt;
	}

	public void setInvoiceDueDt(Date invoiceDueDt) {
		this.invoiceDueDt = invoiceDueDt;
	}

	public Double getAmtDue() {
		return amtDue;
	}

	public void setAmtDue(Double amtDue) {
		this.amtDue = amtDue;
	}

	public Double getAmtDueRemaining() {
		return amtDueRemaining;
	}

	public void setAmtDueRemaining(Double amtDueRemaining) {
		this.amtDueRemaining = amtDueRemaining;
	}

	public String getInvoiceCurrencyCode() {
		return invoiceCurrencyCode;
	}

	public void setInvoiceCurrencyCode(String invoiceCurrencyCode) {
		this.invoiceCurrencyCode = invoiceCurrencyCode;
	}

	public String getInvoiceCurrencyDesc() {
		return invoiceCurrencyDesc;
	}

	public void setInvoiceCurrencyDesc(String invoiceCurrencyDesc) {
		this.invoiceCurrencyDesc = invoiceCurrencyDesc;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillInvoice [id=");
		builder.append(id);
		builder.append(", financeAccountNbr=");
		builder.append(financeAccountNbr);
		builder.append(", billingAccountNbr=");
		builder.append(billingAccountNbr);
		builder.append(", kenanAccountNbr=");
		builder.append(kenanAccountNbr);
		builder.append(", accountName=");
		builder.append(accountName);
		builder.append(", invoiceStatus=");
		builder.append(invoiceStatus);
		builder.append(", invoiceNbr=");
		builder.append(invoiceNbr);
		builder.append(", invoiceDt=");
		builder.append(invoiceDt);
		builder.append(", invoiceDueDt=");
		builder.append(invoiceDueDt);
		builder.append(", amtDue=");
		builder.append(amtDue);
		builder.append(", amtDueRemaining=");
		builder.append(amtDueRemaining);
		builder.append(", invoiceCurrencyCode=");
		builder.append(invoiceCurrencyCode);
		builder.append(", invoiceCurrencyDesc=");
		builder.append(invoiceCurrencyDesc);
		builder.append("]");
		return builder.toString();
	}
}