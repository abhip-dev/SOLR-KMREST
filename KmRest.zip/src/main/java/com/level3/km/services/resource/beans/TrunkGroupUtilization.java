package com.level3.km.services.resource.beans;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "trunkGroupUtilization")
@XmlAccessorType(XmlAccessType.FIELD)
public class TrunkGroupUtilization {
    @Field("id")
    private String id;
    @Field("customerNumber")
    private String customerNumber;
    @Field("customerName")
    private String customerName;
    @Field("billAccountNumber")
    private String billAccountNumber;
    @Field("billAccountName")
    private String billAccountName;
    @Field("trunkGroupUtilizationIntervalStartDate")
    private Date trunkGroupUtilizationIntervalStartDate;
    @Field("trunkGroupType")
    private String trunkGroupType;
    @Field("trunkGroupUtilizationPercentage")
    private Double trunkGroupUtilizationPercentage;
    @Field("trunkGroupPeakCallQuantity")
    private Integer trunkGroupPeakCallQuantity;
    @Field("trunkGroupMaxCallCapacity")
    private Integer trunkGroupMaxCallCapacity;
    @Field("trunkGroupProvisionedCallCapacity")
    private Integer trunkGroupProvisionedCallCapacity;
    @Field("trunkGroupPeakUtilizationPercentage")
    private Double trunkGroupPeakUtilizationPercentage;
    @Field("trunkGroupMinUtilizationPercentage")
    private Double trunkGroupMinUtilizationPercentage;
    @Field("trunkGroupStatus")
    private String trunkGroupStatus;
    @Field("trunkGroupId")
    private String trunkGroupId;
    @Field("switchId")
    private String switchId;
    @Field("statCollectionDayOfWeek")
    private String statCollectionDayOfWeek;
    @Field("trunkGroupTransportType")
    private String trunkGroupTransportType;
    @Field("localInboundTrunkGroupIndicator")
    private Boolean localInboundTrunkGroupIndicator;
    @Field("enhancedLocalTrunkGroupIndicator")
    private Boolean enhancedLocalTrunkGroupIndicator;
    @Field("tollFreeTrunkGroupIndicator")
    private Boolean tollFreeTrunkGroupIndicator;
    @Field("e911TrunkGroupIndicator")
    private Boolean e911TrunkGroupIndicator;
    @Field("voiceTerminationTrunkGroupIndicator")
    private Boolean voiceTerminationTrunkGroupIndicator;
    @Field("voiceCompleteTrunkGroupIndicator")
    private Boolean voiceCompleteTrunkGroupIndicator;
    @Field("networkTrunkGroupIndicator")
    private Boolean networkTrunkGroupIndicator;
    @Field("networkCustomerId")
    private String networkCustomerId;
    @Field("line1Address")
    private String line1Address;
    @Field("cityName")
    private String cityName;
    @Field("stateCode")
    private String stateCode;
    @Field("postalCode")
    private String postalCode;
    @Field("countryName")
    private String countryName;
    @Field("serviceComponentId")
    private String serviceComponentId;

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getCustomerNumber() {
	return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
	this.customerNumber = customerNumber;
    }

    public String getCustomerName() {
	return customerName;
    }

    public void setCustomerName(String customerName) {
	this.customerName = customerName;
    }

    public String getBillAccountNumber() {
	return billAccountNumber;
    }

    public void setBillAccountNumber(String billAccountNumber) {
	this.billAccountNumber = billAccountNumber;
    }

    public String getBillAccountName() {
	return billAccountName;
    }

    public void setBillAccountName(String billAccountName) {
	this.billAccountName = billAccountName;
    }

    public Date getTrunkGroupUtilizationIntervalStartDate() {
	return trunkGroupUtilizationIntervalStartDate;
    }

    public void setTrunkGroupUtilizationIntervalStartDate(Date trunkGroupUtilizationIntervalStartDate) {
	this.trunkGroupUtilizationIntervalStartDate = trunkGroupUtilizationIntervalStartDate;
    }

    public String getTrunkGroupType() {
	return trunkGroupType;
    }

    public void setTrunkGroupType(String trunkGroupType) {
	this.trunkGroupType = trunkGroupType;
    }

    public Double getTrunkGroupUtilizationPercentage() {
	return trunkGroupUtilizationPercentage;
    }

    public void setTrunkGroupUtilizationPercentage(Double trunkGroupUtilizationPercentage) {
	this.trunkGroupUtilizationPercentage = trunkGroupUtilizationPercentage;
    }

    public Integer getTrunkGroupPeakCallQuantity() {
	return trunkGroupPeakCallQuantity;
    }

    public void setTrunkGroupPeakCallQuantity(Integer trunkGroupPeakCallQuantity) {
	this.trunkGroupPeakCallQuantity = trunkGroupPeakCallQuantity;
    }

    public Integer getTrunkGroupMaxCallCapacity() {
	return trunkGroupMaxCallCapacity;
    }

    public void setTrunkGroupMaxCallCapacity(Integer trunkGroupMaxCallCapacity) {
	this.trunkGroupMaxCallCapacity = trunkGroupMaxCallCapacity;
    }

    public Double getTrunkGroupPeakUtilizationPercentage() {
	return trunkGroupPeakUtilizationPercentage;
    }

    public void setTrunkGroupPeakUtilizationPercentage(Double trunkGroupPeakUtilizationPercentage) {
	this.trunkGroupPeakUtilizationPercentage = trunkGroupPeakUtilizationPercentage;
    }

    public Double getTrunkGroupMinUtilizationPercentage() {
	return trunkGroupMinUtilizationPercentage;
    }

    public void setTrunkGroupMinUtilizationPercentage(Double trunkGroupMinUtilizationPercentage) {
	this.trunkGroupMinUtilizationPercentage = trunkGroupMinUtilizationPercentage;
    }

    public String getTrunkGroupStatus() {
	return trunkGroupStatus;
    }

    public void setTrunkGroupStatus(String trunkGroupStatus) {
	this.trunkGroupStatus = trunkGroupStatus;
    }

    public String getTrunkGroupId() {
	return trunkGroupId;
    }

    public void setTrunkGroupId(String trunkGroupId) {
	this.trunkGroupId = trunkGroupId;
    }

    public String getSwitchId() {
	return switchId;
    }

    public void setSwitchId(String switchId) {
	this.switchId = switchId;
    }

    public Boolean getLocalInboundTrunkGroupIndicator() {
	return localInboundTrunkGroupIndicator;
    }

    public void setLocalInboundTrunkGroupIndicator(Boolean localInboundTrunkGroupIndicator) {
	this.localInboundTrunkGroupIndicator = localInboundTrunkGroupIndicator;
    }

    public Boolean getEnhancedLocalTrunkGroupIndicator() {
	return enhancedLocalTrunkGroupIndicator;
    }

    public void setEnhancedLocalTrunkGroupIndicator(Boolean enhancedLocalTrunkGroupIndicator) {
	this.enhancedLocalTrunkGroupIndicator = enhancedLocalTrunkGroupIndicator;
    }

    public Boolean getTollFreeTrunkGroupIndicator() {
	return tollFreeTrunkGroupIndicator;
    }

    public void setTollFreeTrunkGroupIndicator(Boolean tollFreeTrunkGroupIndicator) {
	this.tollFreeTrunkGroupIndicator = tollFreeTrunkGroupIndicator;
    }

    public Boolean getE911TrunkGroupIndicator() {
	return e911TrunkGroupIndicator;
    }

    public void setE911TrunkGroupIndicator(Boolean e911TrunkGroupIndicator) {
	this.e911TrunkGroupIndicator = e911TrunkGroupIndicator;
    }

    public Boolean getVoiceTerminationTrunkGroupIndicator() {
	return voiceTerminationTrunkGroupIndicator;
    }

    public void setVoiceTerminationTrunkGroupIndicator(Boolean voiceTerminationTrunkGroupIndicator) {
	this.voiceTerminationTrunkGroupIndicator = voiceTerminationTrunkGroupIndicator;
    }

    public Boolean getVoiceCompleteTrunkGroupIndicator() {
	return voiceCompleteTrunkGroupIndicator;
    }

    public void setVoiceCompleteTrunkGroupIndicator(Boolean voiceCompleteTrunkGroupIndicator) {
	this.voiceCompleteTrunkGroupIndicator = voiceCompleteTrunkGroupIndicator;
    }

    public Boolean getNetworkTrunkGroupIndicator() {
	return networkTrunkGroupIndicator;
    }

    public void setNetworkTrunkGroupIndicator(Boolean networkTrunkGroupIndicator) {
	this.networkTrunkGroupIndicator = networkTrunkGroupIndicator;
    }

    public String getTrunkGroupTransportType() {
	return trunkGroupTransportType;
    }

    public void setTrunkGroupTransportType(String trunkGroupTransportType) {
	this.trunkGroupTransportType = trunkGroupTransportType;
    }

    public Integer getTrunkGroupProvisionedCallCapacity() {
	return trunkGroupProvisionedCallCapacity;
    }

    public void setTrunkGroupProvisionedCallCapacity(Integer trunkGroupProvisionedCallCapacity) {
	this.trunkGroupProvisionedCallCapacity = trunkGroupProvisionedCallCapacity;
    }

    public String getStatCollectionDayOfWeek() {
	return statCollectionDayOfWeek;
    }

    public void setStatCollectionDayOfWeek(String statCollectionDayOfWeek) {
	this.statCollectionDayOfWeek = statCollectionDayOfWeek;
    }

    public String getNetworkCustomerId() {
	return networkCustomerId;
    }

    public void setNetworkCustomerId(String networkCustomerId) {
	this.networkCustomerId = networkCustomerId;
    }

    public String getLine1Address() {
	return line1Address;
    }

    public void setLine1Address(String line1Address) {
	this.line1Address = line1Address;
    }

    public String getCityName() {
	return cityName;
    }

    public void setCityName(String cityName) {
	this.cityName = cityName;
    }

    public String getStateCode() {
	return stateCode;
    }

    public void setStateCode(String stateCode) {
	this.stateCode = stateCode;
    }

    public String getPostalCode() {
	return postalCode;
    }

    public void setPostalCode(String postalCode) {
	this.postalCode = postalCode;
    }

    public String getCountryName() {
	return countryName;
    }

    public void setCountryName(String countryName) {
	this.countryName = countryName;
    }

    public String getServiceComponentId() {
	return serviceComponentId;
    }

    public void setServiceComponentId(String serviceComponentId) {
	this.serviceComponentId = serviceComponentId;
    }

    @Override
    public String toString() {
	StringBuilder builder = new StringBuilder();
	builder.append("TrunkGroupUtilization [id=");
	builder.append(id);
	builder.append(", customerNumber=");
	builder.append(customerNumber);
	builder.append(", customerName=");
	builder.append(customerName);
	builder.append(", billAccountNumber=");
	builder.append(billAccountNumber);
	builder.append(", billAccountName=");
	builder.append(billAccountName);
	builder.append(", trunkGroupUtilizationIntervalStartDate=");
	builder.append(trunkGroupUtilizationIntervalStartDate);
	builder.append(", trunkGroupType=");
	builder.append(trunkGroupType);
	builder.append(", trunkGroupUtilizationPercentage=");
	builder.append(trunkGroupUtilizationPercentage);
	builder.append(", trunkGroupPeakCallQuantity=");
	builder.append(trunkGroupPeakCallQuantity);
	builder.append(", trunkGroupMaxCallCapacity=");
	builder.append(trunkGroupMaxCallCapacity);
	builder.append(", trunkGroupProvisionedCallCapacity=");
	builder.append(trunkGroupProvisionedCallCapacity);
	builder.append(", trunkGroupPeakUtilizationPercentage=");
	builder.append(trunkGroupPeakUtilizationPercentage);
	builder.append(", trunkGroupMinUtilizationPercentage=");
	builder.append(trunkGroupMinUtilizationPercentage);
	builder.append(", trunkGroupStatus=");
	builder.append(trunkGroupStatus);
	builder.append(", trunkGroupId=");
	builder.append(trunkGroupId);
	builder.append(", switchId=");
	builder.append(switchId);
	builder.append(", statCollectionDayOfWeek=");
	builder.append(statCollectionDayOfWeek);
	builder.append(", trunkGroupTransportType=");
	builder.append(trunkGroupTransportType);
	builder.append(", localInboundTrunkGroupIndicator=");
	builder.append(localInboundTrunkGroupIndicator);
	builder.append(", enhancedLocalTrunkGroupIndicator=");
	builder.append(enhancedLocalTrunkGroupIndicator);
	builder.append(", tollFreeTrunkGroupIndicator=");
	builder.append(tollFreeTrunkGroupIndicator);
	builder.append(", e911TrunkGroupIndicator=");
	builder.append(e911TrunkGroupIndicator);
	builder.append(", voiceTerminationTrunkGroupIndicator=");
	builder.append(voiceTerminationTrunkGroupIndicator);
	builder.append(", voiceCompleteTrunkGroupIndicator=");
	builder.append(voiceCompleteTrunkGroupIndicator);
	builder.append(", networkTrunkGroupIndicator=");
	builder.append(networkTrunkGroupIndicator);
	builder.append(", networkCustomerId=");
	builder.append(networkCustomerId);
	builder.append("]");
	return builder.toString();
    }

}
