package com.level3.km.services.resource.beans;

import org.apache.solr.client.solrj.beans.Field;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@XmlRootElement(name="concurrentCallPathUtilization")
@XmlAccessorType(XmlAccessType.FIELD)
public class ConcurrentCallPathUtilization {
  @Field("id")
  private String id;
  @Field("customerNumber")
  private String customerNumber;
  @Field("customerName")
  private String customerName;
  @Field("billAccountNumber")
  private String billAccountNumber;
  @Field("billAccountName")
  private String billAccountName;
  @Field("CCPUtilizationDate")
  private Date CCPUtilizationDate;
  @Field("networkCustomerId")
  private String networkCustomerId;
  @Field("switchId")
  private String switchId;
  @Field("provisionedCCPQuantity")
  private int provisionedCCPQuantity;
  @Field("maxCCPUsedQuantity")
  private int maxCCPUsedQuantity;
  @Field("maxCCPUsedTimestamp")
  private Date maxCCPUsedTimestamp;
  @Field("dataRefreshTimestamp")
  private Date dataRefreshTimestamp;
  @Field("statsCollectionDayOfWeek")
  private String statsCollectionDayOfWeek;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getCustomerNumber() {
    return customerNumber;
  }

  public void setCustomerNumber(String customerNumber) {
    this.customerNumber = customerNumber;
  }

  public String getCustomerName() {
    return customerName;
  }

  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }

  public String getBillAccountNumber() {
    return billAccountNumber;
  }

  public void setBillAccountNumber(String billAccountNumber) {
    this.billAccountNumber = billAccountNumber;
  }

  public String getBillAccountName() {
    return billAccountName;
  }

  public void setBillAccountName(String billAccountName) {
    this.billAccountName = billAccountName;
  }

  public Date getCCPUtilizationDate() {
    return CCPUtilizationDate;
  }

  public void setCCPUtilizationDate(Date CCPUtilizationDate) {
    this.CCPUtilizationDate = CCPUtilizationDate;
  }

  public String getNetworkCustomerId() {
    return networkCustomerId;
  }

  public void setNetworkCustomerId(String networkCustomerId) {
    this.networkCustomerId = networkCustomerId;
  }

  public String getSwitchId() {
    return switchId;
  }

  public void setSwitchId(String switchId) {
    this.switchId = switchId;
  }

  public int getProvisionedCCPQuantity() {
    return provisionedCCPQuantity;
  }

  public void setProvisionedCCPQuantity(int provisionedCCPQuantity) {
    this.provisionedCCPQuantity = provisionedCCPQuantity;
  }

  public int getMaxCCPUsedQuantity() {
    return maxCCPUsedQuantity;
  }

  public void setMaxCCPUsedQuantity(int maxCCPUsedQuantity) {
    this.maxCCPUsedQuantity = maxCCPUsedQuantity;
  }

  public Date getMaxCCPUsedTimestamp() {
    return maxCCPUsedTimestamp;
  }

  public void setMaxCCPUsedTimestamp(Date maxCCPUsedTimestamp) {
    this.maxCCPUsedTimestamp = maxCCPUsedTimestamp;
  }

  public Date getDataRefreshTimestamp() {
    return dataRefreshTimestamp;
  }

  public void setDataRefreshTimestamp(Date dataRefreshTimestamp) {
    this.dataRefreshTimestamp = dataRefreshTimestamp;
  }

  public String getStatsCollectionDayOfWeek() {
    return statsCollectionDayOfWeek;
  }

  public void setStatsCollectionDayOfWeek(String statsCollectionDayOfWeek) {
    this.statsCollectionDayOfWeek = statsCollectionDayOfWeek;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ConcurrentCallPathUtilization [");
    builder.append("id=").append(id);
    builder.append(", customerNumber").append(customerNumber);
    builder.append(", customerName").append(customerName);
    builder.append(", billAccountNumber").append(billAccountNumber);
    builder.append(", billAccountName").append(billAccountName);
    builder.append(", CCPUtilizationDate").append(CCPUtilizationDate);
    builder.append(", networkCustomerId").append(networkCustomerId);
    builder.append(", switchId").append(switchId);
    builder.append(", provisionedCCPQuantity").append(provisionedCCPQuantity);
    builder.append(", maxCCPUsedQuantity").append(maxCCPUsedQuantity);
    builder.append(", maxCCPUsedTimestamp").append(maxCCPUsedTimestamp);
    builder.append(", dataRefreshTimestamp").append(dataRefreshTimestamp);
    builder.append(", statsCollectionDayOfWeek").append(statsCollectionDayOfWeek);
    builder.append("]");
    return builder.toString();
  }
}
