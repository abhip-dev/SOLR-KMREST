package com.level3.km.services.filters;

import javax.ws.rs.ext.Provider;

import org.slf4j.MDC;

import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerRequestFilter;

@Provider
public class MDCRequestFilter implements ContainerRequestFilter
{
    /**
     * We are setting MDC (Mapped Diagnostic Context) in this filter. It will help correlate log statements
     * that are logged against this request.
     * Most of our calls should be coming through the mediation layer and should have a 
     * X-Level3-Mediation-Id header set.
     * Generally this filter should be the first one that is declared in web.xml, unless there is a very
     * unique filter that has to be executed prior to this filter.
     */
    public ContainerRequest filter(ContainerRequest request)
    {
        MDC.clear();

        String mediationId = request.getHeaderValue("X-Level3-Mediation-Id");
        
        if(mediationId == null || mediationId.equals(""))
        {
            mediationId = "MINS-" + System.currentTimeMillis();
        }
        
        MDC.put("MediationId", mediationId);
        
        String appKey = request.getHeaderValue("X-Level3-Application-Key");
        
        if(appKey == null || appKey.equals(""))
        {
            appKey = "APPKEYNotSet";
        }
        
        MDC.put("ApplicationKey", appKey);
        
        String clientEnv = request.getHeaderValue("X-Level3-Clientenv");
        
        if(clientEnv != null && !clientEnv.equals(""))
        {
            MDC.put("ClientEnvironment", clientEnv);
        }
        
        String userName = request.getHeaderValue("X-Level3-Username");
        
        if(userName != null && !userName.equals(""))
        {
            MDC.put("Username", userName);
        }
        
        String logPerformanceData = request.getHeaderValue("X-Level3-LogPerf");
        
        if(logPerformanceData != null && !logPerformanceData.equals("") && logPerformanceData.equalsIgnoreCase("true"))
        {
            MDC.put("LogPerformanceData", "true");
        }
        
        return request;
    }
}
