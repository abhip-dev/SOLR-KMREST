package com.level3.km.services.resource.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "billrevenuemetrics")
@XmlAccessorType(XmlAccessType.FIELD)

public class BillRevenueMetrics {
	
	@Field("id")
	private String id;
	
	@Field("billingAccountName")
	private String billingAccountName;
	
	@Field("billingAccountId")
	private String billingAccountId;
	
	@Field("billingSystem")
	private String billingSystem;	
	
	@Field("billingLine1Address")
	private String billingLine1Address;
	
	@Field("billingLine2Address")
	private String billingLine2Address;
	
	@Field("billingCityName")
	private String billingCityName;
	
	@Field("billingStateCode")
	private String billingStateCode;
	
	@Field("billingPostalCode")
	private String billingPostalCode;
	
	@Field("billingCountryName")
	private String billingCountryName;

	@Field("ownersRegion")	
	private String ownersRegion;
	
	@Field("salesRepCuid")
	private String salesRepCuid;
	
	@Field("repQBL")
	private String repQBL;
	
	@Field("salesRepId")
	private String salesRepId;
	
	@Field("repName")
	private String repName;
	
	@Field("revenueMonth")
	private String revenueMonth;
	
	@Field("prevYearToDateMrc")
	private String prevYearToDateMrc;
	
	@Field("threeMonthAvgMrc")
	private String threeMonthAvgMrc;
	
	@Field("currentMrc")
	private String currentMrc;
	
	@Field("yearToDateMrc")
	private String yearToDateMrc;
	
	@Field("yearToDateNrc")
	private String yearToDateNrc;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBillingAccountName() {
		return billingAccountName;
	}
	public void setBillingAccountName(String billingAccountName) {
		this.billingAccountName = billingAccountName;
	}
	public String getBillingAccountId() {
		return billingAccountId;
	}
	public void setBillingAccountId(String billingAccountId) {
		this.billingAccountId = billingAccountId;
	}
	public String getBillingSystem() {
		return billingSystem;
	}
	public void setBillingSystem(String billingSystem) {
		this.billingSystem = billingSystem;
	}
	public String getBillingLine1Address() {
		return billingLine1Address;
	}
	public void setBillingLine1Address(String billingLine1Address) {
		this.billingLine1Address = billingLine1Address;
	}
	public String getBillingLine2Address() {
		return billingLine2Address;
	}
	public void setBillingLine2Address(String billingLine2Address) {
		this.billingLine2Address = billingLine2Address;
	}
	public String getBillingCityName() {
		return billingCityName;
	}
	public void setBillingCityName(String billingCityName) {
		this.billingCityName = billingCityName;
	}
	public String getBillingStateCode() {
		return billingStateCode;
	}
	public void setBillingStateCode(String billingStateCode) {
		this.billingStateCode = billingStateCode;
	}
	public String getBillingPostalCode() {
		return billingPostalCode;
	}
	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}
	public String getBillingCountryName() {
		return billingCountryName;
	}
	public void setBillingCountryName(String billingCountryName) {
		this.billingCountryName = billingCountryName;
	}
	public String getOwnersRegion() {
		return ownersRegion;
	}
	public void setOwnersRegion(String ownersRegion) {
		this.ownersRegion = ownersRegion;
	}
	public String getSalesRepCuid() {
		return salesRepCuid;
	}
	public void setSalesRepCuid(String salesRepCuid) {
		this.salesRepCuid = salesRepCuid;
	}
	public String getRepQBL() {
		return repQBL;
	}
	public void setRepQBL(String repQBL) {
		this.repQBL = repQBL;
	}
	public String getSalesRepId() {
		return salesRepId;
	}
	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}
	public String getRepName() {
		return repName;
	}
	public void setRepName(String repName) {
		this.repName = repName;
	}
	public String getRevenueMonth() {
		return revenueMonth;
	}
	public void setRevenueMonth(String revenueMonth) {
		this.revenueMonth = revenueMonth;
	}
	public String getPrevYearToDateMrc() {
		return prevYearToDateMrc;
	}
	public void setPrevYearToDateMrc(String prevYearToDateMrc) {
		this.prevYearToDateMrc = prevYearToDateMrc;
	}
	public String getThreeMonthAvgMrc() {
		return threeMonthAvgMrc;
	}
	public void setThreeMonthAvgMrc(String threeMonthAvgMrc) {
		this.threeMonthAvgMrc = threeMonthAvgMrc;
	}
	public String getCurrentMrc() {
		return currentMrc;
	}
	public void setCurrentMrc(String currentMrc) {
		this.currentMrc = currentMrc;
	}
	public String getYearToDateMrc() {
		return yearToDateMrc;
	}
	public void setYearToDateMrc(String yearToDateMrc) {
		this.yearToDateMrc = yearToDateMrc;
	}
	public String getYearToDateNrc() {
		return yearToDateNrc;
	}
	public void setYearToDateNrc(String yearToDateNrc) {
		this.yearToDateNrc = yearToDateNrc;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillRevenueMetrics [id=");
		builder.append(id);
		builder.append(", billingAccountName=");
		builder.append(billingAccountName);
		builder.append(", billingAccountId=");
		builder.append(billingAccountId);
		builder.append(", billingSystem=");
		builder.append(billingSystem);	
		builder.append(", billingLine1Address=");
		builder.append(billingLine1Address);
		builder.append(", billingLine2Address=");
		builder.append(billingLine2Address);
		builder.append(", billingCityName=");
		builder.append(billingCityName);
		builder.append(", billingStateCode=");
		builder.append(billingStateCode);
		builder.append(", billingPostalCode=");
		builder.append(billingPostalCode);
		builder.append(", billingCountryName=");
		builder.append(billingCountryName);
		builder.append(", ownersRegion=");
		builder.append(ownersRegion);
		builder.append(", salesRepCuid=");
		builder.append(salesRepCuid);
		builder.append(", repQBL=");
		builder.append(repQBL);
		builder.append(", salesRepId=");
		builder.append(salesRepId);
		builder.append(", repName=");
		builder.append(repName);
		builder.append(", revenueMonth=");
		builder.append(revenueMonth);
		builder.append(", prevYearToDateMrc=");
		builder.append(prevYearToDateMrc);
		builder.append(", threeMonthAvgMrc=");
		builder.append(threeMonthAvgMrc);
		builder.append(", currentMrc=");
		builder.append(currentMrc);
		builder.append(", yearToDateMrc=");
		builder.append(yearToDateMrc);
		builder.append(", yearToDateNrc=");
		builder.append(yearToDateNrc);
		builder.append("]");
		return builder.toString();
	}

}