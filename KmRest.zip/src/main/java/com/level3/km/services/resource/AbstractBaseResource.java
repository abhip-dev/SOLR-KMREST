package com.level3.km.services.resource;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManagerFactory;
import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.core.Variant;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.solr.client.solrj.impl.XMLResponseParser;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.util.NamedList;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.ecyrd.speed4j.StopWatch;
import com.ecyrd.speed4j.StopWatchFactory;
import com.level3.km.services.exception.DataServiceBaseException;
import com.level3.km.services.exception.ErrorCodeMapping;
import com.level3.km.services.properties.PropertyManager;
import com.level3.km.services.resource.beans.ConfigResponse;
import com.level3.km.services.resource.beans.ConfigResponse.ConfigProperty;
import com.level3.km.services.resource.beans.Level3Response;
import com.level3.km.services.resource.beans.PingResponse;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.api.representation.Form;
//import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

public abstract class AbstractBaseResource
{
    @Context
    protected UriInfo uriInfo;
    
    @Context
    protected Request request;
    
    @Context
    protected ServletContext servletContext;
    
    @Context
    protected HttpHeaders httpHeaders;
    
    private static Logger log = LoggerFactory.getLogger(AbstractBaseResource.class); 
    
    private static URL xslUrl = null;
    private static Source xsl = null;
    
    // these variables are set per JVM basis, not per request basis. They are valid for the entire session
    // and changes will impact every request following the change. These changes are not thread safe.
    private static int maxAllowedRowCount = 500;
    private static int maxStartParam=500000;
    private static List<Variant> searchVariantList = 
            Variant.mediaTypes(MediaType.APPLICATION_JSON_TYPE, MediaType.APPLICATION_XML_TYPE).add().build();
    
    protected StopWatchFactory speed4jStopWatchFactory = StopWatchFactory.getInstance("loggingFactory");
    
    private static final String ROWS_STR = "rows";
    private static final String START_STR = "start";
    private static final String FQ_PARAM_STR = "fq";
    private static final String ALL_STR = "ALL";
    private static final String FACET_STR = "facet";
    private static final String FACET_MINCOUNT_STR = "facet.mincount";
    private static final String MINCOUNT_STR = "mincount";
    private static final String TRUE_STR = "true";
    private static final String ON_STR = "on";
    private static final String CREDENTAILS_HDR_STR = "X-Level3-Credentials";
    private static final String PANDA_BUILD_LABEL_STR = "PandaBuild-Label";
    private static final String BUILD_DATE_STR = "Build-Date";
    private static final String BUILD_LABEL_STR = "Build-Label";
    private static final String KMREST_BUILD_LABEL_STR = "km-rest";
    private static final String MANIFEST_FILE_PATH = "/META-INF/MANIFEST.MF";
    private static final String PROFILER_SOLR_QUERY_PREP_STR = "Solr Query Prep ";
    private static final String PROFILER_SOLR_QUERY_STR = "Solr Query ";
    private static final String PROFILER_POST_SOLR_QUERY_STR = "Post Solr Query ";
    private static final String SOLR_CERT_STORE_FILE_NAME = "/solr_cert.jks";
    
    private static List<String> minCountDefaultList = null;
    private static Client client = null;
    
    
    private Profiler profiler = null;
    
    static
    {
        xslUrl = AbstractBaseResource.class.getResource("/Level3Response.xsl");
        xsl = new StreamSource(FileUtils.toFile(xslUrl));

        minCountDefaultList = new ArrayList<String>();
        minCountDefaultList.add("1");
        
        // need to determine if this needs to communicate over https
        ClientConfig config = new DefaultClientConfig();
      
        SSLContext sslContext = getSSLContext();
      
        // This is a hack, if we cannot get the SSLContext then we assume we create client with just default configuration, without the SSL
        // If we are successful in getting SSLContext then we set the HTTPS_PROPERTIES
        if(sslContext != null)
        {
            HostnameVerifier hostnameVerifier = new TrustAllHostNameVerifier ();
            HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);

            log.info("!!!!!! GOT SSL CONTEXT, SO FAR SO GOOD !!!!!");
            config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(hostnameVerifier, sslContext));
        }

        client = Client.create(config);
        
        client.addFilter(
                new HTTPBasicAuthFilter(
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_USERNAME_STR),
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_PASSWORD_STR)));
    }
    
    static SSLContext getSSLContext()
    {
        SSLContext ctx = null;
        try
        {
            KeyStore trustStore;
            trustStore = KeyStore.getInstance("JKS");
            trustStore.load(
               AbstractBaseResource.class.getResourceAsStream(SOLR_CERT_STORE_FILE_NAME),
               PropertyManager.instance().getProperty(PropertyManager.CERT_STORE_PASSWORD_STR).toCharArray());
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(trustStore);
            ctx = SSLContext.getInstance("TLSv1");
            ctx.init(null, tmf.getTrustManagers(), null);
        }
        catch (NoSuchAlgorithmException e1)
        {
            log.error("No Such Algorithm Exception ", e1);
            ctx = null;
        }
        catch (KeyStoreException e)
        {
            log.error("Key Store Exception ", e);
            ctx = null;
        }
        catch (CertificateException ce)
        {
            log.error("Certificate Exception ", ce);
            ctx = null;
        }
        catch (FileNotFoundException fe)
        {
            log.error("File not Found Exception ", fe);
            ctx = null;
        }
        catch (IOException ie)
        {
            log.error("IO Exception ", ie);
            ctx = null;
        }
        catch (KeyManagementException ke)
        {
            log.error("Key Management Exception ", ke);
            ctx = null;
        }
        
        return ctx;
    }
    
    protected Response doQuery()
    {
        MultivaluedMap<String, String> queryParams = uriInfo.getQueryParameters();

        return doQuery(queryParams, null); 
    }
    
    protected <T> Response doQuery(Class<T> T)
    {
        MultivaluedMap<String, String> queryParams = uriInfo.getQueryParameters();
        
        return doQuery(queryParams, T);
    }

    protected Response doQuery(MultivaluedMap<String, String> searchParams)
    {
        return doQuery(searchParams, null); 
    }
    
    protected <T> Response doQuery(MultivaluedMap<String, String> searchParams, Class<T> T)
    {
        initializeProfiler();

        ClientResponse solrResponse = null;
        MediaType responseMediaType = request.selectVariant(searchVariantList).getMediaType();
        ResponseBuilder responseBuilder = Response.noContent();
        QueryResponse queryResponse = null;
        List<T> resultList = null;
        long numFound = -1;
        long start = -1;
        if(searchParams == null || searchParams.isEmpty())
        {
            throw new DataServiceBaseException(
                    ErrorCodeMapping.InvalidQueryString, "query string is null or empty");
        }
        
        try
        {
            checkAndLimitRowCount(searchParams);
            
            checkStartParam(searchParams);
            
            checkAndSetExternalCustomerFilter(searchParams);
            
            if(T != null)
            {
                solrResponse = processQueryOutputXml(searchParams);

                addResponseHeaders(solrResponse, responseBuilder);
                
                if(solrResponse.getStatus() == ClientResponse.Status.NOT_MODIFIED.getStatusCode())
                {
                    return processOutputNotModified(responseBuilder);
                }
                
                if(solrResponse.getStatus() != ClientResponse.Status.OK.getStatusCode())
                {
                    // This method will construct and throw the exception to the client
                    processOutputException(solrResponse, true);
                }
                
                queryResponse = processOutputResource(solrResponse);
                
                resultList = getResultAsList(queryResponse, T);
                numFound = queryResponse.getResults().getNumFound();
                start = queryResponse.getResults().getStart();
                
                return responseBuilder.status(solrResponse.getStatusInfo().getStatusCode())
                        .entity(getLevel3Response(resultList, numFound, start))
                        .type(responseMediaType)
                        .build(); 
            }
            else if(responseMediaType.equals(MediaType.APPLICATION_JSON_TYPE))
            {
                solrResponse = processQueryOutputJson(searchParams);

                addResponseHeaders(solrResponse, responseBuilder);
                
                if(solrResponse.getStatus() == ClientResponse.Status.NOT_MODIFIED.getStatusCode())
                {
                    return processOutputNotModified(responseBuilder);
                }
                
                if(solrResponse.getStatus() != ClientResponse.Status.OK.getStatusCode())
                {
                    // This method will construct and throw the exception to the client
                    processOutputException(solrResponse, false);
                }
                
                return responseBuilder.status(solrResponse.getStatusInfo().getStatusCode())
                        .entity(solrResponse.getEntity(String.class))
                        .type(responseMediaType)
                        .build(); 
            }
            else if(responseMediaType.equals(MediaType.APPLICATION_XML_TYPE))
            {
                solrResponse = processQueryOutputXml(searchParams);

                addResponseHeaders(solrResponse, responseBuilder);
                
                if(solrResponse.getStatus() == ClientResponse.Status.NOT_MODIFIED.getStatusCode())
                {
                    return processOutputNotModified(responseBuilder);
                }
                
                if(solrResponse.getStatus() != ClientResponse.Status.OK.getStatusCode())
                {
                    // This method will construct and throw the exception to the client
                    processOutputException(solrResponse, true);
                }
                
                return responseBuilder.status(solrResponse.getStatusInfo().getStatusCode())
                        .entity(processOutputXml(solrResponse))
                        .type(responseMediaType)
                        .build(); 
            }
            else
            {
                // We should never hit this code
                return null;
            }
        }
        catch(DataServiceBaseException dse)
        {
            throw dse;
        }
        catch(Exception ex)
        {
            throw new WebApplicationException(ex);
        }
        finally
        {
            stopProfiler();
        }
    }
    
    // We need to call ge
    // We need to call getTypedGenericEntity as otherwise we get exception while trying to convert the 
    // response to XML or JSON. Jersey cannot deal with generics and results in exceptions.
    // protected abstract <T> GenericEntity<?> getTypedGenericEntity(List<T> resultList);
    
    protected abstract <T> Level3Response<?> getLevel3Response(
            List<T> resultList, long numFound, long start);
    
    protected abstract String getSolrUrl();
    
    /**
     * Management interface for monitoring resource.
     * @return Status of OK
     */
    @GET
    @com.webcohesion.enunciate.metadata.rs.TypeHint(PingResponse.class)
    @Path("ping")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response ping()
    {
        return Response.status(Status.OK).entity(new PingResponse()).build();
    }
    
    /**
     * Management interface for querying configuration for the resource.
     * @return Config response - detailing the build version and link to underlying SOLR index.
     */
    @GET
    @com.webcohesion.enunciate.metadata.rs.TypeHint(ConfigResponse.class)
    @Path("config")
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response config()
    {
        ConfigResponse response = new ConfigResponse();
        
        ConfigProperty configProperty = new ConfigProperty("SOLR URL", getSolrUrl());
        
        response.addProperty(configProperty);
        
        getBuildLabels(servletContext, response);
        
        return Response.status(Status.OK).entity(response).build();
    }
    
    private ClientResponse processQueryOutputJson(MultivaluedMap<String, String> params)
    {
        params.remove("wt");
        params.add("wt", "json");
        return query(params);
    }
    
    private ClientResponse processQueryOutputXml(MultivaluedMap<String, String> params)
    {
        params.remove("wt");
        params.add("wt", "xml");
        return query(params);
    }
    
    private void processOutputException(ClientResponse solrResponse, boolean isSolrResponseXml)
    {
        if(isSolrResponseXml)
        {
            throw new DataServiceBaseException(
                ErrorCodeMapping.InvalidData, getErrorResponse(solrResponse));
        }
        else
        {
            throw new DataServiceBaseException(
                ErrorCodeMapping.InvalidData, getErrorResponseFromJson(solrResponse));
        }
    }
    
    private Response processOutputNotModified(ResponseBuilder responseBuilder)
    {
        return responseBuilder.status(Status.NOT_MODIFIED).build();
    }
    
    private String processOutputXml(ClientResponse clientResponse)
    {
        try
        {
            return wrapInLevel3Response(
                    new ByteArrayInputStream(
                            clientResponse.getEntity(String.class).getBytes("UTF-8")));
        }
        catch(UnsupportedEncodingException uee)
        {
            throw new DataServiceBaseException(ErrorCodeMapping.InternalServerError, uee);
        }
    }
    
    private QueryResponse processOutputResource(ClientResponse clientResponse)
    {
        NamedList<Object> namedList = processOutputResourceGetNamedList(clientResponse);
        
        QueryResponse queryResponse = new QueryResponse();
        queryResponse.setResponse(namedList);
        
        return queryResponse;
    }
    
    private NamedList<Object> processOutputResourceGetNamedList(ClientResponse clientResponse)
    {
        XMLResponseParser responseParser = new XMLResponseParser();
        NamedList<Object> namedList = 
                responseParser.processResponse(clientResponse.getEntityInputStream(), "UTF-8");
        
        return namedList;
    }
    
    private <T> List<T> getResultAsList(QueryResponse queryResponse, Class<T> T)
    {
        List<T> resourceList = queryResponse.getBeans(T);
        
        long numFound = queryResponse.getResults().getNumFound();
        
        if(numFound > 0 && resourceList.isEmpty())
        {
            if(numFound > queryResponse.getResults().getStart())
            {
                // throw exception here
                throw new DataServiceBaseException(
                        ErrorCodeMapping.UnsupportedQueryConversion,
                        "could not convert result set to a bean.");
            }
        }
        
        return resourceList;
    }
    
    private void addResponseHeaders(ClientResponse solrResponse, ResponseBuilder responseBuilder)
    {
        MultivaluedMap<String, String> solrResponseHeaderParams = solrResponse.getHeaders();
        
        // Solr will emit following response header elements
        // Etag, Last-Modified, Expires, Cache-Control
        // http://wiki.apache.org/solr/SolrAndHTTPCaches
        
        if(solrResponse.getEntityTag() != null)
        {
            responseBuilder.tag(solrResponse.getEntityTag());
        }
        if(solrResponse.getLastModified() != null)
        {
            responseBuilder.lastModified(solrResponse.getLastModified());
        }
        
        if(solrResponseHeaderParams.containsKey(HttpHeaders.EXPIRES))
        {
            responseBuilder.header(
                HttpHeaders.EXPIRES, solrResponseHeaderParams.get(HttpHeaders.EXPIRES).get(0));
        }
        if(solrResponseHeaderParams.containsKey(HttpHeaders.CACHE_CONTROL))
        {
            responseBuilder.header(
                HttpHeaders.CACHE_CONTROL, solrResponseHeaderParams.get(HttpHeaders.CACHE_CONTROL).get(0));
        }
        
        return;
    }
    
    private ClientResponse query(MultivaluedMap<String, String> params)
    {
        WebResource webResource = client.resource(getSolrUrl());
        webResource.type(MediaType.APPLICATION_FORM_URLENCODED_TYPE);
        
        Form form = new Form();
        Set<Entry<String, List<String>>> entrySet = params.entrySet();

        for(Entry<String, List<String>> entry : entrySet)
        {
            for(String value : entry.getValue())
            {
                form.add(entry.getKey(), value);
            }
        }
        
        WebResource.Builder requestBuilder = webResource.getRequestBuilder();
        
        // Add If-* headers from client request onto the request we are making to SOLR
        // Only the headers listed below are supported by SOLR
        // http://wiki.apache.org/solr/SolrAndHTTPCaches
        
        setRequestHeader(requestBuilder, HttpHeaders.IF_MATCH);
        setRequestHeader(requestBuilder, HttpHeaders.IF_NONE_MATCH);
        setRequestHeader(requestBuilder, HttpHeaders.IF_MODIFIED_SINCE);
        setRequestHeader(requestBuilder, HttpHeaders.IF_UNMODIFIED_SINCE);
        
        startProfiler(PROFILER_SOLR_QUERY_STR);
        ClientResponse response = requestBuilder.post(ClientResponse.class, form);
        startProfiler(PROFILER_POST_SOLR_QUERY_STR);
        
        return response;
    }
    
    private void setRequestHeader(WebResource.Builder requestBuilder, String requestHeader)
    {
        if(httpHeaders.getRequestHeader(requestHeader) != null && 
           httpHeaders.getRequestHeader(requestHeader).size() > 0)
        {
            requestBuilder.header(requestHeader, httpHeaders.getRequestHeader(requestHeader).get(0));
        }
        
        return;
    }
    
    private void checkAndLimitRowCount(MultivaluedMap<String, String> params)
    {
        List<String> rowList = params.get(ROWS_STR);
        
        if(rowList == null)
        {
            return;
        }
        
        if(rowList.size() == 1)
        {
            int rowCount = Integer.parseInt(rowList.get(0));
            
            if(rowCount > maxAllowedRowCount)
            {
                rowCount = maxAllowedRowCount;
                
                params.remove(ROWS_STR);
                params.add(ROWS_STR, Integer.toString(rowCount));
            }
        }
    }
    
    private void checkStartParam(MultivaluedMap<String, String> params)
    {
        List<String> startList = params.get(START_STR);
        
        if(startList == null)
        {
            return;
        }
        
        // SOLR honors only the first start param value, others are ignored
        int startParam = Integer.parseInt(startList.get(0));

        if (startParam >= maxStartParam)
        {
            // throw exception
            throw new DataServiceBaseException(ErrorCodeMapping.DeepPagingUnavailable, "deep paging of query results is prohibited");
        }
    }
    
    private void checkAndSetExternalCustomerFilter(MultivaluedMap<String, String> params)
    {
        boolean hasFacetMincount = false;

        List<String> credentialsHeaderList = httpHeaders.getRequestHeader(CREDENTAILS_HDR_STR);
        
        if(credentialsHeaderList != null && !credentialsHeaderList.isEmpty())
        {
            String  credentialsHeader = credentialsHeaderList.get(0);
            
            // internal customer requests will have "All" for credentials
            if(ALL_STR.equalsIgnoreCase(credentialsHeader))
            {
                return;
            }

            // add customerNumber filter
            // enable the terms filter, this will not be counted against SOLR maxBooleanClauses
             params.add(FQ_PARAM_STR, "{!terms f=customerNumber}" + credentialsHeader.toLowerCase());
            
            // if facet is true and facet.mincount is not set, default it to 1
            // facet.mincount >= 1
            String facetValue = params.getFirst(FACET_STR);

            if(TRUE_STR.equalsIgnoreCase(facetValue) || ON_STR.equalsIgnoreCase(facetValue))
            {
                // check for mincount, must be >= 1
                Set<Entry<String, List<String>>> entrySet = params.entrySet();

                for(Entry<String, List<String>> entry : entrySet)
                {
                    if(entry.getKey().endsWith(MINCOUNT_STR))
                    {
                        if(FACET_MINCOUNT_STR.equalsIgnoreCase(entry.getKey()))
                        {
                            hasFacetMincount = true;
                        }

                        // check that value is >= 1
                        String value = entry.getValue().get(0);
                        
                        try
                        {
                            int minCountValue = Integer.parseInt(value);

                            if(minCountValue <= 0)
                            {
                                // reset mincount to 1
                                entry.setValue(minCountDefaultList);
                            }
                        }
                        catch(NumberFormatException nfe)
                        {
                            throw new DataServiceBaseException(
                               ErrorCodeMapping.InvalidQueryString,
                               "could not convert facet.mincount value to a number.");
                        }
                    }
                }
                
                if(!hasFacetMincount)
                {
                    // default facet.mincount
                    params.putSingle(FACET_MINCOUNT_STR, "1");
                }
            }
        }
    }
    
    private String wrapInLevel3Response(InputStream inputStream)
    {
        try
        {
            if(xsl == null)
            {
                try
                {
                    return IOUtils.toString(inputStream, "UTF-8");
                }
                catch (IOException ioe)
                {
                    log.error("caught exception while converting InputStream to String.", ioe);
                    
                    throw new DataServiceBaseException(
                            ErrorCodeMapping.InternalServerError,
                            "exception while converting InputStream to String");
                }
            }
            
            Source source = new StreamSource(inputStream);

            StringWriter writer = new StringWriter();
            Result result = new StreamResult(writer);

            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer(xsl);
//            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
            
            return writer.toString();
        }
        catch (TransformerConfigurationException tce)
        {
            log.error("caught exception while trying to create Transformer using Level3Response.xsl", tce);
            
            throw new DataServiceBaseException(
                    ErrorCodeMapping.InternalServerError,
                    "exception while trying to create Transformer using Level3Response.xsl");
        }
        catch (TransformerException te)
        {
            log.error("caught exception while trying to transform Solr response", te);
            
            throw new DataServiceBaseException(
                    ErrorCodeMapping.InternalServerError,
                    "caught exception while trying to transform Solr response");
        }
    }
    
    @SuppressWarnings("unchecked")
    private String getErrorResponse(ClientResponse solrResponse)
    {
        NamedList<Object> namedList = processOutputResourceGetNamedList(solrResponse);

        String reason = null;
        try
        {
            NamedList<String> err = (NamedList<String>) namedList.get("error");
            if (err != null)
            {
                reason = (String) err.get("msg");
            }

            if (reason == null)
            {
                reason = solrResponse.getStatusInfo().getReasonPhrase();
            }
        }
        catch (Exception ex)
        {
            log.error("caught exception while trying to transform Solr error response", ex);
            
            throw new DataServiceBaseException(
                    ErrorCodeMapping.InternalServerError,
                    "caught exception while trying to transform Solr error response");
        }
        
        return reason;
    }

    private String getErrorResponseFromJson(ClientResponse solrResponse)
    {
        String reason = null;
        
        try
        {
            JSONObject json = new JSONObject(solrResponse.getEntity(String.class));
            
            JSONObject error = json.optJSONObject("error");
            
            if(error != null)
            {
                reason = error.optString("msg");
            }
            
            if(reason == null)
            {
                reason = solrResponse.getStatusInfo().getReasonPhrase();
            }
        }
        catch (JSONException jex)
        {
            log.error("caught exception while trying to transform Solr error response to a JSON", jex);
            
            throw new DataServiceBaseException(
                    ErrorCodeMapping.InternalServerError,
                    "caught exception while trying to transform Solr error response to a JSON");
        }
        
        return reason;
    }
        
    protected static int getMaxAllowedRowCount()
    {
        return maxAllowedRowCount;
    }

    /** 
     * Max allowed row count is set per JVM basis, not per request basis. This change is valid for 
     * the entire session and will impact every request following the change. 
     * This change is not thread safe.
     * 
     * @param maxAllowedRowCount
     */
    protected static void setMaxAllowedRowCount(int maxAllowedRowCount)
    {
        AbstractBaseResource.maxAllowedRowCount = maxAllowedRowCount;
    }

    protected static List<Variant> getSearchVariantList()
    {
        return searchVariantList;
    }

    /** 
     * Search variant list is set per JVM basis, not per request basis. This change is valid for 
     * the entire session and will impact every request following the change. 
     * This change is not thread safe.
     * 
     * @param searchVariantList
     */
    protected static void setSearchVariantList(List<Variant> searchVariantList)
    {
        AbstractBaseResource.searchVariantList = searchVariantList;
    }
    
    private void getBuildLabels(ServletContext context, ConfigResponse configResponse)
    {
        Attributes attr = null;
        String buildLabel = null;
        String pandaBuildLabel = null;
        String buildTime = null;
        ConfigProperty configProperty = null;
        
        try
        {
            InputStream inputStream = context.getResourceAsStream(MANIFEST_FILE_PATH);
            
            Manifest manifest = new Manifest(inputStream);
            attr = manifest.getMainAttributes();
            buildLabel = attr.getValue(BUILD_LABEL_STR);

            if(buildLabel != null && buildLabel.startsWith(KMREST_BUILD_LABEL_STR))
            {
                pandaBuildLabel = attr.getValue(PANDA_BUILD_LABEL_STR);
                configProperty = new ConfigProperty(PANDA_BUILD_LABEL_STR, pandaBuildLabel);

                configResponse.addProperty(configProperty);

                buildTime = attr.getValue(BUILD_DATE_STR);
                configProperty = new ConfigProperty(BUILD_DATE_STR, buildTime);
                configResponse.addProperty(configProperty);
            }
            
            log.debug("PANDA Build Label {}, build date {}", pandaBuildLabel, buildTime);
        }
        catch (IOException E) 
        {
            // handle
        }
    }
    
    private boolean logPerformanceData()
    {
        return "true".equals(MDC.get("LogPerformanceData"));
    }
    
    protected void initializeProfiler()
    {
        if(logPerformanceData())
        {
            profiler = new Profiler(PROFILER_SOLR_QUERY_PREP_STR, uriInfo.getPath() + "-" + request.getMethod() + ":" + uriInfo.getQueryParameters().toString());
        }
        
        return;
    }
    
    protected void startProfiler(String tagPrefix)
    {
        if(logPerformanceData())
        {
            profiler.start(tagPrefix, uriInfo.getPath() + "-" + request.getMethod() + ":" + uriInfo.getQueryParameters().toString());
        }
    }
    
    protected void stopProfiler()
    {
        if(logPerformanceData())
        {
            profiler.stop();
        }
    }

    /**
     * This is a hack.
     * It measures the time taken during various stages of request processing.
     * If the request had header X-Level3-LogPerf: TRUE, then the code above instantiates this class. 
     * 
     */
    private static class Profiler
    {
        private static StopWatchFactory speed4jStopWatchFactory = StopWatchFactory.getInstance("loggingFactory");

        private StopWatch stopWatch = null;

        /**
         * Starts a StopWatch and sets the tag and the message on it.
         * @param tag
         * @param message
         */
        public Profiler(String tag, String message)
        {
            stopWatch = speed4jStopWatchFactory.getStopWatch(tag, message);
        }

        /**
         * Stops the running StopWatch, logs the output and then 
         * starts the stopWatch again to measure next stage and sets the tag and message attrs for next stage
         * @param tag
         * @param message
         */
        public void start(String tag, String message)
        {
            stopWatch.lap();
            stopWatch.setTag(tag);
            stopWatch.setMessage(message);
        }

        /**
         * Stops the running StopWatch, logs the output
         */
        public void stop()
        {
            stopWatch.stop();
        }
    }
    
    private static class TrustAllHostNameVerifier implements HostnameVerifier 
    {
        public boolean verify(String hostname, SSLSession session) 
        {
            return true;
        }
    }
}