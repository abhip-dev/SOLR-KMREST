package com.level3.km.services.resource.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

import java.util.Date;

@XmlRootElement(name="customerContractTerm")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerContractTerm {
  @Field("productInstanceId")
  private String productInstanceId;
  @Field("customerServiceId")
  private String customerServiceId;
  @Field("serviceId")
  private String serviceId;
  @Field("originalContractTermLengthInMonths")
  private Long originalContractTermLengthInMonths;
  @Field("originalContractTermStartDate")
  private Date originalContractTermStartDate;
  @Field("currentContractTermLengthInMonths")
  private Long currentContractTermLengthInMonths;
  @Field("currentContractTermStartDate")
  private Date currentContractTermStartDate;
  @Field("currentContractTermEndDate")
  private Date currentContractTermEndDate;
  @Field("previousContractTermEndDate")
  private Date previousContractTermEndDate;
  @Field("customerOrderNumber")
  private String customerOrderNumber;
  @Field("outOfTermIndicator")
  private Boolean outOfTermIndicator;
  @Field("dwSourceSystemCode")
  private String dwSourceSystemCode;
  @Field("previousContractTermStartDate")
  private Date previousContractTermStartDate;
  @Field("serviceOrderActionType")
  private String serviceOrderActionType;
  @Field("lastInvoiceDate")
  private Date lastInvoiceDate;
  @Field("usdMrcAmount")
  private Float usdMrcAmount;
  @Field("salesChannelName")
  private String salesChannelName;
  @Field("customerNumber")
  private String customerNumber;
  @Field("customerName")
  private String customerName;
  @Field("billAccountNumber")
  private String billAccountNumber;
  @Field("productCode")
  private String productCode;
  @Field("productName")
  private String productName;

  public String getProductInstanceId() {
    return productInstanceId;
  }

  public void setProductInstanceId(String productInstanceId) {
    this.productInstanceId = productInstanceId;
  }

  public String getCustomerServiceId() {
    return customerServiceId;
  }

  public void setCustomerServiceId(String customerServiceId) {
    this.customerServiceId = customerServiceId;
  }

  public String getServiceId() {
    return serviceId;
  }

  public void setServiceId(String serviceId) {
    this.serviceId = serviceId;
  }

  public Long getOriginalContractTermLengthInMonths() {
    return originalContractTermLengthInMonths;
  }

  public void setOriginalContractTermLengthInMonths(Long originalContractTermLengthInMonths) {
    this.originalContractTermLengthInMonths = originalContractTermLengthInMonths;
  }

  public Date getOriginalContractTermStartDate() {
    return originalContractTermStartDate;
  }

  public void setOriginalContractTermStartDate(Date originalContractTermStartDate) {
    this.originalContractTermStartDate = originalContractTermStartDate;
  }

  public Long getCurrentContractTermLengthInMonths() {
    return currentContractTermLengthInMonths;
  }

  public void setCurrentContractTermLengthInMonths(Long currentContractTermLengthInMonths) {
    this.currentContractTermLengthInMonths = currentContractTermLengthInMonths;
  }

  public Date getCurrentContractTermStartDate() {
    return currentContractTermStartDate;
  }

  public void setCurrentContractTermStartDate(Date currentContractTermStartDate) {
    this.currentContractTermStartDate = currentContractTermStartDate;
  }

  public Date getCurrentContractTermEndDate() {
    return currentContractTermEndDate;
  }

  public void setCurrentContractTermEndDate(Date currentContractTermEndDate) {
    this.currentContractTermEndDate = currentContractTermEndDate;
  }

  public Date getPreviousContractTermEndDate() {
    return previousContractTermEndDate;
  }

  public void setPreviousContractTermEndDate(Date previousContractTermEndDate) {
    this.previousContractTermEndDate = previousContractTermEndDate;
  }

  public String getCustomerOrderNumber() {
    return customerOrderNumber;
  }

  public void setCustomerOrderNumber(String customerOrderNumber) {
    this.customerOrderNumber = customerOrderNumber;
  }

  public Boolean getOutOfTermIndicator() {
    return outOfTermIndicator;
  }

  public void setOutOfTermIndicator(Boolean outOfTermIndicator) {
    this.outOfTermIndicator = outOfTermIndicator;
  }

  public String getDwSourceSystemCode() {
    return dwSourceSystemCode;
  }

  public void setDwSourceSystemCode(String dwSourceSystemCode) {
    this.dwSourceSystemCode = dwSourceSystemCode;
  }

  public Date getPreviousContractTermStartDate() {
    return previousContractTermStartDate;
  }

  public void setPreviousContractTermStartDate(Date previousContractTermStartDate) {
    this.previousContractTermStartDate = previousContractTermStartDate;
  }

  public String getServiceOrderActionType() {
    return serviceOrderActionType;
  }

  public void setServiceOrderActionType(String serviceOrderActionType) {
    this.serviceOrderActionType = serviceOrderActionType;
  }

  public Date getLastInvoiceDate() {
    return lastInvoiceDate;
  }

  public void setLastInvoiceDate(Date lastInvoiceDate) {
    this.lastInvoiceDate = lastInvoiceDate;
  }

  public Float getUsdMrcAmount() {
    return usdMrcAmount;
  }

  public void setUsdMrcAmount(Float usdMrcAmount) {
    this.usdMrcAmount = usdMrcAmount;
  }

  public String getSalesChannelName() {
    return salesChannelName;
  }

  public void setSalesChannelName(String salesChannelName) {
    this.salesChannelName = salesChannelName;
  }

  public String getCustomerNumber() {
    return customerNumber;
  }

  public void setCustomerNumber(String customerNumber) {
    this.customerNumber = customerNumber;
  }

  public String getCustomerName() {
    return customerName;
  }

  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }

  public String getBillAccountNumber() {
    return billAccountNumber;
  }

  public void setBillAccountNumber(String billAccountNumber) {
    this.billAccountNumber = billAccountNumber;
  }

  public String getProductCode() {
    return productCode;
  }

  public void setProductCode(String productCode) {
    this.productCode = productCode;
  }

  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("CustomerContractTerm [");
    builder.append("productInstanceId=").append(productInstanceId);
    builder.append(", customerServiceId=").append(customerServiceId);
    builder.append(", serviceId=").append(serviceId);
    builder.append(", originalContractTermLengthInMonths=").append(originalContractTermLengthInMonths);
    builder.append(", originalContractTermStartDate=").append(originalContractTermStartDate);
    builder.append(", currentContractTermLengthInMonths=").append(currentContractTermLengthInMonths);
    builder.append(", currentContractTermStartDate=").append(currentContractTermStartDate);
    builder.append(", currentContractTermEndDate=").append(currentContractTermEndDate);
    builder.append(", previousContractTermEndDate=").append(previousContractTermEndDate);
    builder.append(", customerOrderNumber=").append(customerOrderNumber);
    builder.append(", outOfTermIndicator=").append(outOfTermIndicator);
    builder.append(", dwSourceSystemCode=").append(dwSourceSystemCode);
    builder.append(", previousContractTermStartDate=").append(previousContractTermStartDate);
    builder.append(", serviceOrderActionType=").append(serviceOrderActionType);
    builder.append(", lastInvoiceDate=").append(lastInvoiceDate);
    builder.append(", usdMrcAmount=").append(usdMrcAmount);
    builder.append(", salesChannelName=").append(salesChannelName);
    builder.append(", customerNumber=").append(customerNumber);
    builder.append(", customerName=").append(customerName);
    builder.append(", billAccountNumber=").append(billAccountNumber);
    builder.append(", productCode=").append(productCode);
    builder.append(", productName=").append(productName);
    builder.append("]");
    return builder.toString();
  }
}
