package com.level3.km.services.resource.beans;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="level3Response")
@XmlAccessorType(XmlAccessType.FIELD)
public class PingResponse implements Serializable
{
    private static final long serialVersionUID = -2658264408238164213L;

	public PingResponse() 
	{
		this.status = Status.OK;
	}
	
	@XmlElement(name="status")
	private Status status;
	
    public Status getStatus()
    {
        return status;
    }

    public void setStatus(Status status)
    {
        this.status = status;
    }

    public static long getSerialversionuid()
    {
        return serialVersionUID;
    }

    public enum Status
    {
        OK, NOT_FOUND;
    }
}
