package com.level3.km.services.resource.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name="customerBillAccountNumber")
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerBillAccountNumber
{
    @Field("id")
    private String id;
    @Field("billAccountKeyId")
    private String billAccountKeyId;
    @Field("billAccountNumber")
    private String billAccountNumber;
    @Field("billAccountName")
    private String billAccountName;
    @Field("billPeriodCode")
    private String billPeriodCode;
    @Field("effectiveDate")
    private Date effectiveDate;
    @Field("deactivationDate")
    private Date deactivationDate;
    @Field("billAccountStatus")
    private String billAccountStatus;
    @Field("billLine1Address")
    private String billLine1Address;
    @Field("billLine2Address")
    private String billLine2Address;
    @Field("billCityName")
    private String billCityName;
    @Field("billStateCode")
    private String billStateCode;
    @Field("billPostalCode")
    private String billPostalCode;
    @Field("billCountryName")
    private String billCountryName;
    @Field("operatingCompanyName")
    private String operatingCompanyName;
    @Field("parentBillAccountNumber")
    private String parentBillAccountNumber;
    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;
    @Field("customerClassType")
    private String customerClassType;
    @Field("customerName")
    private String customerName;
    @Field("customerNumber")
    private String customerNumber;
    @Field("customerStatusCode")
    private String customerStatusCode;
    @Field("parentCustomerNumber")
    private String parentCustomerNumber;
    @Field("parentCustomerName")
    private String parentCustomerName;
    @Field("salesChannelName")
    private String salesChannelName;

    @Deprecated
    @Field("salesRegionName")
    private String salesRegionName;

    @Deprecated
    @Field("salesTerritoryName")
    private String salesTerritoryName;

    @Field("customerSinceDate")
    private Date customerSinceDate;
    @Field("ultimateCustomerName")
    private String ultimateCustomerName;
    @Field("ultimateCustomerNumber")
    private String ultimateCustomerNumber;
    @Field("lineOfBusinessId")
    private String lineOfBusinessId;
    @Field("secondaryLineOfBusinessId")
    private String secondaryLineOfBusinessId;
    @Field("primarySalesEmployeeNumber")
    private String primarySalesEmployeeNumber;
    @Field("customerKeyId")
    private String customerKeyId;
    @Field("internalCompanyIndicator")
    private Boolean internalCompanyIndicator;
    @Field("customerContactName")
    private String customerContactName;
    @Field("customerContactEmailAddress")
    private String customerContactEmailAddress;
    @Field("customerPhoneNumber")
    private String customerPhoneNumber;

    @Deprecated
    @Field("salesMarketAreaName")
    private String salesMarketAreaName;

    @Field("resellerCategoryType")
    private String resellerCategoryType;
    @Field("partnerIndicator")
    private Boolean partnerIndicator;
    @Field("resellerIndicator")
    private Boolean resellerIndicator;
    @Field("agentType")
    private String agentType;
    @Field("externalReportSalesChannelName")
    private String externalReportSalesChannelName;
    @Field("salesSubChannelName")
    private String salesSubChannelName;

    @Deprecated
    @Field("salesManagerCategoryCode")
    private String salesManagerCategoryCode;

    @Field("gartnerIndustrySegmentName")
    private String gartnerIndustrySegmentName;
    @Field("gartnerIndustrySubSegmentName")
    private String gartnerIndustrySubSegmentName;
    @Field("industryVerticalType")
    private String industryVerticalType;
    @Field("industrySubVerticalType")
    private String industrySubVerticalType;
    @Field("level3TargetGroupName")
    private String level3TargetGroupName;
    @Field("level3TargetTierName")
    private String level3TargetTierName;
    @Field("sourceBillAccountNumber")
    private String sourceBillAccountNumber;
    @Field("sourceBillAccountName")
    private String sourceBillAccountName;
    @Field("sourceBillAccountKeyId")
    private String sourceBillAccountKeyId;
    @Field("sourceBillAccountSourceSystemCode")
    private String sourceBillAccountSourceSystemCode;
    @Field("sourceBillAccountXrefTypeDescription")
    private String sourceBillAccountXrefTypeDescription;
    @Field("sourceBillAccountXrefAccountNumber")
    private String sourceBillAccountXrefAccountNumber;
    @Field("legacySourceSystemCodes")
    private List<String> legacySourceSystemCodes;
    @Field("financeAccountNumber")
    private String financeAccountNumber;
    @Field("preferredSourceRecordIndicator")
    private Boolean preferredSourceRecordIndicator;
    @Field("serviceLevelType")
    private String serviceLevelType;
    @Field("dunsNumber")
    private String dunsNumber;
    @Field("naicsCode")
    private String naicsCode;
    @Field("alternateSourceSystemCode")
    private String alternateSourceSystemCode;
    @Field("alternateCustomerNumber")
    private String alternateCustomerNumber;
    @Field("currencyCode")
    private String currencyCode;
    @Field("globalAccountManagementIndicator")
    private Boolean globalAccountManagementIndicator;
    @Field("vatNumber")
    private String vatNumber;
    
    @Field("cpniStatusCode")
    private String cpniStatusCode;

    @Field("cpniNoticeCreateDate")
    private Date cpniNoticeCreateDate;

    @Field("cpniStatusReceivedDate")
    private Date cpniStatusReceivedDate;

    @Field("cpniWaitPeriodExpireDate")
    private Date cpniWaitPeriodExpireDate;

    @Field("cpniStatusRenewalDate")
    private Date cpniStatusRenewalDate;

    @Field("cpniSubmitterName")
    private String cpniSubmitterName;

    @Field("cpniSubmitterPhoneNumber")
    private String cpniSubmitterPhoneNumber;

    @Field("cpniSubmitterEmailAddress")
    private String cpniSubmitterEmailAddress;

    @Field("cpniNoticeType")
    private String cpniNoticeType;

    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public String getBillAccountKeyId()
    {
        return billAccountKeyId;
    }
    public void setBillAccountKeyId(String billAccountKeyId)
    {
        this.billAccountKeyId = billAccountKeyId;
    }
    public String getBillAccountNumber()
    {
        return billAccountNumber;
    }
    public void setBillAccountNumber(String billAccountNumber)
    {
        this.billAccountNumber = billAccountNumber;
    }
    public String getBillAccountName()
    {
        return billAccountName;
    }
    public void setBillAccountName(String billAccountName)
    {
        this.billAccountName = billAccountName;
    }
    public String getBillPeriodCode()
    {
        return billPeriodCode;
    }
    public void setBillPeriodCode(String billPeriodCode)
    {
        this.billPeriodCode = billPeriodCode;
    }
    public Date getEffectiveDate()
    {
        return effectiveDate;
    }
    public void setEffectiveDate(Date effectiveDate)
    {
        this.effectiveDate = effectiveDate;
    }
    public Date getDeactivationDate()
    {
        return deactivationDate;
    }
    public void setDeactivationDate(Date deactivationDate)
    {
        this.deactivationDate = deactivationDate;
    }
    public String getBillAccountStatus()
    {
        return billAccountStatus;
    }
    public void setBillAccountStatus(String billAccountStatus)
    {
        this.billAccountStatus = billAccountStatus;
    }
    public String getBillLine1Address()
    {
        return billLine1Address;
    }
    public void setBillLine1Address(String billLine1Address)
    {
        this.billLine1Address = billLine1Address;
    }
    public String getBillLine2Address()
    {
        return billLine2Address;
    }
    public void setBillLine2Address(String billLine2Address)
    {
        this.billLine2Address = billLine2Address;
    }
    public String getBillCityName()
    {
        return billCityName;
    }
    public void setBillCityName(String billCityName)
    {
        this.billCityName = billCityName;
    }
    public String getBillStateCode()
    {
        return billStateCode;
    }
    public void setBillStateCode(String billStateCode)
    {
        this.billStateCode = billStateCode;
    }
    public String getBillPostalCode()
    {
        return billPostalCode;
    }
    public void setBillPostalCode(String billPostalCode)
    {
        this.billPostalCode = billPostalCode;
    }
    public String getBillCountryName()
    {
        return billCountryName;
    }
    public void setBillCountryName(String billCountryName)
    {
        this.billCountryName = billCountryName;
    }
    public String getOperatingCompanyName()
    {
        return operatingCompanyName;
    }
    public void setOperatingCompanyName(String operatingCompanyName)
    {
        this.operatingCompanyName = operatingCompanyName;
    }
    public String getParentBillAccountNumber()
    {
        return parentBillAccountNumber;
    }
    public void setParentBillAccountNumber(String parentBillAccountNumber)
    {
        this.parentBillAccountNumber = parentBillAccountNumber;
    }
    public String getDwSourceSystemCode()
    {
        return dwSourceSystemCode;
    }
    public void setDwSourceSystemCode(String dwSourceSystemCode)
    {
        this.dwSourceSystemCode = dwSourceSystemCode;
    }
    public String getCustomerClassType()
    {
        return customerClassType;
    }
    public void setCustomerClassType(String customerClassType)
    {
        this.customerClassType = customerClassType;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
    public String getCustomerNumber()
    {
        return customerNumber;
    }
    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber = customerNumber;
    }
    public String getCustomerStatusCode()
    {
        return customerStatusCode;
    }
    public void setCustomerStatusCode(String customerStatusCode)
    {
        this.customerStatusCode = customerStatusCode;
    }
    public String getParentCustomerNumber()
    {
        return parentCustomerNumber;
    }
    public void setParentCustomerNumber(String parentCustomerNumber)
    {
        this.parentCustomerNumber = parentCustomerNumber;
    }
    public String getParentCustomerName()
    {
        return parentCustomerName;
    }
    public void setParentCustomerName(String parentCustomerName)
    {
        this.parentCustomerName = parentCustomerName;
    }
    public String getSalesChannelName()
    {
        return salesChannelName;
    }
    public void setSalesChannelName(String salesChannelName)
    {
        this.salesChannelName = salesChannelName;
    }
    public String getSalesRegionName()
    {
        return salesRegionName;
    }
    public void setSalesRegionName(String salesRegionName)
    {
        this.salesRegionName = salesRegionName;
    }
    public String getSalesTerritoryName()
    {
        return salesTerritoryName;
    }
    public void setSalesTerritoryName(String salesTerritoryName)
    {
        this.salesTerritoryName = salesTerritoryName;
    }
    public Date getCustomerSinceDate()
    {
        return customerSinceDate;
    }
    public void setCustomerSinceDate(Date customerSinceDate)
    {
        this.customerSinceDate = customerSinceDate;
    }
    public String getUltimateCustomerName()
    {
        return ultimateCustomerName;
    }
    public void setUltimateCustomerName(String ultimateCustomerName)
    {
        this.ultimateCustomerName = ultimateCustomerName;
    }
    public String getUltimateCustomerNumber()
    {
        return ultimateCustomerNumber;
    }
    public void setUltimateCustomerNumber(String ultimateCustomerNumber)
    {
        this.ultimateCustomerNumber = ultimateCustomerNumber;
    }
    public String getLineOfBusinessId()
    {
        return lineOfBusinessId;
    }
    public void setLineOfBusinessId(String lineOfBusinessId)
    {
        this.lineOfBusinessId = lineOfBusinessId;
    }
    public String getPrimarySalesEmployeeNumber()
    {
        return primarySalesEmployeeNumber;
    }
    public void setPrimarySalesEmployeeNumber(String primarySalesEmployeeNumber)
    {
        this.primarySalesEmployeeNumber = primarySalesEmployeeNumber;
    }
    public String getCustomerKeyId()
    {
        return customerKeyId;
    }
    public void setCustomerKeyId(String customerKeyId)
    {
        this.customerKeyId = customerKeyId;
    }
    public Boolean getInternalCompanyIndicator()
    {
        return internalCompanyIndicator;
    }
    public void setInternalCompanyIndicator(Boolean internalCompanyIndicator)
    {
        this.internalCompanyIndicator = internalCompanyIndicator;
    }
    public String getCustomerContactName()
    {
        return customerContactName;
    }
    public void setCustomerContactName(String customerContactName)
    {
        this.customerContactName = customerContactName;
    }
    public String getCustomerContactEmailAddress()
    {
        return customerContactEmailAddress;
    }
    public void setCustomerContactEmailAddress(String customerContactEmailAddress)
    {
        this.customerContactEmailAddress = customerContactEmailAddress;
    }
    public String getCustomerPhoneNumber()
    {
        return customerPhoneNumber;
    }
    public void setCustomerPhoneNumber(String customerPhoneNumber)
    {
        this.customerPhoneNumber = customerPhoneNumber;
    }
    public String getSalesMarketAreaName()
    {
        return salesMarketAreaName;
    }
    public void setSalesMarketAreaName(String salesMarketAreaName)
    {
        this.salesMarketAreaName = salesMarketAreaName;
    }
    public String getResellerCategoryType()
    {
        return resellerCategoryType;
    }
    public void setResellerCategoryType(String resellerCategoryType)
    {
        this.resellerCategoryType = resellerCategoryType;
    }
    public Boolean getPartnerIndicator()
    {
        return partnerIndicator;
    }
    public void setPartnerIndicator(Boolean partnerIndicator)
    {
        this.partnerIndicator = partnerIndicator;
    }
    public Boolean getResellerIndicator()
    {
        return resellerIndicator;
    }
    public void setResellerIndicator(Boolean resellerIndicator)
    {
        this.resellerIndicator = resellerIndicator;
    }
    public String getAgentType()
    {
        return agentType;
    }
    public void setAgentType(String agentType)
    {
        this.agentType = agentType;
    }
    public String getExternalReportSalesChannelName()
    {
        return externalReportSalesChannelName;
    }
    public void setExternalReportSalesChannelName(
            String externalReportSalesChannelName)
    {
        this.externalReportSalesChannelName = externalReportSalesChannelName;
    }
    public String getSalesSubChannelName()
    {
        return salesSubChannelName;
    }
    public void setSalesSubChannelName(String salesSubChannelName)
    {
        this.salesSubChannelName = salesSubChannelName;
    }
    public String getGartnerIndustrySegmentName()
    {
        return gartnerIndustrySegmentName;
    }
    public void setGartnerIndustrySegmentName(String gartnerIndustrySegmentName)
    {
        this.gartnerIndustrySegmentName = gartnerIndustrySegmentName;
    }
    public String getGartnerIndustrySubSegmentName()
    {
        return gartnerIndustrySubSegmentName;
    }
    public void setGartnerIndustrySubSegmentName(
            String gartnerIndustrySubSegmentName)
    {
        this.gartnerIndustrySubSegmentName = gartnerIndustrySubSegmentName;
    }
    public String getIndustryVerticalType()
    {
        return industryVerticalType;
    }
    public void setIndustryVerticalType(String industryVerticalType)
    {
        this.industryVerticalType = industryVerticalType;
    }
    public String getLevel3TargetGroupName()
    {
        return level3TargetGroupName;
    }
    public void setLevel3TargetGroupName(String level3TargetGroupName)
    {
        this.level3TargetGroupName = level3TargetGroupName;
    }
    public String getLevel3TargetTierName()
    {
        return level3TargetTierName;
    }
    public void setLevel3TargetTierName(String level3TargetTierName)
    {
        this.level3TargetTierName = level3TargetTierName;
    }
    public String getSourceBillAccountNumber()
    {
        return sourceBillAccountNumber;
    }
    public void setSourceBillAccountNumber(String sourceBillAccountNumber)
    {
        this.sourceBillAccountNumber = sourceBillAccountNumber;
    }
    public String getSourceBillAccountName()
    {
        return sourceBillAccountName;
    }
    public void setSourceBillAccountName(String sourceBillAccountName)
    {
        this.sourceBillAccountName = sourceBillAccountName;
    }
    public String getSourceBillAccountKeyId()
    {
        return sourceBillAccountKeyId;
    }
    public void setSourceBillAccountKeyId(String sourceBillAccountKeyId)
    {
        this.sourceBillAccountKeyId = sourceBillAccountKeyId;
    }
    public String getSourceBillAccountSourceSystemCode()
    {
        return sourceBillAccountSourceSystemCode;
    }
    public void setSourceBillAccountSourceSystemCode(
            String sourceBillAccountSourceSystemCode)
    {
        this.sourceBillAccountSourceSystemCode = sourceBillAccountSourceSystemCode;
    }
    public String getSourceBillAccountXrefTypeDescription()
    {
        return sourceBillAccountXrefTypeDescription;
    }
    public void setSourceBillAccountXrefTypeDescription(
            String sourceBillAccountXrefTypeDescription)
    {
        this.sourceBillAccountXrefTypeDescription = sourceBillAccountXrefTypeDescription;
    }
    public String getSourceBillAccountXrefAccountNumber()
    {
        return sourceBillAccountXrefAccountNumber;
    }
    public void setSourceBillAccountXrefAccountNumber(
            String sourceBillAccountXrefAccountNumber)
    {
        this.sourceBillAccountXrefAccountNumber = sourceBillAccountXrefAccountNumber;
    }
    public String getIndustrySubVerticalType()
    {
        return industrySubVerticalType;
    }
    public void setIndustrySubVerticalType(String industrySubVerticalType)
    {
        this.industrySubVerticalType = industrySubVerticalType;
    }
    public List<String> getLegacySourceSystemCodes()
    {
        return legacySourceSystemCodes;
    }
    public void setLegacySourceSystemCodes(
            List<String> legacySourceSystemCodes)
    {
        this.legacySourceSystemCodes = legacySourceSystemCodes;
    }
    public String getFinanceAccountNumber()
    {
        return financeAccountNumber;
    }
    public void setFinanceAccountNumber(String financeAccountNumber)
    {
        this.financeAccountNumber = financeAccountNumber;
    }
    public Boolean getPreferredSourceRecordIndicator()
    {
        return preferredSourceRecordIndicator;
    }
    public void setPreferredSourceRecordIndicator(
            Boolean preferredSourceRecordIndicator)
    {
        this.preferredSourceRecordIndicator = preferredSourceRecordIndicator;
    }
    public String getSecondaryLineOfBusinessId()
    {
        return secondaryLineOfBusinessId;
    }
    public void setSecondaryLineOfBusinessId(String secondaryLineOfBusinessId)
    {
        this.secondaryLineOfBusinessId = secondaryLineOfBusinessId;
    }
    public String getSalesManagerCategoryCode()
    {
        return salesManagerCategoryCode;
    }
    public void setSalesManagerCategoryCode(String salesManagerCategoryCode)
    {
        this.salesManagerCategoryCode = salesManagerCategoryCode;
    }
    public String getServiceLevelType()
    {
        return serviceLevelType;
    }
    public void setServiceLevelType(String serviceLevelType)
    {
        this.serviceLevelType = serviceLevelType;
    }
    public String getDunsNumber()
    {
        return dunsNumber;
    }
    public void setDunsNumber(String dunsNumber)
    {
        this.dunsNumber = dunsNumber;
    }
    public String getNaicsCode()
    {
        return naicsCode;
    }
    public void setNaicsCode(String naicsCode)
    {
        this.naicsCode = naicsCode;
    }
    public String getAlternateSourceSystemCode()
    {
        return alternateSourceSystemCode;
    }
    public void setAlternateSourceSystemCode(String alternateSourceSystemCode)
    {
        this.alternateSourceSystemCode = alternateSourceSystemCode;
    }
    public String getAlternateCustomerNumber()
    {
        return alternateCustomerNumber;
    }
    public void setAlternateCustomerNumber(String alternateCustomerNumber)
    {
        this.alternateCustomerNumber = alternateCustomerNumber;
    }

    public String getCurrencyCode()
    {
        return currencyCode;
    }
    public void setCurrencyCode(String currencyCode)
    {
        this.currencyCode = currencyCode;
    }
    public Boolean getGlobalAccountManagementIndicator()
    {
        return globalAccountManagementIndicator;
    }
    public void setGlobalAccountManagementIndicator(
            Boolean globalAccountManagementIndicator)
    {
        this.globalAccountManagementIndicator = globalAccountManagementIndicator;
    }
    public String getVatNumber()
    {
        return vatNumber;
    }
    public void setVatNumber(String vatNumber)
    {
        this.vatNumber = vatNumber;
    }
    public String getCpniStatusCode()
    {
        return cpniStatusCode;
    }
    public void setCpniStatusCode(String cpniStatusCode)
    {
        this.cpniStatusCode = cpniStatusCode;
    }
    public Date getCpniNoticeCreateDate()
    {
        return cpniNoticeCreateDate;
    }
    public void setCpniNoticeCreateDate(Date cpniNoticeCreateDate)
    {
        this.cpniNoticeCreateDate = cpniNoticeCreateDate;
    }
    public Date getCpniStatusReceivedDate()
    {
        return cpniStatusReceivedDate;
    }
    public void setCpniStatusReceivedDate(Date cpniStatusReceivedDate)
    {
        this.cpniStatusReceivedDate = cpniStatusReceivedDate;
    }
    public Date getCpniWaitPeriodExpireDate()
    {
        return cpniWaitPeriodExpireDate;
    }
    public void setCpniWaitPeriodExpireDate(Date cpniWaitPeriodExpireDate)
    {
        this.cpniWaitPeriodExpireDate = cpniWaitPeriodExpireDate;
    }
    public Date getCpniStatusRenewalDate()
    {
        return cpniStatusRenewalDate;
    }
    public void setCpniStatusRenewalDate(Date cpniStatusRenewalDate)
    {
        this.cpniStatusRenewalDate = cpniStatusRenewalDate;
    }
    public String getCpniSubmitterName()
    {
        return cpniSubmitterName;
    }
    public void setCpniSubmitterName(String cpniSubmitterName)
    {
        this.cpniSubmitterName = cpniSubmitterName;
    }
    public String getCpniSubmitterPhoneNumber()
    {
        return cpniSubmitterPhoneNumber;
    }
    public void setCpniSubmitterPhoneNumber(String cpniSubmitterPhoneNumber)
    {
        this.cpniSubmitterPhoneNumber = cpniSubmitterPhoneNumber;
    }
    public String getCpniSubmitterEmailAddress()
    {
        return cpniSubmitterEmailAddress;
    }
    public void setCpniSubmitterEmailAddress(String cpniSubmitterEmailAddress)
    {
        this.cpniSubmitterEmailAddress = cpniSubmitterEmailAddress;
    }
    public String getCpniNoticeType()
    {
        return cpniNoticeType;
    }
    public void setCpniNoticeType(String cpniNoticeType)
    {
        this.cpniNoticeType = cpniNoticeType;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("CustomerBillAccountNumber [id=");
        builder.append(id);
        builder.append(", billAccountKeyId=");
        builder.append(billAccountKeyId);
        builder.append(", billAccountNumber=");
        builder.append(billAccountNumber);
        builder.append(", billAccountName=");
        builder.append(billAccountName);
        builder.append(", billPeriodCode=");
        builder.append(billPeriodCode);
        builder.append(", effectiveDate=");
        builder.append(effectiveDate);
        builder.append(", deactivationDate=");
        builder.append(deactivationDate);
        builder.append(", billAccountStatus=");
        builder.append(billAccountStatus);
        builder.append(", billLine1Address=");
        builder.append(billLine1Address);
        builder.append(", billLine2Address=");
        builder.append(billLine2Address);
        builder.append(", billCityName=");
        builder.append(billCityName);
        builder.append(", billStateCode=");
        builder.append(billStateCode);
        builder.append(", billPostalCode=");
        builder.append(billPostalCode);
        builder.append(", billCountryName=");
        builder.append(billCountryName);
        builder.append(", operatingCompanyName=");
        builder.append(operatingCompanyName);
        builder.append(", parentBillAccountNumber=");
        builder.append(parentBillAccountNumber);
        builder.append(", dwSourceSystemCode=");
        builder.append(dwSourceSystemCode);
        builder.append(", customerClassType=");
        builder.append(customerClassType);
        builder.append(", customerName=");
        builder.append(customerName);
        builder.append(", customerNumber=");
        builder.append(customerNumber);
        builder.append(", customerStatusCode=");
        builder.append(customerStatusCode);
        builder.append(", parentCustomerNumber=");
        builder.append(parentCustomerNumber);
        builder.append(", parentCustomerName=");
        builder.append(parentCustomerName);
        builder.append(", salesChannelName=");
        builder.append(salesChannelName);
        builder.append(", customerSinceDate=");
        builder.append(customerSinceDate);
        builder.append(", ultimateCustomerName=");
        builder.append(ultimateCustomerName);
        builder.append(", ultimateCustomerNumber=");
        builder.append(ultimateCustomerNumber);
        builder.append(", lineOfBusinessId=");
        builder.append(lineOfBusinessId);
        builder.append(", secondaryLineOfBusinessId=");
        builder.append(secondaryLineOfBusinessId);
        builder.append(", primarySalesEmployeeNumber=");
        builder.append(primarySalesEmployeeNumber);
        builder.append(", customerKeyId=");
        builder.append(customerKeyId);
        builder.append(", internalCompanyIndicator=");
        builder.append(internalCompanyIndicator);
        builder.append(", customerContactName=");
        builder.append(customerContactName);
        builder.append(", customerContactEmailAddress=");
        builder.append(customerContactEmailAddress);
        builder.append(", customerPhoneNumber=");
        builder.append(customerPhoneNumber);
        builder.append(", resellerCategoryType=");
        builder.append(resellerCategoryType);
        builder.append(", partnerIndicator=");
        builder.append(partnerIndicator);
        builder.append(", resellerIndicator=");
        builder.append(resellerIndicator);
        builder.append(", agentType=");
        builder.append(agentType);
        builder.append(", externalReportSalesChannelName=");
        builder.append(externalReportSalesChannelName);
        builder.append(", salesSubChannelName=");
        builder.append(salesSubChannelName);
        builder.append(", gartnerIndustrySegmentName=");
        builder.append(gartnerIndustrySegmentName);
        builder.append(", gartnerIndustrySubSegmentName=");
        builder.append(gartnerIndustrySubSegmentName);
        builder.append(", industryVerticalType=");
        builder.append(industryVerticalType);
        builder.append(", industrySubVerticalType=");
        builder.append(industrySubVerticalType);
        builder.append(", level3TargetGroupName=");
        builder.append(level3TargetGroupName);
        builder.append(", level3TargetTierName=");
        builder.append(level3TargetTierName);
        builder.append(", sourceBillAccountNumber=");
        builder.append(sourceBillAccountNumber);
        builder.append(", sourceBillAccountName=");
        builder.append(sourceBillAccountName);
        builder.append(", sourceBillAccountKeyId=");
        builder.append(sourceBillAccountKeyId);
        builder.append(", sourceBillAccountSourceSystemCode=");
        builder.append(sourceBillAccountSourceSystemCode);
        builder.append(", sourceBillAccountXrefTypeDescription=");
        builder.append(sourceBillAccountXrefTypeDescription);
        builder.append(", sourceBillAccountXrefAccountNumber=");
        builder.append(sourceBillAccountXrefAccountNumber);
        builder.append(", legacySourceSystemCodes=");
        builder.append(legacySourceSystemCodes);
        builder.append(", financeAccountNumber=");
        builder.append(financeAccountNumber);
        builder.append(", preferredSourceRecordIndicator=");
        builder.append(preferredSourceRecordIndicator);
        builder.append(", serviceLevelType=");
        builder.append(serviceLevelType);
        builder.append(", dunsNumber=");
        builder.append(dunsNumber);
        builder.append(", naicsCode=");
        builder.append(naicsCode);
        builder.append(", alternateSourceSystemCode=");
        builder.append(alternateSourceSystemCode);
        builder.append(", alternateCustomerNumber=");
        builder.append(alternateCustomerNumber);
        builder.append(", currencyCode=");
        builder.append(currencyCode);
        builder.append(", globalAccountManagementIndicator=");
        builder.append(globalAccountManagementIndicator);
        builder.append(", vatNumber=");
        builder.append(vatNumber);
        builder.append(", cpniStatusCode=");
        builder.append(cpniStatusCode);
        builder.append(", cpniNoticeCreateDate=");
        builder.append(cpniNoticeCreateDate);
        builder.append(", cpniStatusReceivedDate=");
        builder.append(cpniStatusReceivedDate);
        builder.append(", cpniWaitPeriodExpireDate=");
        builder.append(cpniWaitPeriodExpireDate);
        builder.append(", cpniStatusRenewalDate=");
        builder.append(cpniStatusRenewalDate);
        builder.append(", cpniSubmitterName=");
        builder.append(cpniSubmitterName);
        builder.append(", cpniSubmitterPhoneNumber=");
        builder.append(cpniSubmitterPhoneNumber);
        builder.append(", cpniSubmitterEmailAddress=");
        builder.append(cpniSubmitterEmailAddress);
        builder.append(", cpniNoticeType=");
        builder.append(cpniNoticeType);
        builder.append("]");
        return builder.toString();
    }
}
