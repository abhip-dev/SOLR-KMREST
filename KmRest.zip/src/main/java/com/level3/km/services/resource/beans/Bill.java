package com.level3.km.services.resource.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import java.util.Date;


import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "bill")
@XmlAccessorType(XmlAccessType.FIELD)
public class Bill {
    @Field("id")
    private String id;
    @Field("financeAccountNbr")
    private String financeAccountNbr;
    @Field("latestInvoiceNbr")
    private String latestInvoiceNbr;
    @Field("latestInvoiceDt")
    private Date latestInvoiceDt;
    @Field("currentBalanceAmt")
    private String currentBalanceAmt;
    @Field("latestInvoiceAmt")
    private String latestInvoiceAmt;
    @Field("latestInvoiceDueDt")
    private Date latestInvoiceDueDt;
    @Field("latestPaymentNbr")
    private String latestPaymentNbr;
    @Field("latestPaymentDt")
    private Date latestPaymentDt;
    @Field("latestPaymentAmt")
    private String latestPaymentAmt;
    @Field("latestCreditNbr")
    private String latestCreditNbr;
    @Field("latestCreditDt")
    private Date latestCreditDt;
    @Field("latestCreditAmt")
    private String latestCreditAmt;
    @Field("latestDebitNbr")
    private String latestDebitNbr;
    @Field("latestDebitDt")
    private Date latestDebitDt;
    @Field("latestDebitAmt")
    private String latestDebitAmt;
    @Field("minInvoiceDueDt")
    private Date minInvoiceDueDt;
    @Field("maxInvoiceDueDt")
    private Date maxInvoiceDueDt;
    @Field("parentFinanceAccountNbr")
    private String parentFinanceAccountNbr;    
    @Field("parentBillingAccountNbr")
    private String parentBillingAccountNbr;
    @Field("billingAccountNbr")
    private String billingAccountNbr;
    @Field("billAccountName")
    private String billAccountName;
    @Field("billLine1Addr")
    private String billLine1Addr;   
    @Field("billLine2Addr")
    private String billLine2Addr;    
    @Field("billCityName")
    private String billCityName;   
    @Field("billCountyName")
    private String billCountyName;    
    @Field("billStateCd")
    private String billStateCd ;    
    @Field("billPostalCd")
    private String billPostalCd;    
    @Field("billCountryName")
    private String billCountryName;    
    @Field("billRedirectInd")
    private String billRedirectInd;    
    @Field("billDispatchCd")
    private String billDispatchCd;    
    @Field("billDispatchTyp")
    private String billDispatchTyp;
    @Field("glCompanyCd")
    private String glCompanyCd;
    @Field("glOperatingCompanyCd")
    private String glOperatingCompanyCd;
    @Field("glOperatingCompanyName")
    private String glOperatingCompanyName;
    @Field("regionCode")
    private String regionCode;
    @Field("invoiceCurrencyCode")
    private String invoiceCurrencyCode;
    @Field("invoiceCurrencyDesc")
    private String invoiceCurrencyDesc;
    @Field("invoiceStatus")
    private String invoiceStatus;
    @Field("invoiceSummaryLevelCd")
    private String invoiceSummaryLevelCd;
    @Field("invoiceSummaryLevelDesc")
    private String invoiceSummaryLevelDesc;
    @Field("paymentMethodTyp")
    private String paymentMethodTyp;
    @Field("functionalCurrency")
    private String functionalCurrency;
    @Field("invoiceFunctCurrencyDesc")
    private String invoiceFunctCurrencyDesc;
    @Field("billCycleCd")
    private String billCycleCd;
    @Field("billEmailAddr")
    private String billEmailAddr;
    @Field("secureInvoiceInd")
    private String secureInvoiceInd;


    
    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFinanceAccountNbr() {
		return financeAccountNbr;
	}


	public void setFinanceAccountNbr(String financeAccountNbr) {
		this.financeAccountNbr = financeAccountNbr;
	}


	public String getLatestInvoiceNbr() {
		return latestInvoiceNbr;
	}

	public void setLatestInvoiceNbr(String latestInvoiceNbr) {
		this.latestInvoiceNbr = latestInvoiceNbr;
	}

	public Date getLatestInvoiceDt() {
		return latestInvoiceDt;
	}

	public void setLatestInvoiceDt(Date latestInvoiceDt) {
		this.latestInvoiceDt = latestInvoiceDt;
	}

	public String getCurrentBalanceAmt() {
		return currentBalanceAmt;
	}

	public void setCurrentBalanceAmt(String currentBalanceAmt) {
		this.currentBalanceAmt = currentBalanceAmt;
	}

	public String getLatestInvoiceAmt() {
		return latestInvoiceAmt;
	}

	public void setLatestInvoiceAmt(String latestInvoiceAmt) {
		this.latestInvoiceAmt = latestInvoiceAmt;
	}

	public Date getLatestInvoiceDueDt() {
		return latestInvoiceDueDt;
	}

	public void setLatestInvoiceDueDt(Date latestInvoiceDueDt) {
		this.latestInvoiceDueDt = latestInvoiceDueDt;
	}

	public String getLatestPaymentNbr() {
		return latestPaymentNbr;
	}

	public void setLatestPaymentNbr(String latestPaymentNbr) {
		this.latestPaymentNbr = latestPaymentNbr;
	}

	public Date getLatestPaymentDt() {
		return latestPaymentDt;
	}

	public void setLatestPaymentDt(Date latestPaymentDt) {
		this.latestPaymentDt = latestPaymentDt;
	}

	public String getLatestPaymentAmt() {
		return latestPaymentAmt;
	}

	public void setLatestPaymentAmt(String latestPaymentAmt) {
		this.latestPaymentAmt = latestPaymentAmt;
	}

	public String getLatestCreditNbr() {
		return latestCreditNbr;
	}

	public void setLatestCreditNbr(String latestCreditNbr) {
		this.latestCreditNbr = latestCreditNbr;
	}

	public Date getLatestCreditDt() {
		return latestCreditDt;
	}

	public void setLatestCreditDt(Date latestCreditDt) {
		this.latestCreditDt = latestCreditDt;
	}

	public String getLatestCreditAmt() {
		return latestCreditAmt;
	}

	public void setLatestCreditAmt(String latestCreditAmt) {
		this.latestCreditAmt = latestCreditAmt;
	}

	public String getLatestDebitNbr() {
		return latestDebitNbr;
	}

	public void setLatestDebitNbr(String latestDebitNbr) {
		this.latestDebitNbr = latestDebitNbr;
	}

	public Date getLatestDebitDt() {
		return latestDebitDt;
	}

	public void setLatestDebitDt(Date latestDebitDt) {
		this.latestDebitDt = latestDebitDt;
	}

	public String getLatestDebitAmt() {
		return latestDebitAmt;
	}

	public void setLatestDebitAmt(String latestDebitAmt) {
		this.latestDebitAmt = latestDebitAmt;
	}

	public Date getMinInvoiceDueDt() {
		return minInvoiceDueDt;
	}

	public void setMinInvoiceDueDt(Date minInvoiceDueDt) {
		this.minInvoiceDueDt = minInvoiceDueDt;
	}

	public Date getMaxInvoiceDueDt() {
		return maxInvoiceDueDt;
	}

	public void setMaxInvoiceDueDt(Date maxInvoiceDueDt) {
		this.maxInvoiceDueDt = maxInvoiceDueDt;
	}

	public String getParentFinanceAccountNbr() {
		return parentFinanceAccountNbr;
	}

	public void setParentFinanceAccountNbr(String parentFinanceAccountNbr) {
		this.parentFinanceAccountNbr = parentFinanceAccountNbr;
	}

	public String getParentBillingAccountNbr() {
		return parentBillingAccountNbr;
	}

	public void setParentBillingAccountNbr(String parentBillingAccountNbr) {
		this.parentBillingAccountNbr = parentBillingAccountNbr;
	}
	
	public String getBillingAccountNbr() {
		return billingAccountNbr;
	}

	public void setBillingAccountNbr(String billingAccountNbr) {
		this.billingAccountNbr = billingAccountNbr;
	}

	public String getBillAccountName() {
		return billAccountName;
	}

	public void setBillAccountName(String billAccountName) {
		this.billAccountName = billAccountName;
	}

	public String getBillLine1Addr() {
		return billLine1Addr;
	}

	public void setBillLine1Addr(String billLine1Addr) {
		this.billLine1Addr = billLine1Addr;
	}

	public String getBillLine2Addr() {
		return billLine2Addr;
	}

	public void setBillLine2Addr(String billLine2Addr) {
		this.billLine2Addr = billLine2Addr;
	}

	public String getBillCityName() {
		return billCityName;
	}

	public void setBillCityName(String billCityName) {
		this.billCityName = billCityName;
	}

	public String getBillCountyName() {
		return billCountyName;
	}

	public void setBillCountyName(String billCountyName) {
		this.billCountyName = billCountyName;
	}

	public String getBillStateCd() {
		return billStateCd;
	}

	public void setBillStateCd(String billStateCd) {
		this.billStateCd = billStateCd;
	}

	public String getBillPostalCd() {
		return billPostalCd;
	}

	public void setBillPostalCd(String billPostalCd) {
		this.billPostalCd = billPostalCd;
	}

	public String getBillCountryName() {
		return billCountryName;
	}

	public void setBillCountryName(String billCountryName) {
		this.billCountryName = billCountryName;
	}

	public String getBillRedirectInd() {
		return billRedirectInd;
	}

	public void setBillRedirectInd(String billRedirectInd) {
		this.billRedirectInd = billRedirectInd;
	}

	public String getBillDispatchCd() {
		return billDispatchCd;
	}

	public void setBillDispatchCd(String billDispatchCd) {
		this.billDispatchCd = billDispatchCd;
	}

	public String getBillDispatchTyp() {
		return billDispatchTyp;
	}

	public void setBillDispatchTyp(String billDispatchTyp) {
		this.billDispatchTyp = billDispatchTyp;
	}

	public String getGlCompanyCd() {
		return glCompanyCd;
	}

	public void setGlCompanyCd(String glCompanyCd) {
		this.glCompanyCd = glCompanyCd;
	}
	
	public String getGlOperatingCompanyCd() {
		return glOperatingCompanyCd;
	}

	public void setGlOperatingCompanyCd(String glOperatingCompanyCd) {
		this.glOperatingCompanyCd = glOperatingCompanyCd;
	}
	
	public String getGlOperatingCompanyName() {
		return glOperatingCompanyName;
	}

	public void setGlOperatingCompanyName(String glOperatingCompanyName) {
		this.glOperatingCompanyName = glOperatingCompanyName;
	}
	
	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getInvoiceCurrencyCode() {
		return invoiceCurrencyCode;
	}

	public void setInvoiceCurrencyCode(String invoiceCurrencyCode) {
		this.invoiceCurrencyCode = invoiceCurrencyCode;
	}
	
	public String getInvoiceCurrencyDesc() {
		return invoiceCurrencyDesc;
	}

	public void setInvoiceCurrencyDesc(String invoiceCurrencyDesc) {
		this.invoiceCurrencyDesc = invoiceCurrencyDesc;
	}
	
	public String getInvoiceStatus() {
		return invoiceStatus;
	}

	public void setInvoiceStatus(String invoiceStatus) {
		this.invoiceStatus = invoiceStatus;
	}
	
	public String getInvoiceSummaryLevelCd() {
		return invoiceSummaryLevelCd;
	}

	public void setInvoiceSummaryLevelCd(String invoiceSummaryLevelCd) {
		this.invoiceSummaryLevelCd = invoiceSummaryLevelCd;
	}

	public String getInvoiceSummaryLevelDesc() {
		return invoiceSummaryLevelDesc;
	}

	public void setInvoiceSummaryLevelDesc(String invoiceSummaryLevelDesc) {
		this.invoiceSummaryLevelDesc = invoiceSummaryLevelDesc;
	}
	
	public String getPaymentMethodTyp() {
		return paymentMethodTyp;
	}

	public void setPaymentMethodTyp(String paymentMethodTyp) {
		this.paymentMethodTyp = paymentMethodTyp;
	}
	
	public String getFunctionalCurrency() {
		return functionalCurrency;
	}

	public void setFunctionalCurrency(String functionalCurrency) {
		this.functionalCurrency = functionalCurrency;
	}
	
	public String getInvoiceFunctCurrencyDesc() {
		return invoiceFunctCurrencyDesc;
	}

	public void setInvoiceFunctCurrencyDesc(String invoiceFunctCurrencyDesc) {
		this.invoiceFunctCurrencyDesc = invoiceFunctCurrencyDesc;

	public String getBillCycleCd() {
		return billCycleCd;
	}

	public void setBillCycleCd(String billCycleCd) {
		this.billCycleCd = billCycleCd;
	}
	
	public String getBillEmailAddr() {
		return billEmailAddr;
	}

	public void setBillEmailAddr(String billEmailAddr) {
		this.billEmailAddr = billEmailAddr;
	}
	
	public String getSecureInvoiceInd() {
		return secureInvoiceInd;
	}

	public void setSecureInvoiceInd(String secureInvoiceInd) {
		this.secureInvoiceInd = secureInvoiceInd;
	}
	
	@Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("Bill [id=");
        builder.append(id);
        builder.append(", financeAccountNbr=");
        builder.append(financeAccountNbr);
        builder.append(", latestInvoiceNbr=");
        builder.append(latestInvoiceNbr);
        builder.append(", latestInvoiceDt=");
        builder.append(latestInvoiceDt);
        builder.append(", currentBalanceAmt=");
        builder.append(currentBalanceAmt);
        builder.append(", latestInvoiceAmt=");
        builder.append(latestInvoiceAmt);
        builder.append(", latestInvoiceDueDt=");
        builder.append(latestInvoiceDueDt);
        builder.append(", latestPaymentNbr=");
        builder.append(latestPaymentNbr);
        builder.append(", latestPaymentDt=");
        builder.append(latestPaymentDt);
        builder.append(", latestPaymentAmt=");
        builder.append(latestPaymentAmt);
        builder.append(", latestCreditNbr=");
        builder.append(latestCreditNbr);
        builder.append(", latestCreditDt=");
        builder.append(latestCreditDt);
        builder.append(", latestCreditAmt=");
        builder.append(latestCreditAmt);
        builder.append(", latestDebitNbr=");
        builder.append(latestDebitNbr);
        builder.append(", latestDebitDt=");
        builder.append(latestDebitDt);
        builder.append(", latestDebitAmt=");
        builder.append(latestDebitAmt);
        builder.append(", minInvoiceDueDt=");
        builder.append(minInvoiceDueDt);
        builder.append(", maxInvoiceDueDt=");
        builder.append(maxInvoiceDueDt);
        builder.append(", parentFinanceAccountNbr=");
        builder.append(parentFinanceAccountNbr);
        builder.append(", parentBillingAccountNbr=");
        builder.append(parentBillingAccountNbr);
        builder.append(", billingAccountNbr=");
        builder.append(billingAccountNbr);
        builder.append(", billAccountName=");
        builder.append(billAccountName);
        builder.append(", billLine1Addr=");
        builder.append(billLine1Addr);
        builder.append(", billLine2Addr=");
        builder.append(billLine2Addr);
        builder.append(", billCityName=");
        builder.append(billCityName);
        builder.append(", billCountyName=");
        builder.append(billCountyName);
        builder.append(", billStateCd=");
        builder.append(billStateCd);
        builder.append(", billPostalCd=");
        builder.append(billPostalCd);
        builder.append(", billCountryName=");
        builder.append(billCountryName);
        builder.append(", billRedirectInd=");
        builder.append(billRedirectInd);
        builder.append(", billDispatchCd=");
        builder.append(billDispatchCd);
        builder.append(", billDispatchTyp=");
        builder.append(billDispatchTyp);
        builder.append(", glCompanyCd=");
        builder.append(glCompanyCd);
        builder.append(", glOperatingCompanyCd=");
        builder.append(glOperatingCompanyCd);		
        builder.append(", glOperatingCompanyName=");
        builder.append(glOperatingCompanyName);
        builder.append(", regionCode=");
        builder.append(regionCode);
        builder.append(", invoiceCurrencyCode=");
        builder.append(invoiceCurrencyCode);
        builder.append(", invoiceCurrencyDesc=");
        builder.append(invoiceCurrencyDesc);
        builder.append(", invoiceStatus=");
        builder.append(invoiceStatus);
        builder.append(", invoiceSummaryLevelCd=");
        builder.append(invoiceSummaryLevelCd);
        builder.append(", invoiceSummaryLevelDesc=");
        builder.append(invoiceSummaryLevelDesc);
        builder.append(", paymentMethodTyp=");
        builder.append(paymentMethodTyp);
        builder.append(", functionalCurrency=");
        builder.append(functionalCurrency);
        builder.append(", invoiceFunctCurrencyDesc=");
        builder.append(invoiceFunctCurrencyDesc);
        builder.append(", billCycleCd=");
        builder.append(billCycleCd);    
        builder.append(", billEmailAddr=");
        builder.append(billEmailAddr); 
        builder.append(", secureInvoiceInd=");
        builder.append(secureInvoiceInd); 
        builder.append("]");
        return builder.toString();
    }

}