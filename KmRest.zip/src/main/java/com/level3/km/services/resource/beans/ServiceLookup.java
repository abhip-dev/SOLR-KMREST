package com.level3.km.services.resource.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "serviceLookup")
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceLookup {
    @Field("id")
    private String id;

    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;

    @Field("customerNumber")
    private String customerNumber;

    @Field("customerName")
    private String customerName;

    @Field("endCustomerNumber")
    private String endCustomerNumber;

    @Field("endCustomerName")
    private String endCustomerName;

    @Field("thirdPartyCustomerNumber")
    private String thirdPartyCustomerNumber;

    @Field("thirdPartyCustomerName")
    private String thirdPartyCustomerName;

    @Field("customerOrderNumber")
    private String customerOrderNumber;

    @Field("serviceOrderNumber")
    private String serviceOrderNumber;

    @Field("productInstanceId")
    private String productInstanceId;

    @Field("serviceComponentId")
    private String serviceComponentId;

    @Field("productName")
    private String productName;

    @Field("productCode")
    private String productCode;

    @Field("serviceComponentProductName")
    private String serviceComponentProductName;

    @Field("serviceComponentProductCode")
    private String serviceComponentProductCode;

    @Field("billStartDate")
    private Date billStartDate;

    @Field("customerRequestDate")
    private Date customerRequestDate;

    @Field("usdTotalMrcAmount")
    private Double usdTotalMrcAmount;

    @Field("serviceOrderType")
    private String serviceOrderType;

    @Field("serviceOrderStatusCode")
    private String serviceOrderStatusCode;

    @Field("serviceOrderActionType")
    private String serviceOrderActionType;

    @Field("gatewayName")
    private String gatewayName;

    @Field("customerOrderCreateDate")
    private Date customerOrderCreateDate;

    @Field("serviceLocationAddress")
    private String serviceLocationAddress;

    @Field("serviceLocationName")
    private String serviceLocationName;

    @Field("serviceInstanceId")
    private String serviceInstanceId;

    @Field("activeIndicator")
    private String activeIndicator;

    @Field("serviceOrderSequenceNumber")
    private String serviceOrderSequenceNumber;

    @Field("onnetIndicator")
    private String onnetIndicator;

    @Field("customerCircuitId")
    private String customerCircuitId;

    @Field("serviceInstallDate")
    private Date serviceInstallDate;

    @Field("tspCode")
    private String tspCode;

    @Field("sourceCustomerNumber")
    private String sourceCustomerNumber;

    @Field("diversityTrailName")
    private String diversityTrailName;

    @Field("diversitySecondTrailName")
    private String diversitySecondTrailName;

    @Field("bandwidthCode")
    private String bandwidthCode;

    @Field("subBandwidthCode")
    private String subBandwidthCode;

    @Field("aEndClliCode")
    private String aEndClliCode;

    @Field("zEndClliCode")
    private String zEndClliCode;

    @Field("legacyBillAccountNumber")
    private String legacyBillAccountNumber;

    @Field("legacyLastServiceOrderNumber")
    private String legacyLastServiceOrderNumber;

    @Field("legacySourceSystemCode")
    private String legacySourceSystemCode;

    @Field("legacyCircuitId")
    private String legacyCircuitId;

    @Field("customerPurchaseOrderNumber")
    private String customerPurchaseOrderNumber;

    @Field("associatedOrderNumber")
    private String associatedOrderNumber;

    @Field("latencyGuranteeLevelType")
    private String latencyGuranteeLevelType;

    @Field("latencyGuranteeValue")
    private Long latencyGuranteeValue;

    @Field("latencyActualValue")
    private Long latencyActualValue;

    @Field("ipVersionCode")
    private String ipVersionCode;

    @Field("equipmentConfigDescription")
    private String equipmentConfigDescription;

    @Field("equipmentManufacturerName")
    private String equipmentManufacturerName;

    @Field("equipmentServiceProviderName")
    private String equipmentServiceProviderName;

    @Field("equipmentMaintAgreementType")
    private String equipmentMaintAgreementType;

    @Field("cnrJeopIndicator")
    private Boolean cnrJeopIndicator;

    @Field("cnrJeopRaisedDate")
    private Date cnrJeopRaisedDate;

    @Field("bundledServiceIndicator")
    private Boolean bundledServiceIndicator;

    @Field("ultimateServiceStatusCode")
    private String ultimateServiceStatusCode;

    @Field("billAccountNumber")
    private String billAccountNumber;

    @Field("parentBillAccountNumber")
    private String parentBillAccountNumber;

    @Field("activeBillIndicator")
    private Boolean activeBillIndicator;

    @Field("enableAutoTicketIndicator")
    private Boolean enableAutoTicketIndicator;

    @Field("protectType")
    private String protectType;

    @Field("serviceLocationId")
    private Long serviceLocationId;

    @Field("specialsId")
    private String specialsId;

    @Field("sidActiveBillIndicator")
    private Boolean sidActiveBillIndicator;

    @Field("scidActiveBillIndicator")
    private Boolean scidActiveBillIndicator;

    @Field("piidActiveBillIndicator")
    private Boolean piidActiveBillIndicator;

    @Field("pcsidActiveBillIndicator")
    private Boolean pcsidActiveBillIndicator;

    @Field("componentSubTypeName")
    private String componentSubTypeName;

    @Field("billAccountName")
    private String billAccountName;

    @Field("serviceClassLevelType")
    private String serviceClassLevelType;

    @Field("circuitId")
    private String circuitId;

    @Field("serviceId")
    private String serviceId;

    @Field("aLine1Address")
    private String aLine1Address;

    @Field("aLine2Address")
    private String aLine2Address;

    @Field("aCityName")
    private String aCityName;

    @Field("aStateCode")
    private String aStateCode;

    @Field("aPostalCode")
    private String aPostalCode;

    @Field("aCountyName")
    private String aCountyName;

    @Field("aCountryName")
    private String aCountryName;

    @Field("aLatitudeNumber")
    private Double aLatitudeNumber;

    @Field("aLongitudeNumber")
    private Double aLongitudeNumber;

    @Field("zLine1Address")
    private String zLine1Address;

    @Field("zLine2Address")
    private String zLine2Address;

    @Field("zCityName")
    private String zCityName;

    @Field("zStateCode")
    private String zStateCode;

    @Field("zPostalCode")
    private String zPostalCode;

    @Field("zCountyName")
    private String zCountyName;

    @Field("zCountryName")
    private String zCountryName;

    @Field("zLatitudeNumber")
    private Double zLatitudeNumber;

    @Field("zLongitudeNumber")
    private Double zLongitudeNumber;

    @Field("aLocationId")
    private String aLocationId;

    @Field("zLocationId")
    private String zLocationId;

    @Field("aLocationName")
    private String aLocationName;

    @Field("zLocationName")
    private String zLocationName;

    @Field("aTimezoneName")
    private String aTimezoneName;

    @Field("zTimezoneName")
    private String zTimezoneName;

    @Field("aDokuvizId")
    private String aDokuvizId;

    @Field("zDokuvizId")
    private String zDokuvizId;

    @Field("aLocationNumber")
    private Long aLocationNumber;

    @Field("zLocationNumber")
    private Long zLocationNumber;

    @Field("aRegionCode")
    private String aRegionCode;

    @Field("zRegionCode")
    private String zRegionCode;

    @Field("vpnId")
    private String vpnId;

    @Field("ticketingProductName")
    private String ticketingProductName;

    @Field("ticketingProductFamilyName")
    private String ticketingProductFamilyName;

    @Field("ticketingParentServiceId")
    private String ticketingParentServiceId;

    @Field("classOfServiceClassType")
    private String classOfServiceClassType;

    @Field("classOfServiceAllocationType")
    private String classOfServiceAllocationType;

    @Field("multiServiceAllocationType")
    private String multiServiceAllocationType;

    @Field("committedDataRateMbps")
    private Double committedDataRateMbps;

    @Field("peakInformationRateMbps")
    private Double peakInformationRateMbps;

    @Field("parentCircuitServiceId")
    private String parentCircuitServiceId;

    @Field("relatedServiceInstanceIdLevel1")
    private List<String> relatedServiceInstanceIdLevel1;

    @Field("relatedServiceInstanceIdLevel2")
    private List<String> relatedServiceInstanceIdLevel2;

    @Field("relatedServiceInstanceIdLevel3")
    private List<String> relatedServiceInstanceIdLevel3;

    @Field("relatedServiceInstanceIdLevel4")
    private List<String> relatedServiceInstanceIdLevel4;

    @Field("relatedServiceInstanceIdLevel5")
    private List<String> relatedServiceInstanceIdLevel5;

    @Field("cpeDeviceName")
    private String cpeDeviceName;

    @Field("orderProductInstanceId")
    private String orderProductInstanceId;

    @Field("orderServiceComponentId")
    private String orderServiceComponentId;

    @Field("equipmentSerialNumber")
    private String equipmentSerialNumber;

 // added column diverseRoleType and billType as per US272260
    
    @Field("diverseRoleType")
    private String diverseRoleType;
    
    @Field("billType")
    private String billType;
    
    @Field("vendorName")
    private String vendorName;
    
	@Field("vendorCircuitId")
    private String vendorCircuitId;
	
    @Field("primaryControllerName")
    private String primaryControllerName;
    
    @Field("primaryDirectorName")
    private String primaryDirectorName;
    
    @Field("servicePropertyListTxt")
    private String servicePropertyListTxt;
    
    @Field("serviceMgmtTyp")
    private String serviceMgmtTyp;
    
    @Field("financeAccountNbr")
    private String financeAccountNbr;
    
    @Field("orderSourceSystemName")
    private String orderSourceSystemName;
    
    @Field("billAcctSourceSystemCd")
    private String billAcctSourceSystemCd;
    
    public String getDwSourceSystemCode() {
	return dwSourceSystemCode;
    }

    public void setDwSourceSystemCode(String dwSourceSystemCode) {
	this.dwSourceSystemCode = dwSourceSystemCode;
    }

    public String getCustomerNumber() {
	return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
	this.customerNumber = customerNumber;
    }

    public String getCustomerName() {
	return customerName;
    }

    public void setCustomerName(String customerName) {
	this.customerName = customerName;
    }

    public String getEndCustomerNumber() {
	return endCustomerNumber;
    }

    public void setEndCustomerNumber(String endCustomerNumber) {
	this.endCustomerNumber = endCustomerNumber;
    }

    public String getEndCustomerName() {
	return endCustomerName;
    }

    public void setEndCustomerName(String endCustomerName) {
	this.endCustomerName = endCustomerName;
    }

    public String getCustomerOrderNumber() {
	return customerOrderNumber;
    }

    public void setCustomerOrderNumber(String customerOrderNumber) {
	this.customerOrderNumber = customerOrderNumber;
    }

    public String getServiceOrderNumber() {
	return serviceOrderNumber;
    }

    public void setServiceOrderNumber(String serviceOrderNumber) {
	this.serviceOrderNumber = serviceOrderNumber;
    }

    public String getProductInstanceId() {
	return productInstanceId;
    }

    public void setProductInstanceId(String productInstanceId) {
	this.productInstanceId = productInstanceId;
    }

    public String getServiceComponentId() {
	return serviceComponentId;
    }

    public void setServiceComponentId(String serviceComponentId) {
	this.serviceComponentId = serviceComponentId;
    }

    public String getProductName() {
	return productName;
    }

    public void setProductName(String productName) {
	this.productName = productName;
    }

    public String getProductCode() {
	return productCode;
    }

    public void setProductCode(String productCode) {
	this.productCode = productCode;
    }

    public String getServiceComponentProductName() {
	return serviceComponentProductName;
    }

    public void setServiceComponentProductName(String serviceComponentProductName) {
	this.serviceComponentProductName = serviceComponentProductName;
    }

    public String getServiceComponentProductCode() {
	return serviceComponentProductCode;
    }

    public void setServiceComponentProductCode(String serviceComponentProductCode) {
	this.serviceComponentProductCode = serviceComponentProductCode;
    }

    public Date getBillStartDate() {
	return billStartDate;
    }

    public void setBillStartDate(Date billStartDate) {
	this.billStartDate = billStartDate;
    }

    public Date getCustomerRequestDate() {
	return customerRequestDate;
    }

    public void setCustomerRequestDate(Date customerRequestDate) {
	this.customerRequestDate = customerRequestDate;
    }

    public Double getUsdTotalMrcAmount() {
	return usdTotalMrcAmount;
    }

    public void setUsdTotalMrcAmount(Double usdTotalMrcAmount) {
	this.usdTotalMrcAmount = usdTotalMrcAmount;
    }

    public String getServiceOrderType() {
	return serviceOrderType;
    }

    public void setServiceOrderType(String serviceOrderType) {
	this.serviceOrderType = serviceOrderType;
    }

    public String getServiceOrderStatusCode() {
	return serviceOrderStatusCode;
    }

    public void setServiceOrderStatusCode(String serviceOrderStatusCode) {
	this.serviceOrderStatusCode = serviceOrderStatusCode;
    }

    public String getServiceOrderActionType() {
	return serviceOrderActionType;
    }

    public void setServiceOrderActionType(String serviceOrderActionType) {
	this.serviceOrderActionType = serviceOrderActionType;
    }

    public String getGatewayName() {
	return gatewayName;
    }

    public void setGatewayName(String gatewayName) {
	this.gatewayName = gatewayName;
    }

    public Date getCustomerOrderCreateDate() {
	return customerOrderCreateDate;
    }

    public void setCustomerOrderCreateDate(Date customerOrderCreateDate) {
	this.customerOrderCreateDate = customerOrderCreateDate;
    }

    public String getServiceLocationAddress() {
	return serviceLocationAddress;
    }

    public void setServiceLocationAddress(String serviceLocationAddress) {
	this.serviceLocationAddress = serviceLocationAddress;
    }

    public String getServiceLocationName() {
	return serviceLocationName;
    }

    public void setServiceLocationName(String serviceLocationName) {
	this.serviceLocationName = serviceLocationName;
    }

    public String getServiceInstanceId() {
	return serviceInstanceId;
    }

    public void setServiceInstanceId(String serviceInstanceId) {
	this.serviceInstanceId = serviceInstanceId;
    }

    public String getActiveIndicator() {
	return activeIndicator;
    }

    public void setActiveIndicator(String activeIndicator) {
	this.activeIndicator = activeIndicator;
    }

    public String getServiceOrderSequenceNumber() {
	return serviceOrderSequenceNumber;
    }

    public void setServiceOrderSequenceNumber(String serviceOrderSequenceNumber) {
	this.serviceOrderSequenceNumber = serviceOrderSequenceNumber;
    }

    public String getOnnetIndicator() {
	return onnetIndicator;
    }

    public void setOnnetIndicator(String onnetIndicator) {
	this.onnetIndicator = onnetIndicator;
    }

    public String getCustomerCircuitId() {
	return customerCircuitId;
    }

    public void setCustomerCircuitId(String customerCircuitId) {
	this.customerCircuitId = customerCircuitId;
    }

    public Date getServiceInstallDate() {
	return serviceInstallDate;
    }

    public void setServiceInstallDate(Date serviceInstallDate) {
	this.serviceInstallDate = serviceInstallDate;
    }

    public String getTspCode() {
	return tspCode;
    }

    public void setTspCode(String tspCode) {
	this.tspCode = tspCode;
    }

    public String getSourceCustomerNumber() {
	return sourceCustomerNumber;
    }

    public void setSourceCustomerNumber(String sourceCustomerNumber) {
	this.sourceCustomerNumber = sourceCustomerNumber;
    }

    public String getDiversityTrailName() {
	return diversityTrailName;
    }

    public void setDiversityTrailName(String diversityTrailName) {
	this.diversityTrailName = diversityTrailName;
    }

    public String getDiversitySecondTrailName() {
	return diversitySecondTrailName;
    }

    public void setDiversitySecondTrailName(String diversitySecondTrailName) {
	this.diversitySecondTrailName = diversitySecondTrailName;
    }

    public String getBandwidthCode() {
	return bandwidthCode;
    }

    public void setBandwidthCode(String bandwidthCode) {
	this.bandwidthCode = bandwidthCode;
    }

    public String getSubBandwidthCode() {
	return subBandwidthCode;
    }

    public void setSubBandwidthCode(String subBandwidthCode) {
	this.subBandwidthCode = subBandwidthCode;
    }

    public String getaEndClliCode() {
	return aEndClliCode;
    }

    public void setaEndClliCode(String aEndClliCode) {
	this.aEndClliCode = aEndClliCode;
    }

    public String getzEndClliCode() {
	return zEndClliCode;
    }

    public void setzEndClliCode(String zEndClliCode) {
	this.zEndClliCode = zEndClliCode;
    }

    public String getLegacyBillAccountNumber() {
	return legacyBillAccountNumber;
    }

    public void setLegacyBillAccountNumber(String legacyBillAccountNumber) {
	this.legacyBillAccountNumber = legacyBillAccountNumber;
    }

    public String getLegacyLastServiceOrderNumber() {
	return legacyLastServiceOrderNumber;
    }

    public void setLegacyLastServiceOrderNumber(String legacyLastServiceOrderNumber) {
	this.legacyLastServiceOrderNumber = legacyLastServiceOrderNumber;
    }

    public String getLegacySourceSystemCode() {
	return legacySourceSystemCode;
    }

    public void setLegacySourceSystemCode(String legacySourceSystemCode) {
	this.legacySourceSystemCode = legacySourceSystemCode;
    }

    public String getLegacyCircuitId() {
	return legacyCircuitId;
    }

    public void setLegacyCircuitId(String legacyCircuitId) {
	this.legacyCircuitId = legacyCircuitId;
    }

    public String getCustomerPurchaseOrderNumber() {
	return customerPurchaseOrderNumber;
    }

    public void setCustomerPurchaseOrderNumber(String customerPurchaseOrderNumber) {
	this.customerPurchaseOrderNumber = customerPurchaseOrderNumber;
    }

    public String getAssociatedOrderNumber() {
	return associatedOrderNumber;
    }

    public void setAssociatedOrderNumber(String associatedOrderNumber) {
	this.associatedOrderNumber = associatedOrderNumber;
    }

    public String getLatencyGuranteeLevelType() {
	return latencyGuranteeLevelType;
    }

    public void setLatencyGuranteeLevelType(String latencyGuranteeLevelType) {
	this.latencyGuranteeLevelType = latencyGuranteeLevelType;
    }

    public Long getLatencyGuranteeValue() {
	return latencyGuranteeValue;
    }

    public void setLatencyGuranteeValue(Long latencyGuranteeValue) {
	this.latencyGuranteeValue = latencyGuranteeValue;
    }

    public Long getLatencyActualValue() {
	return latencyActualValue;
    }

    public void setLatencyActualValue(Long latencyActualValue) {
	this.latencyActualValue = latencyActualValue;
    }

    public String getIpVersionCode() {
	return ipVersionCode;
    }

    public void setIpVersionCode(String ipVersionCode) {
	this.ipVersionCode = ipVersionCode;
    }

    public String getEquipmentConfigDescription() {
	return equipmentConfigDescription;
    }

    public void setEquipmentConfigDescription(String equipmentConfigDescription) {
	this.equipmentConfigDescription = equipmentConfigDescription;
    }

    public String getEquipmentManufacturerName() {
	return equipmentManufacturerName;
    }

    public void setEquipmentManufacturerName(String equipmentManufacturerName) {
	this.equipmentManufacturerName = equipmentManufacturerName;
    }

    public String getEquipmentServiceProviderName() {
	return equipmentServiceProviderName;
    }

    public void setEquipmentServiceProviderName(String equipmentServiceProviderName) {
	this.equipmentServiceProviderName = equipmentServiceProviderName;
    }

    public String getEquipmentMaintAgreementType() {
	return equipmentMaintAgreementType;
    }

    public void setEquipmentMaintAgreementType(String equipmentMaintAgreementType) {
	this.equipmentMaintAgreementType = equipmentMaintAgreementType;
    }

    public Boolean getCnrJeopIndicator() {
	return cnrJeopIndicator;
    }

    public void setCnrJeopIndicator(Boolean cnrJeopIndicator) {
	this.cnrJeopIndicator = cnrJeopIndicator;
    }

    public Date getCnrJeopRaisedDate() {
	return cnrJeopRaisedDate;
    }

    public void setCnrJeopRaisedDate(Date cnrJeopRaisedDate) {
	this.cnrJeopRaisedDate = cnrJeopRaisedDate;
    }

    public Boolean getBundledServiceIndicator() {
	return bundledServiceIndicator;
    }

    public void setBundledServiceIndicator(Boolean bundledServiceIndicator) {
	this.bundledServiceIndicator = bundledServiceIndicator;
    }

    public String getUltimateServiceStatusCode() {
	return ultimateServiceStatusCode;
    }

    public void setUltimateServiceStatusCode(String ultimateServiceStatusCode) {
	this.ultimateServiceStatusCode = ultimateServiceStatusCode;
    }

    public String getBillAccountNumber() {
	return billAccountNumber;
    }

    public void setBillAccountNumber(String billAccountNumber) {
	this.billAccountNumber = billAccountNumber;
    }

    public String getParentBillAccountNumber() {
	return parentBillAccountNumber;
    }

    public void setParentBillAccountNumber(String parentBillAccountNumber) {
	this.parentBillAccountNumber = parentBillAccountNumber;
    }

    public Boolean getActiveBillIndicator() {
	return activeBillIndicator;
    }

    public void setActiveBillIndicator(Boolean activeBillIndicator) {
	this.activeBillIndicator = activeBillIndicator;
    }

    public Boolean getEnableAutoTicketIndicator() {
	return enableAutoTicketIndicator;
    }

    public void setEnableAutoTicketIndicator(Boolean enableAutoTicketIndicator) {
	this.enableAutoTicketIndicator = enableAutoTicketIndicator;
    }

    public String getProtectType() {
	return protectType;
    }

    public void setProtectType(String protectType) {
	this.protectType = protectType;
    }

    public Long getServiceLocationId() {
	return serviceLocationId;
    }

    public void setServiceLocationId(Long serviceLocationId) {
	this.serviceLocationId = serviceLocationId;
    }

    public String getSpecialsId() {
	return specialsId;
    }

    public void setSpecialsId(String specialsId) {
	this.specialsId = specialsId;
    }

    public Boolean getSidActiveBillIndicator() {
	return sidActiveBillIndicator;
    }

    public void setSidActiveBillIndicator(Boolean sidActiveBillIndicator) {
	this.sidActiveBillIndicator = sidActiveBillIndicator;
    }

    public Boolean getScidActiveBillIndicator() {
	return scidActiveBillIndicator;
    }

    public void setScidActiveBillIndicator(Boolean scidActiveBillIndicator) {
	this.scidActiveBillIndicator = scidActiveBillIndicator;
    }

    public Boolean getPiidActiveBillIndicator() {
	return piidActiveBillIndicator;
    }

    public void setPiidActiveBillIndicator(Boolean piidActiveBillIndicator) {
	this.piidActiveBillIndicator = piidActiveBillIndicator;
    }

    public Boolean getPcsidActiveBillIndicator() {
	return pcsidActiveBillIndicator;
    }

    public void setPcsidActiveBillIndicator(Boolean pcsidActiveBillIndicator) {
	this.pcsidActiveBillIndicator = pcsidActiveBillIndicator;
    }

    public String getComponentSubTypeName() {
	return componentSubTypeName;
    }

    public void setComponentSubTypeName(String componentSubTypeName) {
	this.componentSubTypeName = componentSubTypeName;
    }

    public String getBillAccountName() {
	return billAccountName;
    }

    public void setBillAccountName(String billAccountName) {
	this.billAccountName = billAccountName;
    }

    public String getServiceClassLevelType() {
	return serviceClassLevelType;
    }

    public void setServiceClassLevelType(String serviceClassLevelType) {
	this.serviceClassLevelType = serviceClassLevelType;
    }

    public String getCircuitId() {
	return circuitId;
    }

    public void setCircuitId(String circuitId) {
	this.circuitId = circuitId;
    }

    public String getServiceId() {
	return serviceId;
    }

    public void setServiceId(String serviceId) {
	this.serviceId = serviceId;
    }

    public String getaLine1Address() {
	return aLine1Address;
    }

    public void setaLine1Address(String aLine1Address) {
	this.aLine1Address = aLine1Address;
    }

    public String getaLine2Address() {
	return aLine2Address;
    }

    public void setaLine2Address(String aLine2Address) {
	this.aLine2Address = aLine2Address;
    }

    public String getaCityName() {
	return aCityName;
    }

    public void setaCityName(String aCityName) {
	this.aCityName = aCityName;
    }

    public String getaStateCode() {
	return aStateCode;
    }

    public void setaStateCode(String aStateCode) {
	this.aStateCode = aStateCode;
    }

    public String getaPostalCode() {
	return aPostalCode;
    }

    public void setaPostalCode(String aPostalCode) {
	this.aPostalCode = aPostalCode;
    }

    public String getaCountyName() {
	return aCountyName;
    }

    public void setaCountyName(String aCountyName) {
	this.aCountyName = aCountyName;
    }

    public String getaCountryName() {
	return aCountryName;
    }

    public void setaCountryName(String aCountryName) {
	this.aCountryName = aCountryName;
    }

    public Double getaLatitudeNumber() {
	return aLatitudeNumber;
    }

    public void setaLatitudeNumber(Double aLatitudeNumber) {
	this.aLatitudeNumber = aLatitudeNumber;
    }

    public Double getaLongitudeNumber() {
	return aLongitudeNumber;
    }

    public void setaLongitudeNumber(Double aLongitudeNumber) {
	this.aLongitudeNumber = aLongitudeNumber;
    }

    public String getzLine1Address() {
	return zLine1Address;
    }

    public void setzLine1Address(String zLine1Address) {
	this.zLine1Address = zLine1Address;
    }

    public String getzLine2Address() {
	return zLine2Address;
    }

    public void setzLine2Address(String zLine2Address) {
	this.zLine2Address = zLine2Address;
    }

    public String getzCityName() {
	return zCityName;
    }

    public void setzCityName(String zCityName) {
	this.zCityName = zCityName;
    }

    public String getzStateCode() {
	return zStateCode;
    }

    public void setzStateCode(String zStateCode) {
	this.zStateCode = zStateCode;
    }

    public String getzPostalCode() {
	return zPostalCode;
    }

    public void setzPostalCode(String zPostalCode) {
	this.zPostalCode = zPostalCode;
    }

    public String getzCountyName() {
	return zCountyName;
    }

    public void setzCountyName(String zCountyName) {
	this.zCountyName = zCountyName;
    }

    public String getzCountryName() {
	return zCountryName;
    }

    public void setzCountryName(String zCountryName) {
	this.zCountryName = zCountryName;
    }

    public Double getzLatitudeNumber() {
	return zLatitudeNumber;
    }

    public void setzLatitudeNumber(Double zLatitudeNumber) {
	this.zLatitudeNumber = zLatitudeNumber;
    }

    public Double getzLongitudeNumber() {
	return zLongitudeNumber;
    }

    public void setzLongitudeNumber(Double zLongitudeNumber) {
	this.zLongitudeNumber = zLongitudeNumber;
    }

    public String getaLocationId() {
	return aLocationId;
    }

    public void setaLocationId(String aLocationId) {
	this.aLocationId = aLocationId;
    }

    public String getzLocationId() {
	return zLocationId;
    }

    public void setzLocationId(String zLocationId) {
	this.zLocationId = zLocationId;
    }

    public String getaLocationName() {
	return aLocationName;
    }

    public void setaLocationName(String aLocationName) {
	this.aLocationName = aLocationName;
    }

    public String getzLocationName() {
	return zLocationName;
    }

    public void setzLocationName(String zLocationName) {
	this.zLocationName = zLocationName;
    }

    public String getaTimezoneName() {
	return aTimezoneName;
    }

    public void setaTimezoneName(String aTimezoneName) {
	this.aTimezoneName = aTimezoneName;
    }

    public String getzTimezoneName() {
	return zTimezoneName;
    }

    public void setzTimezoneName(String zTimezoneName) {
	this.zTimezoneName = zTimezoneName;
    }

    public String getaDokuvizId() {
	return aDokuvizId;
    }

    public void setaDokuvizId(String aDokuvizId) {
	this.aDokuvizId = aDokuvizId;
    }

    public String getzDokuvizId() {
	return zDokuvizId;
    }

    public void setzDokuvizId(String zDokuvizId) {
	this.zDokuvizId = zDokuvizId;
    }

    public Long getaLocationNumber() {
	return aLocationNumber;
    }

    public void setaLocationNumber(Long aLocationNumber) {
	this.aLocationNumber = aLocationNumber;
    }

    public Long getzLocationNumber() {
	return zLocationNumber;
    }

    public void setzLocationNumber(Long zLocationNumber) {
	this.zLocationNumber = zLocationNumber;
    }

    public String getaRegionCode() {
	return aRegionCode;
    }

    public void setaRegionCode(String aRegionCode) {
	this.aRegionCode = aRegionCode;
    }

    public String getzRegionCode() {
	return zRegionCode;
    }

    public void setzRegionCode(String zRegionCode) {
	this.zRegionCode = zRegionCode;
    }

    public List<String> getRelatedServiceInstanceIdLevel1() {
	return relatedServiceInstanceIdLevel1;
    }

    public void setRelatedServiceInstanceIdLevel1(List<String> relatedServiceInstanceIdLevel1) {
	this.relatedServiceInstanceIdLevel1 = relatedServiceInstanceIdLevel1;
    }

    public List<String> getRelatedServiceInstanceIdLevel2() {
	return relatedServiceInstanceIdLevel2;
    }

    public void setRelatedServiceInstanceIdLevel2(List<String> relatedServiceInstanceIdLevel2) {
	this.relatedServiceInstanceIdLevel2 = relatedServiceInstanceIdLevel2;
    }

    public List<String> getRelatedServiceInstanceIdLevel3() {
	return relatedServiceInstanceIdLevel3;
    }

    public void setRelatedServiceInstanceIdLevel3(List<String> relatedServiceInstanceIdLevel3) {
	this.relatedServiceInstanceIdLevel3 = relatedServiceInstanceIdLevel3;
    }

    public List<String> getRelatedServiceInstanceIdLevel4() {
	return relatedServiceInstanceIdLevel4;
    }

    public void setRelatedServiceInstanceIdLevel4(List<String> relatedServiceInstanceIdLevel4) {
	this.relatedServiceInstanceIdLevel4 = relatedServiceInstanceIdLevel4;
    }

    public List<String> getRelatedServiceInstanceIdLevel5() {
	return relatedServiceInstanceIdLevel5;
    }

    public void setRelatedServiceInstanceIdLevel5(List<String> relatedServiceInstanceIdLevel5) {
	this.relatedServiceInstanceIdLevel5 = relatedServiceInstanceIdLevel5;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getThirdPartyCustomerNumber() {
	return thirdPartyCustomerNumber;
    }

    public void setThirdPartyCustomerNumber(String thirdPartyCustomerNumber) {
	this.thirdPartyCustomerNumber = thirdPartyCustomerNumber;
    }

    public String getThirdPartyCustomerName() {
	return thirdPartyCustomerName;
    }

    public void setThirdPartyCustomerName(String thirdPartyCustomerName) {
	this.thirdPartyCustomerName = thirdPartyCustomerName;
    }

    public String getCpeDeviceName() {
	return cpeDeviceName;
    }

    public void setCpeDeviceName(String cpeDeviceName) {
	this.cpeDeviceName = cpeDeviceName;
    }

    public String getVpnId() {
	return vpnId;
    }

    public void setVpnId(String vpnId) {
	this.vpnId = vpnId;
    }

    public String getTicketingProductName() {
	return ticketingProductName;
    }

    public void setTicketingProductName(String ticketingProductName) {
	this.ticketingProductName = ticketingProductName;
    }

    public String getTicketingProductFamilyName() {
	return ticketingProductFamilyName;
    }

    public void setTicketingProductFamilyName(String ticketingProductFamilyName) {
	this.ticketingProductFamilyName = ticketingProductFamilyName;
    }

    public String getTicketingParentServiceId() {
	return ticketingParentServiceId;
    }

    public void setTicketingParentServiceId(String ticketingParentServiceId) {
	this.ticketingParentServiceId = ticketingParentServiceId;
    }

    public String getClassOfServiceClassType() {
	return classOfServiceClassType;
    }

    public void setClassOfServiceClassType(String classOfServiceClassType) {
	this.classOfServiceClassType = classOfServiceClassType;
    }

    public String getClassOfServiceAllocationType() {
	return classOfServiceAllocationType;
    }

    public void setClassOfServiceAllocationType(String classOfServiceAllocationType) {
	this.classOfServiceAllocationType = classOfServiceAllocationType;
    }

    public String getMultiServiceAllocationType() {
	return multiServiceAllocationType;
    }

    public void setMultiServiceAllocationType(String multiServiceAllocationType) {
	this.multiServiceAllocationType = multiServiceAllocationType;
    }

    public Double getCommittedDataRateMbps() {
	return committedDataRateMbps;
    }

    public void setCommittedDataRateMbps(Double committedDataRateMbps) {
	this.committedDataRateMbps = committedDataRateMbps;
    }

    public Double getPeakInformationRateMbps() {
	return peakInformationRateMbps;
    }

    public void setPeakInformationRateMbps(Double peakInformationRateMbps) {
	this.peakInformationRateMbps = peakInformationRateMbps;
    }

    public String getParentCircuitServiceId() {
	return parentCircuitServiceId;
    }

    public void setParentCircuitServiceId(String parentCircuitServiceId) {
	this.parentCircuitServiceId = parentCircuitServiceId;
    }

    public String getOrderProductInstanceId()
    {
        return orderProductInstanceId;
    }

    public void setOrderProductInstanceId(String orderProductInstanceId)
    {
        this.orderProductInstanceId = orderProductInstanceId;
    }

    public String getOrderServiceComponentId()
    {
        return orderServiceComponentId;
    }

    public void setOrderServiceComponentId(String orderServiceComponentId)
    {
        this.orderServiceComponentId = orderServiceComponentId;
    }

    public String getEquipmentSerialNumber()
    {
        return equipmentSerialNumber;
    }

    public void setEquipmentSerialNumber(String equipmentSerialNumber)
    {
        this.equipmentSerialNumber = equipmentSerialNumber;
    }
    
    public String getDiverseRoleType()
    {
        return diverseRoleType;
    }

    public void setDiverseRoleType(String diverseRoleType)
    {
        this.diverseRoleType = diverseRoleType;
    }
    public String getBillType()
    {
        return billType;
    }

    public void setBillType(String billType)
    {
        this.billType = billType;
    }
    
	public String getVendorName()
    {
        return vendorName;
    }

    public void setVendorName(String vendorName)
    {
        this.vendorName = vendorName;
    }
    public String getVendorCircuitId()
    {
        return vendorCircuitId;
    }

    public void setVendorCircuitId(String vendorCircuitId)
    {
        this.vendorCircuitId = vendorCircuitId;
    }
    public String getPrimaryControllerName()
    {
        return primaryControllerName;
    }

    public void setPrimaryControllerName(String primaryControllerName)
    {
        this.primaryControllerName = primaryControllerName;
    }
    public String getPrimaryDirectorName()
    {
        return primaryDirectorName;
    }

    public void setPrimaryDirectorName(String primaryDirectorName)
    {
        this.primaryDirectorName = primaryDirectorName;
    }
    public String getServicePropertyListTxt()
    {
        return servicePropertyListTxt;
    }

    public void setServicePropertyListTxt(String servicePropertyListTxt)
    {
        this.servicePropertyListTxt = servicePropertyListTxt;
    }
    public String getServiceMgmtTyp()
    {
        return serviceMgmtTyp;
    }

    public void setServiceMgmtTyp(String serviceMgmtTyp)
    {
        this.serviceMgmtTyp = serviceMgmtTyp;
    }
    public String getFinanceAccountNbr()
    {
        return financeAccountNbr;
    }

    public void setFinanceAccountNbr(String financeAccountNbr)
    {
        this.financeAccountNbr = financeAccountNbr;
    }
    public String getOrderSourceSystemName()
    {
        return orderSourceSystemName;
    }

    public void setOrderSourceSystemName(String orderSourceSystemName)
    {
        this.orderSourceSystemName = orderSourceSystemName;
    }
    public String getBillAcctSourceSystemCd()
    {
        return billAcctSourceSystemCd;
    }

    public void setBillAcctSourceSystemCd(String billAcctSourceSystemCd)
    {
        this.billAcctSourceSystemCd = billAcctSourceSystemCd;
    }
	
    

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ServiceLookup [id=");
        builder.append(id);
        builder.append(", dwSourceSystemCode=");
        builder.append(dwSourceSystemCode);
        builder.append(", customerNumber=");
        builder.append(customerNumber);
        builder.append(", customerName=");
        builder.append(customerName);
        builder.append(", endCustomerNumber=");
        builder.append(endCustomerNumber);
        builder.append(", endCustomerName=");
        builder.append(endCustomerName);
        builder.append(", thirdPartyCustomerNumber=");
        builder.append(thirdPartyCustomerNumber);
        builder.append(", thirdPartyCustomerName=");
        builder.append(thirdPartyCustomerName);
        builder.append(", customerOrderNumber=");
        builder.append(customerOrderNumber);
        builder.append(", serviceOrderNumber=");
        builder.append(serviceOrderNumber);
        builder.append(", productInstanceId=");
        builder.append(productInstanceId);
        builder.append(", serviceComponentId=");
        builder.append(serviceComponentId);
        builder.append(", productName=");
        builder.append(productName);
        builder.append(", productCode=");
        builder.append(productCode);
        builder.append(", serviceComponentProductName=");
        builder.append(serviceComponentProductName);
        builder.append(", serviceComponentProductCode=");
        builder.append(serviceComponentProductCode);
        builder.append(", billStartDate=");
        builder.append(billStartDate);
        builder.append(", customerRequestDate=");
        builder.append(customerRequestDate);
        builder.append(", usdTotalMrcAmount=");
        builder.append(usdTotalMrcAmount);
        builder.append(", serviceOrderType=");
        builder.append(serviceOrderType);
        builder.append(", serviceOrderStatusCode=");
        builder.append(serviceOrderStatusCode);
        builder.append(", serviceOrderActionType=");
        builder.append(serviceOrderActionType);
        builder.append(", gatewayName=");
        builder.append(gatewayName);
        builder.append(", customerOrderCreateDate=");
        builder.append(customerOrderCreateDate);
        builder.append(", serviceLocationAddress=");
        builder.append(serviceLocationAddress);
        builder.append(", serviceLocationName=");
        builder.append(serviceLocationName);
        builder.append(", serviceInstanceId=");
        builder.append(serviceInstanceId);
        builder.append(", activeIndicator=");
        builder.append(activeIndicator);
        builder.append(", serviceOrderSequenceNumber=");
        builder.append(serviceOrderSequenceNumber);
        builder.append(", onnetIndicator=");
        builder.append(onnetIndicator);
        builder.append(", customerCircuitId=");
        builder.append(customerCircuitId);
        builder.append(", serviceInstallDate=");
        builder.append(serviceInstallDate);
        builder.append(", tspCode=");
        builder.append(tspCode);
        builder.append(", sourceCustomerNumber=");
        builder.append(sourceCustomerNumber);
        builder.append(", diversityTrailName=");
        builder.append(diversityTrailName);
        builder.append(", diversitySecondTrailName=");
        builder.append(diversitySecondTrailName);
        builder.append(", bandwidthCode=");
        builder.append(bandwidthCode);
        builder.append(", subBandwidthCode=");
        builder.append(subBandwidthCode);
        builder.append(", aEndClliCode=");
        builder.append(aEndClliCode);
        builder.append(", zEndClliCode=");
        builder.append(zEndClliCode);
        builder.append(", legacyBillAccountNumber=");
        builder.append(legacyBillAccountNumber);
        builder.append(", legacyLastServiceOrderNumber=");
        builder.append(legacyLastServiceOrderNumber);
        builder.append(", legacySourceSystemCode=");
        builder.append(legacySourceSystemCode);
        builder.append(", legacyCircuitId=");
        builder.append(legacyCircuitId);
        builder.append(", customerPurchaseOrderNumber=");
        builder.append(customerPurchaseOrderNumber);
        builder.append(", associatedOrderNumber=");
        builder.append(associatedOrderNumber);
        builder.append(", latencyGuranteeLevelType=");
        builder.append(latencyGuranteeLevelType);
        builder.append(", latencyGuranteeValue=");
        builder.append(latencyGuranteeValue);
        builder.append(", latencyActualValue=");
        builder.append(latencyActualValue);
        builder.append(", ipVersionCode=");
        builder.append(ipVersionCode);
        builder.append(", equipmentConfigDescription=");
        builder.append(equipmentConfigDescription);
        builder.append(", equipmentManufacturerName=");
        builder.append(equipmentManufacturerName);
        builder.append(", equipmentServiceProviderName=");
        builder.append(equipmentServiceProviderName);
        builder.append(", equipmentMaintAgreementType=");
        builder.append(equipmentMaintAgreementType);
        builder.append(", cnrJeopIndicator=");
        builder.append(cnrJeopIndicator);
        builder.append(", cnrJeopRaisedDate=");
        builder.append(cnrJeopRaisedDate);
        builder.append(", bundledServiceIndicator=");
        builder.append(bundledServiceIndicator);
        builder.append(", ultimateServiceStatusCode=");
        builder.append(ultimateServiceStatusCode);
        builder.append(", billAccountNumber=");
        builder.append(billAccountNumber);
        builder.append(", parentBillAccountNumber=");
        builder.append(parentBillAccountNumber);
        builder.append(", activeBillIndicator=");
        builder.append(activeBillIndicator);
        builder.append(", enableAutoTicketIndicator=");
        builder.append(enableAutoTicketIndicator);
        builder.append(", protectType=");
        builder.append(protectType);
        builder.append(", serviceLocationId=");
        builder.append(serviceLocationId);
        builder.append(", specialsId=");
        builder.append(specialsId);
        builder.append(", sidActiveBillIndicator=");
        builder.append(sidActiveBillIndicator);
        builder.append(", scidActiveBillIndicator=");
        builder.append(scidActiveBillIndicator);
        builder.append(", piidActiveBillIndicator=");
        builder.append(piidActiveBillIndicator);
        builder.append(", pcsidActiveBillIndicator=");
        builder.append(pcsidActiveBillIndicator);
        builder.append(", componentSubTypeName=");
        builder.append(componentSubTypeName);
        builder.append(", billAccountName=");
        builder.append(billAccountName);
        builder.append(", serviceClassLevelType=");
        builder.append(serviceClassLevelType);
        builder.append(", circuitId=");
        builder.append(circuitId);
        builder.append(", serviceId=");
        builder.append(serviceId);
        builder.append(", aLine1Address=");
        builder.append(aLine1Address);
        builder.append(", aLine2Address=");
        builder.append(aLine2Address);
        builder.append(", aCityName=");
        builder.append(aCityName);
        builder.append(", aStateCode=");
        builder.append(aStateCode);
        builder.append(", aPostalCode=");
        builder.append(aPostalCode);
        builder.append(", aCountyName=");
        builder.append(aCountyName);
        builder.append(", aCountryName=");
        builder.append(aCountryName);
        builder.append(", aLatitudeNumber=");
        builder.append(aLatitudeNumber);
        builder.append(", aLongitudeNumber=");
        builder.append(aLongitudeNumber);
        builder.append(", zLine1Address=");
        builder.append(zLine1Address);
        builder.append(", zLine2Address=");
        builder.append(zLine2Address);
        builder.append(", zCityName=");
        builder.append(zCityName);
        builder.append(", zStateCode=");
        builder.append(zStateCode);
        builder.append(", zPostalCode=");
        builder.append(zPostalCode);
        builder.append(", zCountyName=");
        builder.append(zCountyName);
        builder.append(", zCountryName=");
        builder.append(zCountryName);
        builder.append(", zLatitudeNumber=");
        builder.append(zLatitudeNumber);
        builder.append(", zLongitudeNumber=");
        builder.append(zLongitudeNumber);
        builder.append(", aLocationId=");
        builder.append(aLocationId);
        builder.append(", zLocationId=");
        builder.append(zLocationId);
        builder.append(", aLocationName=");
        builder.append(aLocationName);
        builder.append(", zLocationName=");
        builder.append(zLocationName);
        builder.append(", aTimezoneName=");
        builder.append(aTimezoneName);
        builder.append(", zTimezoneName=");
        builder.append(zTimezoneName);
        builder.append(", aDokuvizId=");
        builder.append(aDokuvizId);
        builder.append(", zDokuvizId=");
        builder.append(zDokuvizId);
        builder.append(", aLocationNumber=");
        builder.append(aLocationNumber);
        builder.append(", zLocationNumber=");
        builder.append(zLocationNumber);
        builder.append(", aRegionCode=");
        builder.append(aRegionCode);
        builder.append(", zRegionCode=");
        builder.append(zRegionCode);
        builder.append(", vpnId=");
        builder.append(vpnId);
        builder.append(", ticketingProductName=");
        builder.append(ticketingProductName);
        builder.append(", ticketingProductFamilyName=");
        builder.append(ticketingProductFamilyName);
        builder.append(", ticketingParentServiceId=");
        builder.append(ticketingParentServiceId);
        builder.append(", classOfServiceClassType=");
        builder.append(classOfServiceClassType);
        builder.append(", classOfServiceAllocationType=");
        builder.append(classOfServiceAllocationType);
        builder.append(", multiServiceAllocationType=");
        builder.append(multiServiceAllocationType);
        builder.append(", committedDataRateMbps=");
        builder.append(committedDataRateMbps);
        builder.append(", peakInformationRateMbps=");
        builder.append(peakInformationRateMbps);
        builder.append(", parentCircuitServiceId=");
        builder.append(parentCircuitServiceId);
        builder.append(", relatedServiceInstanceIdLevel1=");
        builder.append(relatedServiceInstanceIdLevel1);
        builder.append(", relatedServiceInstanceIdLevel2=");
        builder.append(relatedServiceInstanceIdLevel2);
        builder.append(", relatedServiceInstanceIdLevel3=");
        builder.append(relatedServiceInstanceIdLevel3);
        builder.append(", relatedServiceInstanceIdLevel4=");
        builder.append(relatedServiceInstanceIdLevel4);
        builder.append(", relatedServiceInstanceIdLevel5=");
        builder.append(relatedServiceInstanceIdLevel5);
        builder.append(", cpeDeviceName=");
        builder.append(cpeDeviceName);
        builder.append(", orderProductInstanceId=");
        builder.append(orderProductInstanceId);
        builder.append(", orderServiceComponentId=");
        builder.append(orderServiceComponentId);
        builder.append(", equipmentSerialNumber=");
        builder.append(equipmentSerialNumber);
        builder.append(", diverseRoleType=");
        builder.append(diverseRoleType);
        builder.append(", billType=");
        builder.append(billType);
	    builder.append(", vendorName=");
        builder.append(vendorName);
        builder.append(", vendorCircuitId=");
        builder.append(vendorCircuitId);
        builder.append(", primaryControllerName=");
        builder.append(primaryControllerName);
        builder.append(", primaryDirectorName=");
        builder.append(primaryDirectorName);
        builder.append(", servicePropertyListTxt=");
        builder.append(servicePropertyListTxt);
        builder.append(", serviceMgmtTyp=");
        builder.append(serviceMgmtTyp);
        builder.append(", financeAccountNbr=");
        builder.append(financeAccountNbr);
        builder.append(", orderSourceSystemName=");
        builder.append(orderSourceSystemName);
        builder.append(", billAcctSourceSystemCd=");
        builder.append(billAcctSourceSystemCd);
        builder.append("]");
        return builder.toString();
    }

}
