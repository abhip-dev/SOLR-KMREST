package com.level3.km.services.resource.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "loopQualification")
@XmlAccessorType(XmlAccessType.FIELD)
public class LoopQualification
{
    @Field("id")
    private String id;

    @Field("tnNumber")
    private String tnNumber;

    @Field("billingSourceSystemCode")
    private String billingSourceSystemCode;

    @Field("billingAccountId")
    private String billingAccountId;

    @Field("houseNumber")
    private String houseNumber;

    @Field("street")
    private String street;

    @Field("unit")
    private String unit;

    @Field("floor")
    private String floor;

    @Field("building")
    private String building;

    @Field("community")
    private String community;

    @Field("stateName")
    private String stateName;

    @Field("postalCode")
    private String postalCode;

    @Field("purchasedSpeedDownloadKbps")
    private Long purchasedSpeedDownloadKbps;

    @Field("purchasedSpeedUploadKbps")
    private Long purchasedSpeedUploadKbps;

    @Field("maxSpeedDownloadKbps")
    private Long maxSpeedDownloadKbps;

    @Field("maxSpeedUploadKbps")
    private Long maxSpeedUploadKbps;

    @Field("universalServiceOrderCode")
    private String universalServiceOrderCode;

    @Field("networkTechnology")
    private String networkTechnology;

    @Field("iptvTechnology")
    private String iptvTechnology;

    @Field("billingAccountIdFull")
    private String billingAccountIdFull;

    @Field("networkTechnologyAggregation")
    private String networkTechnologyAggregation;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getTnNumber()
    {
        return tnNumber;
    }

    public void setTnNumber(String tnNumber)
    {
        this.tnNumber = tnNumber;
    }

    public String getBillingSourceSystemCode()
    {
        return billingSourceSystemCode;
    }

    public void setBillingSourceSystemCode(String billingSourceSystemCode)
    {
        this.billingSourceSystemCode = billingSourceSystemCode;
    }

    public String getBillingAccountId()
    {
        return billingAccountId;
    }

    public void setBillingAccountId(String billingAccountId)
    {
        this.billingAccountId = billingAccountId;
    }

    public String getHouseNumber()
    {
        return houseNumber;
    }

    public void setHouseNumber(String houseNumber)
    {
        this.houseNumber = houseNumber;
    }

    public String getStreet()
    {
        return street;
    }

    public void setStreet(String street)
    {
        this.street = street;
    }

    public String getUnit()
    {
        return unit;
    }

    public void setUnit(String unit)
    {
        this.unit = unit;
    }

    public String getFloor()
    {
        return floor;
    }

    public void setFloor(String floor)
    {
        this.floor = floor;
    }

    public String getBuilding()
    {
        return building;
    }

    public void setBuilding(String building)
    {
        this.building = building;
    }

    public String getCommunity()
    {
        return community;
    }

    public void setCommunity(String community)
    {
        this.community = community;
    }

    public String getStateName()
    {
        return stateName;
    }

    public void setStateName(String stateName)
    {
        this.stateName = stateName;
    }

    public String getPostalCode()
    {
        return postalCode;
    }

    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }

    public Long getPurchasedSpeedDownloadKbps()
    {
        return purchasedSpeedDownloadKbps;
    }

    public void setPurchasedSpeedDownloadKbps(Long purchasedSpeedDownloadKbps)
    {
        this.purchasedSpeedDownloadKbps = purchasedSpeedDownloadKbps;
    }

    public Long getPurchasedSpeedUploadKbps()
    {
        return purchasedSpeedUploadKbps;
    }

    public void setPurchasedSpeedUploadKbps(Long purchasedSpeedUploadKbps)
    {
        this.purchasedSpeedUploadKbps = purchasedSpeedUploadKbps;
    }

    public Long getMaxSpeedDownloadKbps()
    {
        return maxSpeedDownloadKbps;
    }

    public void setMaxSpeedDownloadKbps(Long maxSpeedDownloadKbps)
    {
        this.maxSpeedDownloadKbps = maxSpeedDownloadKbps;
    }

    public Long getMaxSpeedUploadKbps()
    {
        return maxSpeedUploadKbps;
    }

    public void setMaxSpeedUploadKbps(Long maxSpeedUploadKbps)
    {
        this.maxSpeedUploadKbps = maxSpeedUploadKbps;
    }

    public String getUniversalServiceOrderCode()
    {
        return universalServiceOrderCode;
    }

    public void setUniversalServiceOrderCode(String universalServiceOrderCode)
    {
        this.universalServiceOrderCode = universalServiceOrderCode;
    }

    public String getNetworkTechnology()
    {
        return networkTechnology;
    }

    public void setNetworkTechnology(String networkTechnology)
    {
        this.networkTechnology = networkTechnology;
    }

    public String getIptvTechnology()
    {
        return iptvTechnology;
    }

    public void setIptvTechnology(String iptvTechnology)
    {
        this.iptvTechnology = iptvTechnology;
    }

    public String getBillingAccountIdFull()
    {
        return billingAccountIdFull;
    }

    public void setBillingAccountIdFull(String billingAccountIdFull)
    {
        this.billingAccountIdFull = billingAccountIdFull;
    }

    public String getNetworkTechnologyAggregation()
    {
        return networkTechnologyAggregation;
    }

    public void setNetworkTechnologyAggregation(String networkTechnologyAggregation)
    {
        this.networkTechnologyAggregation = networkTechnologyAggregation;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("LoopQualification [id=");
        builder.append(id);
        builder.append(", tnNumber=");
        builder.append(tnNumber);
        builder.append(", billingSourceSystemCode=");
        builder.append(billingSourceSystemCode);
        builder.append(", billingAccountId=");
        builder.append(billingAccountId);
        builder.append(", houseNumber=");
        builder.append(houseNumber);
        builder.append(", street=");
        builder.append(street);
        builder.append(", unit=");
        builder.append(unit);
        builder.append(", floor=");
        builder.append(floor);
        builder.append(", building=");
        builder.append(building);
        builder.append(", community=");
        builder.append(community);
        builder.append(", stateName=");
        builder.append(stateName);
        builder.append(", postalCode=");
        builder.append(postalCode);
        builder.append(", purchasedSpeedDownloadKbps=");
        builder.append(purchasedSpeedDownloadKbps);
        builder.append(", purchasedSpeedUploadKbps=");
        builder.append(purchasedSpeedUploadKbps);
        builder.append(", maxSpeedDownloadKbps=");
        builder.append(maxSpeedDownloadKbps);
        builder.append(", maxSpeedUploadKbps=");
        builder.append(maxSpeedUploadKbps);
        builder.append(", universalServiceOrderCode=");
        builder.append(universalServiceOrderCode);
        builder.append(", networkTechnology=");
        builder.append(networkTechnology);
        builder.append(", iptvTechnology=");
        builder.append(iptvTechnology);
        builder.append(", billingAccountIdFull=");
        builder.append(billingAccountIdFull);
        builder.append(", networkTechnologyAggregation=");
        builder.append(networkTechnologyAggregation);
        builder.append("]");
        return builder.toString();
    }

}
