package com.level3.km.services.resource.beans;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name="exchangeRate")
@XmlAccessorType(XmlAccessType.FIELD)
public class ExchangeRate
{
    @Field("id")
    private String id;
    @Field("conversionType")
    private String conversionType;
    @Field("fromCurrencyCode")
    private String fromCurrencyCode;
    @Field("toCurrencyCode")
    private String toCurrencyCode;
    @Field("conversionDate")
    private Date conversionDate;
    @Field("exchangeRateValue")
    private Double exchangeRateValue;
    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public String getConversionType()
    {
        return conversionType;
    }
    public void setConversionType(String conversionType)
    {
        this.conversionType = conversionType;
    }
    public String getFromCurrencyCode()
    {
        return fromCurrencyCode;
    }
    public void setFromCurrencyCode(String fromCurrencyCode)
    {
        this.fromCurrencyCode = fromCurrencyCode;
    }
    public String getToCurrencyCode()
    {
        return toCurrencyCode;
    }
    public void setToCurrencyCode(String toCurrencyCode)
    {
        this.toCurrencyCode = toCurrencyCode;
    }
    public Date getConversionDate()
    {
        return conversionDate;
    }
    public void setConversionDate(Date conversionDate)
    {
        this.conversionDate = conversionDate;
    }
    public Double getExchangeRateValue()
    {
        return exchangeRateValue;
    }
    public void setExchangeRateValue(Double exchangeRateValue)
    {
        this.exchangeRateValue = exchangeRateValue;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ExchangeRate [id=");
        builder.append(id);
        builder.append(", conversionType=");
        builder.append(conversionType);
        builder.append(", fromCurrencyCode=");
        builder.append(fromCurrencyCode);
        builder.append(", toCurrencyCode=");
        builder.append(toCurrencyCode);
        builder.append(", conversionDate=");
        builder.append(conversionDate);
        builder.append(", exchangeRateValue=");
        builder.append(exchangeRateValue);
        builder.append("]");
        return builder.toString();
    }
}