package com.level3.km.services.resource.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name="location")
@XmlAccessorType(XmlAccessType.FIELD)
public class Location
{
    @Field("id")
    private String id;
    @Field("physicalStructureId")
    private Long physicalStructureId;
    @Field("rootPhysicalStructureId")
    private Long rootPhysicalStructureId;
    @Field("parentPhysicalStructureId")
    private Long parentPhysicalStructureId;
    @Field("parentPhysicalStructureName")
    private String parentPhysicalStructureName;
    @Field("line1Address")
    private String line1Address;
    @Field("line2Address")
    private String line2Address;
    @Field("cityName")
    private String cityName;
    @Field("stateCode")
    private String stateCode;
    @Field("postalCode")
    private String postalCode;
    @Field("postalShortCode")
    private String postalShortCode;
    @Field("countyName")
    private String countyName;
    @Field("countryCodeIso2Letter")
    private String countryCodeIso2Letter;
    @Field("countryName")
    private String countryName;
    @Field("latitudeNumber")
    private Double latitudeNumber;
    @Field("longitudeNumber")
    private Double longitudeNumber;
    @Field("lataCode")
    private String lataCode;
    @Field("servingWireCenterClliCode")
    private String servingWireCenterClliCode;
    @Field("type")
    private String type;
    @Field("physicalStructureName")
    private String physicalStructureName;
    @Field("clliCode")
    private String clliCode;
    @Field("spaceCode")
    private String spaceCode;
    @Field("dwCreateDate")
    private Date dwCreateDate;
    @Field("dwLastModifyDate")
    private Date dwLastModifyDate;
    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;
    @Field("npa")
    private String npa;
    @Field("nxx")
    private String nxx;
    @Field("enterpriseAddressEid")
    private String enterpriseAddressEid;
    @Field("timezoneName")
    private String timezoneName;
    @Field("sourceLine1Address")
    private String sourceLine1Address;
    @Field("sourceLine2Address")
    private String sourceLine2Address;
    @Field("sourceCityName")
    private String sourceCityName;
    @Field("sourceStateCode")
    private String sourceStateCode;
    @Field("sourcePostalCode")
    private String sourcePostalCode;
    @Field("sourcePostalShortCode")
    private String sourcePostalShortCode;
    @Field("sourceCountyName")
    private String sourceCountyName;
    @Field("sourceCountryCodeIso2Letter")
    private String sourceCountryCodeIso2Letter;
    @Field("sourceCountryName")
    private String sourceCountryName;
    @Field("sourceLine1AddressGeocoded")
    private String sourceLine1AddressGeocoded;
    @Field("sourceCityNameGeocoded")
    private String sourceCityNameGeocoded;
    @Field("sourceStateCodeGeocoded")
    private String sourceStateCodeGeocoded;
    @Field("sourcePostalCodeGeocoded")
    private String sourcePostalCodeGeocoded;
    @Field("sourceCountryCodeIso2LetterGeocoded")
    private String sourceCountryCodeIso2LetterGeocoded;
    @Field("glProfitCenterGMCode")
    private String glProfitCenterGMCode;
    @Field("glProfitCenterMarketCode")
    private String glProfitCenterMarketCode;
    @Field("glProfitCenterCode")
    private String glProfitCenterCode;
    @Field("glProfitCenterRegionCode")
    private String glProfitCenterRegionCode;
    @Field("glProfitCenterSubRegionCode")
    private String glProfitCenterSubRegionCode;
    @Field("preferredSourceRecordIndicator")
    private Boolean preferredSourceRecordIndicator;
    @Field("locationNumbers")
    private List<String> locationNumbers;
    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public Long getPhysicalStructureId()
    {
        return physicalStructureId;
    }
    public void setPhysicalStructureId(Long physicalStructureId)
    {
        this.physicalStructureId = physicalStructureId;
    }
    public Long getRootPhysicalStructureId()
    {
        return rootPhysicalStructureId;
    }
    public void setRootPhysicalStructureId(Long rootPhysicalStructureId)
    {
        this.rootPhysicalStructureId = rootPhysicalStructureId;
    }
    public Long getParentPhysicalStructureId()
    {
        return parentPhysicalStructureId;
    }
    public void setParentPhysicalStructureId(Long parentPhysicalStructureId)
    {
        this.parentPhysicalStructureId = parentPhysicalStructureId;
    }
    public String getParentPhysicalStructureName()
    {
        return parentPhysicalStructureName;
    }
    public void setParentPhysicalStructureName(String parentPhysicalStructureName)
    {
        this.parentPhysicalStructureName = parentPhysicalStructureName;
    }
    public String getLine1Address()
    {
        return line1Address;
    }
    public void setLine1Address(String line1Address)
    {
        this.line1Address = line1Address;
    }
    public String getLine2Address()
    {
        return line2Address;
    }
    public void setLine2Address(String line2Address)
    {
        this.line2Address = line2Address;
    }
    public String getCityName()
    {
        return cityName;
    }
    public void setCityName(String cityName)
    {
        this.cityName = cityName;
    }
    public String getStateCode()
    {
        return stateCode;
    }
    public void setStateCode(String stateCode)
    {
        this.stateCode = stateCode;
    }
    public String getPostalCode()
    {
        return postalCode;
    }
    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }
    public String getPostalShortCode()
    {
        return postalShortCode;
    }
    public void setPostalShortCode(String postalShortCode)
    {
        this.postalShortCode = postalShortCode;
    }
    public String getCountyName()
    {
        return countyName;
    }
    public void setCountyName(String countyName)
    {
        this.countyName = countyName;
    }
    public String getCountryCodeIso2Letter()
    {
        return countryCodeIso2Letter;
    }
    public void setCountryCodeIso2Letter(String countryCodeIso2Letter)
    {
        this.countryCodeIso2Letter = countryCodeIso2Letter;
    }
    public String getCountryName()
    {
        return countryName;
    }
    public void setCountryName(String countryName)
    {
        this.countryName = countryName;
    }
    public Double getLatitudeNumber()
    {
        return latitudeNumber;
    }
    public void setLatitudeNumber(Double latitudeNumber)
    {
        this.latitudeNumber = latitudeNumber;
    }
    public Double getLongitudeNumber()
    {
        return longitudeNumber;
    }
    public void setLongitudeNumber(Double longitudeNumber)
    {
        this.longitudeNumber = longitudeNumber;
    }
    public String getLataCode()
    {
        return lataCode;
    }
    public void setLataCode(String lataCode)
    {
        this.lataCode = lataCode;
    }
    public String getServingWireCenterClliCode()
    {
        return servingWireCenterClliCode;
    }
    public void setServingWireCenterClliCode(String servingWireCenterClliCode)
    {
        this.servingWireCenterClliCode = servingWireCenterClliCode;
    }
    public String getType()
    {
        return type;
    }
    public void setType(String type)
    {
        this.type = type;
    }
    public String getPhysicalStructureName()
    {
        return physicalStructureName;
    }
    public void setPhysicalStructureName(String physicalStructureName)
    {
        this.physicalStructureName = physicalStructureName;
    }
    public String getClliCode()
    {
        return clliCode;
    }
    public void setClliCode(String clliCode)
    {
        this.clliCode = clliCode;
    }
    public String getSpaceCode()
    {
        return spaceCode;
    }
    public void setSpaceCode(String spaceCode)
    {
        this.spaceCode = spaceCode;
    }
    public Date getDwCreateDate()
    {
        return dwCreateDate;
    }
    public void setDwCreateDate(Date dwCreateDate)
    {
        this.dwCreateDate = dwCreateDate;
    }
    public Date getDwLastModifyDate()
    {
        return dwLastModifyDate;
    }
    public void setDwLastModifyDate(Date dwLastModifyDate)
    {
        this.dwLastModifyDate = dwLastModifyDate;
    }
    public String getDwSourceSystemCode()
    {
        return dwSourceSystemCode;
    }
    public void setDwSourceSystemCode(String dwSourceSystemCode)
    {
        this.dwSourceSystemCode = dwSourceSystemCode;
    }
    public String getNpa()
    {
        return npa;
    }
    public void setNpa(String npa)
    {
        this.npa = npa;
    }
    public String getNxx()
    {
        return nxx;
    }
    public void setNxx(String nxx)
    {
        this.nxx = nxx;
    }
    public String getEnterpriseAddressEid()
    {
        return enterpriseAddressEid;
    }
    public void setEnterpriseAddressEid(String enterpriseAddressEid)
    {
        this.enterpriseAddressEid = enterpriseAddressEid;
    }
    public String getTimezoneName()
    {
        return timezoneName;
    }
    public void setTimezoneName(String timezoneName)
    {
        this.timezoneName = timezoneName;
    }
    public String getSourceLine1Address()
    {
        return sourceLine1Address;
    }
    public void setSourceLine1Address(String sourceLine1Address)
    {
        this.sourceLine1Address = sourceLine1Address;
    }
    public String getSourceLine2Address()
    {
        return sourceLine2Address;
    }
    public void setSourceLine2Address(String sourceLine2Address)
    {
        this.sourceLine2Address = sourceLine2Address;
    }
    public String getSourceCityName()
    {
        return sourceCityName;
    }
    public void setSourceCityName(String sourceCityName)
    {
        this.sourceCityName = sourceCityName;
    }
    public String getSourceStateCode()
    {
        return sourceStateCode;
    }
    public void setSourceStateCode(String sourceStateCode)
    {
        this.sourceStateCode = sourceStateCode;
    }
    public String getSourcePostalCode()
    {
        return sourcePostalCode;
    }
    public void setSourcePostalCode(String sourcePostalCode)
    {
        this.sourcePostalCode = sourcePostalCode;
    }
    public String getSourcePostalShortCode()
    {
        return sourcePostalShortCode;
    }
    public void setSourcePostalShortCode(String sourcePostalShortCode)
    {
        this.sourcePostalShortCode = sourcePostalShortCode;
    }
    public String getSourceCountyName()
    {
        return sourceCountyName;
    }
    public void setSourceCountyName(String sourceCountyName)
    {
        this.sourceCountyName = sourceCountyName;
    }
    public String getSourceCountryCodeIso2Letter()
    {
        return sourceCountryCodeIso2Letter;
    }
    public void setSourceCountryCodeIso2Letter(String sourceCountryCodeIso2Letter)
    {
        this.sourceCountryCodeIso2Letter = sourceCountryCodeIso2Letter;
    }
    public String getSourceCountryName()
    {
        return sourceCountryName;
    }
    public void setSourceCountryName(String sourceCountryName)
    {
        this.sourceCountryName = sourceCountryName;
    }
    public String getSourceLine1AddressGeocoded()
    {
        return sourceLine1AddressGeocoded;
    }
    public void setSourceLine1AddressGeocoded(String sourceLine1AddressGeocoded)
    {
        this.sourceLine1AddressGeocoded = sourceLine1AddressGeocoded;
    }
    public String getSourceCityNameGeocoded()
    {
        return sourceCityNameGeocoded;
    }
    public void setSourceCityNameGeocoded(String sourceCityNameGeocoded)
    {
        this.sourceCityNameGeocoded = sourceCityNameGeocoded;
    }
    public String getSourceStateCodeGeocoded()
    {
        return sourceStateCodeGeocoded;
    }
    public void setSourceStateCodeGeocoded(String sourceStateCodeGeocoded)
    {
        this.sourceStateCodeGeocoded = sourceStateCodeGeocoded;
    }
    public String getSourcePostalCodeGeocoded()
    {
        return sourcePostalCodeGeocoded;
    }
    public void setSourcePostalCodeGeocoded(String sourcePostalCodeGeocoded)
    {
        this.sourcePostalCodeGeocoded = sourcePostalCodeGeocoded;
    }
    public String getSourceCountryCodeIso2LetterGeocoded()
    {
        return sourceCountryCodeIso2LetterGeocoded;
    }
    public void setSourceCountryCodeIso2LetterGeocoded(
            String sourceCountryCodeIso2LetterGeocoded)
    {
        this.sourceCountryCodeIso2LetterGeocoded = sourceCountryCodeIso2LetterGeocoded;
    }
    public String getGlProfitCenterGMCode()
    {
        return glProfitCenterGMCode;
    }
    public void setGlProfitCenterGMCode(String glProfitCenterGMCode)
    {
        this.glProfitCenterGMCode = glProfitCenterGMCode;
    }
    public String getGlProfitCenterMarketCode()
    {
        return glProfitCenterMarketCode;
    }
    public void setGlProfitCenterMarketCode(String glProfitCenterMarketCode)
    {
        this.glProfitCenterMarketCode = glProfitCenterMarketCode;
    }
    public String getGlProfitCenterCode()
    {
        return glProfitCenterCode;
    }
    public void setGlProfitCenterCode(String glProfitCenterCode)
    {
        this.glProfitCenterCode = glProfitCenterCode;
    }
    public String getGlProfitCenterRegionCode()
    {
        return glProfitCenterRegionCode;
    }
    public void setGlProfitCenterRegionCode(String glProfitCenterRegionCode)
    {
        this.glProfitCenterRegionCode = glProfitCenterRegionCode;
    }
    public String getGlProfitCenterSubRegionCode()
    {
        return glProfitCenterSubRegionCode;
    }
    public void setGlProfitCenterSubRegionCode(String glProfitCenterSubRegionCode)
    {
        this.glProfitCenterSubRegionCode = glProfitCenterSubRegionCode;
    }
    public Boolean getPreferredSourceRecordIndicator()
    {
        return preferredSourceRecordIndicator;
    }
    public void setPreferredSourceRecordIndicator(
            Boolean preferredSourceRecordIndicator)
    {
        this.preferredSourceRecordIndicator = preferredSourceRecordIndicator;
    }
    public List<String> getLocationNumbers()
    {
        return locationNumbers;
    }
    public void setLocationNumbers(List<String> locationNumbers)
    {
        this.locationNumbers = locationNumbers;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("Location [id=");
        builder.append(id);
        builder.append(", physicalStructureId=");
        builder.append(physicalStructureId);
        builder.append(", rootPhysicalStructureId=");
        builder.append(rootPhysicalStructureId);
        builder.append(", parentPhysicalStructureId=");
        builder.append(parentPhysicalStructureId);
        builder.append(", parentPhysicalStructureName=");
        builder.append(parentPhysicalStructureName);
        builder.append(", line1Address=");
        builder.append(line1Address);
        builder.append(", line2Address=");
        builder.append(line2Address);
        builder.append(", cityName=");
        builder.append(cityName);
        builder.append(", stateCode=");
        builder.append(stateCode);
        builder.append(", postalCode=");
        builder.append(postalCode);
        builder.append(", postalShortCode=");
        builder.append(postalShortCode);
        builder.append(", countyName=");
        builder.append(countyName);
        builder.append(", countryCodeIso2Letter=");
        builder.append(countryCodeIso2Letter);
        builder.append(", countryName=");
        builder.append(countryName);
        builder.append(", latitudeNumber=");
        builder.append(latitudeNumber);
        builder.append(", longitudeNumber=");
        builder.append(longitudeNumber);
        builder.append(", lataCode=");
        builder.append(lataCode);
        builder.append(", servingWireCenterClliCode=");
        builder.append(servingWireCenterClliCode);
        builder.append(", type=");
        builder.append(type);
        builder.append(", physicalStructureName=");
        builder.append(physicalStructureName);
        builder.append(", clliCode=");
        builder.append(clliCode);
        builder.append(", spaceCode=");
        builder.append(spaceCode);
        builder.append(", dwCreateDate=");
        builder.append(dwCreateDate);
        builder.append(", dwLastModifyDate=");
        builder.append(dwLastModifyDate);
        builder.append(", dwSourceSystemCode=");
        builder.append(dwSourceSystemCode);
        builder.append(", npa=");
        builder.append(npa);
        builder.append(", nxx=");
        builder.append(nxx);
        builder.append(", enterpriseAddressEid=");
        builder.append(enterpriseAddressEid);
        builder.append(", timezoneName=");
        builder.append(timezoneName);
        builder.append(", sourceLine1Address=");
        builder.append(sourceLine1Address);
        builder.append(", sourceLine2Address=");
        builder.append(sourceLine2Address);
        builder.append(", sourceCityName=");
        builder.append(sourceCityName);
        builder.append(", sourceStateCode=");
        builder.append(sourceStateCode);
        builder.append(", sourcePostalCode=");
        builder.append(sourcePostalCode);
        builder.append(", sourcePostalShortCode=");
        builder.append(sourcePostalShortCode);
        builder.append(", sourceCountyName=");
        builder.append(sourceCountyName);
        builder.append(", sourceCountryCodeIso2Letter=");
        builder.append(sourceCountryCodeIso2Letter);
        builder.append(", sourceCountryName=");
        builder.append(sourceCountryName);
        builder.append(", sourceLine1AddressGeocoded=");
        builder.append(sourceLine1AddressGeocoded);
        builder.append(", sourceCityNameGeocoded=");
        builder.append(sourceCityNameGeocoded);
        builder.append(", sourceStateCodeGeocoded=");
        builder.append(sourceStateCodeGeocoded);
        builder.append(", sourcePostalCodeGeocoded=");
        builder.append(sourcePostalCodeGeocoded);
        builder.append(", sourceCountryCodeIso2LetterGeocoded=");
        builder.append(sourceCountryCodeIso2LetterGeocoded);
        builder.append(", glProfitCenterGMCode=");
        builder.append(glProfitCenterGMCode);
        builder.append(", glProfitCenterMarketCode=");
        builder.append(glProfitCenterMarketCode);
        builder.append(", glProfitCenterCode=");
        builder.append(glProfitCenterCode);
        builder.append(", glProfitCenterRegionCode=");
        builder.append(glProfitCenterRegionCode);
        builder.append(", glProfitCenterSubRegionCode=");
        builder.append(glProfitCenterSubRegionCode);
        builder.append(", preferredSourceRecordIndicator=");
        builder.append(preferredSourceRecordIndicator);
        builder.append("]");
        return builder.toString();
    }

}
