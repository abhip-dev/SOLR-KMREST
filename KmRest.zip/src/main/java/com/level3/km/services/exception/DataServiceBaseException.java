package com.level3.km.services.exception;

import javax.ws.rs.WebApplicationException;

public class DataServiceBaseException extends WebApplicationException
{
    private static final long serialVersionUID = -4710857855984284996L;
    
    private ErrorCodeMapping errorCodeMapping = null;
    
    private String errorDetail = null;
    
    public DataServiceBaseException(ErrorCodeMapping errorCodeMapping)
    {
        super(errorCodeMapping.getHttpStatusCode());
        
        this.errorCodeMapping = errorCodeMapping;
    }

    public DataServiceBaseException(ErrorCodeMapping errorCodeMapping, String errorDetail)
    {
        super(errorCodeMapping.getHttpStatusCode());
        
        this.errorCodeMapping = errorCodeMapping;
        this.errorDetail = errorDetail;
    }
    
    public DataServiceBaseException(ErrorCodeMapping errorCodeMapping, Throwable throwable)
    {
        super(throwable);
        
        this.errorCodeMapping = errorCodeMapping;
    }

    public ErrorCodeMapping getErrorCodeMapping()
    {
        return errorCodeMapping;
    }

    public String getErrorDetail()
    {
        return errorDetail;
    }

    public void setErrorDetail(String errorDetail)
    {
        this.errorDetail = errorDetail;
    }
}
