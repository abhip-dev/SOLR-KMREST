package com.level3.km.services.resource.beans;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name="task")
@XmlAccessorType(XmlAccessType.FIELD)
public class Task
{
    @Field("id")
    private String id;
    @Field("customerOrderNumber")
    private String customerOrderNumber;
    @Field("customerOrderVersionNumber")
    private String customerOrderVersionNumber;
    @Field("serviceOrderNumber")
    private String serviceOrderNumber;
    @Field("processId")
    private String processId;
    @Field("productName")
    private String productName;
    @Field("serviceOrderServiceId")
    private String serviceOrderServiceId;
    @Field("taskName")
    private String taskName;
    @Field("taskStatus")
    private String taskStatus;
    @Field("performerName")
    private String performerName;
    @Field("taskDueDate")
    private Date taskDueDate;
    @Field("taskStartTime")
    private Date taskStartTime;
    @Field("taskEndTime")
    private Date taskEndTime;
    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;

    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public String getCustomerOrderNumber()
    {
        return customerOrderNumber;
    }
    public void setCustomerOrderNumber(String customerOrderNumber)
    {
        this.customerOrderNumber = customerOrderNumber;
    }
    public String getCustomerOrderVersionNumber()
    {
        return customerOrderVersionNumber;
    }
    public void setCustomerOrderVersionNumber(String customerOrderVersionNumber)
    {
        this.customerOrderVersionNumber = customerOrderVersionNumber;
    }
    public String getServiceOrderNumber()
    {
        return serviceOrderNumber;
    }
    public void setServiceOrderNumber(String serviceOrderNumber)
    {
        this.serviceOrderNumber = serviceOrderNumber;
    }
    public String getProcessId()
    {
        return processId;
    }
    public void setProcessId(String processId)
    {
        this.processId = processId;
    }
    public String getProductName()
    {
        return productName;
    }
    public void setProductName(String productName)
    {
        this.productName = productName;
    }
    public String getServiceOrderServiceId()
    {
        return serviceOrderServiceId;
    }
    public void setServiceOrderServiceId(String serviceOrderServiceId)
    {
        this.serviceOrderServiceId = serviceOrderServiceId;
    }
    public String getTaskName()
    {
        return taskName;
    }
    public void setTaskName(String taskName)
    {
        this.taskName = taskName;
    }
    public String getTaskStatus()
    {
        return taskStatus;
    }
    public void setTaskStatus(String taskStatus)
    {
        this.taskStatus = taskStatus;
    }
    public String getPerformerName()
    {
        return performerName;
    }
    public void setPerformerName(String performerName)
    {
        this.performerName = performerName;
    }
    public Date getTaskDueDate()
    {
        return taskDueDate;
    }
    public void setTaskDueDate(Date taskDueDate)
    {
        this.taskDueDate = taskDueDate;
    }
    public Date getTaskStartTime()
    {
        return taskStartTime;
    }
    public void setTaskStartTime(Date taskStartTime)
    {
        this.taskStartTime = taskStartTime;
    }
    public Date getTaskEndTime()
    {
        return taskEndTime;
    }
    public void setTaskEndTime(Date taskEndTime)
    {
        this.taskEndTime = taskEndTime;
    }
    public String getDwSourceSystemCode()
    {
        return dwSourceSystemCode;
    }
    public void setDwSourceSystemCode(String dwSourceSystemCode)
    {
        this.dwSourceSystemCode = dwSourceSystemCode;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("Task [id=");
        builder.append(id);
        builder.append(", customerOrderNumber=");
        builder.append(customerOrderNumber);
        builder.append(", customerOrderVersionNumber=");
        builder.append(customerOrderVersionNumber);
        builder.append(", serviceOrderNumber=");
        builder.append(serviceOrderNumber);
        builder.append(", processId=");
        builder.append(processId);
        builder.append(", productName=");
        builder.append(productName);
        builder.append(", serviceOrderServiceId=");
        builder.append(serviceOrderServiceId);
        builder.append(", taskName=");
        builder.append(taskName);
        builder.append(", taskStatus=");
        builder.append(taskStatus);
        builder.append(", performerName=");
        builder.append(performerName);
        builder.append(", taskDueDate=");
        builder.append(taskDueDate);
        builder.append(", taskStartTime=");
        builder.append(taskStartTime);
        builder.append(", taskEndTime=");
        builder.append(taskEndTime);
        builder.append(", dwSourceSystemCode=");
        builder.append(dwSourceSystemCode);
        builder.append("]");
        return builder.toString();
    }

}