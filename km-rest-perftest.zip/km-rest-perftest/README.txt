Perftest - Version 1.0 07/20/2016 


GENERAL USAGE NOTES
-------------------------

NAME
	perftest - a tool to stress-test performance for benchmarking our Solr deploy.


DESCRIPTION
	* This program requires the run as [-r] option and a log file in order to run. 
	* The search is set to: search index=tomcat host=kmdsidc*-prod source="/app/kmwebsvc/logs/dataservice.log"
	* The APPKEY is set to: 0122333444455555


OPTIONS
	-r  RUN-AS [dev] or [prod] or [test]

	-s  QUERY SPLUNK
		-f  FROM [YYYY-MM-DDTHH:MM:SS] (Note: 'T' between date/time)
		-t  TO   [YYYY-MM-DDTHH:MM:SS] (Note: 'T' between date/time)
		[See Splunk Search Section for more information]

	-l  LOCAL FILE [file.log]

	-g  HTTP FILE [http://website.com/file.log]


EXAMPLES
	./perftest -r dev -s -f 2016-06-28T00:00:00 -t 2016-06-29T01:00:00
		RUN as [dev] use SPLUNK FROM [2016-06-28T0:0:0] TO [2016-06-29T0:1:0] (1 min later)

	./perftest -r prod -l file.log
		RUN as [prod] use LOCAL file [file.log]

	./perftest -r dev -g http://somesite.com/file.log
		RUN as [dev] GET HTTP log [http://somesite.com/file.log]


SPLUNK SEARCH OPTIONS (For -f & -t flags)
	Date:
		2016-07-01T:00:00:00	(July 01 at 12:00am UTC)

	Date & Time: 
		2016-07-01T:01:30:00	(July 01 at 1:30am UTC)

	Relative Time:
		now
		-15s	(15 seconds ago)
		-15m	(15 minutes ago)
		-15h	(15 hour ago)
		-15d	(15 days ago)
		-15w	(15 weeks ago)
		-15mon	(15 months ago)
		-15q	(15 quarters ago)
		-15y	(15 years ago)



