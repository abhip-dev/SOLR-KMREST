package cassandra_extract.com.level3.km;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.splunk.Event;
import com.splunk.HttpService;
import com.splunk.JobExportArgs;
import com.splunk.MultiResultsReaderXml;
import com.splunk.SSLSecurityProtocol;
import com.splunk.SearchResults;
import com.splunk.Service;
import com.splunk.ServiceArgs;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

/**********************************************************************************************************************************
 *
 * Level 3 Communications
 * Perftest - a tool to stress test performance for benchmarking our Solr deploy.
 * 
 **********************************************************************************************************************************/

@SuppressWarnings("unused")
public class Perftest {

	public static String run_as;
	public static String target_log;
	public static int log_location;
	public static int total_events = 1;  

	static final Logger logger = LogManager.getLogger();

	public static void Download_URL(String URL_path) throws IOException {
		// Create a temp file called temp_file.log for execution
		String target_log = "temp_file.log";
		URL link = new URL(URL_path);
		InputStream in = new BufferedInputStream(link.openStream());
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		int n = 0;
		while (-1 != (n = in.read(buf)))
			out.write(buf, 0, n);
		out.close();
		in.close();
		byte[] response = out.toByteArray();
		FileOutputStream fos = new FileOutputStream(target_log);
		fos.write(response);
		fos.close();
		logger.info("Successfully Downloaded file: temp_file.log from " + URL_path);
		System.out.println("=> Successfully Downloaded file: temp_file.log from " + URL_path);
	}

	public static void Splunk_Search(String earliest_time, String latest_time) throws IOException {

		/**********************************************************************************************************************************
		 * Query Splunk (using Splunk SDK)
		 **********************************************************************************************************************************/
		
		// Create a map of arguments and add login parameters
		ServiceArgs loginArgs = new ServiceArgs();
		loginArgs.setUsername("rouser");
		loginArgs.setPassword("rouser");
		loginArgs.setHost("i14-07.idc1.level3.com");
		loginArgs.setPort(8089);
		
		HttpService.setSslSecurityProtocol(SSLSecurityProtocol.TLSv1_2);
		Service service = Service.connect(loginArgs);

		JobExportArgs exportArgs = new JobExportArgs();
		exportArgs.setEarliestTime(earliest_time);
		exportArgs.setLatestTime(latest_time);
		exportArgs.setSearchMode(JobExportArgs.SearchMode.NORMAL); 

		// Run the search with a search query and export arguments
		String mySearch = "search index=tomcat host=kmdsidc*-prod source=\"/app/kmwebsvc/logs/dataservice.log\"";
		InputStream exportSearch = service.export(mySearch, exportArgs);
		
		// Display results using the SDK's multi-results reader for XML 
		MultiResultsReaderXml multiResultsReader = null;
		try {
			multiResultsReader = new MultiResultsReaderXml(exportSearch);
		} catch (IOException e2) {
			logger.error("multiResultsReader failed for Splunk Query - Line: 110");
			e2.printStackTrace();
			throw new RuntimeException("multiResultsReader failed.");
		}

		PrintWriter writer = new PrintWriter("splunk_temp_file.log");
		for (SearchResults searchResults : multiResultsReader)
		{
		    for (Event event : searchResults) {
		        for (String key: event.keySet())
		        	if (key.equals("_raw")) {
				        System.out.print("  [Downloading events: " + total_events++ + "]\r");
				        writer.println(event.get(key));
		        	}
		    }
		    writer.close();
		}
		logger.info("Downloaded: " + (total_events-1) + " events from Splunk.");
		multiResultsReader.close();
	}
	
	public static void main(String[] args) throws IOException  {		
		

		/**********************************************************************************************************************************
		 * Setting up command line options
		 **********************************************************************************************************************************/
		Options options = new Options();

		options.addOption("r", true, "RUN-as [dev],[test],[prod]");
		options.addOption("l", true, "LOCAL file [file.log]");
		options.addOption("g", true, "GET from URL [http://website.com/file.log]");
		options.addOption("s", false, "Download from SPLUNK (Use -f and -t to set date/time range)");
		options.addOption("f", true, "FROM (earliest) date for Splunk [YYYY-MM-DDTHH:MM:SS] (Note: T between date/time)");
		options.addOption("t", true, "TO (latest) date for Splunk [YYYY-MM-DDTHH:MM:SS] (Note: T between date/time)");
		HelpFormatter formatter = new HelpFormatter();
		
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd;
		
		/**********************************************************************************************************************************
		 * Look for command line options
		 **********************************************************************************************************************************/
		try {
			cmd = parser.parse(options, args);
			if (cmd.hasOption("r")) {
				run_as = cmd.getOptionValue("r");
				logger.info("Running as: [" + run_as + "]");
			} else {
				logger.error("Insufficient parameters were passed.");
				formatter.printHelp("perftest -r dev -s -f 2016-07-28T00:00:00 -t 2016-07-29T01:00:00  - For more information check README.txt.", options );
				System.exit(0);
			}

			if (cmd.hasOption("l")) {  //Local file
				target_log = cmd.getOptionValue("l");
				logger.info("Target log is local and set to: " + target_log);
			} 
			else if (cmd.hasOption("g")) {  //Get file from URL
				target_log = "temp_file.log";
				String url = cmd.getOptionValue("g");
				logger.info("Downloading file from URL...");
				try {
					Download_URL(url);
				} catch (IOException e) {
					logger.fatal("Could not download URL. There is no log file to run.");
					e.printStackTrace();
				}
			} 
			else if (cmd.hasOption("s")) {  //Curl splunk for log file
				target_log = "splunk_temp_file.log";
				logger.info("Splunk selected as input file.");
				String from_date = null;
				String to_date = null;
				if (cmd.hasOption("f"))
					from_date = cmd.getOptionValue("f");
				
				if (cmd.hasOption("t"))
					to_date = cmd.getOptionValue("t");

				logger.info("Downloading log file from Splunk for: " + from_date + " to " + to_date);
				
				System.out.println("Query Splunk Server...\n");				
				
				Splunk_Search(from_date, to_date);
			}
			else {
				logger.error("Valid run parameter not passed in.\n");
				formatter.printHelp("perftest -r dev -s -f 2016-07-28T00:00:00 -t 2016-07-29T01:00:00   - For more information check README.txt.", options );
				System.exit(0);
			}

		} catch (ParseException e1) {
			logger.error("Insufficient parameters were passed.\n");
			formatter.printHelp("perftest -r dev -s -f 2016-07-28T00:00:00 -t 2016-07-29T01:00:00   - For more information check README.txt.", options );
			System.exit(0);
		}

		
		/**********************************************************************************************************************************
		 * Print Start time for execution (UTC)
		 **********************************************************************************************************************************/
		DateTime date_time_start = new DateTime(DateTimeZone.UTC);
		logger.info("Program start time (UTC): " + date_time_start.toString());
		System.out.println("\n\nStart Time: " + date_time_start.toString() + "(UTC)\n");
		
		
		/**********************************************************************************************************************************
		 * Start reading file in
		 **********************************************************************************************************************************/
		long startTime = System.nanoTime();
		String name = "";
		String val = "";
		String input_text = "";
		String line = null; 
		int current = 0;
		int count = 1;
		int http_errors = 1;

		try {
			FileReader fileReader = new FileReader(target_log); 
			BufferedReader bufferedReader = new BufferedReader(fileReader); 

			// Read file and parse
			while ((line = bufferedReader.readLine()) != null) {
				String brackets_text = null;
				String search = null;
				String appKey = "APPKEY0122333444455555";
				String base_query = null;

				/**********************************************************************************************************************************
				 * Check for line matching pattern and execute.
				 **********************************************************************************************************************************/
				if (line.matches("^20\\d\\d\\-.*?INFO\\s.*?APPKEY.*?U\\=.*?Search\\/.*?\\{.*?q\\=\\[.*?\\].*?}")) {
					input_text = line;
					
					/**********************************************************************************************************************************
					 * Determine type of search -> Get text inside brackets -> Map names and values -> Build URL for execution
					 **********************************************************************************************************************************/
					Pattern search_pattern = Pattern.compile(".*-\\sU=.*[^\\/](Search\\/.*?\\w+)");
					Matcher search_matcher = search_pattern.matcher(input_text);
					if (search_matcher.find())
						search = search_matcher.group(1);
					else
						System.out.println("No Match Found for Search Type");
					
					base_query = "http://kmservices-" + run_as + "/DataServices/v1/" + search + "?";

					// Get text inside brackets and remove brackets
					brackets_text = input_text.substring(input_text.indexOf(" {"), input_text.lastIndexOf("}") + 1);
					brackets_text = brackets_text.trim();
					if (brackets_text.startsWith("{"))
						brackets_text = brackets_text.substring(1);
					if (brackets_text.endsWith("}"))
						brackets_text = brackets_text.substring(0, brackets_text.length() - 1) + ", ";

					// Find name = value
					String params = "";
					String final_url = "";
					StringBuilder params_builder = new StringBuilder();
					//Map<String, String> name_val_map = new HashMap<String, String>();
					
					Pattern name_val_pattern = Pattern.compile("(\\w.*?)=\\[(.*?)\\],[\\s]"); 
					Matcher name_val_matcher = name_val_pattern.matcher(brackets_text);
					while (name_val_matcher.find()) {
						name = name_val_matcher.group(1).trim();
						val = name_val_matcher.group(2).trim();
						//name_val_map.put(name, val);
						params_builder.append(name + "=" + val + "&");
					}
					
					params = params_builder.toString();
					
					if (params.endsWith("&"))
						params = params.substring(0, params.length() - 1);
					params = URLEncoder.encode(params, "UTF-8"); 
					
					
					final_url = base_query + params;

					
					/**********************************************************************************************************************************
					 * Start Apache HTTP GET Request
					 **********************************************************************************************************************************/

					HttpClient client = HttpClientBuilder.create().build();
					HttpGet request = new HttpGet(final_url);

					request.setHeader("X-Level3-Application-Key", appKey);
					request.setHeader("Accept", "application/xml");
					HttpResponse response = client.execute(request);

					if (response.getStatusLine().getStatusCode() == 200) {
						current++;
						count++;
					} else {
						current++;
						http_errors++;
					}
					if (count > 1) System.out.print("  [HTTP Query: " + current + "]\r");  // Print current query to console

                    /*
                    BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
					StringBuffer result = new StringBuffer();
					String http_line = "";
					while ((http_line = rd.readLine()) != null) {
						result.append(http_line);
					}
					*/

					/**********************************************************************************************************************************
					 * END HTTP GET Request
					 **********************************************************************************************************************************/
				} else {
					//System.out.println("Bad string: " + line);
				}

			} 
			
			logger.info("HTTP Queries: " + (current) +" completed");
			bufferedReader.close(); // Closing file
			
		} catch (IOException ex) {
			logger.fatal("Error reading file: " + target_log);
			System.out.println("Error: reading file: '" + target_log + "'");
		}

		
		/**********************************************************************************************************************************
		 * Print End time for execution (UTC) 
		 **********************************************************************************************************************************/
		DateTime date_time_end = new DateTime(DateTimeZone.UTC);
		logger.info("Program end time (UTC): " + date_time_end.toString());
		System.out.println("\n\nEnd Time: " + date_time_end.toString() + "(UTC)\n");
		
		/**********************************************************************************************************************************
		 * Delete Temporary files and Finish Execution
		 **********************************************************************************************************************************/
		if (target_log == "temp_file.log") { // Delete HTTP temp file
			try {
				File file = new File("temp_file.log");
				if (file.delete()) {
					logger.info("temp_file.log was successfully deleted.");
					System.out.println("\ntemp_file.log was successfully deleted.");
				}
				else
					logger.error("Could not delete file: temp_file.log -  Op. Failed.");

			} catch (Exception e) {
				logger.error("Exception: Could not delete file: temp_file.log");
				e.printStackTrace();
			}
		}
		if (target_log == "splunk_temp_file.log") { // Delete Splunk temp file
			try {
				File file = new File("splunk_temp_file.log");
				if (file.delete()) {
					logger.info("splunk_temp_file.log was successfully deleted.");
					System.out.println("\nsplunk_temp_file.log was successfully deleted.");
				}
				else
					logger.error("Could not delete file: splunk_temp_file.log - Op. Failed.");

			} catch (Exception e) {
				logger.error("Exception: Could not delete file: splunk_temp_file.log");
				e.printStackTrace();
			}
		}

		/**********************************************************************************************************************************
		 * Program Finished Executing. Printing Successful queries, HTTP exceptions, and program exec time.
		 **********************************************************************************************************************************/
		long endTime = System.nanoTime(); // Measure program execution time
		System.out.println("");
		long totalTime_ms = (endTime - startTime) / (1000000); // Get total time (ms)
		long totalTime_s = ((totalTime_ms)/(1000));
		System.out.println("\n- Program Statistics - \n");
		System.out.println("Processed Successfully: " + (count-1));
		if ((http_errors - 1) > 0)
			System.out.println("HTTP Exceptions: " + (http_errors - 1));
		System.out.println("Time: " + totalTime_ms + " ms"); 
		if (totalTime_ms > 1000) {
			System.out.println("Time: " + totalTime_s + " sec");
			if (totalTime_s > 600)
				System.out.println("Time: " + (totalTime_s/60) + " min");
		}
	}
}
