#!/bin/sh
# -------------------------------------------------------------
# Arguments:
# $1 - The Informatica javalib directory
#
# --------------------------------------------------------------


if [ "$#" -lt 1 ]
then
  echo "Incorrect number of arguments."
  echo "Usage: delete_old_jars.sh <Informatica java lib dir>"
  exit 1
fi

INFORMATICA_JAVA_DIR=$1

function deleteJar
{
   FILE_NAME=$1

   if [ -f ${INFORMATICA_JAVA_DIR}/${FILE_NAME} ]
   then
      # remove file 
      sudo su - infa -c "/bin/rm ${INFORMATICA_JAVA_DIR}/${FILE_NAME}"
      RETVAL=$?
      if [ $RETVAL -eq 0 ]
      then
         echo "REMOVED ${FILE_NAME} FROM ${INFORMATICA_JAVA_DIR}"
      else
         echo "FAILED TO REMOVE ${FILE_NAME} FROM ${INFORMATICA_JAVA_DIR}"
      fi
   fi
}

for fileName in activation-1.1.jar antlr-2.7.7.jar antlr-3.2.jar antlr-runtime-3.2.jar avro-1.4.0-cassandra-1.jar cassandra-all-1.1.6.jar cassandra-thrift-1.1.5.jar commons-cli-1.1.jar commons-codec-1.7.jar commons-io-2.4.jar commons-lang-2.5.jar commons-logging-1.1.1.jar commons-pool-1.5.3.jar compress-lzf-0.8.4.jar concurrentlinkedhashmap-lru-1.3.jar ess_japi-9.3.1.jar guava-r09.jar hector-core-1.0-5.jar high-scale-lib-1.1.2.jar httpclient-4.0.1.jar httpcore-4.0.1.jar jackson-core-asl-1.9.2.jar jackson-mapper-asl-1.9.2.jar jamm-0.2.5.jar jersey-client-1.17.1.jar jersey-core-1.17.1.jar jetty-6.1.22.jar jetty-util-6.1.22.jar jline-0.9.94.jar json-20090211.jar json-path-0.8.1.jar json-simple-1.1.jar json-smart-1.1.1.jar jsoup-1.7.2.jar libthrift-0.7.0.jar log4j-1.2.16.jar mail-1.4.7.jar metrics-core-2.0.3.jar servlet-api-2.5.jar servlet-api-2.5-20081211.jar slf4j-api-1.6.1.jar slf4j-log4j12-1.6.1.jar snakeyaml-1.6.jar snappy-java-1.0.4.1.jar snaptree-0.1.jar speed4j-0.9.jar stringtemplate-3.2.jar uuid-3.2.0.jar ;
do
   #echo ${INFORMATICA_JAVA_DIR}/${fileName}
   deleteJar ${fileName}
done
