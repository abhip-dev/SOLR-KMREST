#!/bin/sh
# -------------------------------------------------------------
# This script is a wrapper around the automated deployment process.
# Its job is to control the deployment process and call the necessary
# scripts to get the job done
#
# Arguments:
# $1 - The environment to deploy for
#
# --------------------------------------------------------------


if [ "$#" -lt 1 ]
then
  echo "Incorrect number of arguments."
  echo "Usage: deploydriver.sh environment"
  exit 1
fi

echo "Environment is $1"

ENVIRONMENT=$1

DATE_FORMAT=`date +%Y%m%d:%H:%M:%S`

DEPLOY_DIR=${PWD}

###################################
###   source properties files   ###
###################################
echo "Including ${DEPLOY_DIR}/env_config/${ENVIRONMENT}_environment.properties"
dos2unix ${DEPLOY_DIR}/env_config/${ENVIRONMENT}_environment.properties ${DEPLOY_DIR}/env_config/${ENVIRONMENT}_environment.properties 2> /dev/null
. ${DEPLOY_DIR}/env_config/${ENVIRONMENT}_environment.properties

echo "Informatica java deployment directory is $INFORMATICA_JAVA_DIR"

# delete old jar files related to data-extract
SCRIPTSDIR=${DEPLOY_DIR}/deploy_scripts
if [ -f ${SCRIPTSDIR}//delete_old_jars.sh ]
then
   ${SCRIPTSDIR}/delete_old_jars.sh ${INFORMATICA_JAVA_DIR}
else
   echo "delete_old_jars.sh not found, exiting."
   exit 1;
fi


# rename existing jar files in informatica javalib dir
# keep only one copy of backup jar
# copy jar file to destination dir
for ZIP in `ls ${DEPLOY_DIR}/dist/*.zip`
do
   ZIP_FILE_NAME=`echo ${ZIP} | sed -e 's/.*\/dist\///'`
   echo "FOUND zip file ${ZIP_FILE_NAME}"

   # make temp dir
   mkdir ${DEPLOY_DIR}/temp
   #cd $DEPLOY_DIR}/temp
   # unzip this file
   unzip $ZIP -d ${DEPLOY_DIR}/temp

   # so now we will have lots of files - jars, pom etc
   # iterate over each file and copy
   for FILE in `ls ${DEPLOY_DIR}/temp`
   do
           FILE_NAME=`echo ${FILE} | sed -e 's/.*\/temp\///'`

	   if [ ${FILE_NAME} = "cassandra-extract-1.0.jar" ]
	   then
                   # we keep only one backup file, that would be the current jar file
		   # remove old backup files
		   for BACKUP_FILE in `sudo su - infa -c "ls ${INFORMATICA_JAVA_DIR}/backup/${FILE_NAME}.*"`
		   do
			   echo "FOUND BACKUP FILE ${BACKUP_FILE}"
			   sudo su - infa -c "rm -f ${BACKUP_FILE}"
		  	   RETVAL=$?
		           if [ $RETVAL -eq 0 ]
		           then
		     	   	echo "REMOVED ${BACKUP_FILE}"
		           else
		     	   	echo "FAILED to REMOVE ${BACKUP_FILE}, exit status ${RETVAL}"
		     	   	exit ${RETVAL};
		           fi
		   done

		   # move active jar to backup
   		   if [ -f ${INFORMATICA_JAVA_DIR}/${FILE_NAME} ]
   		   then
      			   sudo su - infa -c "mv ${INFORMATICA_JAVA_DIR}/${FILE_NAME} ${INFORMATICA_JAVA_DIR}/backup/${FILE_NAME}.${DATE_FORMAT}"
		  	   RETVAL=$?
		           if [ $RETVAL -eq 0 ]
		           then
		     	   	echo "MOVED ${INFORMATICA_JAVA_DIR}/${FILE_NAME} to ${INFORMATICA_JAVA_DIR}/backup/${FILE_NAME}.${DATE_FORMAT}"
		           else
		     	   	echo "FAILED TO MOVE ${INFORMATICA_JAVA_DIR}/${FILE_NAME} to ${INFORMATICA_JAVA_DIR}/backup/${FILE_NAME}.${DATE_FORMAT}, exit status ${RETVAL}"
		     	   	exit ${RETVAL};
		           fi
		   fi
	   fi

	   # copy files over to INFORMATICA_JAVA_DIR if file does not exist
	   if [ ! -f ${INFORMATICA_JAVA_DIR}/${FILE_NAME} ]
	   then
		   # copy file over
		   sudo su - infa -c "cp ${DEPLOY_DIR}/temp/${FILE} ${INFORMATICA_JAVA_DIR}"
		   RETVAL=$?
		   if [ $RETVAL -eq 0 ]
		   then
			   echo "COPIED ${FILE} TO ${INFORMATICA_JAVA_DIR}"
		   else
			   echo "FAILED TO COPY ${FILE} TO ${INFORMATICA_JAVA_DIR}, exit status ${RETVAL}"
			   exit ${RETVAL};
		   fi
	   fi
   done
done

echo "deploydriver.sh Done"
echo "exiting..."
exit 0
