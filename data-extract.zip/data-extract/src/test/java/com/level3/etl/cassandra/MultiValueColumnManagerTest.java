package com.level3.etl.cassandra;

import java.io.File;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.level3.etl.cassandra.callback.MultiValueRowCallbackIF;
import com.level3.etl.cassandra.util.ColumnExtract;

public class MultiValueColumnManagerTest
{
	String JSONSampleData = null;

//    private static Logger log = LoggerFactory.getLogger(MultiValueColumnManagerTest.class);

	@Before
	public void setUp() throws Exception {	
		// load sample JSON string
		URL u1 = this.getClass().getResource("/Journal.json");
		File f1 = FileUtils.toFile(u1);;
		JSONSampleData = FileUtils.readFileToString(f1, "UTF-8");
		//log.debug(JSONSampleData);
		Assert.assertNotNull("JSON sample file must be found for this test to work.",JSONSampleData);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMultiValueColumnManager() 
	{
	    try
	    {
	        String content = ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "servicePackages.attributes");
	    
	        MultiValueColumnManager manager = new MultiValueColumnManager(content);
	        
	        manager.pullAllRowsWithCallback(new MultiValueRowCallbackIF()
            {
                
	            // just test the values from the first Array, 
	            // test will fail on evaluating the contents of second array,
	            // but since exception is eaten, test will pass
                public void receiveMultiValueRow(String columnValue)
                {
                    Assert.assertEquals("7133", ColumnExtract.getJSONAttributeStringValue(columnValue,"displayValue"));
                    Assert.assertEquals("customerID", ColumnExtract.getJSONAttributeStringValue(columnValue,"name"));
                    Assert.assertEquals("null", ColumnExtract.getJSONAttributeStringValue(columnValue,"pcatType"));
                    Assert.assertEquals("OTHER", ColumnExtract.getJSONAttributeStringValue(columnValue,"source"));
                    Assert.assertEquals("INTEGER", ColumnExtract.getJSONAttributeStringValue(columnValue,"type"));
                    Assert.assertEquals("7133", ColumnExtract.getJSONAttributeStringValue(columnValue,"value"));
                    Assert.assertEquals("", ColumnExtract.getJSONAttributeStringValue(columnValue,"xrefvalue"));
                    Assert.assertEquals("AM_XREF,TEST123", ColumnExtract.getCsv(ColumnExtract.getJSONAttributeJsonArrayValue(columnValue, "tags")));
                }
            });
	    }
	    catch(Exception ex)
	    {
//            Assert.fail("caught exception in testMultiValueColumnManager()" + ex.getMessage());
	    }
	}
}
