package com.level3.etl.email;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.SystemUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;
import org.jsoup.safety.Whitelist;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.jvnet.mock_javamail.Mailbox;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.etl.email.dataobjects.MailMessageDO;
import com.level3.etl.email.dataobjects.MailMessageDO.MessageStatus;
import com.level3.etl.email.dataobjects.MailboxDO;
import com.level3.etl.email.dataobjects.ReportStorageDO;

/**
 * We are using mock-javamail for tests. So no actual email will be sent. Emails will be sent to an
 * in memory mailbox and retrieved from the same in memory mailbox. 
 * mock-javamail is used with a scope of test, so that our production code does not use
 * mock-javamail.
 * @author agarwal.nitin
 *
 */
public class MailMessageProcessorTest
{
    private static Logger log = LoggerFactory.getLogger(MailMessageProcessorTest.class);
    
    MailboxDO mailboxDO = null;
    ReportStorageDO reportStorageDO = null;
    Session session = null;
    
    private static final String targetInboxId = "Starbucksreports@level3.com";
    private static final String originInboxId = "testmail@level3.com";
    
    private String inboundValidMessage = null;
    
    @Before
    public void setUp() throws Exception
    {
		URL u1 = this.getClass().getResource("/EmailMessageValid.txt");
		File f1 = FileUtils.toFile(u1);;
		inboundValidMessage = FileUtils.readFileToString(f1);
		
        mailboxDO = new MailboxDO();
        
        mailboxDO.setSmtpServer("smtp.level3.com");
        mailboxDO.setSmtpPort("25");
        
        // mock java mail has some issues, it tries to construct mailbox using 'username'@'host'
        // so we are using level3.com for host name, instead of email.level3.com for testing
        mailboxDO.setMailServer("level3.com");
        mailboxDO.setMailBox(targetInboxId);
        mailboxDO.setUserName("Starbucksreports");
        mailboxDO.setPassword("31arb8ck3!");
        
        reportStorageDO = new ReportStorageDO();
        reportStorageDO.setCustomerNumber("1-5K14R");
        
        if(SystemUtils.IS_OS_WINDOWS)
        {
            reportStorageDO.setReportFtpDir("C:/Starbucks");
            reportStorageDO.setReportStorageDir("C:/temp/Starbucks/data");
            reportStorageDO.setReportStagingDir("C:/temp/Starbucks/staging");
        }
        else
        {
            reportStorageDO.setReportFtpDir("/tmp/ftp/Starbucks");
            reportStorageDO.setReportStorageDir("/tmp/Starbucks/data");
            reportStorageDO.setReportStagingDir("/tmp/Starbucks/staging");
        }
        
        Properties props = new Properties();

        // set up properties for SMTP mail server
        props.setProperty("mail.smtp.host", mailboxDO.getSmtpServer());
        props.setProperty("mail.smtp.port", mailboxDO.getSmtpPort() == null ? "25" : mailboxDO.getSmtpPort());
        props.setProperty("mail.imap.partialfetch", "false");

        session = Session.getInstance(
                props, new ExchangeAuthenticator(mailboxDO.getUserName(), mailboxDO.getPassword()));
        
        // create data dir where attachment will be downloaded
        File dataDir = new File(reportStorageDO.getReportStorageDir());
        if(dataDir.exists())
        {
            // delete files in directory
            for(File file : dataDir.listFiles())
            {
                FileUtils.deleteQuietly(file);
            }
        }
        else
        {
            // create dir
            FileUtils.forceMkdir(dataDir);
        }
        
        // create meta data dir where xml will be placed
        File stagingDir = new File(reportStorageDO.getReportStagingDir());
        if(stagingDir.exists())
        {
            // delete files in directory
            for(File file : stagingDir.listFiles())
            {
                FileUtils.deleteQuietly(file);
            }
        }
        else
        {
            // create dir
            FileUtils.forceMkdir(stagingDir);
        }
    }
    
    @After
    public void tearDown() throws Exception
    {
        Mailbox.clearAll();
    }
    
    private MimeMessage getMessageWithoutAttachment() throws IOException, MessagingException
    {
        MimeMessage message = new MimeMessage(session);
        
        message.setFrom(new InternetAddress(originInboxId));
        
        InternetAddress[] address = {new InternetAddress(targetInboxId)};
        message.setRecipients(Message.RecipientType.TO, address);
        
        message.setSubject("October Usage and Charges Report for Starbucks");

        // create and fill the first message part
        MimeBodyPart bodyPart1 = new MimeBodyPart();
        bodyPart1.setText(inboundValidMessage);

        // create multipart
        Multipart multiPart = new MimeMultipart();
        multiPart.addBodyPart(bodyPart1);

        // add Multipart to the message
        message.setContent(multiPart);
        
        return message;
    }
    
    private MimeMessage getMessageWithMultipleAttachments() throws IOException, MessagingException
    {
        MimeMessage message = new MimeMessage(session);
        
        message.setFrom(new InternetAddress(originInboxId));
        
        InternetAddress[] address = {new InternetAddress(targetInboxId)};
        message.setRecipients(Message.RecipientType.TO, address);
        
        message.setSubject("November Usage and Charges Report for Starbucks");

        // create and fill the first message part
        MimeBodyPart bodyPart1 = new MimeBodyPart();
        bodyPart1.setText(inboundValidMessage);

        // create the second message part
        MimeBodyPart bodyPart2 = new MimeBodyPart();

        // attach the file to the message
		URL u1 = this.getClass().getResource("/Level3-Starbucks UAD.xls");
		File f1 = FileUtils.toFile(u1);;
        bodyPart2.attachFile(f1);
        
        // create the third message part
        MimeBodyPart bodyPart3 = new MimeBodyPart();

        // attach the file to the message
		URL u2 = this.getClass().getResource("/JSONSample.json");
		File f2 = FileUtils.toFile(u2);;
        bodyPart3.attachFile(f2);
        
        // create multipart
        Multipart multiPart = new MimeMultipart();
        multiPart.addBodyPart(bodyPart1);
        multiPart.addBodyPart(bodyPart2);
        multiPart.addBodyPart(bodyPart3);

        // add Multipart to the message
        message.setContent(multiPart);
        
        return message;
    }
    
    private MimeMessage getValidMessage() throws IOException, MessagingException
    {
        MimeMessage message = new MimeMessage(session);
        
        message.setFrom(new InternetAddress(originInboxId));
        
        InternetAddress[] address = {new InternetAddress(targetInboxId)};
        message.setRecipients(Message.RecipientType.TO, address);
        
        message.setSubject("August Usage and Charges Report for Starbucks");

        // create and fill the first message part
        MimeBodyPart bodyPart1 = new MimeBodyPart();
        bodyPart1.setText(inboundValidMessage);

        // create the second message part
        MimeBodyPart bodyPart2 = new MimeBodyPart();

        // attach the file to the message
		URL u1 = this.getClass().getResource("/Level3-Starbucks UAD.xls");
		File f1 = FileUtils.toFile(u1);;
        bodyPart2.attachFile(f1);
        
        // create multipart
        Multipart multiPart = new MimeMultipart();
        multiPart.addBodyPart(bodyPart1);
        multiPart.addBodyPart(bodyPart2);

        // add Multipart to the message
        message.setContent(multiPart);
        
        return message;
    }
    
    private MimeMessage getMessageWithBadContent() throws IOException, MessagingException
    {
        MimeMessage message = new MimeMessage(session);
        
        message.setFrom(new InternetAddress(originInboxId));
        
        InternetAddress[] address = {new InternetAddress(targetInboxId)};
        message.setRecipients(Message.RecipientType.TO, address);
        
        message.setSubject("September Usage and Charges Report for Starbucks");

        // create and fill the first message part
        MimeBodyPart bodyPart1 = new MimeBodyPart();
        
        String invalidContent = inboundValidMessage.replaceFirst("Report Period", "Reportperiod");
        bodyPart1.setText(invalidContent);

        // create the second message part
        MimeBodyPart bodyPart2 = new MimeBodyPart();

        // attach the file to the message
		URL u1 = this.getClass().getResource("/Level3-Starbucks UAD.xls");
		File f1 = FileUtils.toFile(u1);;
        bodyPart2.attachFile(f1);
        
        // create multipart
        Multipart multiPart = new MimeMultipart();
        multiPart.addBodyPart(bodyPart1);
        multiPart.addBodyPart(bodyPart2);

        // add Multipart to the message
        message.setContent(multiPart);
        
        return message;
    }
    
    private String getMessageBody(Message message) throws IOException, MessagingException
    {
        Object messageContent = message.getContent();

        if (messageContent instanceof Multipart)
        {
            return processMultipart((Multipart)messageContent);
        }
        else
        {
            return (String)messageContent;
        }
    }
    
    private String processMultipart(Multipart multipart) throws IOException, MessagingException
    {
        String output = null;
        
        for (int index = 0; index < multipart.getCount(); ++index)
        {
            BodyPart bodyPart = multipart.getBodyPart(index);
            
            if(bodyPart.isMimeType("text/plain"))
            {
                log.debug("!!! MULTIPART MIME TYPE :text/plain");
                output = (String)bodyPart.getContent();
                log.debug("CONTENT :\n" + output);
                
                return output;
            }
            else if(bodyPart.isMimeType("text/html"))
            {
                log.debug("!!! MULTIPART MIME TYPE :text/html");
                String html = (String)bodyPart.getContent();

                // strip out html tags and get text
                Document.OutputSettings outputSettings = 
                        new Document.OutputSettings().prettyPrint(false);
                outputSettings.escapeMode(Entities.EscapeMode.xhtml);
                output = Jsoup.clean(html, "", Whitelist.none(), outputSettings);
                log.debug("CONTENT :\n" + output);
                
                return output;
            }
            else if(bodyPart.isMimeType("multipart/alternative"))
            {
                log.debug("!!! MULTIPART MIME TYPE :multipart/alternative");
                return processMultipart((Multipart)bodyPart.getContent());
            }
        }
        
        return output;
    }
    
    @Test
    public void testProcessEmail_validEmail()
    {
        MailMessageProcessor messageProcessor = null;
        MailMessageCallbackImpl callback = null;
        
        try
        {
            MimeMessage message = getValidMessage();
            
            Transport.send(message);
            
            callback = new MailMessageCallbackImpl();
            messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
            
            messageProcessor.processMessages(callback);
            
            // validate callback was called just once
            Assert.assertEquals(true, callback.calledJustOnce());
            
            // validate status is GOOD
            Assert.assertEquals(MailMessageDO.MessageStatus.GOOD, callback.getMailMessageDO().getStatus());
            
            // validate attachment
            URL u1 = this.getClass().getResource("/Level3-Starbucks UAD.xls");
            File inputFile = FileUtils.toFile(u1);;
            
            Assert.assertNotNull(callback.getMailMessageDO().getAttachment());
            Assert.assertTrue(callback.getMailMessageDO().getAttachment().exists());
            
            // validate inputFile and attachment file on callback match
            Assert.assertEquals(
                    FileUtils.checksumCRC32(inputFile),
                    FileUtils.checksumCRC32(callback.getMailMessageDO().getAttachment()));
            
            // validate that attachment file is written to correct dir
            File dataDir = new File(reportStorageDO.getReportStorageDir());
            Assert.assertNotNull(dataDir.listFiles());
            Assert.assertEquals(1, dataDir.listFiles().length);
            
            // validate inputFile and attachment file in data dir match
            for(File file : dataDir.listFiles())
            {
                Assert.assertEquals(FileUtils.checksumCRC32(inputFile), FileUtils.checksumCRC32(file));
            }
            
            // TODO - validate contents of XML, against input 
            
            // validate we have email message
            Assert.assertNotNull(callback.getMailMessageDO().getEmailMessage());
            
            // validate we have email message body
            Assert.assertNotNull(callback.getMailMessageDO().getEmailMessageBody());
            
//            Assert.assertEquals(inboundValidMessage.trim(), callback.getMailMessageDO().getEmailMessageBody().trim());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail("caught unexpected Exception while trying to process email." + e.getClass());
        }
    }
        
    @Test
    public void testProcessEmail_EmailWithoutAttachment()
    {
        MailMessageProcessor messageProcessor = null;
        MailMessageCallbackImpl callback = null;
        
        try
        {
            MimeMessage message = getMessageWithoutAttachment();
            
            Transport.send(message);
            
            messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
            
            callback = new MailMessageCallbackImpl();
            messageProcessor.processMessages(callback);
            
            Assert.assertEquals(true, callback.calledJustOnce());
            
            Assert.assertEquals(MailMessageDO.MessageStatus.NO_ATTACHMENTS, callback.getMailMessageDO().getStatus());
            
            // validate there is no data file in staging dir
            File dataDir = new File(reportStorageDO.getReportStagingDir());
            Assert.assertNotNull(dataDir.listFiles());
            Assert.assertEquals(0, dataDir.listFiles().length);
            
            // validate there is no data file in storage dir
            File storageDataDir = new File(reportStorageDO.getReportStorageDir());
            Assert.assertNotNull(storageDataDir.listFiles());
            Assert.assertEquals(0, storageDataDir.listFiles().length);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail("caught unexpected Exception while trying to process email." + e.getClass());
        }
    }
    
    @Test
    public void testProcessEmail_EmailWithBadContent()
    {
        MailMessageProcessor messageProcessor = null;
        MailMessageCallbackImpl callback = null;
        
        try
        {
            MimeMessage message = getMessageWithBadContent();
            
            Transport.send(message);
            
            messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
            
            callback = new MailMessageCallbackImpl();
            messageProcessor.processMessages(callback);
            
            Assert.assertEquals(true, callback.calledJustOnce());
            
            Assert.assertEquals(MailMessageDO.MessageStatus.INVALID_DATA, callback.getMailMessageDO().getStatus());
            
            // validate there is no data file in storage dir
            File storageDataDir = new File(reportStorageDO.getReportStorageDir());
            Assert.assertNotNull(storageDataDir.listFiles());
            Assert.assertEquals(0, storageDataDir.listFiles().length);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail("caught unexpected Exception while trying to process email." + e.getClass());
        }
    }
    
    @Test
    public void testProcessEmail_EmailWithMultipleAttachments()
    {
        MailMessageProcessor messageProcessor = null;
        MailMessageCallbackImpl callback = null;
        
        try
        {
            MimeMessage message = getMessageWithMultipleAttachments();
            
            Transport.send(message);
            
            messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
            
            callback = new MailMessageCallbackImpl();
            messageProcessor.processMessages(callback);
            
            Assert.assertEquals(true, callback.calledJustOnce());
            
            Assert.assertEquals(MailMessageDO.MessageStatus.MULTIPLE_ATTACHMENTS, callback.getMailMessageDO().getStatus());
            
            // validate there are multiple data files
            File dataDir = new File(reportStorageDO.getReportStagingDir());
            Assert.assertNotNull(dataDir.listFiles());
            Assert.assertEquals(2, dataDir.listFiles().length);
            
            // validate there is no data file in storage dir
            File storageDataDir = new File(reportStorageDO.getReportStorageDir());
            Assert.assertNotNull(storageDataDir.listFiles());
            Assert.assertEquals(0, storageDataDir.listFiles().length);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail("caught unexpected Exception while trying to process email." + e.getClass());
        }
    }
    
    @Test
    public void testProcessEmailReply_MultipleAttachments()
    {
        MailMessageProcessor messageProcessor = null;
        List<Message> inbox = null;
        
        try
        {
            MimeMessage message = getMessageWithMultipleAttachments();
            
            messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
            
            messageProcessor.replyAsRejection(
                    message, getMessageBody(message), MessageStatus.MULTIPLE_ATTACHMENTS, true);
            
            // get messages from testmail@level3.com
            inbox = Mailbox.get(originInboxId);
            
            Assert.assertFalse(inbox.isEmpty());
            
            Assert.assertTrue(inbox.size() == 1);
            
            Assert.assertEquals(
                "RE: Returned November Usage and Charges Report for Starbucks", inbox.get(0).getSubject());
            
            // validate contents of body has correct message String
            String messageBody = getMessageBody(inbox.get(0));
            
            Assert.assertTrue(
               messageBody.startsWith("The following email has been returned as email contains multiple attachments"));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail("caught unexpected Exception while trying to process email." + e.getClass());
        }
    }
    
    @Test
    public void testProcessEmailReply_NoAttachment()
    {
        MailMessageProcessor messageProcessor = null;
        List<Message> inbox = null;
        
        try
        {
            MimeMessage message = getMessageWithoutAttachment();
            
            messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
            
            messageProcessor.replyAsRejection(
                    message, getMessageBody(message), MessageStatus.NO_ATTACHMENTS, true);
            
            // get messages from testmail@level3.com
            inbox = Mailbox.get(originInboxId);
            
            Assert.assertFalse(inbox.isEmpty());
            
            Assert.assertTrue(inbox.size() == 1);
            
            Assert.assertEquals(
                "RE: Returned October Usage and Charges Report for Starbucks", inbox.get(0).getSubject());
            
            // validate contents of body has correct message String
            String messageBody = getMessageBody(inbox.get(0));
            
            Assert.assertTrue(
               messageBody.startsWith("The following email has been returned as email contains zero attachments."));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail("caught unexpected Exception while trying to process email." + e.getClass());
        }
    }
    
    @Test
    public void testProcessEmailReply_InvalidData()
    {
        MailMessageProcessor messageProcessor = null;
        List<Message> inbox = null;
        
        try
        {
            MimeMessage message = getMessageWithBadContent();
            
            messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
            
            messageProcessor.replyAsRejection(
                    message, getMessageBody(message), MessageStatus.INVALID_DATA, true);
            
            // get messages from testmail@level3.com
            inbox = Mailbox.get(originInboxId);
            
            Assert.assertFalse(inbox.isEmpty());
            
            Assert.assertTrue(inbox.size() == 1);
            
            Assert.assertEquals(
                "RE: Returned September Usage and Charges Report for Starbucks", inbox.get(0).getSubject());
            
            // validate contents of body has correct message String
            String messageBody = getMessageBody(inbox.get(0));
            
            Assert.assertTrue(
               messageBody.startsWith("The following email has been returned as email does not contain valid data."));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail("caught unexpected Exception while trying to process email." + e.getClass());
        }
    }
    
    public static class MailMessageCallbackImpl implements MailMessageCallbackIF
    {
        private MailMessageDO mailMessageDao = null;
        
        private long counter = 0;
        
        public MailMessageCallbackImpl()
        {
            counter = 0;
        }

        public void receiveMailMessage(MailMessageDO mailMessageDao)
        {
            // TODO Auto-generated method stub
            this.mailMessageDao = mailMessageDao;
            
            counter++;
        }
        
        public MailMessageDO getMailMessageDO()
        {
            return this.mailMessageDao;
        }
        
        public boolean calledJustOnce()
        {
            if(counter == 1)
            {
                return true;
            }
            
            log.info("callback called " + counter + " times.");
            return false;
        }
    }
}
