/**
 * 
 */
package com.level3.etl.cassandra.util;

import java.io.File;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.etl.exception.IncrementErrorCountException;

/**
 * @author nelson.david
 *
 */
public class ColumnExtractTest 
{
	String JSONSampleData = null;
	String JSONSampleData2 = "{\"blankAttribute\":\"\"}";
	String JSONSampleData3 = "{\"decimalZero\":0}";

    private static Logger log = LoggerFactory.getLogger(ColumnExtractTest.class);
    
//    private static final String CASSANDRA_URL_STR = "CASSANDRA_URL"testGetFirstElementJSONObject;
//    private static final String CASSANDRA_CLUSTER_NAME_STR = "CASSANDRA_CLUSTER_NAME";
	
	@Before
	public void setUp() throws Exception {	
		// load sample JSON string
		URL u1 = this.getClass().getResource("/JSONSample.json");
		File f1 = FileUtils.toFile(u1);;
		JSONSampleData = FileUtils.readFileToString(f1, "UTF-8");
		//log.debug(JSONSampleData);
		Assert.assertNotNull("JSON sample file must be found for this test to work.",JSONSampleData);
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getBigDecimalValue(me.prettyprint.hector.api.beans.Row, java.lang.String)}.
	 */
	@Test
	public void testTruncateStringToByteLimit() {
		//example string that contains 5 characters: double, single, single, single, double
		String s = "\uFFC3\uFFA1\u0062\u0063\u0065\uFFC3\uFF8A";
		int maxLength = 11;
		byte[] bytearray;
		long actualValue;
		
		long expectedValue = 11;
		try {
			log.debug("[" + s + "]");
			String news = ColumnExtract.truncateStringToByteLimit(s, maxLength);
			log.debug("[" + news + "]");
			bytearray = news.getBytes("UTF-8");
			actualValue = bytearray.length;
			log.debug("byte array length " + actualValue);
//			Assert.assertEquals("Byte count should match",expectedValue, actualValue);
			Assert.assertTrue("Byte count is <= MaxLength", (actualValue <= expectedValue));
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
/*		
		try {
			actualValue = ColumnExtract.getJSONAttributeBigDecimalValue(JSONSampleData
					, "Non-existent");
		} catch (Throwable e) {
			Assert.fail("Non-existent BigDecimal attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Non-existent BigDecimal attribute should return 0.", expectedValue, actualValue);
		log.debug("[Pass] Non-existent BigDecimal attribute produced 0 as expected.");
	*/
		
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getBigDecimalValue(me.prettyprint.hector.api.beans.Row, java.lang.String)}.
	 */
	@Test
	public void testGetBigDecimalValue_NonExistent() {
		BigDecimal expectedValue = BigDecimal.ZERO;
		BigDecimal actualValue = BigDecimal.ZERO;
		try {
			actualValue = ColumnExtract.getJSONAttributeBigDecimalValue(JSONSampleData
					, "Non-existent");
		} catch (Throwable e) {
			Assert.fail("Non-existent BigDecimal attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Non-existent BigDecimal attribute should return 0.", expectedValue, actualValue);
		log.debug("[Pass] Non-existent BigDecimal attribute produced 0 as expected.");
	}
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getBigDecimalValue(me.prettyprint.hector.api.beans.Row, java.lang.String)}.
	 */
	@Test
	public void testGetBigDecimalValue_Blank() {
		BigDecimal expectedValue = BigDecimal.ZERO;
		BigDecimal actualValue = BigDecimal.ZERO;
		try {
			actualValue = ColumnExtract.getJSONAttributeBigDecimalValue(JSONSampleData
					, "blankAttribute");
		} catch (Throwable e) {
			Assert.fail("Blank BigDecimal attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Blank BigDecimal attribute should return 0.", expectedValue, actualValue);
		log.debug("[Pass] Blank BigDecimal attribute produced 0 as expected.");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
	public void testGetJSONAttributeBigDecimalValue_Good() {
		BigDecimal expectedValue = new BigDecimal("1062.20");
		BigDecimal actualValue = null;
		try {
			//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "order.detail.general.DiscountedMRC") + "'");
			actualValue = ColumnExtract.getJSONAttributeBigDecimalValue(JSONSampleData
					, "order.detail.general.DiscountedMRC");
		} catch (Throwable e) {
			Assert.fail("Good BigDecimal attribute produced unexpected exception: " + e.getClass());
		}
		int compareToResult = actualValue.compareTo(expectedValue);
		Assert.assertEquals("Good BigDecimal attribute doesn't match expected value.", 0, compareToResult);
		log.debug("[Pass] Good BigDecimal attribute produced valid value as expected.");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
	public void testGetJSONAttributeBigDecimalValue_GoodZero() {
		BigDecimal expectedValue = new BigDecimal("0");
		BigDecimal actualValue = null;
		try {
			//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "order.detail.general.DiscountedMRC") + "'");
			actualValue = ColumnExtract.getJSONAttributeBigDecimalValue(JSONSampleData3
					, "decimalZero");
		} catch (Throwable e) {
			Assert.fail("GoodZero BigDecimal attribute produced unexpected exception: " + e.getClass());
		}
		int compareToResult = actualValue.compareTo(expectedValue);
		Assert.assertEquals("GoodZero BigDecimal attribute doesn't match expected value.", 0, compareToResult);
		log.debug("[Pass] GoodZero BigDecimal attribute produced valid value as expected.");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetJSONAttributeBigDecimalValue_Bad() {
		BigDecimal actualValue = null;
		try {
			actualValue = ColumnExtract.getJSONAttributeBigDecimalValue(JSONSampleData
					, "order.detail.general.orderType");
		} catch (IncrementErrorCountException e) {
			log.debug("[Pass] Bad BigDecimal threw IncrementErrorCountException as expected.  '" + e.getMessage() + "'");
			return;
		} catch (Throwable e) {
			Assert.fail("Bad BigDecimal attribute produced unexpected exception: " + e.getClass());
			return;
		}
		Assert.fail("Bad BigDecimal produced unexpected value [" + actualValue + "].");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
    public void testGetJSONAttributeBigDecimalValue_NullString()
    {
		BigDecimal expectedValue = new BigDecimal("0");
		BigDecimal actualValue = null;
        try
        {
            actualValue = ColumnExtract.getJSONAttributeBigDecimalValue(
                    JSONSampleData, "order.detail.general.testNullBigDecimalValue");
            
            Assert.assertEquals("Null String should return -999.", expectedValue, actualValue);
        }
        catch (Throwable e)
        {
            Assert.fail("Null String attribute produced unexpected exception: " + e.getClass());
        }
    }
	
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getDoubleValue(me.prettyprint.hector.api.beans.Row, java.lang.String)}.
	 */
	@Test
	public void testGetDoubleValue_NonExistent() {
		Double expectedValue = new Double(-999);
		Double actualValue = new Double(-999);
		try {
			actualValue = ColumnExtract.getJSONAttributeDoubleValue(JSONSampleData
					, "Non-existent");
		} catch (Throwable e) {
			Assert.fail("Non-existent Double attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Non-existent Double attribute should return -999.", expectedValue, actualValue);
		log.debug("[Pass] Non-existent Double attribute produced -999 as expected.");
	}
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getDoubleValue(me.prettyprint.hector.api.beans.Row, java.lang.String)}.
	 */
	@Test
	public void testGetDoubleValue_Blank() {
		Double expectedValue = new Double(-999);
		Double actualValue = new Double(-999);
		try {
			actualValue = ColumnExtract.getJSONAttributeDoubleValue(JSONSampleData
					, "blankAttribute");
		} catch (Throwable e) {
			Assert.fail("Blank Double attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Blank Double attribute should return -999.", expectedValue, actualValue);
		log.debug("[Pass] Blank Double attribute produced -999 as expected.");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
	public void testGetJSONAttributeDoubleValue_Good() {
		Double expectedValue = new Double("1062.20");
		Double actualValue = null;
		try {
			//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "order.detail.general.DiscountedMRC") + "'");
			actualValue = ColumnExtract.getJSONAttributeDoubleValue(JSONSampleData
					, "order.detail.general.DiscountedMRC");
		} catch (Throwable e) {
			Assert.fail("Good Double attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Good Double attribute doesn't match expected value.", expectedValue, actualValue);
		log.debug("[Pass] Good Double attribute produced valid value as expected.");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
	public void testGetJSONAttributeDoubleValue_GoodZero() {
		Double expectedValue = new Double("0.00");
		Double actualValue = null;
		try {
			//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "order.detail.general.DiscountedMRC") + "'");
			actualValue = ColumnExtract.getJSONAttributeDoubleValue(JSONSampleData3
					, "decimalZero");
		} catch (Throwable e) {
			Assert.fail("GoodZero Double attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("GoodZero Double attribute doesn't match expected value.", expectedValue, actualValue);
		log.debug("[Pass] GoodZero Double attribute produced valid value as expected.");
	}


	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetJSONAttributeDoubleValue_Bad() {
		Double actualValue = null;
		try {
			actualValue = ColumnExtract.getJSONAttributeDoubleValue(JSONSampleData
					, "order.detail.general.orderType");
		} catch (IncrementErrorCountException e) {
			log.debug("[Pass] Bad Double threw IncrementErrorCountException as expected.  '" + e.getMessage() + "'");
			return;
		} catch (Throwable e) {
			Assert.fail("Bad Double attribute produced unexpected exception: " + e.getClass());
			return;
		}
		Assert.fail("Bad Double produced unexpected value [" + actualValue + "].");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
    public void testGetJSONAttributeDoubleValue_NullString()
    {
        Double expectedValue = new Double(-999);
        Double actualValue = new Double(0);
        try
        {
            actualValue = ColumnExtract.getJSONAttributeDoubleValue(
                    JSONSampleData, "order.detail.general.testNullDoubleValue");
            
            Assert.assertEquals("Null String should return -999.", expectedValue, actualValue);
        }
        catch (Throwable e)
        {
            Assert.fail("Null String attribute produced unexpected exception: " + e.getClass());
        }
    }
	
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
    public void testGetJSONAttributeDateValue_NonExistent()
    {
        BigDecimal expectedValue = null;
        BigDecimal actualValue = null;
        try
        {
            actualValue = ColumnExtract.getJSONAttributeDateValue(JSONSampleData, "Non-existent");
        }
        catch (Throwable e)
        {
            Assert.fail("Non-existent date attribute produced unexpected exception: " + e.getClass());
        }
        Assert.assertEquals("Non-existent date attribute should return null.", expectedValue, actualValue);
    }

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
    public void testGetJSONAttributeDateValue_Null()
    {
        BigDecimal expectedValue = null;
        BigDecimal actualValue = null;
        try
        {
            actualValue = ColumnExtract.getJSONAttributeDateValue(JSONSampleData, "blankAttribute");
        }
        catch (Throwable e)
        {
            Assert.fail("Blank date attribute produced unexpected exception: "+ e.getClass());
        }
        Assert.assertEquals("Blank date attribute should return null.", expectedValue, actualValue);
    }

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
    public void testGetJSONAttributeDateValue_NullString()
    {
        BigDecimal actualValue = new BigDecimal(1);
        try
        {
            actualValue =
                    ColumnExtract.getJSONAttributeDateValue(
                            JSONSampleData, 
                            "order.detail.general.lastModifiedTimestamp");
            Assert.assertNull("Null String for date returns null value", actualValue);
        }
        catch (Throwable e)
        {
            Assert.fail("Blank date attribute produced unexpected exception: "+ e.getClass());
        }
    }

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
    public void testGetJSONAttributeDateValue_Good()
    {
        BigDecimal expectedValue = null;
        BigDecimal actualValue = null;
        try
        {
            Date dateValue = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse("2013-01-31T00:00:00");
            expectedValue = new BigDecimal(dateValue.getTime()); 
            
            actualValue = ColumnExtract.getJSONAttributeDateValue(
                    JSONSampleData,
                    "order.detail.general.orderDate.customerSignedDate");
        }
        catch (Throwable e)
        {
            Assert.fail("Good date attribute produced unexpected exception: "
                    + e.getClass());
        }
        Assert.assertEquals(
                "Good date attribute doesn't match expected value.",
                expectedValue, actualValue);
        log.debug("[Pass] Good date attribute produced valid value as expected.");
    }

	@Test
    public void testGetJSONAttributeDateValue_CustomFormat()
    {
        BigDecimal expectedValue = null;
        BigDecimal actualValue = null;
        String xmlString = 
                "<?xml version=\"1.0\"?> <TASK><TASK_ID>2845940</TASK_ID><SOURCE_LAST_MODIFY_DT>06/18/2013 19:56:05.020003 </SOURCE_LAST_MODIFY_DT><DW_ACTION_CD>UPSERT</DW_ACTION_CD></TASK>";
        try
        {
            String[] dateFormats = {"MM/dd/yyyy HH:mm:ss.SSS"};
            Date dateValue = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss.SSS").parse("06/18/2013 19:56:05.020003");
            expectedValue = new BigDecimal(dateValue.getTime()); 
            
            String jsonString = ColumnExtract.convertXMLToJSON(xmlString);
            actualValue = ColumnExtract.getJSONAttributeDateValue(
                    jsonString,
                    "TASK.SOURCE_LAST_MODIFY_DT",
                    dateFormats);
            
            log.info("" + actualValue);
        }
        catch (Throwable e)
        {
            Assert.fail("Custom date format produced unexpected exception: " + e.getClass());
        }
        Assert.assertEquals(
                "Custom date format match expected value.", expectedValue, actualValue);
        log.debug("[Pass] Custom date format produced valid value as expected.");
    }
	
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
	public void testGetJSONAttributeDateValue_Bad() {
		BigDecimal actualValue = null;
		try {
			actualValue = ColumnExtract.getJSONAttributeDateValue(JSONSampleData
					, "order.detail.customer.customerName");
		} catch (IncrementErrorCountException e) {
			log.debug("[Pass] Bad Date threw IncrementErrorCountException as expected.  '" + e.getMessage() + "'");
			return;
		} catch (Throwable e) {
			Assert.fail("Bad date attribute produced unexpected exception: " + e.getClass());
			return;
		}
		Assert.fail("Bad date produced unexpected value [" + actualValue + "].");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetJSONAttributeIntegerValue_NonExistent() {
		int expectedValue = -999;
		int actualValue = 0;
		//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "Non-existent") + "'");
		try {
			actualValue = ColumnExtract.getJSONAttributeIntegerValue(JSONSampleData
					, "Non-existent");
		} catch (Throwable e) {
			Assert.fail("Non-existent int attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Non-existent int should return -999.",expectedValue,actualValue);
		log.debug("[Pass] Non-existent BigDecimal attribute produced -999 as expected.");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetJSONAttributeIntegerValue_Blank() {
		int expectedValue = -999;
		int actualValue = 0;
		//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "Non-existent") + "'");
		try {
			actualValue = ColumnExtract.getJSONAttributeIntegerValue(JSONSampleData
					, "blankAttribute");
		} catch (Throwable e) {
			Assert.fail("Blank int attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Blank int should return -999.",expectedValue,actualValue);
		log.debug("[Pass] Blank int attribute produced null as expected.");
	}
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetJSONAttributeIntegerValue_Good() {
		int expectedValue = 5280;
		int actualValue = 0;
		//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "Non-existent") + "'");
		try {
			actualValue = ColumnExtract.getJSONAttributeIntegerValue(JSONSampleData
					, "order.detail.general.proposalNumber");
		} catch (Throwable e) {
			Assert.fail("Good int attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Good int doesn't match.",expectedValue,actualValue);
		log.debug("[Pass] Good int attribute produced valid value as expected.");
	}
	
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetJSONAttributeIntegerValue_Bad() {
		int actualValue = 0;
		try {
			actualValue = ColumnExtract.getJSONAttributeIntegerValue(JSONSampleData
					, "order.detail.general.orderType");
		} catch (IncrementErrorCountException e) {
			log.debug("[Pass] Bad int threw IncrementErrorCountException as expected.  '" + e.getMessage() + "'");
			return;
		} catch (Throwable e) {
			Assert.fail("Bad int attribute produced unexpected exception: " + e.getClass());
			return;
		}
		Assert.fail("Bad int produced unexpected value [" + actualValue + "].");
	}

	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeIntegerValue(java.lang.String, java.lang.String)}.
	 */
	@Test
    public void testGetJSONAttributeIntegerValue_NullString()
    {
        int expectedValue = -999;
        int actualValue = 0;
        try
        {
            actualValue = ColumnExtract.getJSONAttributeIntegerValue(
                    JSONSampleData, "order.detail.general.testNullIntValue");
            
            Assert.assertEquals("Null String should return -999.", expectedValue, actualValue);
        }
        catch (Throwable e)
        {
            Assert.fail("Null String attribute produced unexpected exception: " + e.getClass());
        }
    }
	
	/**
	 * Test method for {@link com.level3.etl.cassandra.util.ColumnExtract#getJSONAttributeDateValue(java.lang.String, java.lang.String, java.lang.String[])}.
	 */
	@Test
	public void testGetJSONAttributeStringValue_Good() {
//		String expectedValue = "TESTUSER";
		String expectedValue = "/oe-platfor[TR]";
		String actualValue = null;
		try {
			//log.debug("value='" + ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "order.detail.general.DiscountedMRC") + "'");
			actualValue = ColumnExtract.getJSONAttributeStringTruncatedValue(JSONSampleData
//					, "order.detail.general.orderStatus", 8);
					, "order.orderIdentifier.orderURL", 15);
			
			log.debug("Actual value " + actualValue + ", length " + actualValue.length());
			log.debug("Actual value " + actualValue + ", length as UTF-8 " + actualValue.getBytes("UTF-8").length);
		} catch (Throwable e) {
			Assert.fail("Good String attribute produced unexpected exception: " + e.getClass());
		}
		Assert.assertEquals("Good String attribute doesn't match expected value.", expectedValue, actualValue);
		log.debug("[Pass] Good String attribute produced valid value as expected.");
	}
	
	/**
	 * Test XML conversion to JSON and unzip flatContentElement, test method for 
	 * {@link com.level3.etl.cassandra.util.ColumnExtract#getDecompressedContent(String, String) getDecompressedContent(String, String)}
	 */
	@Test
	public void testUnzipJSONContent()
	{
	    try
	    {
	        URL u1 = this.getClass().getResource("/TaskXMLSample5-Gzip.xml");
	        File f1 = FileUtils.toFile(u1);;
	        String xmlContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String jsonString = ColumnExtract.convertXMLToJSON(xmlContent);
//	        log.info(new JSONObject(jsonString).toString(3));
	        String content = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.content.content");
	        String contentEncoding = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.contentEncoding");
	        
	        String contentUnzipped = ColumnExtract.getDecompressedContent(content, contentEncoding);
//	        log.info(new JSONArray(content).toString(3));
	        log.info("Content \n" +new JSONObject(contentUnzipped).toString(3));
	        Assert.assertNotNull(contentUnzipped);
	        
	        String flatContent = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.flatContent.content");
	        String flatContentEncoding = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.flatContentEncoding");
	        
	        String flatContentUnzipped = ColumnExtract.getDecompressedContent(flatContent, flatContentEncoding);
//	        log.info(new JSONArray(content).toString(3));
	        log.info("FlatContent \n" +new JSONObject(flatContentUnzipped).toString(3));
	        Assert.assertNotNull(flatContentUnzipped);
	        
	        String diffContent = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.difference.content");
	        String diffContentEncoding = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.differenceEncoding");
	        
	        String diffContentUnzipped = ColumnExtract.getDecompressedContent(diffContent, diffContentEncoding);
	        log.info("Difference Content \n" + new JSONArray(diffContentUnzipped).toString(3));
//	        log.info(new JSONObject(diffContentUnzipped).toString(3));
	        Assert.assertNotNull(diffContentUnzipped);
	    }
	    catch(Exception ex)
	    {
	        ex.printStackTrace();
	        Assert.fail("exception while testing testUnzipJSONContent " + ex.getMessage());
	    }
	}
	
	/**
	 * Test XML conversion to JSON and unzip flatContentElement, test method for 
	 * {@link com.level3.etl.cassandra.util.ColumnExtract#getDecompressedContent(String, String) getDecompressedContent(String, String)}
	 */
	@Test
	public void testUnzipJSONContentBadFlatContent()
	{
	    try
	    {
	        URL u1 = this.getClass().getResource("/TaskXMLBadFlatContent.xml");
	        File f1 = FileUtils.toFile(u1);;
	        String xmlContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String jsonString = ColumnExtract.convertXMLToJSON(xmlContent);
	        log.debug("JSON for XML is \n" + new JSONObject(jsonString).toString(3));
	        
	        String flatContent = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.flatContent.content");
	        String flatContentEncoding = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.flatContentEncoding");
	        String unZippedContent = ColumnExtract.getDecompressedContent(flatContent, flatContentEncoding);
	        log.debug("Unzipped flat content is \n" + new JSONObject(unZippedContent).toString(3));
	        Assert.assertNotNull(unZippedContent);
	        
	        String content = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.content.content");
	        String contentEncoding = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.contentEncoding");
	        unZippedContent = ColumnExtract.getDecompressedContent(content, contentEncoding);
	        log.debug("Unzipped content is \n" + new JSONObject(unZippedContent).toString(3));
	        Assert.assertNotNull(unZippedContent);
	        
	        String diffContent = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.difference.content");
	        String diffContentEncoding = ColumnExtract.getJSONAttributeStringValue(jsonString, "dataChange.differenceEncoding");
	        unZippedContent = ColumnExtract.getDecompressedContent(diffContent, diffContentEncoding);
	        log.debug("Unzipped diff content is \n" + new JSONArray(unZippedContent).toString(3));
	        Assert.assertNotNull(unZippedContent);
	    }
	    catch(Exception ex)
	    {
	        ex.printStackTrace();
	        Assert.fail("exception while testing testUnzipJSONContentBadFlatContent " + ex.getMessage());
	    }
	}
	
	/**
	 * Test conversion of cassandra row to JSON string, test method for
	 * {@link com.level3.etl.cassandra.util.ColumnExtract#convertRowToJSON(me.prettyprint.hector.api.beans.Row) convertRowToJSON(me.prettyprint.hector.api.beans.Row)}
	@Test
	public void testConvertRowToJSON()
	{
        try
        {
            GenericCFManager manager = 
                    new GenericCFManager(
                            100,
                            PropertyManager.instance().getProperty("OE", CASSANDRA_URL_STR),
                            "OE",
                            PropertyManager.instance().getProperty("OE", CASSANDRA_CLUSTER_NAME_STR),
                            "slob_archive");
//                    new GenericCFManager(100, "oestore01.env4:9160", "OE", "oestore_env4", "slob_archive");
//                    new GenericCFManager(100, "wfstore01.env4:9160", "wfp", "wfstore_env4", "workflow");

            manager.pullOneRowWithCallback( new GenericRowCallbackIF() {
                
                public void receiveRow(Row<String, String, String> row)
                {
                    log.debug("Row is " + row.toString());
                    String rowString = ColumnExtract.convertRowToJSONWithTimeStamp(row);
                    try
                    {
                        log.debug("JSON String is " + new JSONObject(rowString).toString(3));
                    }
                    catch(Exception ex)
                    {

                    }

                    Assert.assertNotNull(rowString);
                    Assert.assertTrue(rowString.contains("rowkey"));
                }
            } );
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testConvertRowToJSON()" + ex.getMessage());
        }
	}
	*/
	
	/**
	 * Test extraction of nested attribute value for JSON
	 */
	@Test
	public void testJSONNestedAttributeValue()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/NestedAttributeJSON.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "keys.value", "proposalNumber");
	        
	        Assert.assertEquals("Nested Attribute Retrival Test", "9068", returnValue);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testJSONNestedAttributeValue()" + ex.getMessage());
        }
	}
	
	@Test
	public void testJSONNestedAttributeValue_IgnoreCase()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/NestedAttributeJSON.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "keys.value", "proposalNumber");
	        
	        Assert.assertEquals("Nested Attribute Retrival Test", "9068", returnValue);
	        
	        String returnValue2 = ColumnExtract.getJSONAttributeStringValue(jsonContent, "keys.value", "PrOpOsAlnumber");
	        
	        Assert.assertEquals("Nested Attribute Retrival Test Ignore Case", returnValue, returnValue2);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testJSONNestedAttributeValue_IgnoreCase()" + ex.getMessage());
        }
	}
	/**
	 * Test extraction of nested attribute value for JSON
	 */
	@Test
	public void testJSONNestedAttributeValue2()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/NestedAttributeJSON-2.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "keys.value", "workOrderNumber");
	        
	        Assert.assertEquals("Nested Attribute Retrival Test 2", "a5efa64f-98c3-4355-a806-c11bfcf40a7d", returnValue);
	        
	        returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "keys.value", "orderNumber");
	        
	        Assert.assertEquals("Nested Attribute Retrival Test 2", "1006DXTH", returnValue);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testJSONNestedAttributeValue2()" + ex.getMessage());
        }
	}
	
	@Test
	public void testMultiColumnJson_WithValueAndColumnTimeStampInArray()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/MultiValueJSON.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONOfMultiColumnSet(jsonContent, "workflowSubProcessId\\|(.+)");
	        
	        Assert.assertNotNull(returnValue);
	        
	        JSONArray jsonArray = new JSONArray(returnValue);
	        
	        log.debug(jsonArray.toString(3));
	        
	        Assert.assertTrue(jsonArray instanceof JSONArray);
	        
	        Assert.assertEquals(4, jsonArray.length());
	        for(int index = 0; index < jsonArray.length(); ++index)
	        {
	            JSONObject jsonObject = jsonArray.getJSONObject(index);
	            
	            Assert.assertFalse(jsonObject.getString("ColumnName").startsWith("workflowSubProcessId"));
	        }
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testMultiColumnJSON_WithValueAndColumnTimeStampInArray()" + ex.getMessage());
        }
	}
	
	@Test
	public void testMultiColumnJson_KeyValuePair()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/MultiValueJSON-2.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONOfMultiColumnSet(jsonContent, "taskId\\|(.+)");
	        
	        Assert.assertNotNull(returnValue);
	        
	        JSONArray jsonArray = new JSONArray(returnValue);
	        
	        log.debug(jsonArray.toString(3));
	        
	        Assert.assertTrue(jsonArray instanceof JSONArray);
	        
	        Assert.assertEquals(3, jsonArray.length());
	        for(int index = 0; index < jsonArray.length(); ++index)
	        {
	            JSONObject jsonObject = jsonArray.getJSONObject(index);
	            
	            Assert.assertFalse(jsonObject.getString("ColumnName").startsWith("taskId"));
	        }
        }
        catch (Exception ex)
        {
            log.error("caught exception", ex);
            Assert.fail("caught exception in testMultiColumnJSON_KeyValuePair()" + ex.getMessage());
        }
	}
	
	@Test
	public void testMultiColumnJson_IgnoreCase()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/MultiValueJSON-2.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONOfMultiColumnSet(jsonContent, "childProcessId\\|(.+)");
	        
	        Assert.assertNotNull(returnValue);
	        
	        JSONArray jsonArray = new JSONArray(returnValue);
	        
	        Assert.assertTrue(jsonArray instanceof JSONArray);
	        
	        Assert.assertEquals(1, jsonArray.length());
	        
	        String returnValue2 = ColumnExtract.getJSONOfMultiColumnSet(jsonContent, "ChIldPrOceSsId\\|(.+)");
	        
	        Assert.assertNotNull(returnValue2);
	        
	        JSONArray jsonArray2 = new JSONArray(returnValue2);
	        
	        Assert.assertTrue(jsonArray2 instanceof JSONArray);
	        
	        Assert.assertEquals(1, jsonArray2.length());
        }
        catch (Exception ex)
        {
            log.error("caught exception", ex);
            Assert.fail("caught exception in testMultiColumnJSON_KeyValuePair()" + ex.getMessage());
        }
	}
	
	@Test
	public void testMultiColumnJson_NoGroup()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/MultiValueJSON.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONOfMultiColumnSet(jsonContent, "workflowSubProcessId\\|.+");
	        
	        Assert.assertNotNull(returnValue);
	        
	        JSONArray jsonArray = new JSONArray(returnValue);
	        
	        log.debug(jsonArray.toString(3));
	        
	        Assert.assertTrue(jsonArray instanceof JSONArray);
	        
	        Assert.assertEquals(4, jsonArray.length());
	        
	        for(int index = 0; index < jsonArray.length(); ++index)
	        {
	            JSONObject jsonObject = jsonArray.getJSONObject(index);
	            
	            Assert.assertTrue(jsonObject.getString("ColumnName").startsWith("workflowSubProcessId"));
	        }
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testMultiColumnJson_NoGroup()" + ex.getMessage());
        }
	}
	
	/** - 4/7/2014
	@Test
	public void testMultiColumnJson_ForRow()
	{
        try
        {
//	        String returnValue = ColumnExtract.getJSONOfMultiColumnSet(jsonContent, "workflowSubProcessId\\|(.+)");
            GenericCFManager manager = 
                    new GenericCFManager(
                            100,
                            PropertyManager.instance().getProperty("WORKFLOW", CASSANDRA_URL_STR),
                            "wfp",
                            PropertyManager.instance().getProperty("WORKFLOW", CASSANDRA_CLUSTER_NAME_STR),
                            "workflow");

            manager.pullAllRowsWithCallback( new GenericRowCallbackIF() {
                
                public void receiveRow(Row<String, String, String> row)
                {
                    if(row.toString().contains("workflowSubProcessId"))
                    {
//                        log.debug("Row is " + row.toString());
                        String returnValue = ColumnExtract.getJSONOfMultiColumnSet(row, "workflowSubProcessId\\|.+");
                        
                        log.debug(returnValue);
                    }
                }
            } );
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testMultiColumnJSON()" + ex.getMessage());
        }
	}
	**/
	
	@Test
	public void testAttrbiuteNotPresent()
	{
        try
        {
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "nitin.value");
	        
	        Assert.assertNull(returnValue);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testAttributeNotPresent()" + ex.getMessage());
        }
	    
	}
	
	@Test
	public void testGetAttributeJSONArray()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/JSONSampleArray.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "ColumnName");
	        
	        Assert.assertNotNull(returnValue);
	        
	        Assert.assertEquals("Array value found", "8009149:1524252:36028797018964766", returnValue);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testGetAttributeJSONArray()" + ex.getMessage());
        }
	}
	
	@Test
	public void testGetAttributeJSONArray_NotPresent()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/JSONSampleArray.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "NotPresent");
	        
	        Assert.assertNull(returnValue);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testGetAttributeJSONArray_NotPresent()" + ex.getMessage());
        }
	}
	
	/*
	@Test
	public void testGetFirstElementJSONObject()
	{
        try
        {
	        String returnValue = ColumnExtract.getJSONFirstElementName(JSONSampleData);
	        
	        Assert.assertEquals("order", returnValue);
	        
	        URL u1 = this.getClass().getResource("/JSONSampleArray.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue2 = ColumnExtract.getJSONFirstElementName(jsonContent);
	        Assert.assertEquals("ColumnValue", returnValue2);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testGetAttributeJSONArray_NotPresent()" + ex.getMessage());
        }
	}
	*/
	
	@Test
	public void testGetJSONAttributeStringValue_IgnoreCase()
	{
        try
        {
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "order.orderIdentifier.orderNumber");
	        
	        Assert.assertEquals("1005TGXY", returnValue);
	        
	        String returnValue2 = ColumnExtract.getJSONAttributeStringValue(JSONSampleData, "Order.OrderIdentifier.Ordernumber");
	        
	        Assert.assertEquals(returnValue, returnValue2);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testGetJSONAttributeStringValue_IgnoreCase()" + ex.getMessage());
        }
	}
	
	@Test
	public void testGetAttributeJSONArray_IgnoreCase()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/JSONSampleArray.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "ColumnValue");
	        
	        Assert.assertEquals("Array value found", "1524252", returnValue);
	        
	        String returnValue2 = ColumnExtract.getJSONAttributeStringValue(jsonContent, "colUmnvAlue");
	        
	        Assert.assertEquals("Array value matches, Ignore case", returnValue, returnValue2);
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testGetAttributeJSONArray_IgnoreCase()" + ex.getMessage());
        }
	}
	
	@Test
	public void test_getJsonString()
	{
	    try
	    {
	        String expectedCustomerName = "Sunday UAT";
	        String actualCustomerName =
	                ColumnExtract.getJsonString(JSONSampleData, "order.detail.customer.customerName");
	        Assert.assertEquals("Customer Name matches", expectedCustomerName, actualCustomerName);
	        
	        String expectedOrderType = "Install";
	        String actualOrderType = ColumnExtract.getJsonString(JSONSampleData, "order.detail.general.orderType");
	        Assert.assertEquals("Order Type matches", expectedOrderType, actualOrderType);
	        
	        String nullOrderType = ColumnExtract.getJsonString(JSONSampleData, "order.det.general.orderType");
	        Assert.assertNull("Order Type is null", nullOrderType);
	    }
	    catch(Exception ex)
	    {
	        log.error("caught exception in test_getJsonString()", ex);
            Assert.fail("caught exception in test_getJsonString()" + ex.getMessage());
	    }
	}
	
	@Test
	public void test_getJsonDouble()
	{
	    try
	    {
	        Double expectedDiscountedMRC = 1062.2;
	        Double actualDiscountedMRC =
	                ColumnExtract.getJsonDouble(JSONSampleData, "order.detail.general.DiscountedMRC");
	        Assert.assertEquals("Discounted MRC matches", expectedDiscountedMRC, actualDiscountedMRC);
	        
	        Double nullMrc = ColumnExtract.getJsonDouble(JSONSampleData, "order.det.general.DiscountedMRC");
	        Assert.assertNull("Mrc is null", nullMrc);
	    }
	    catch(Exception ex)
	    {
	        log.error("caught exception in test_getJsonDouble()", ex);
            Assert.fail("caught exception in test_getJsonDouble()" + ex.getMessage());
	    }
	}
	
	
	@Test
	public void test_getJsonInteger()
	{
	    try
	    {
	        Integer expectedAmortizedNRC = 1200;
	        Integer actualAmortizedNRC =
	                ColumnExtract.getJsonInteger(JSONSampleData, "order.detail.general.AmortizedNRC");
	        Assert.assertEquals("Discounted MRC matches", expectedAmortizedNRC, actualAmortizedNRC);
	        
	        Integer nullNrc = ColumnExtract.getJsonInteger(JSONSampleData, "order.det.general.AmortizedNRC");
	        Assert.assertNull("Nrc is null", nullNrc);
	    }
	    catch(Exception ex)
	    {
	        log.error("caught exception in test_getJsonInteger()", ex);
            Assert.fail("caught exception in test_getJsonInteger()" + ex.getMessage());
	    }
	}
	
	@Test
	public void test_getJsonLong()
	{
	    try
	    {
	        Long expectedAmortizedNRC = 1200L;
	        Long actualAmortizedNRC =
	                ColumnExtract.getJsonLong(JSONSampleData, "order.detail.general.AmortizedNRC");
	        Assert.assertEquals("Discounted MRC matches", expectedAmortizedNRC, actualAmortizedNRC);
	        
	        Long nullNrc = ColumnExtract.getJsonLong(JSONSampleData, "order.det.general.AmortizedNRC");
	        Assert.assertNull("Nrc is null", nullNrc);
	    }
	    catch(Exception ex)
	    {
	        log.error("caught exception in test_getJsonLong()", ex);
            Assert.fail("caught exception in test_getJsonLong()" + ex.getMessage());
	    }
	}
	
	@Test
	public void testGenerateUUID()
	{
	    Assert.assertNotNull(ColumnExtract.generateUUID());
	}
	
	@Test
    public void testGetJSONAttributeDateValue_JSONObject_Good()
    {
        BigDecimal expectedValue = null;
        BigDecimal actualValue = null;
        
        try
        {
	        URL u1 = this.getClass().getResource("/MultiValueJSON-2.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        JSONObject jsonObject = new JSONObject(jsonContent);
            Date dateValue = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse("2013-04-27T14:03:18.342Z");
            expectedValue = new BigDecimal(dateValue.getTime()); 
            
            actualValue = ColumnExtract.getJSONAttributeDateValue(jsonObject, "startDate");
        }
        catch (Throwable e)
        {
            Assert.fail("Good date attribute produced unexpected exception: " + e.getClass());
        }
        
        Assert.assertEquals(
                "Good date attribute match expected value.", expectedValue, actualValue);
    }

	@Test
    public void testGetJSONAttributeJsonArrayValue_Good()
    {
        JSONArray actualValue = null;
        
        try
        {
	        URL u1 = this.getClass().getResource("/Journal.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
            actualValue = ColumnExtract.getJSONAttributeJsonArrayValue(jsonContent, "servicePackages.attributes");
            
            Assert.assertTrue("Good JSONArray attribute match expected type", actualValue instanceof JSONArray);
            Assert.assertTrue("Good JSONArray attribute match expected value", actualValue.length() == 2);
        }
        catch (Throwable e)
        {
            Assert.fail("Good JSONArray attribute produced unexpected exception: " + e.getClass());
        }
    }

	@Test
    public void testGetJSONAttributeJsonArrayAsCSVValue_Good()
    {
	    JSONArray jsonArray = null;
        String actualValue = null;
        String expectedValue = "AM_XREF,TEST123";
        
        try
        {
	        URL u1 = this.getClass().getResource("/Journal.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String json = ColumnExtract.getJSONAttributeStringValue(jsonContent, "servicePackages.attributes");
            jsonArray = ColumnExtract.getJSONAttributeJsonArrayValue(json, "tags");
            
            Assert.assertTrue("JSONArray as CSV match expected type", jsonArray instanceof JSONArray);
            Assert.assertTrue("JSONArray as CSV match expected array length", jsonArray.length() == 2);
            
            actualValue = ColumnExtract.getCsv(jsonArray);
            
            Assert.assertEquals("JSONArray as CSV match expected value", expectedValue, actualValue);
            
        }
        catch (Throwable e)
        {
            Assert.fail("JSONArray as CSV produced unexpected exception: " + e.getClass());
        }
    }
	
	@Test
	public void testIsValidJson()
	{
	    Assert.assertFalse("isValidJson() null match", ColumnExtract.isValidJson(null));
	    Assert.assertFalse("isValidJson() empty string match", ColumnExtract.isValidJson(""));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("Hi"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("{Hi"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("Hi}"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("{{Hi}"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("{Hi}}"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("[Hi"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("Hi]"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("[[Hi]"));
	    Assert.assertFalse("isValidJson() random string match", ColumnExtract.isValidJson("{Hi]]"));

        try
        {
	        URL u1 = this.getClass().getResource("/Journal.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        Assert.assertTrue("isValidJson() json string match", ColumnExtract.isValidJson(jsonContent));

	        String json = ColumnExtract.getJSONAttributeStringValue(jsonContent, "servicePackages.attributes");
	        Assert.assertTrue("isValidJson() json array match", ColumnExtract.isValidJson(json));
        }
        catch (Throwable e)
        {
            Assert.fail("isValidJson produced unexpected exception: " + e.getClass());
        }
	}

	/*
	@Test
	public void testGetResourceFromURL()
	{
	    String httpUrl = "http://oews-dev3.level3.com/oe-platform-app/Order/OrderTree/Published/1006BGSB";
	    
	    ClientResponse clientResponse = ColumnExtract.getResourceFromUrl(httpUrl);
	    
	    Assert.assertEquals(ClientResponse.Status.OK, clientResponse.getClientResponseStatus());
	    Assert.assertNotNull(clientResponse.getEntity(String.class));
	}
	
	@Test
	public void testJsonGetString()
	{
//	    String jsonString = "{\"entityKey\":\"5720588\",\"lastModifiedTimestamp\":\"2013-08-28T07:11:19.601Z\",\"name_en-US\":\"O2S_Wait_for_Validate_Exit_Criteria\",\"processInstanceIds\":\"solrjson:[\"O2S_Install_Customer_Service--1.0--6154\"]\",\"queueId\":\"SYSTEM-Workflow.Q.WorkflowAutomation\",\"outputContent\":\"rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAKeA==\",\"inputContent\":\"rO0ABXNyABNqYXZhLnV0aWwuQXJyYXlMaXN0eIHSHZnHYZ0DAAFJAARzaXpleHAAAAAAdwQAAAAKeA==\",\"processId|1YwDv-o0by-2F0LaTPQE6\":\"5761076\",\"id\":\"5720588\",\"taskModelID\":\"ORDER_TO_SERVICE--O2S_Wait_for_Validate_Exit_Criteria--1.0\",\"expectedStartDate\":\"2013-08-28T11:11:19.444Z\",\"archived\":\"false\",\"skipable\":\"false\",\"activationTime\":\"2013-08-28T07:11:19.480Z\",\"actionable\":\"true\",\"priority\":\"50\",\"inputType\":\"java.util.list\",\"outputType\":\"java.util.list\",\"bizadminUsers\":\"solrjson:[\"SYSTEM-wfp.workflow\"]\",\"pausedForCompensation\":\"false\",\"compensationTask\":\"false\",\"unplannedWork\":\"false\",\"status\":\"Created\",\"expectedCompletionDate\":\"2013-08-28T11:11:19.444Z\",\"createdOn\":\"2013-08-28T07:11:19.480Z\",\"workflowId\":\"5761072\",\"taskModelId\":\"ORDER_TO_SERVICE--O2S_Wait_for_Validate_Exit_Criteria--1.0\",\"previousStatus\":\"Created\",\"subject_en-US\":\"Wait for Validate Exit Criteria\",\"riskIndicator\":\"1\"}";
//	    String jsonToMap = jsonString.replaceAll("solrjson:\\[\\\"", "").replaceAll("\\\"]", "");
//	    Integer ek = ColumnExtract.getJsonInteger(jsonToMap, "entityKey");
//	    System.out.println("" + ek);
//            
//	    String aa = ColumnExtract.getJsonString(jsonToMap, "actioable");
//	    System.out.println("" + aa);
	    
	    try
        {
            JSONObject jsonObject = new JSONObject(JSONSampleData);
            
            log.info(jsonObject.optJSONObject("order").optJSONObject("detail").optJSONObject("customer").optString("customerName"));
            log.info(jsonObject.optJSONObject("order").optJSONObject("detail").optJSONObject("general").optJSONObject("orderDate").optString("customerSignedDate"));
            JSONObject dateObject = 
                jsonObject.optJSONObject("order").optJSONObject("detail").optJSONObject("general").optJSONObject("orderDate");
            log.info(ColumnExtract.getJSONAttributeDateValue(dateObject, "customerSignedDate").toString());
        }
        catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	}
	
	@Test
	public void testGetClusterStateJSON()
    {
        try
        {
            URL u1 = this.getClass().getResource("/clusterstate.json");
            File f1 = FileUtils.toFile(u1);;
            String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
            
            JSONObject json = new JSONObject(jsonContent);
            
            log.info(json.toString(3));
            
            String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "znode.data.tnlookupcore.shards.shard1.replicas");
            
            JSONObject jsonShard1 = new JSONObject(returnValue);
            log.info("SHARD 1\n" + jsonShard1.toString(3));
            
            log.info("SHARD 1 REPLICA 1\n" + jsonShard1.get("10.5.148.89:8080_tnlookupcore_tnlookupcore"));
            
            JSONObject jsonShard1ValueObject = jsonShard1.getJSONObject("10.5.148.89:8080_tnlookupcore_tnlookupcore");
            
            log.info("SHARD 1 REPLICA 1 STATE " + jsonShard1ValueObject.getString("state"));
            
//            Iterator iter = jsonShard1.keys();
//            
//            while(iter.hasNext())
//            {
//                log.info("SHARD 1 REPLICA 1 KEY " + iter.next().toString());
//            }
            
            
            
//            log.debug("[" + returnValue + "]");
            
//          Assert.assertEquals("Array value found", "1524252", returnValue);
//          
//          String returnValue2 = ColumnExtract.getJSONAttributeStringValue(jsonContent, "colUmnvAlue");
//          
//          Assert.assertEquals("Array value matches, Ignore case", returnValue, returnValue2);
        }
        catch (Exception ex)
        {
            log.error("caught exception" + ex.getMessage(), ex);
            Assert.fail("caught exception in testGetAttributeJSONArray_IgnoreCase()" + ex.getMessage());
        }
    }
	
	@Test
	public void testGetAttributeJSONString_DuplicateAttribute()
	{
        try
        {
	        URL u1 = this.getClass().getResource("/JSONWithDuplicateValues.json");
	        File f1 = FileUtils.toFile(u1);;
	        String jsonContent = FileUtils.readFileToString(f1, "UTF-8");
	        
	        String returnValue = ColumnExtract.getJSONAttributeStringValue(jsonContent, "concatenated");
	        
	        log.debug("[" + returnValue + "]");
	        
//	        Assert.assertEquals("Array value found", "1524252", returnValue);
//	        
//	        String returnValue2 = ColumnExtract.getJSONAttributeStringValue(jsonContent, "colUmnvAlue");
//	        
//	        Assert.assertEquals("Array value matches, Ignore case", returnValue, returnValue2);
        }
        catch (Exception ex)
        {
            log.error("caught exception" + ex.getMessage(), ex);
            Assert.fail("caught exception in testGetAttributeJSONArray_IgnoreCase()" + ex.getMessage());
        }
	}
	
	 * constructs to help with searching for data in Cassandra to create sample test data
	 * 
	@Test
	public void testMultiValueJsonArray()
	{
        try
        {
            GenericCFManager manager = 
                    new GenericCFManager(100, "wfstore01.env4:9160", "wfp", "wfstore_env4", "workflow");

            manager.pullAllRowsWithCallback( new GenericRowCallbackIF() {
                
                public void receiveRow(Row<String, String, String> row)
                {
                    if(row.toString().contains("workflowSubProcessId"))
//                    if(row.toString().contains("keys"))
//                    if(row.toString().contains("1000488"))
//                    if(row.getKey().equals("1524076"))
//                    if(row.getKey().equals("1882104"))
//                    if(row.toString().contains("1006KYQB"))
//                    if(row.getKey().equals("1006KYQB"))
                    {
                        log.debug("Row is " + row.toString());
//                        String rowString = ColumnExtract.convertRowToJSON(row);
                        String rowString = ColumnExtract.convertRowToJSONWithTimeStamp(row);
                        try
                        {
                            log.debug("JSON String is " + new JSONObject(rowString).toString(3));
                        }
                        catch(Exception ex)
                        {
                            
                        }
                    
                        Assert.assertNotNull(rowString);
                        Assert.assertTrue(rowString.contains("rowkey"));
                        
//                        log.debug("BusinessEntityKey - " + ColumnExtract.getJSONAttributeStringValue(rowString, "businessEntityKey.value"));
                        log.debug("Keys - " + ColumnExtract.getJSONAttributeStringValue(rowString, "keys.value"));
                        
//                        log.debug("WorkflowSubProcessID - " + ColumnExtract.getJSONOfMultiColumnSet(row, "workflowSubProcessId\\|(.+)"));
//                        log.debug("ChildId - " + ColumnExtract.getJSONOfMultiColumnSet(row, "childId\\|(.+)"));
                        
//                        String entityKeyValue = ColumnExtract.getJSONAttributeStringValue(rowString, "entityKey.value");
//                        log.debug("Entity key is " + entityKeyValue);
//                        String entityKeyTimestamp = ColumnExtract.getJSONAttributeStringValue(rowString, "entityKey.columnTimestamp");
//                        log.debug("Entity key timestamp is " + entityKeyTimestamp);
                    }
                        
//                    log.debug("KEYS ARE " + ColumnExtract.getAttributeStringValue(row, "keys", "proposalNumber"));
                }
            } );
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testMultValueJsonArray()" + ex.getMessage());
        }
	}
	
	@Test
	public void testRegex()
	{
	    // nested attribute has following patterns
        // solrjson:["orderId=1006CQQY"]
        // solrjson:["workOrderNumber=acfe1f78-b291-4f7a-8d83-ef0ce93c0d95","orderNumber=1006DGNP"]
        // solrjson:["proposalNumber=9427"]
	    // solrjson:[]
	    // "solrjson:[\"{\\\"name\\\":\\\"Level3-Order.R.SalesEngineering\\\",\\\"responsiblePartyUserName\\\":\\\"90159               \\\",\\\"responsiblePartyGroupNames\\\":[]}\"]"
	    
//        Pattern pattern = Pattern.compile("\\S+\\[\\\"\\w+=(\\w+)\\\"[\\[,]");
//        Pattern pattern = Pattern.compile("\\S+:\\[\\\"orderId=(\\S+)\\\"\\]");
        Pattern pattern =Pattern.compile(".*[\\[,]\\\"orderId=(\\S+?)\\\"[\\],]");
        Matcher matcher = pattern.matcher("");
        
        String inputString = "[\"orderId=1006CQQY\"]";
//        String inputString = "solrjson:[]";
        
        Assert.assertTrue(matcher.reset(inputString).lookingAt());
        
//        Assert.assertEquals("orderId", matcher.group(1));
        Assert.assertEquals("1006CQQY", matcher.group(1));
	}
	
	@Test
	public void testRegex2()
	{
//        Pattern pattern2 = Pattern.compile("\\S+:[\\[,]\\\"orderNumber=(\\S+)\\\"[,\\]]");
//        Pattern pattern2 = Pattern.compile("[\\[,]\\\"orderNumber=(\\S+)\\\"[,\\]]");
        Pattern pattern2 = Pattern.compile(".*[\\[,]\\\"workOrderNumber=(\\S+?)\\\"[\\],]");
        Matcher matcher2 = pattern2.matcher("");
	    String inputString4 = "[\"workOrderNumber=a5efa64f-98c3-4355-a806-c11bfcf40a7d\",\"orderNumber=1006DXTH\"]";
//	    String inputString4 = "solrjson:[\"workOrderNumber=a5efa64f-98c3-4355-a806-c11bfcf40a7d\",\"orderNumber=1006DXTH\"]";
	    
	    Assert.assertTrue(matcher2.reset(inputString4).lookingAt());
        Assert.assertEquals("a5efa64f-98c3-4355-a806-c11bfcf40a7d", matcher2.group(1));
//        Assert.assertEquals("1006DXTH", matcher2.group(1));
	    
//	    String inputString2 = "solrjson:[\"{\\\"name\\\":\\\"Level3-Order.R.SalesEngineering\\\",\\\"responsiblePartyUserName\\\":\\\"90159               \\\",\\\"responsiblePartyGroupNames\\\":[]}\"]";
//	    String inputString3 = "{\\\"name\\\":\\\"Level3-Order.R.SalesEngineering\\\",\\\"responsiblePartyUserName\\\":\\\"90159               \\\",\\\"responsiblePartyGroupNames\\\":[]}";
        
        Pattern pattern3 = Pattern.compile(".*[\\[,]\\\"orderNumber=(\\S+?)\\\"[\\],]");
        Matcher matcher3 = pattern3.matcher("");
//	    String inputString3 = "[\"workOrderNumber=a5efa64f-98c3-4355-a806-c11bfcf40a7d\",\"orderNumber=1006DXTH\"]";
//	    String inputString4 = "solrjson:[\"workOrderNumber=a5efa64f-98c3-4355-a806-c11bfcf40a7d\",\"orderNumber=1006DXTH\"]";
	    
	    Assert.assertTrue(matcher3.reset(inputString4).find());
//        Assert.assertEquals("a5efa64f-98c3-4355-a806-c11bfcf40a7d", matcher2.group(1));
        Assert.assertEquals("1006DXTH", matcher3.group(1));
	}
	 */
	
}
