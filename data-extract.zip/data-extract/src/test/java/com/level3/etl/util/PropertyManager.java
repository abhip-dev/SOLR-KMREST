package com.level3.etl.util;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyManager
{
    private static Logger log = LoggerFactory.getLogger(PropertyManager.class);
    private static PropertyManager instance = null;
    private static Object mutex = new int[ 1 ];
    
    private Properties properties = null;
    
    public static final String CASSANDRA_URL_STR = "CASSANDRA_URL";
    public static final String CASSANDRA_CLUSTER_NAME_STR = "CASSANDRA_CLUSTER_NAME";
    
    private PropertyManager()
    {
        try
        {
            URL url = this.getClass().getResource("/ResourceLocator.properties");

            properties = new Properties();
            properties.load(url.openStream());

            URL url2 = this.getClass().getResource("/EnvironmentSelector.properties");

            properties.load(url2.openStream());
        }
        catch(IOException ioe)
        {
            log.error("caught exception while trying to read properties file.", ioe);
        }
    }
    
    public static PropertyManager instance()
    {
        PropertyManager tempInstance = null;
        
        if(instance == null)
        {
            synchronized (mutex)
            {
                if(instance == null)
                {
                    tempInstance = new PropertyManager();
                    instance = tempInstance;
                }
            }
        }
        
        return instance;
    }
    
    private String getTestEnvironment(String domain)
    {
        return properties.getProperty(domain);
    }
    
    public String getProperty(String domain, String attribute)
    {
        return properties.getProperty(domain + "." + getTestEnvironment(domain) + "." + attribute);
    }
    
    public static void main(String[] args)
    {
        try
        {
            log.info(PropertyManager.instance().getProperty("WORKFLOW", "CASSANDRA_URL"));
            log.info(PropertyManager.instance().getProperty("EMP", "SECURITY_HOST"));
        }
        catch(Exception ex)
        {
            log.error("caught exception", ex);
            
        }
    }
}
