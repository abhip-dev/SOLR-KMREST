package com.level3.etl.solr.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SolrjUtilTest
{
    private static Logger log = LoggerFactory.getLogger(SolrjUtilTest.class);
    
    @Before
    public void setup()
    {
        
    }
    
    @Test
    public void testGetSolrDate()
    {
        String inputDate = "8/9/2013 11:52:10.123456";
        String expectedDate = "2013-08-09T11:52:10Z";
        
        String actualDate = SolrjUtil.getSolrDate(inputDate);
        
        Assert.assertEquals(expectedDate, actualDate);
    }
    
/**
    @Test
    public void testAddJsonDocument()
    {
        final String SOLJ_DATE_FMT = "yyyy-MM-dd'T'HH:mm:ss'Z'" ; 
//        final String urlString = "http://10.5.148.96:8080/tnlookupcore/tnlookupcore/update/json";
//        final String lookupUrl = "http://10.5.148.96:8080/tnlookupcore/tnlookupcore/select?q=tnLookupKeyId:3034211344&fl=dwLastModifyDate&wt=json&omitHeader=true";
        final String urlString = "http://tnlookup-dev.level3.com/solr/tnlookup/update/json";
        final String lookupUrl = "http://tnlookup-dev.level3.com/solr/tnlookup/select?q=tnLookupKeyId:3034211344&fl=dwLastModifyDate&wt=json&omitHeader=true";
        
        StringBuffer strbuf = new StringBuffer();
        URL u1 = null;
        URL url = null;
        File f1 = null;
        HttpURLConnection connection = null;
        BufferedReader inputReader = null;
        SimpleDateFormat dateFormat = null;
        String inputLine;
        String jsonContent;
        String updatedDwLastModifyDate;
        String jsonDocToUpload;
        
        try
        {
            // read TN record 
            u1 = SolrjUtil.class.getResource("/tnSample.json");
            f1 = FileUtils.toFile(u1);;
            jsonContent = FileUtils.readFileToString(f1, "UTF-8");
            
            // change dwLastModifyDate 
            // get current date
            // change it to Solr Date format
            // update dwLastModifyDate to current Date and time
            dateFormat = new SimpleDateFormat(SOLJ_DATE_FMT);
            updatedDwLastModifyDate = dateFormat.format(new Date());
            jsonDocToUpload = 
                    jsonContent.replaceFirst(
                            "\"dwLastModifyDate\": \"2012-05-19T07:36:37Z\"",
                            "\"dwLastModifyDate\": \"" + updatedDwLastModifyDate + "\"");
            
            log.debug(jsonDocToUpload);
            
            // update document in the SOLR index
            SolrjUtil.addJsonDocument(urlString, jsonDocToUpload);
            
            // sleep for 5 seconds, then get the document
            Thread.sleep(10000L);
            
            // retrieve the document and verify dwLastModifyDate has been updated
            url = new URL(lookupUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);

            connection.connect();

            inputReader = new BufferedReader(new InputStreamReader( connection.getInputStream() ));
            while ((inputLine = inputReader.readLine()) != null) 
            {
                strbuf.append(inputLine);
                strbuf.append("\n");
            }
            
            String response = strbuf.toString();
            
            log.debug("Response is [" + response + "]");
            
            Assert.assertTrue(String.format("Updated date is [%s].Response is [%s]", updatedDwLastModifyDate , response), response.contains(updatedDwLastModifyDate));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        catch (IOException ioe)
        {
            Assert.fail("caught exception in testAddJsonDocument()" + ioe.getMessage());
        }
        catch (Exception ex)
        {
            Assert.fail("caught exception in testAddJsonDocument()" + ex.getMessage());
        }
    }
**/
    
    /*
    @Test
    public void testAddJsonDocument_TaskOrder()
    {
        final String urlString = "http://kmdsidc02-dev1:8080/taskcore/taskcore/update/json";
        final String lookupUrl = "http://kmdsidc02-dev1:8080/taskcore/taskcore/select?q=taskId:367857&fl=taskStatus&wt=json&omitHeader=true";
        
        StringBuffer strbuf = new StringBuffer();
        URL u1 = null;
        URL url = null;
        File f1 = null;
        HttpURLConnection connection = null;
        BufferedReader inputReader = null;
        String inputLine;
        String jsonContent;
        String jsonDocToUpload;
        Random random = new Random();
        int randomNumber = random.nextInt(100);
        
        try
        {
            // read TN record 
            u1 = SolrjUtil.class.getResource("/taskOrder.json");
            f1 = FileUtils.toFile(u1);;
            jsonContent = FileUtils.readFileToString(f1, "UTF-8");
            
            // change dwLastModifyDate 
            // get current date
            // change it to Solr Date format
            // update dwLastModifyDate to current Date and time
            jsonDocToUpload = 
                    jsonContent.replaceFirst(
                            "\"taskStatus\":\"I_ASSIGNED2\"",
                            "\"taskStatus\":\"I_ASSIGNED" + randomNumber + "\"");
            
            log.debug(jsonDocToUpload);
            
            // update document in the SOLR index
            SolrjUtil.addJsonDocument(urlString, jsonDocToUpload);
            
            // sleep for 5 seconds, then get the document
            Thread.sleep(5000L);
            
            // retrieve the document and verify dwLastModifyDate has been updated
            url = new URL(lookupUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            connection.setRequestProperty("Accept", MediaType.APPLICATION_JSON);

            connection.connect();

            inputReader = new BufferedReader(new InputStreamReader( connection.getInputStream() ));
            while ((inputLine = inputReader.readLine()) != null) 
            {
                strbuf.append(inputLine);
                strbuf.append("\n");
            }
            
            String response = strbuf.toString();
            
            log.debug("Response is [" + response + "]");
            
            Assert.assertTrue("taskStatus is I_ASSIGNED" + randomNumber, response.contains("I_ASSIGNED" + randomNumber));
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        catch (IOException ioe)
        {
            Assert.fail("caught exception in testAddJsonDocument_TaskOrder()" + ioe.getMessage());
        }
    }
    */
}
