package com.level3.etl.email.dataobjects;

import java.util.HashMap;
import java.util.Map;

public class MailboxDO
{
    private String mailServer = null;
    private String mailBox = null;
    private String userName = null;
    private String password = null;
    private String smtpServer = null;
    private String smtpPort = null;
    
    private Map<String, String> propertiesMap = new HashMap<String, String>();
    
    public String getMailServer()
    {
        return mailServer;
    }
    public void setMailServer(String mailServer)
    {
        this.mailServer = mailServer;
    }
    public String getMailBox()
    {
        return mailBox;
    }
    public void setMailBox(String mailBox)
    {
        this.mailBox = mailBox;
    }
    public String getUserName()
    {
        return userName;
    }
    public void setUserName(String userName)
    {
        this.userName = userName;
    }
    public String getPassword()
    {
        return password;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public String getSmtpServer()
    {
        return smtpServer;
    }
    public void setSmtpServer(String smtpServer)
    {
        this.smtpServer = smtpServer;
    }
    public String getSmtpPort()
    {
        return smtpPort;
    }
    public void setSmtpPort(String smtpPort)
    {
        this.smtpPort = smtpPort;
    }
    public Map<String, String> getPropertiesMap()
    {
        return propertiesMap;
    }
    public void setPropertiesMap(Map<String, String> propertiesMap)
    {
        this.propertiesMap = propertiesMap;
    }
    
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("MailboxDO [mailServer=");
        builder.append(mailServer);
        builder.append(", mailBox=");
        builder.append(mailBox);
        builder.append(", userName=");
        builder.append(userName);
        builder.append(", password=");
        builder.append(password);
        builder.append(", smtpServer=");
        builder.append(smtpServer);
        builder.append(", smtpPort=");
        builder.append(smtpPort);
        builder.append(", propertiesMap=");
        builder.append(propertiesMap);
        builder.append("]");
        return builder.toString();
    }
}
