package com.level3.etl.cassandra.callback;

/**
 * Interface used for declaring Callback for use in MultiValueColumnManager
 * 
 * @author Andy Klun
 *
 */
public interface MultiValueRowCallbackIF {
	public void receiveMultiValueRow( String columnValue );

}
