package com.level3.etl.exception;

@SuppressWarnings("serial")
public class IncrementErrorCountException extends RuntimeException {

	public IncrementErrorCountException( final String msg )
	{
		super(msg);
	}
	
	public IncrementErrorCountException(final String msg, Throwable e )
	{
		super(msg,e);
	}
	
	public IncrementErrorCountException()
	{
		super();
	}
	
	public IncrementErrorCountException(Throwable e )
	{
		super(e);
	}

}
