package com.level3.etl.exception;

import java.lang.String;

public enum ErrorCodeMapping
{
    EMPPrivateFacadeInitException("10001", "Error while trying to start private message facade, aborting connection to EMP."),
    EMPEnterpriseFacadeInitException("10002", "Error while trying to start enterprise message facade, aborting connection to EMP."),
    EMPCreateDigestException(     "10003", "Error while trying to create digest."),
    EMPControlFileException(      "10004", "Error while trying to create control file to manage EMP listener."),
    EMPInvalidInputException(     "10005", "Input parameters are not valid."),
    JSONAddAttributeException("10006", "Error while trying to add attribute to JSON object."),
    EMPUnknownException(          "99999", "Unknown error thrown from EMP.");
    
    private final String errorCode;
    private final String errorMessage;
    
    ErrorCodeMapping(String errorCode, String errorMessage)
    {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }
    
    public String getErrorCode()
    {
        return errorCode;
    }
    
    public String getErrorMessage()
    {
        return errorMessage;
    }

}
