package com.level3.etl.cassandra.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.jayway.jsonpath.InvalidPathException;
import com.jayway.jsonpath.JsonPath;
import com.level3.etl.emp.util.GZIPUtil;
import com.level3.etl.exception.IncrementErrorCountException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

//import me.prettyprint.hector.api.beans.ColumnSlice;
//import me.prettyprint.hector.api.beans.HColumn;
//import me.prettyprint.hector.api.beans.Row;

public class ColumnExtract {

    private static final String className = "ColumnExtract";
    
	private static final String GZIP_ENCODING = "gzip";
	
	private static final String OPEN_CURLY_BRACE = "{";
	private static final String OPEN_SQUARE_BRACKET = "[";
	
	public static final String[] DateFormats = {"yyyy-MM-dd HH:mm:ssZ"
		, "yyyy-MM-dd HH:mm:ss.SSSZ"
		, "yyyy-MM-dd'T'HH:mm:ss'Z'"
		, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
		, "yyyy-MM-dd'T'HH:mm:ss.SSS"
		, "yyyy-MM-dd'T'HH:mm:ss"
		, "MM/dd/yyyy"
		, "MM/dd/yy"};
	public static String storageFormat = "yyyy-MM-dd HH:mm:ssZ";

//    private static Logger log = LoggerFactory.getLogger(ColumnExtract.class);
	
	/**
	 * Extracts the key value of a Cassandra row.  Since the rowkey of a Cassandra row is never null, this method will never return a null.
	 * 
	 * @param	row		A Cassandra Row object
	 * @return			String value of the rowkey
	 * @throws			IncrementErrorCountException if any exception occurs
	 * /
	public static String getKeyValue(Row<String, String, String> row) throws IncrementErrorCountException {
		String keyValue = null;
		try {
			keyValue = row.getKey();				
		} catch (Exception e) {
			throw new IncrementErrorCountException("Error occurred while trying to fetch the rowkey.  " + e.getMessage());
    	}
		return keyValue;
	}
	*/
	
	/**
	 * Extracts the key value of a Cassandra row as an int.  Since the rowkey of a Cassandra row is never null, this method will never return a null.
	 * 
	 * @param	row		A Cassandra Row object
	 * @return			Integer representing the rowkey
     * @throws	IncrementErrorCountException	when the column value can't be converted to an int.
	 * /
	public static int getIntegerKeyValue(Row<String, String, String> row) throws IncrementErrorCountException {
		int resultInteger = -999;
		String columnValue = row.getKey();
		try {
			if (columnValue != null && columnValue.length()>0)
			{
				resultInteger = Integer.parseInt(columnValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(genColumnErrorMsg("rowkey",columnValue) + e.getMessage());
		}
		return resultInteger;
	}
	*/
	
	/**
	 * Returns the string value of a column from a Cassandra row.  No exceptions are expected from this method.
	 * 
	 * @param	row			A Cassandra Row object
	 * @param	columnName	The name of the column you want extracted
	 * @return				string value of column (null if column not found)
	 * /
	public static String getStringValue(Row<String, String, String> row,String columnName) {
		String columnValue = null;
		if ((row != null) && (columnName != null))
			{
				ColumnSlice<String, String> cs = row.getColumnSlice();
				if (cs != null && cs.getColumnByName(columnName) != null) {
					columnValue = cs.getColumnByName(columnName).getValue();
				}
			}
		return columnValue;
	}
	*/
	
	/**
	 * Returns the string value of a column from a Cassandra row.  No exceptions are expected from this method.
	 * 
	 * @param	row			A Cassandra Row object
	 * @param	columnName	The name of the column you want extracted
	 * @return				string value of column (null if column not found)
	 * /
    public static String getStringValueTruncated(
            Row<String, String, String> row, String columnName, int maxLength)
    {
        return truncateStringToByteLimit(getStringValue(row, columnName), maxLength);
    }
    */
    
	/**
	 * Returns a String whose byte count does not exceed maxLength without truncating in the middle of a multi-byte character
	 * This method will not work for maxLength <= 3 and string > maxLength (3 or less),
	 *  as it appends [TR] to every truncated String
	 * 
	 * @param	string		string to truncate
	 * @param	maxLength	maximum byte count of the returned string
	 * @return				truncated string
	 */
    public static String truncateStringToByteLimit(String string, int maxLength)
    {
        int strByteLength = 0;
        int skip = 0;
        int nextCharByteLength = 0;
        char charAtIndex;
        String truncatedStringSuffix = "[TR]";
        
        // we will use deque to store the index position and length of last 4 characters examined
        // we set the size to 4 since length of "[TR]" is 4 bytes and at worst we would need to remove 4 characters,
        // at best just 1 from the end of the substring that we are building
        ArrayDeque<CharPositionLength> arrayDeque = new ArrayDeque<CharPositionLength>(4);
        CharPositionLength charPositionLength = null;
        
        if(string == null)
        {
            return string;
        }
        
        // This approach does not try to convert the String into UTF-8, rather it uses 
        // the following info
        // http://docs.oracle.com/javase/1.5.0/docs/api/java/io/DataInput.html#modified-utf-8
        // supplementary (surrogate) characters that uses a pair of char values are also handled
        for (int strIndex = 0; strIndex < string.length(); strIndex++)
        {
            charAtIndex = string.charAt(strIndex);

            // ranges from http://en.wikipedia.org/wiki/UTF-8
            if (charAtIndex <= 0x007f)
            {
                nextCharByteLength = 1;
            }
            else if (charAtIndex <= 0x07FF)
            {
                nextCharByteLength = 2;
            }
            else if (charAtIndex <= 0xd7ff)
            {
                nextCharByteLength = 3;
            }
            else if (charAtIndex <= 0xDFFF)
            {
                // surrogate area, consume next char as well
                nextCharByteLength = 4;
                skip = 1;
            }
            else
            {
                nextCharByteLength = 3;
            }

            if (strByteLength + nextCharByteLength > maxLength)
            {
                // so we are going to truncate the String, since we are truncating we need to add "[TR]" to the
                // end of the String.
                // check how many chars do we need to remove from the end of the string, before we add [TR]
                // it may be anywhere from 1 to 4
                // please note it is possible the return string is smaller than max length

                if(maxLength < truncatedStringSuffix.length())
                {
                    return truncatedStringSuffix;
                }
        
                // [TR] occupies 4 bytes, so we can just use its length
                int bytesToRemove = strByteLength + truncatedStringSuffix.length() - maxLength;
                
                bytesToRemove = (bytesToRemove < 0) ? 0 : bytesToRemove;
                int bytesToRemoveTotal = 0;
                
                for( ;bytesToRemoveTotal < bytesToRemove ; )
                {
                    if(arrayDeque.size() > 0)
                    {
                        charPositionLength = arrayDeque.removeLast();
                    
                        bytesToRemoveTotal += charPositionLength.getLength();
                    }
                }
                
                return string.substring(0, charPositionLength.getPosition()) + truncatedStringSuffix;
            }
            
            // charPositionLength must be setup prior to incrementing strIndex to next String
            charPositionLength = new CharPositionLength(strIndex, nextCharByteLength);
            
            if(arrayDeque.size() == 4)
            {
                arrayDeque.remove();
            }
            arrayDeque.add(charPositionLength);
            
            strByteLength += nextCharByteLength;
            strIndex += skip;
        }
        
        return string;
    }
    
	/**
     * Returns a Big Decimal representing a date using a "yyyy-MM-dd'T'HH:mm:ss.SSS" to parse the column extracted<br>
     * <br>
     * Returns a BigDecimal.ZERO (i.e. Jan 1, 1970) when::<br>
     * 		a. The requested date column is not present on the row<br>
     * 		b. The requested date column is blank/empty<br>
     * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @param	_dateFormats	Arracy of date formats.  Ex: new String[]{"yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd HH:mm:ssZ"}
     * @return					Big Decimal representing the date.
     * @throws IncrementErrorCountException when no valid date format is found to convert this date value
     * /
	public static BigDecimal getDateTimeValue(Row<String, String, String> row,String columnName, String[] _dateFormats) throws IncrementErrorCountException {
		BigDecimal resultDateTimeValue = null; //BigDecimal.ZERO;
		String rawValue = ColumnExtract.getStringValue(row, columnName);
		if (rawValue != null && rawValue.length()>0)
		{
			try {
				resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, _dateFormats);
			} catch (IncrementErrorCountException e) {
				try {
					resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, DateFormats);
				} catch (Exception e1) {
					throw new IncrementErrorCountException(genClassErrorMsg(className,"getDateTimeValue") + genColumnErrorMsg(columnName, rawValue) + e1.getMessage());
				}
			} catch (Exception e) {
				throw new IncrementErrorCountException(genClassErrorMsg(className,"getDateTimeValue") + genColumnErrorMsg(columnName, rawValue) + e.getMessage());
			}
		}
		return resultDateTimeValue;
	}
	*/
	
	/**
     * Returns a Big Decimal representing a date using a "yyyy-MM-dd'T'HH:mm:ss.SSS" to parse the column extracted<br>
     * <br>
     * Returns a BigDecimal.ZERO (i.e. Jan 1, 1970) when::<br>
     * 		a. The requested date column is not present on the row<br>
     * 		b. The requested date column is blank/empty<br>
     * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
     * @return					Big Decimal representing the date.
     * @throws IncrementErrorCountException when no valid date format is found to convert this date value
     * /
	public static BigDecimal getDateTimeValue(Row<String, String, String> row,String columnName) throws IncrementErrorCountException {
		return ColumnExtract.getDateTimeValue(row, columnName, DateFormats);
	}
	*/
	
	/**
     * Returns a Big Decimal representing a date using the provided _dateFormats to parse the column extracted<br>
     * If the column is blank or null, returns a BigDecimal.Zero.
     * 
     * @param	rawValue		String value representing a date
     * @param	_dateFormats	String array of date formats to try, in order, to parse the rawValue
     * @return Big Decimal representing the date.
     * @throws	IncrementErrorCountException	when date doesn't match any of the provided _dateFormats and therefore can't be parsed from the data
     */
	private static BigDecimal getDateTimeFromFormat(String rawValue, String[] _dateFormats) throws IncrementErrorCountException {
		Date dateValue = null;
		BigDecimal resultDateTimeValue = BigDecimal.ZERO;

		if (rawValue == null || rawValue.length() == 0)
		{
			return resultDateTimeValue;
		}
		for (int i = 0; i < _dateFormats.length; i++ )
		{
			try {
				dateValue = (new SimpleDateFormat(_dateFormats[i])).parse(rawValue);
				resultDateTimeValue = new BigDecimal(dateValue.getTime()); //timeInMillisSinceEpoch
				break;
			}catch (Exception e) {
				//throw e;
			}
		}
		// if date was not converted by one of the date format strings, then throw an error
		if (resultDateTimeValue == BigDecimal.ZERO) {
			// throw an intermediate message back to the caller who can throw a more informative message
			throw new IncrementErrorCountException("Failed to find a matching date format for this date value [" + rawValue + "].");
		}
		
		return resultDateTimeValue;
	}
	
	/** Returns the int value of a column<br>
	 * <br>
     * Returns a -999 when:<br>
     * 		a. The requested column is not found on the row<br>
     * 		b. The column value is null or zero length<br>
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @return					Integer representing the column's value.
     * @throws	IncrementErrorCountException	when the column value can't be converted to an int.
	 * /
	public static int getIntegerValue(Row<String, String, String> row,String columnName) {
		int resultInteger = -999;
		String columnValue = ColumnExtract.getStringValue(row, columnName);
		try {
			if (columnValue != null && columnValue.length()>0)
			{
				resultInteger = Integer.parseInt(columnValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(genColumnErrorMsg(columnName,columnValue) + e.getMessage());
		}
		return resultInteger;
	}
	*/
    
	/** Returns the BigDecimal value of a column 
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @return BigDecimal
	 *
	 *
     * Returns a null when:
     * 		a. The requested column is not found on the row
     * 		b. The column value is null or zero length
     *
     * Throws an IncrementErrorCountException when
     * 		a. Unable to convert the column value to a BigDecimal
     *
	 * /
	public static BigDecimal getBigDecimalValue(Row<String, String, String> row,String columnName) throws IncrementErrorCountException {
		BigDecimal resultBigDecimal = null;
		String columnValue = ColumnExtract.getStringValue(row, columnName);
		try {
			if (columnValue != null && columnValue.length()>0)
			{
				resultBigDecimal = new BigDecimal(columnValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(genColumnErrorMsg(columnName, columnValue) +  e.getClass());
		}
		return resultBigDecimal;
	}
	*/
	
	/** Returns an Double value of a column 
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @return Double.  Null if column not found or column value is not an Double
	 *
	 *
     * Returns a null when:
     * 		a. The requested column is not found on the row
     * 		b. The column value is null or zero length
     *
     * Throws an IncrementErrorCountException when
     * 		a. Unable to convert the column value to a Double
     *
	 * /
	public static Double getDoubleValue(Row<String, String, String> row,String columnName) throws IncrementErrorCountException {
		Double resultDouble = new Double(-999);
		String columnValue = ColumnExtract.getStringValue(row, columnName);
		try {
			if (columnValue != null && columnValue.length()>0)
			{
				resultDouble = new Double(columnValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(genColumnErrorMsg(columnName, columnValue) + e.getMessage());
		}
		return resultDouble;
	}
	*/
	
	/**
	 * Steps through every column returning the most recent timestamp.  This should give you the last time a row was updated
	 * 
     * @param	row				A Cassandra Row object
	 * @return BigDecimal representing the last update date
	 *
	 *
     * Returns a BigDecimal.ZERO (Jan 1, 1970) when:
     * 		a. No columns exist on this row
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method.
     *
	 * /
	public static BigDecimal getMaxDateValue(Row<String, String, String> row) throws IncrementErrorCountException {
		long resultMaxDate = 0;
		try {
		
			ColumnSlice<String, String> cs = row.getColumnSlice();
			for (int i = 0; i <cs.getColumns().size(); i++)
			{
				if (resultMaxDate < cs.getColumns().get(i).getClock())
				{
					resultMaxDate = cs.getColumns().get(i).getClock();
				}
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException("Error trying to compute max date for a row.  " + e.getMessage());
		}
		return new BigDecimal(resultMaxDate/1000);
	}
	*/
	
	/**
	 * Steps through every column returning the most recent timestamp.  This should give you the last time a row was updated
	 * 
     * @param	row				A Cassandra Row object
	 * @return BigDecimal representing the last update date
	 *
	 *
     * Returns a BigDecimal.ZERO (Jan 1, 1970) when:
     * 		a. The requested column does not exist on this row
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method.
     *
	 * /
	public static BigDecimal getTimestampValueForColumn(Row<String, String, String> row, String columnName) throws IncrementErrorCountException{
		long resultMaxDate = 0;
		try {
			ColumnSlice<String, String> cs = row.getColumnSlice();
			if (cs != null && cs.getColumnByName(columnName) != null) {
				resultMaxDate = cs.getColumnByName(columnName).getClock();
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException("Error trying to get timestamp for a column.  " + e.getMessage());
		}
		return new BigDecimal(resultMaxDate/1000);
	}
	*/
	
	/**
	 * Extracts a the value of a key from a key=value pair column.  
	 * 
	 * For Example:
	 * 		row's keys column:  "serviceOrderId=123456","CRD=1234661212"
	 * 		columnName=keys
	 * 		attribute=serviceOrderId
	 *	  returns "123456"
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @param attributeName - attribute name in the column
	 * @return String value (null if either the column or attribute is not found)
     *
     * Returns a null when
     * 		a. The provided Cassandra row is null
     * 		b. The requested columnName does not exist on this row
     * 		c. The requested attributeName does not exist within the column's value
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method.
     *
	 * /
	public static String getAttributeStringValue(Row<String, String, String> row,String columnName, String attributeName) throws IncrementErrorCountException{
		String columnValue = null;
		String returnValue = null;
		
		try {
			if ((row != null)&&(columnName != null)&&(attributeName != null))
			{
				ColumnSlice<String, String> cs = row.getColumnSlice();
				if (cs != null && cs.getColumnByName(columnName) != null) {
					columnValue = cs.getColumnByName(columnName).getValue();
					// uses toUpperCase to make the search case insensitive
					int columnLocation = columnValue.toUpperCase().indexOf("\"" + attributeName.toUpperCase() + "=");
					if (columnLocation >= 0)
					{
						returnValue = columnValue.substring(columnLocation + attributeName.length() + 2, columnValue.indexOf('"', columnLocation + attributeName.length() + 2));
					}
				}
			}

		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	*/
	
	/**
	 * Extracts a the value of a key from a key=value pair column and converts it to a BigDecimal
	 * 
	 * For Example:
	 * 		row's keys column:  "serviceOrderId=123456;CRD=1234661212"
	 * 		columnName=keys
	 * 		attribute=CRD
	 *	  returns 1234661212
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @param attributeName - attribute name in the column
	 * @return BigDecimal (null if either the column or attribute is not found)
     *
     * Returns a null when
     * 		a. The provided Cassandra row is null
     * 		b. The requested columnName does not exist on this row
     * 		c. The requested attributeName does not exist within the column's value
     *
     * Throws an IncrementErrorCountException when
     * 		a. Unable to convert value to a BigDecimal
     * 		b. An unexpected error occurs during this method
     *
	 * /
	public static BigDecimal geAttributeBigDecimalValue(Row<String, String, String> row,String columnName, String attributeName) 
			throws IncrementErrorCountException {
		BigDecimal returnValue = null;
		String rawValue = getAttributeStringValue(row, columnName, attributeName);
		
		try {
			if (rawValue != null)
			{
				returnValue = new BigDecimal(rawValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	*/
	
	/**
	 * Extracts a the value of a key from a key=value pair column and converts it to a Integer
	 * 
	 * For Example:
	 * 		row's keys column:  "serviceOrderId=123456","CRD=1234661212"
	 * 		columnName=keys
	 * 		attribute=serviceOrderId
	 *	  returns 123456
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @param attributeName - attribute name in the column
	 * @return Integer (null if either the column or attribute is not found)
     *
     * Returns -999 when
     * 		a. The provided Cassandra row is null
     * 		b. The requested columnName does not exist on this row
     * 		c. The requested attributeName does not exist within the column's value
     * 		d. The attrubuteName's value is null or has a length of zero
     *
     * Throws an IncrementErrorCountException when
     * 		a. Unable to convert value to an int
     * 		b. An unexpected error occurs during this method
     *
	 * /
	public static int getAttributeIntegerValue(Row<String, String, String> row,String columnName, String attributeName) throws IncrementErrorCountException {
		int returnValue = -999;
		String rawValue = getAttributeStringValue(row, columnName, attributeName);
		
		try {
			if (rawValue != null && rawValue.length()>0)
			{
				returnValue = Integer.parseInt(rawValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	*/
	
	/**
	 * Extracts a the value of a key from a key=value pair column and converts it to a Double
	 * 
	 * For Example:
	 * 		row's keys column:  "serviceOrderId=123456;CRD=1234661212"
	 * 		columnName=keys
	 * 		attribute=serviceOrderId
	 *	  returns 123456
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @param attributeName - attribute name in the column
	 * @return Double (null if either the column or attribute is not found)
     *
     * Returns null when
     * 		a. The provided Cassandra row is null
     * 		b. The requested columnName does not exist on this row
     * 		c. The requested attributeName does not exist within the column's value
     * 		d. The attrubuteName's value is null or has a length of zero
     *
     * Throws an IncrementErrorCountException when
     * 		a. Unable to convert value to a Double
     * 		b. An unexpected error occurs during this method
     *
	 * /
	public static Double getAttributeDoubleValue(Row<String, String, String> row,String columnName, String attributeName) throws IncrementErrorCountException {
		Double returnValue = new Double(-999);
		String rawValue = getAttributeStringValue(row, columnName, attributeName);
		
		try {
			if (rawValue != null && rawValue.length()>0)
			{
				returnValue = new Double(rawValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	*/
	
	/**
	 * Extracts a the value of a key from a key=value pair column and 
	 * returns a Big Decimal representing a date using a "yyyy-MM-dd'T'HH:mm:ss.SSS" to parse the attribute extracted
	 * 
	 * For Example:
	 * 		row's keys column:  "serviceOrderId=123456","CRD=1234661212"
	 * 		columnName=keys
	 * 		attribute=serviceOrderId
	 *	  returns 123456
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @param attributeName - attribute name in the column
	 * @param _dateFromats - Arracy of date formats.  Ex: new String[]{"yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd HH:mm:ssZ"}
	 * @return BigDecimal (null if either the column or attribute is not found)
     *
     * Returns a BigDecimal.ZERO (Jan 1, 1970) when
     * 		a. The provided Cassandra row is null
     * 		b. The requested columnName does not exist on this row
     * 		c. The requested attributeName does not exist within the column's value
     * 		d. The attrubuteName's value is null or has a length of zero
     *
     * Throws an IncrementErrorCountException when
     * 		a. Unable to convert value to one of the provided date formats
     * 		b. An unexpected error occurs during this method
     *
	 * /
	public static BigDecimal getAttributeDateValue(Row<String, String, String> row,String columnName, String attributeName, String[] _dateFormats) 
			throws IncrementErrorCountException {
		BigDecimal resultDateTimeValue = null; //BigDecimal.ZERO;
		String rawValue = getAttributeStringValue(row, columnName, attributeName);
		
		if (rawValue != null && rawValue.length()>0)
		{
//			try {
//				resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, _dateFormats);
//			} catch (Exception e) {
//				throw new IncrementErrorCountException(e.getMessage());
//			}

			try {
				resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, _dateFormats);
			} catch (IncrementErrorCountException e) {
				try {
					resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, DateFormats);
				} catch (Exception e1) {
					throw new IncrementErrorCountException(genClassErrorMsg(className,"getAttributeDateValue") + genColumnErrorMsg(attributeName, rawValue) + e1.getMessage());
				}
			} catch (Exception e) {
				throw new IncrementErrorCountException(genClassErrorMsg(className,"getAttributeDateValue") + genColumnErrorMsg(attributeName, rawValue) + e.getMessage());
			}
		}
		return resultDateTimeValue;
	}
	*/
	

	/**
	 * Extracts a the value of a key from a key=value pair column and 
	 * returns a Big Decimal representing a date using a "yyyy-MM-dd'T'HH:mm:ss.SSS" to parse the attribute extracted
	 * 
	 * For Example:
	 * 		row's keys column:  "serviceOrderId=123456","CRD=1234661212"
	 * 		columnName=keys
	 * 		attribute=serviceOrderId
	 *	  returns 123456
	 * 
     * @param	row				A Cassandra Row object
     * @param	columnName		The name of the column you want extracted
	 * @param attributeName - attribute name in the column
	 * @return BigDecimal (null if either the column or attribute is not found)
     *
     * Returns a BigDecimal.ZERO (Jan 1, 1970) when
     * 		a. The provided Cassandra row is null
     * 		b. The requested columnName does not exist on this row
     * 		c. The requested attributeName does not exist within the column's value
     * 		d. The attrubuteName's value is null or has a length of zero
     *
     * Throws an IncrementErrorCountException when
     * 		a. Unable to convert value to one of the date formats pre-defined in this class
     * 		b. An unexpected error occurs during this method
     *
	 * /
	public static BigDecimal getAttributeDateValue(Row<String, String, String> row,String columnName, String attributeName) throws IncrementErrorCountException {
		return ColumnExtract.getAttributeDateValue(row, columnName, attributeName, DateFormats);
	}
	*/
	
	/**
	 * Uses JSON to attempt to extract the requested attribute.  
	 * The attribute can be multiple levels deep.  
	 * Performs a case insensitive search if the exact case match is not found
	 * 
	 * For Example: 
	 * 		AttributeName="order'details.customer.customerName"
	 * 	 - This would search for a top level element of order, then search for details in that, then search for customer in that, then search for customerName in that
	 * 
	* @param	json			A valid JSON string
	* @param	attributeName	Name of the attribute to return
	 * @return - String value of attribute (null if it can't parse the json or the attribute is not found)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
    public static String getJSONAttributeStringValue(String json,
            String attributeName) throws IncrementErrorCountException
    {
        JSONObject jobj = null;
        JSONArray array = null;

        try
        {
            if ((json == null) || (attributeName == null))
            {
                return null;
            }

            if (attributeName.indexOf('.') > 0)
            {
                String[] attributes = attributeName.split("\\.");
                for (int i = 0; i < attributes.length - 1; i++)
                {
                    json = getJSONAttributeStringValue(json, attributes[i]);

                    if (json == null)
                    {
                        return null;
                    }
                }
                
                attributeName = attributes[attributes.length - 1];
            }

            json = json.replace("solrjson:", "");
            if (isJSONObject(json))
            {
                jobj = new JSONObject(json);
                
                for(String name : JSONObject.getNames(jobj))
                {
                    if(name.equalsIgnoreCase(attributeName))
                    {
                        return jobj.get(name).toString();
                    }
                }
                
                // no match found, return null
                return null;
                
            }
            else if (isJSONArray(json))
            {
                array = new JSONArray(json);
                
                return getAttributeFromJSONArray(array, attributeName);
            }
            else
            {
                return null;
            }

            /*
             * if (jobj != null) 
             * { 
             *    if (jobj.get(attributeName) == null) 
             *    { 
             *       for(int i = 0; i < jobj.keySet().toArray().length; i++) 
             *       {
             *          if(jobj.keySet().toArray()[i].toString().equalsIgnoreCase(attributeName)) 
             *          { 
             *             attributeName = jobj.keySet().toArray()[i].toString();
             *             returnValue = jobj.get(attributeName).toString(); break; 
             *          }
             *       }
             *    }
             *    else
             *    {
             *       returnValue = jobj.get(attributeName).toString(); 
             *    }
             * }
             */
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(e.getMessage());
        }
    }
    
	/**
	 * Uses JSON to attempt to extract the requested nested attribute. Nested attribute value is nested inside
	 * value of a JSON Name.  
	 * Performs a case insensitive search if the exact case match is not found
	 * 
	 * For Example: 
	 * "keys": [
     *    {"value": "solrjson:[\"proposalNumber=9068\"]"},
     *    {"columnTimestamp": 1367465477331000}
     * ]
     * 
	 * This would search for element keys.value, then search for proposalNumber in the value of "keys.value"
	 * 
	 * @param	json			A valid JSON string
	 * @param	attributeName	Name of the attribute to return
	 * @param   nestedAttribute Attribute nested inside value of attributeName
	 * @return - String value of attribute (null if it can't parse the json or the attribute is not found)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
    public static String getJSONAttributeStringValue(String json, String attributeName, String nestedAttribute)
            throws IncrementErrorCountException
    {
//             nested attribute has following patterns
//             solrjson:["orderId=1006CQQY"]
//             solrjson:["workOrderNumber=acfe1f78-b291-4f7a-8d83-ef0ce93c0d95","orderNumber=1006DGNP"]
//             solrjson:["proposalNumber=9427"]
            
        String attributeValue = null;
        String patternString = ".*[\\[,]\\\"" + nestedAttribute + "=(\\S+?)\\\"[\\],]";
        Pattern pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher("");
        
        try
        {
            attributeValue = getJSONAttributeStringValue(json, attributeName);
            
            if(matcher.reset(attributeValue).lookingAt())
            {
                return matcher.group(1);
            }
            else
            {
                return null;
            }
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(e.getMessage());
        }
    }
    
    private static String getAttributeFromJSONArray(JSONArray array, String attributeName)
    {
        try
        {
            for(int index = 0; index < array.length(); ++index)
            {
                Object arrayElement = array.get(index);

                // array element could be a JSONObject or JSONArray or String or Number or Boolean or null
                if(arrayElement instanceof JSONObject)
                {
                    JSONObject jobj = (JSONObject)arrayElement;
                    for(String name : JSONObject.getNames(jobj))
                    {
                        if(name.equalsIgnoreCase(attributeName))
                        {
                            return jobj.get(name).toString();
                        }
                    }
                }
                else if(arrayElement instanceof JSONArray)
                {
                    getAttributeFromJSONArray(array, attributeName);
                }
                else
                {
                    return array.toString();
                }
            }
        }
        catch(JSONException je)
        {
            
        }
        
        return null;
    }
	
	/**
	 * Truncate a JSON attribute value to desired max length
	 * 
	 * @param	json			A JSON string that needs to be truncated
	 * @param	attributeName	The name of the attribute you want extracted from Json
	 * @param   maxLength       Maximum length of the Json attribute value
	 * @return				string value of column (null if column not found), truncated to maximum length as specified by input
	 */
    public static String getJSONAttributeStringTruncatedValue(
            String json, String attributeName, int maxLength)
			throws IncrementErrorCountException 
    {
        return truncateStringToByteLimit(getJSONAttributeStringValue(json, attributeName), maxLength);
    }
    

	/**
	* Uses JSON to attempt to extract the requested attribute.  
	* The attribute can be multiple levels deep.  
	* Performs a case insensitive search if the exact case match is not found<br>
	* <br>
	* For Example:<br>
	* 	attributeName="order'details.customer.createDate"<br>
	* 	This would search for a top level element of order, then search for details in that, then search for customer in that, then search for createDate in that
	* 
	* @param	json			A valid JSON string
	* @param	attributeName	Name of the attribute to return
	* @param	_dateFormats	Arracy of date formats.  Ex: new String[]{"yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd HH:mm:ssZ"}
	* @return					The value of the named attribute.  Null if the attribute is not found or empty.
    * @throws IncrementErrorCountException When the value can't be parsed into one of the provided date formats.
	*/
	public static BigDecimal getJSONAttributeDateValue(String json, String attributeName, String[] _dateFormats) throws IncrementErrorCountException
	{
		BigDecimal resultDateTimeValue = null; //BigDecimal.ZERO;
		String rawValue = ColumnExtract.getJSONAttributeStringValue(json, attributeName);
		
		if (rawValue == null || rawValue.equals("") || rawValue.equalsIgnoreCase("null"))
		{
		    return resultDateTimeValue;
		}
		
/*			try {
		if (rawValue != null && rawValue.length()>0)
		{
				resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, _dateFormats);
			} catch (Exception e) {
				throw new IncrementErrorCountException(e.getMessage());
			}
*/
        try
        {
            resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, _dateFormats);
        }
        catch (IncrementErrorCountException e)
        {
            try
            {
                resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, DateFormats);
            }
            catch (Exception e1)
            {
                throw new IncrementErrorCountException(genClassErrorMsg(
                        className, "getJSONAttributeDateValue")
                        + genColumnErrorMsg(attributeName, rawValue)
                        + e1.getMessage());
            }
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(genClassErrorMsg(className,
                    "getJSONAttributeDateValue")
                    + genColumnErrorMsg(attributeName, rawValue)
                    + e.getMessage());
        }
        return resultDateTimeValue;
	}
	
	/**
	* Uses JSON to attempt to extract the requested attribute.  
	 * The attribute can be multiple levels deep.  
	 * Performs a case insensitive search if the exact case match is not found
	 * Returns a BigDecimal representing a date using a "yyyy-MM-dd'T'HH:mm:ss.SSS" to parse the attribute extracted
	 * 
	 * For Example: 
	 * 		AttributeName="order'details.customer.createDate"
	 * 	 - This would search for a top level element of order, then search for details in that, then search for customer in that, then search for createDate in that
	 * 
	* @param	json			A valid JSON string
	* @param	attributeName	Name of the attribute to return
	 * @return - BigDecimal (null if it can't parse the json, the attribute is not found, the value can't be converted)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
	public static BigDecimal getJSONAttributeDateValue(String json, String attributeName) throws IncrementErrorCountException 
	{
		return ColumnExtract.getJSONAttributeDateValue(json, attributeName, DateFormats);
	}
	/**
	* Uses JSON to attempt to extract the requested attribute.  
	 * The attribute can be multiple levels deep.  
	 * Performs a case insensitive search if the exact case match is not found
	 * Converts the value to a Double
	 * 
	 * For Example: 
	 * 		AttributeName="order'details.customer.customerId"
	 * 	 - This would search for a top level element of order, then search for details in that, then search for customer in that, then search for customerId in that
	 * 
	* @param	json			A valid JSON string
	* @param	attributeName	Name of the attribute to return
	 * @return - Double (null if it can't parse the json, the attribute is not found, the value can't be converted)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
    public static Double getJSONAttributeDoubleValue(String json,
            String attributeName) throws IncrementErrorCountException
    {
        Double returnValue = new Double(-999);
        String rawValue = ColumnExtract.getJSONAttributeStringValue(json, attributeName);
        
		if (rawValue == null || rawValue.equals("") || rawValue.equalsIgnoreCase("null"))
		{
		    return returnValue;
		}

        try
        {
            returnValue = new Double(rawValue);
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(
                    "Failed to convert attribute [" + attributeName
                            + "] raw value = [" + rawValue + "] to a Double");
        }
        return returnValue;
    }
	
	/**
	 * Uses JSON to attempt to extract the requested attribute.  
	 * The attribute can be multiple levels deep.  
	 * Performs a case insensitive search if the exact case match is not found
	 * Converts the value to a Integer
	 * 
	 * For Example: 
	 * 		AttributeName="order'details.customer.customerId"
	 * 	 - This would search for a top level element of order, then search for details in that, then search for customer in that, then search for customerId in that
	 * 
	* @param	json			A valid JSON string
	* @param	attributeName	Name of the attribute to return
	 * @return - Integer (null if it can't parse the json, the attribute is not found, the value can't be converted)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
    public static int getJSONAttributeIntegerValue(String json,
            String attributeName) throws IncrementErrorCountException
    {
        String rawValue = ColumnExtract.getJSONAttributeStringValue(json, attributeName);
        int returnValue = -999;

		if (rawValue == null || rawValue.equals("") || rawValue.equalsIgnoreCase("null"))
		{
		    return returnValue;
		}
		
        try
        {
            returnValue = Integer.parseInt(rawValue);
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(
                    "Failed to convert attribute [" + attributeName
                            + "] raw value = [" + rawValue + "] to a Integer");
        }
        return returnValue;
    }
	
	
	/**
	 * Uses JSON to attempt to extract the requested attribute.  
	 * The attribute can be multiple levels deep.  
	 * Performs a case insensitive search if the exact case match is not found
	 * Converts the value to a BigDecimal
	 * 
	 * For Example: 
	 * 		AttributeName="order'details.customer.customerId"
	 * 	 - This would search for a top level element of order, then search for details in that, then search for customer in that, then search for customerId in that
	 * 
	* @param	json			A valid JSON string
	* @param	attributeName	Name of the attribute to return
	 * @return - BigDecimal (null if it can't parse the json, the attribute is not found, the value can't be converted)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
	public static BigDecimal getJSONAttributeBigDecimalValue(String json, String attributeName) throws IncrementErrorCountException
	{
        BigDecimal returnValue = BigDecimal.ZERO;
        String rawValue = ColumnExtract.getJSONAttributeStringValue(json, attributeName);
        
        if (rawValue == null || rawValue.equals("") || rawValue.equalsIgnoreCase("null"))
        {
            return returnValue;
        }

        try
        {
            returnValue = new BigDecimal(rawValue);
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(
                    "Failed to convert attribute [" + attributeName
                            + "] raw value = [" + rawValue
                            + "] to a BigDecimal.");
        }

        return returnValue;
	}
	

	/**
	 * Takes in a json string, parses it and returns the first top element
	 * 
     * @param	json			A valid JSON string
	 * @return - element name (null if can't be parsed or can't find an element)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
	public static String getJSONFirstElementName(String json) throws IncrementErrorCountException
	{
        JSONObject jobj = null;
        JSONArray jarray = null;

        try
        {
            if (isJSONObject(json))
            {
                jobj = new JSONObject(json);
                
                return jobj.names().get(0).toString();
            }
            else if (isJSONArray(json))
            {
                jarray = new JSONArray(json);
                
                jobj = (JSONObject)jarray.get(0);

                return jobj.names().get(0).toString();
            }
            else
            {
                return json;
            }
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(e.getMessage());
        }
	}
	
	/**
	 * Converts the input from a XML Dsocument string to a json string
	 * 
	 * @param xml - input xml document string
	 * @return - json string output (null if can't be converted)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
    public static String convertXMLToJSON(String xml)
            throws IncrementErrorCountException
    {
        String returnJson = null;
        try
        {
            if ((xml != null) && (xml.length() > 0))
            {
                returnJson = XML.toJSONObject(xml).toString();
            }
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(e.getMessage());
        }
        return returnJson;
    }
	
	/**
	 * Extracts the column from the HashTable
	 * 
	 * @param _ht - input HashTable
	 * @param _columnName - column to return
	 * @return - String value of column (null if column not found)
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
	public static String getHashTableString(Hashtable<String, String> _ht, String _columnName) throws IncrementErrorCountException
	{
		String returnValue = null;
		try {
			if ((_ht != null)&&(_columnName != null)&&(_ht.containsKey(_columnName)))
			{
				returnValue = _ht.get(_columnName).toString();
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	/**
	 * Extracts the column from the HashTable and converts to an Integer
	 * 
	 * @param _ht - input HashTable
	 * @param _columnName - column to return
	 * @return - Integer
     *
     * Returns -999 when:
     * 		a. The column name is not found in the hash table
     * 		b. The value for the requested column name is null or has a length of 0
     * 
     * Throws an IncrementErrorCountException when
     * 		a. The value can't be converted to an int
     * 		b. An unexpected error occurs during this method
     *
	 */
	public static int getHashTableInteger(Hashtable<String, String> _ht, String _columnName) throws IncrementErrorCountException
	{
		int returnValue = -999;
		String rawValue = ColumnExtract.getHashTableString(_ht, _columnName);
		
		try {
			if ((rawValue != null)&&(rawValue.length() > 0))
			{
				returnValue = Integer.parseInt(rawValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	
	
	/**
	 * Extracts the column from the HashTable and converts to a Double
	 * 
	 * @param _ht - input HashTable
	 * @param _columnName - column to return
	 * @return - Double
     *
     * Returns null when
     * 		a. Column name is not found in the hash table
     * 		b. The column's value is null or has a length of 0
     * 
     * Throws an IncrementErrorCountException when
     * 		a. The value can't be converted to a Double
     * 		b. An unexpected error occurs during this method
     *
	 */
	public static Double getHashTableDouble(Hashtable<String, String> _ht, String _columnName) throws IncrementErrorCountException
	{
		Double returnValue = null;
		String rawValue = ColumnExtract.getHashTableString(_ht, _columnName);
		
		try {
			if ((rawValue != null)&&(rawValue.length() > 0))
			{
				returnValue = new Double(rawValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	
	/**
	 * Extracts the column from the HashTable and converts to a BigDecimal
	 * 
	 * @param _ht - input HashTable
	 * @param _columnName - column to return
	 * @return - BigDecimal
     *
     * Returns null when
     * 		a. Column name is not found in the hash table
     * 		b. The column's value is null or has a length of 0
     * 
     * Throws an IncrementErrorCountException when
     * 		a. The value can't be converted to a BigDecimal
     * 		b. An unexpected error occurs during this method
     *
	 */
	public static BigDecimal getHashTableBigDecimal(Hashtable<String, String> _ht, String _columnName) throws IncrementErrorCountException 
	{
		BigDecimal returnValue = null;
		String rawValue = ColumnExtract.getHashTableString(_ht, _columnName);
		
		try {
			if ((rawValue != null)&&(rawValue.length() > 0))
			{
				returnValue = new BigDecimal(rawValue);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return returnValue;
	}
	
	/**
     * Extracts the column from the HashTable and
     * Returns a Big Decimal representing a date using a "yyyy-MM-dd'T'HH:mm:ss.SSS" to parse the value
     * 
     * 
     * @param _ht - input HashTable
	 * @param _columnName - column to return
	 * @param _dateFromats - Arracy of date formats.  Ex: new String[]{"yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd HH:mm:ssZ"}
     * @return Big Decimal representing the date
     *
     * Returns a BigDecimal.ZERO when
     * 		a. Column name is not found in the hash table
     * 		b. The column's value is null or has a length of 0
     * 
     * Throws an IncrementErrorCountException when
     * 		a. The value can't be converted to a one of the provided date formats
     * 		b. An unexpected error occurs during this method
     *
     * /
	public static BigDecimal getHashTableDateTimeValue(Hashtable<String, String> _ht, String _columnName, String[] _dateFromats) throws IncrementErrorCountException
	{
		BigDecimal resultDateTimeValue = BigDecimal.ZERO;
		String rawValue = ColumnExtract.getHashTableString(_ht, _columnName);
		
		try {
			if (rawValue != null && rawValue.length()>0)
			{
				resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, _dateFromats);
			}
		} catch (Exception e) {
			throw new IncrementErrorCountException(e.getMessage());
		}
		return resultDateTimeValue;
	}
	*/
	
	/**
     * Extracts the column from the HashTable and
     * Returns a Big Decimal representing a date using a "yyyy-MM-dd'T'HH:mm:ss.SSS" to parse the value
     * 
     * 
     * @param _ht - input HashTable
	 * @param _columnName - column to return
     * @return Big Decimal representing the date.  Null if column not found or the date can't be extracted from the column
     *
     * Returns a BigDecimal.ZERO when
     * 		a. Column name is not found in the hash table
     * 		b. The column's value is null or has a length of 0
     * 
     * Throws an IncrementErrorCountException when
     * 		a. The value can't be converted to a one of the date formats pre-defined in this class
     * 		b. An unexpected error occurs during this method
     *
     * /
	public static BigDecimal getHashTableDateTimeValue(Hashtable<String, String> _ht, String _columnName) throws IncrementErrorCountException
	{
		return ColumnExtract.getHashTableDateTimeValue(_ht, _columnName, DateFormats);
	}
	*/
	
	/**
	 * Takes in a cassandra row and a regular expression.  It returns all of the columns that match the regular expression in a JSON Array string
	 * Each object in the JSON array has these attributes:
	 * 		ColumnName - Name of the column it matched on
	 * 		ColumnValue - Value of the column it matched on
	 * 		ColumnTimestamp - Timestamp of the column it matched on
	 * 
	 * The expectation of use is:
	 * 		 - The output of this would be stored in an output port in Informatica.  
	 * 		 - Then passed to a new java transformation.
	 * 		 - Use a MultiValueColumnManager to break the array into multiple rows
	 * 		 - Use ColumnExtract.getJSONAttribute calls to retrieve the attributes of the column  
	 * 	
	 * 
	 * @param row - cassandra row
	 * @param regex - pattern to match columns on.  Ex: \\d+ would match all columns that are numbers.
	 * @return
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 * /
    public static String getJSONOfMultiColumnSet(
            Row<String, String, String> row, String regex)
            throws IncrementErrorCountException
    {
        String returnValue = null;
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher("");
        String columnName = null;

        try
        {
            if ((row != null) && (regex != null))
            {
                JSONArray columnArray = new JSONArray();
                ColumnSlice<String, String> cs = row.getColumnSlice();
                for (int i = 0; i < cs.getColumns().size(); i++)
                {
                    columnName = cs.getColumns().get(i).getName();
                    if (matcher.reset(columnName).lookingAt())
                    {
                        JSONObject newColumn = new JSONObject();
                        newColumn.put("ColumnTimestamp",
                                new BigDecimal(cs.getColumns().get(i)
                                        .getClock() / 1000).toString());
                        // newColumn.put("ColumnValue",
                        // ColumnExtract.convertXMLToJSON(cs.getColumns().get(i).getValue()));
                        newColumn.put("ColumnValue", cs.getColumns().get(i)
                                .getValue());
                        if(matcher.groupCount() > 0)
                        {
                            newColumn.put("ColumnName", matcher.group(1));
                        }
                        else
                        {
                            newColumn.put("ColumnName", matcher.group());
                        }
                        columnArray.put(newColumn);
                    }
                }
                if (columnArray.length() > 0)
                {
                    returnValue = columnArray.toString();
                }
            }

        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(e.getMessage());
        }
        return returnValue;
        
//        String returnValue = null;
//
//        try
//        {
//            if ((row != null) && (regex != null))
//            {
//                JSONArray columnArray = new JSONArray();
//                ColumnSlice<String, String> cs = row.getColumnSlice();
//                for (int i = 0; i < cs.getColumns().size(); i++)
//                {
//                    if (cs.getColumns().get(i).getName().matches(regex))
//                    {
//                        JSONObject newColumn = new JSONObject();
//                        newColumn.put("ColumnTimestamp",
//                                new BigDecimal(cs.getColumns().get(i)
//                                        .getClock() / 1000).toString());
//                        // newColumn.put("ColumnValue",
//                        // ColumnExtract.convertXMLToJSON(cs.getColumns().get(i).getValue()));
//                        newColumn.put("ColumnValue", cs.getColumns().get(i)
//                                .getValue());
//                        newColumn.put("ColumnName", cs.getColumns().get(i)
//                                .getName());
//                        columnArray.put(newColumn);
//                    }
//                }
//                if (columnArray.length() > 0)
//                {
//                    returnValue = columnArray.toString();
//                }
//            }
//
//        }
//        catch (Exception e)
//        {
//            throw new IncrementErrorCountException(e.getMessage());
//        }
//        return returnValue;
    }
    */
	
	/**
     * Simply constructs a standard error message for data type conversions.
     * 
     * 
     * @param _columnName - Column name of the column where the data type conversion error occurred
	 * @param _columnValue - Value that failed conversion 
	 * @return String representing the formated error message.
     */
	public static String genColumnErrorMsg(String _columnName, String _columnValue) {
		return "Error occurred on data type conversion for ColumnName '" + _columnName + "', ColumnValue: '" + _columnValue + "', Error message: ";
	}
	
	/**
	 * 
	 */
	public static String genClassErrorMsg(String _className, String _methodName) {
		return "Error occurred in " + _className + "." + _methodName + ".  ";
	}
	/**
	 * 
	 */
	public static String genConnectErrorMsg(String _cassandraUrl, String _keySpace, String _cassandraCluster, String _columnFamily) {
		return "Error accessing Cassandra.  CassandraUrl='" + _cassandraUrl + "'; " 
	            + "KeySpace='" + _keySpace  + "'; "
	            + "CassandraClusterName='" + _cassandraCluster  + "'; " 
	            + "ColumnFamilyName='" + _columnFamily  +"'.  ";
	}
	
	/**
	 * Unzips a gzipped input String and returns the content as String.
	 * @param content
	 * @param contentEncoding
	 * @return decompressed (unzipped) content
	 */
    public static String getDecompressedContent(String content, String contentEncoding)
    {
        if (GZIP_ENCODING.equals(contentEncoding))
        {
            byte[] decoded = Base64.decodeBase64((String) content);
            return new String(GZIPUtil.decompress(decoded));
        }

        return content.toString();
    }
    
    /**
     * converts a cassandra row <pre>(Row<K,N,V>)</pre> to a JSON string. This method only converts name value pairs and ignores
     * other attributes on the cassandra column <pre>(HColumn<N, V>)</pre>
     * It  adds following additional attributes to the JSON String
     * <li> rowkey - maps to row key of cassandra row
     * <li> updateTimestamp - most recent timestamp on the row, gives you the last time the row was updated
     * 
     * @param row - Row, input cassandra Row to convert
     * @return - String, JSON representation of cassandra row
     * /
    public static String convertRowToJSON(Row<String, String, String> row)
    {
	    JSONObject jsonObject = new JSONObject();

	    try
	    {
	        jsonObject.put("rowkey", row.getKey());
	        jsonObject.put("updateTimestamp", getMaxDateValue(row));

	        ColumnSlice<String, String> columnSlice = row.getColumnSlice();
	        List<HColumn<String, String>> columnList = columnSlice.getColumns();

	        for (HColumn<String, String> column : columnList)
	        {
	            jsonObject.put(column.getName(), column.getValue());
	        }

	        return jsonObject.toString();
	    }
	    catch(JSONException je)
	    {
	        throw new FormatConversionException(
	                ErrorCodeMapping.JSONAddAttributeException.getErrorMessage(),
	                ErrorCodeMapping.JSONAddAttributeException.getErrorCode(),
	                je);
	    }
    }
    */
	
    /**
     * converts a cassandra row <pre>(Row<K,N,V>)</pre> to a JSON string. This method converts name value pairs
     * along with column timestamp and ignores other attributes on the cassandra column <pre>(HColumn<N, V>)</pre>
     * It  adds following additional attributes to the JSON String
     * <li> rowkey - maps to row key of cassandra row
     * <li> updateTimestamp - most recent timestamp on the row, gives you the last time the row was updated
     * 
     * @param row - Row, input cassandra Row to convert
     * @return - String, JSON representation of cassandra row
     * /
    public static String convertRowToJSONWithTimeStamp(Row<String, String, String> row)
    {
	    JSONArray jsonArray = null;
        JSONObject jsonObject = new JSONObject();
        JSONObject childValueJSONObject = null;
        JSONObject childTimestampJSONObject = null;

        try
        {
            jsonObject.put("rowkey", row.getKey());
            jsonObject.put("updateTimestamp", getMaxDateValue(row));

            ColumnSlice<String, String> columnSlice = row.getColumnSlice();
            List<HColumn<String, String>> columnList = columnSlice.getColumns();

            for (HColumn<String, String> column : columnList)
            {
                jsonArray = new JSONArray();
                childValueJSONObject = new JSONObject();
                childValueJSONObject.put("value", column.getValue());
                jsonArray.put(childValueJSONObject);

                childTimestampJSONObject = new JSONObject();
                childTimestampJSONObject.put("columnTimestamp", column.getClock());
                jsonArray.put(childTimestampJSONObject);

                jsonObject.put(column.getName(), jsonArray);
            }
        }
        catch(JSONException je)
        {
	        throw new FormatConversionException(
	                ErrorCodeMapping.JSONAddAttributeException.getErrorMessage(),
	                ErrorCodeMapping.JSONAddAttributeException.getErrorCode(),
	                je);
        }
        
        return jsonObject.toString();
    }
    */
	
	private static class CharPositionLength
	{
	    private int position = -1;
	    private int length = 0;
	    
	    public CharPositionLength(int position, int length)
	    {
	        this.position = position;
	        this.length = length;
	    }
	    
	    public int getPosition()
	    {
	        return this.position;
	    }
	    
	    public int getLength()
	    {
	        return this.length;
	    }

        @Override
        public String toString()
        {
            return "CharPositionLength [position=" + position + ", length="
                    + length + "]";
        }
	}
	
	public static boolean isJSONObject(String json)
	{
	    if (json.startsWith(OPEN_CURLY_BRACE))
	    {
	        return true;
	    }
	    return false;
	}
	
	public static boolean isJSONArray(String json)
	{
	    if (json.startsWith(OPEN_SQUARE_BRACKET))
	    {
	        return true;
	    }
	    return false;
	}
	
	/**
	 * Takes in a JSON String and a regular expression.  It returns all of the columns that match the 
	 * regular expression in a JSON Array string
	 * Each object in the JSON array has these attributes:
	 * 		ColumnName - Name of the column it matched on
	 * 		ColumnValue - Value of the column it matched on
	 * 		ColumnTimestamp - Timestamp of the column it matched on
	 * 
	 * The expectation of use is:
	 * 		 - The output of this would be stored in an output port in Informatica.  
	 * 		 - Then passed to a new java transformation.
	 * 		 - Use a MultiValueColumnManager to break the array into multiple rows
	 * 		 - Use ColumnExtract.getJSONAttribute calls to retrieve the attributes of the column  
	 * 
	 * @param json - JSON String
	 * @param regex - pattern to match columns on.  Ex: \\d+ would match all columns that are numbers.
	 * @return
     *
     * Throws an IncrementErrorCountException when
     * 		a. An unexpected error occurs during this method
     *
	 */
    public static String getJSONOfMultiColumnSet(String json, String regex) throws IncrementErrorCountException
    {
        String returnValue = null;
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher("");
        String columnName = null;
        boolean hasTimeStamp = false;

        /**
                        Following input formats need to be supported
                        Given json
                        {
                          "workflowSubProcessId|8008863:1524128:36028797018964766": [
                              {"value": "1524128"},
                              {"columnTimestamp": 1368023360839001}
                           ],
                           "workflowSubProcessId|8009139:1524248:36028797018964766": [
                              {"value": "1524248"},
                              {"columnTimestamp": 1368026601601001}
                           ]
                        }

                        ColumnExtract.getJSONOfMultiColumnSet(json, "workflowSubProcessID\\|(+.)");
                        will return
                        [
                           {
                              "ColumnName": "8009139:1524248:36028797018964766",
                              "ColumnTimestamp": "1368026601601001",
                              "ColumnValue": "1524248"
                           },
                           {
                              "ColumnName": "8008863:1524128:36028797018964766",
                              "ColumnTimestamp": "1368023360839001",
                              "ColumnValue": "1524128"
                           }
                        ]

                        -----------------------------------------------
                        Given json
                        {
                           "childProcessId|1402321:241048:36028797018964758": "241048",
                           "entityKey": "O2S_Install_Access--1.0--48",
                           "childProcessId|1402322:241048:36028797018964758": "241049",
                        }

                        ColumnExtract.getJSONOfMultiColumnSet(json, "childProcessId\\|(+.)");
                        will return
                        [
                           {
                              "ColumnName":"1402321:241048:36028797018964758",
                              "ColumnValue":"241048"      
                           },
                           {
                              "ColumnName":"1402322:241048:36028797018964758",
                              "ColumnValue":"241049"      
                           }
                        ]
         **/
                        
        try
        {
            if ((json != null) && (regex != null))
            {
                JSONObject jsonObject = new JSONObject(json);
                JSONArray columnArray = new JSONArray();
                
                Iterator<String> iter = jsonObject.keys();
                while(iter.hasNext())
                {
                    columnName = iter.next();
                    if (matcher.reset(columnName).lookingAt())
                    {
                        // we found a match for the column name regex, so column exists
                        // determine what pattern of json is passed in
                        if(getJSONAttributeStringValue(json, columnName + ".columnTimestamp") != null)
                        {
                            hasTimeStamp = true;
                        }
                        
                        JSONObject newColumn = new JSONObject();
                        
                        if(hasTimeStamp)
                        {
                            newColumn.put("ColumnValue", getJSONAttributeStringValue(json, columnName + ".value"));
                            newColumn.put("ColumnTimestamp",
                                    new BigDecimal(getJSONAttributeStringValue(json, columnName + ".columnTimestamp")).toString());
                        }
                        else
                        {
                            newColumn.put("ColumnValue", getJSONAttributeStringValue(json, columnName));
                        }
                        
                        if(matcher.groupCount() > 0)
                        {
                            newColumn.put("ColumnName", matcher.group(1));
                        }
                        else
                        {
                            newColumn.put("ColumnName", matcher.group());
                        }
                        
                        columnArray.put(newColumn);
                    }
                }
                if (columnArray.length() > 0)
                {
                    returnValue = columnArray.toString();
                }
            }

        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(e.getMessage());
        }
        return returnValue;
    }
    
    public static ClientResponse getResourceFromUrl(String url)
    {
            Client client = Client.create();
            
//            client.addFilter(new HTTPBasicAuthFilter(userName, password));

            WebResource webResource = client.resource(url);

//            ClientResponse response = webResource.queryParams(params).get(ClientResponse.class);
            ClientResponse response = webResource.get(ClientResponse.class);
            
            return response;
    }
    
    public static synchronized String generateUUID()
    {
        return UUID.randomUUID().toString();
    }
    
    /**
     * This method uses JsonPath to lookup attributes in a hierarchial JSON, attribute to be looked up
     * is passed using dot notation e.g. order.detail.customer.customerName
     * @param json Json String containing the attribute
     * @param attribute Attribute name for which value is to be searched
     * @return Attribute value if found, else null
     */
    public static String getJsonString(String json, String attribute)
    {
        try
        {
            return (String)JsonPath.read(json, attribute);
        }
        catch(InvalidPathException ex)
        {
            
        }
        
        return null;
    }
    
    /**
     * This method uses JsonPath to lookup attributes in a hierarchial JSON, attribute to be looked up
     * is passed using dot notation e.g. order.detail.general.AmortizedNRC. Returns an Integer value for the
     * attribute
     * @param json Json String containing the attribute
     * @param attribute Attribute name for which value is to be searched
     * @return Attribute value as Integer if found, else null
     */
    public static Integer getJsonInteger(String json, String attribute)
    {
        try
        {
            return JsonPath.read(json, attribute);
        }
        catch(InvalidPathException ex)
        {
            
        }
        
        return null;
    }
    
    /**
     * This method uses JsonPath to lookup attributes in a hierarchial JSON, attribute to be looked up
     * is passed using dot notation e.g. order.detail.general.AmortizedNRC. Returns a Long value for the
     * attribute
     * @param json Json String containing the attribute
     * @param attribute Attribute name for which value is to be searched
     * @return Attribute value as Long if found, else null
     */
    public static Long getJsonLong(String json, String attribute)
    {
        try
        {
            Object value = JsonPath.read(json, attribute);
            
            if(value instanceof Integer)
            {
                return Long.valueOf(((Integer)value).longValue());
            }
            else
            {
                return (Long)value;
            }
        }
        catch(InvalidPathException ex)
        {
            
        }
        
        return null;
    }
    
    /**
     * This method uses JsonPath to lookup attributes in a hierarchial JSON, attribute to be looked up
     * is passed using dot notation e.g. order.detail.general.AmortizedNRC. Returns a Double value for the
     * attribute
     * @param json Json String containing the attribute
     * @param attribute Attribute name for which value is to be searched
     * @return Attribute value as Double if found, else null
     */
    public static Double getJsonDouble(String json, String attribute)
    {
        try
        {
            return JsonPath.read(json, attribute);
            
//            return Double.valueOf(value);
        }
        catch(InvalidPathException ex)
        {
            
        }
        
        return null;
    }
    
    /**
     * This method takes a JSONObject and retrieves a Date value as BigDecimal for the given attribute.
     * @param jsonObject JSONObject that needs to be searched
     * @param attributeName Attribute name for which the Date value needs to be parsed
     * @return Date as BigDecimal
     * @throws IncrementErrorCountException
     */
	public static BigDecimal getJSONAttributeDateValue(JSONObject jsonObject, String attributeName) throws IncrementErrorCountException 
	{
		return ColumnExtract.getJSONAttributeDateValue(jsonObject, attributeName, DateFormats);
	}
	
    /**
     * This method takes a JSONObject and retrieves a Date value as BigDecimal for the given attribute.
     * @param jsonObject JSONObject that needs to be searched
     * @param attributeName Attribute name for which the Date value needs to be parsed
     * @param dateFormats custom DateFormat to parse date string
     * @return Date as BigDecimal
     * @throws IncrementErrorCountException
     */
	public static BigDecimal getJSONAttributeDateValue(JSONObject jsonObject, String attributeName, String[] dateFormats) throws IncrementErrorCountException
	{
		BigDecimal resultDateTimeValue = null; //BigDecimal.ZERO;
		String rawValue = jsonObject.optString(attributeName);
		
		if (rawValue == null || rawValue.equals("") || rawValue.equalsIgnoreCase("null"))
		{
		    return resultDateTimeValue;
		}
		
        try
        {
            resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, dateFormats);
        }
        catch (IncrementErrorCountException e)
        {
            try
            {
                resultDateTimeValue = ColumnExtract.getDateTimeFromFormat(rawValue, DateFormats);
            }
            catch (Exception e1)
            {
                throw new IncrementErrorCountException(genClassErrorMsg(
                        className, "getJSONAttributeDateValue")
                        + genColumnErrorMsg(attributeName, rawValue)
                        + e1.getMessage());
            }
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(genClassErrorMsg(className,
                    "getJSONAttributeDateValue")
                    + genColumnErrorMsg(attributeName, rawValue)
                    + e.getMessage());
        }
        return resultDateTimeValue;
	}
	
	/**
	 * This method takes a JSONObject and retrieves a JSONArray as value for the given attribute.
	 * @param json String that needs to be searched
	 * @param attributeName Attribute name for which the JSONArray needs to be retrieved
	 * @return attribute value as JSONArray
	 * @throws IncrementErrorCountException
	 */
    public static JSONArray getJSONAttributeJsonArrayValue(String json, String attributeName) throws IncrementErrorCountException
    {
        JSONArray returnValue = null;
        String rawValue = ColumnExtract.getJSONAttributeStringValue(json, attributeName);
        
        if (rawValue == null || rawValue.equals("") || rawValue.equalsIgnoreCase("null"))
        {
            return returnValue;
        }

        try
        {
            if(isJSONArray(rawValue))
            {
                returnValue = new JSONArray(rawValue);
                
                return returnValue;
            }
            else
            {
                throw new IncrementErrorCountException(
                    "Failed to convert attribute [" + attributeName
                            + "] raw value = [" + rawValue
                            + "] to a JSONArray.");
            }
        }
        catch (Exception e)
        {
            throw new IncrementErrorCountException(
                    "Failed to convert attribute [" + attributeName
                            + "] raw value = [" + rawValue
                            + "] to a JSONArray.");
        }
    }
    
    /**
     * This method parses the given JSONArray and returns a comma seperate list of the contents of JSONArray
     * @param json JSONArray that needs to be converted to comma seperated list
     * @return String value containing the contents of JSONArray as comma seperated list
     * @throws IncrementErrorCountException
     */
    public static String getCsv(JSONArray json) throws IncrementErrorCountException
    {
        StringBuffer strBuf = null;

        try
        {
            if(json == null || json.length() == 0)
            {
                return null;
            }
            
            strBuf = new StringBuffer();
            for(int index = 0; index < json.length(); ++index)
            {
                if(index != 0)
                {
                    strBuf.append(",");
                }
                strBuf.append(json.getString(index));
            }
            
            return strBuf.toString();
        }
        catch(Exception e)
        {
            throw new IncrementErrorCountException(
                    "Failed to convert JSONArray [" + json + "] to csv value.");
        }
    }
    
    /**
     * checks whether the input String is a valid JSON. null string or empty string are treated as invalid JSON.
     * @param jsonString String that needs to be checked for JSON validity
     * @return boolean - true, if input String is valid JSON. false, if input String is not valid JSON
     * @throws IncrementErrorCountException
     */
    public static boolean isValidJson(String jsonString) throws IncrementErrorCountException
    {
        if(jsonString == null || jsonString.equals(""))
        {
            return false;
        }
        
        try
        {
            if(isJSONObject(jsonString))
            {
                new JSONObject(jsonString);
                return true;
            }

            if(isJSONArray(jsonString))
            {
                new JSONArray(jsonString);
                return true;
            }
            
            return false; // if not a JSONString or JSONArray 
        }
        catch(Exception ex)
        {
            return false;
        }
    }
}