package com.level3.etl.cassandra.metadata;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class MetadataManager {
	
	// workflow column families
	
	
	// task
	public final static String TASK_ID_FIELD = "id";
	public final static String CREATED_ON_FIELD = "createdOn";
	public final static String BIZ_ADMIN_USERS_FIELD = "bizadminUsers";
	public final static String ACTIVATION_TIME_FIELD = "activationTime";
	public final static String POT_OWNER_GROUPS_FIELD = "potownerGroups";
	public final static String TASK_NAME_FIELD = "name_en-US";
	public final static String NOTE_SOURCE_SYSTEM_CODE_FIELD = "noteSourceSystemCode";
	public final static String SUBJECT_FIELD = "subject_en-US";
	public final static String ACTUAL_OWNER_FIELD = "actualOwner";
	public final static String DESCRIPTION_FIELD = "description_en-US";

	static public final String WORKFLOW_TASK_CF = "task";
	static public final String WORKFLOW_TASK_CF_COLUMNS = TASK_ID_FIELD + ", " + CREATED_ON_FIELD + ", " +  BIZ_ADMIN_USERS_FIELD + ", " +  ACTIVATION_TIME_FIELD + ", " +  POT_OWNER_GROUPS_FIELD + ", " +  TASK_NAME_FIELD + ", " +  NOTE_SOURCE_SYSTEM_CODE_FIELD + ", " +  SUBJECT_FIELD + ", " +  ACTUAL_OWNER_FIELD + ", " +  DESCRIPTION_FIELD;
	
	// order column families
	
	
	// hash maps
	static private Hashtable<String,String> CFColumns = initCFColumnNames();
	
	
	
	
	
	
	public static final Hashtable<String,String> initCFColumnNames()
	{
		Hashtable<String,String> ht = new Hashtable<String,String>();
		
		ht.put(WORKFLOW_TASK_CF, WORKFLOW_TASK_CF_COLUMNS);
		
		return ht;
	}
	
	
	// functions
	public static String getColumns(String columnFamilyName)
	{
		return CFColumns.get(columnFamilyName);
	}
	
	public static List<String> getColumnsArray(String columnFamilyName)
	{
		String colListStr = CFColumns.get(columnFamilyName);
		String[] colArray = colListStr.split(",");
		ArrayList<String> aList = new ArrayList<String>();
		for( String item: colArray)
		{
			aList.add(item);
		}
		
		return aList;
	}


}
