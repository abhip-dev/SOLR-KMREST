package com.level3.etl.exception;

@SuppressWarnings("serial")
public class FailSessionException extends RuntimeException {

	public FailSessionException( final String msg)
	{
		super(msg);
	}
	
	public FailSessionException(final String msg, Throwable e )
	{
		super(msg,e);
	}
	
	public FailSessionException()
	{
		super();
	}
	
	public FailSessionException(Throwable e )
	{
		super(e);
	}

}

