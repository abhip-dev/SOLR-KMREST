package com.level3.etl.emp.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.util.zip.GZIPInputStream;

public class GZIPUtil
{
    private static final int BAOS_INIT_SIZE = 0x1000;
    private static final int READ_BUFF_SIZE = 0x0800;
    
    public static byte[] decompress(byte[] data)
    {
        if (null == data)
        {
            return null;
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream(BAOS_INIT_SIZE);
        byte[] buffer = new byte[READ_BUFF_SIZE];
        GZIPInputStream gzip = null;

        try
        {
            gzip = new GZIPInputStream(new ByteArrayInputStream(data));

            for (int len = 0; (len = gzip.read(buffer)) > 0;)
            {
                bos.write(buffer, 0, len);
            }

            return bos.toByteArray();

        }
        catch (Exception e)
        {
            throw new RuntimeException(
                    "An error occurred while trying to gzip decompress", e);
        }
        finally
        {
            safeClose(gzip);
        }
    }
    
    private static final boolean safeClose(Closeable closeable)
    {
        boolean error = false;
        try
        {
            if (null != closeable)
            {
                closeable.close();
            }
        }
        catch (Exception e)
        {
            error = true;
        }
        return error;
    }
}
