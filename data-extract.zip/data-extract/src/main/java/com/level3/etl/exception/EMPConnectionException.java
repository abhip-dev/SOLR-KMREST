package com.level3.etl.exception;

public class EMPConnectionException extends Exception
{
    private static final long serialVersionUID = -1317680814155654598L;
    
    private String errorCode = null;

    public EMPConnectionException()
    {
        super();
    }
    
    public EMPConnectionException(Throwable cause)
    {
        super(cause);
    }
    
    public EMPConnectionException(String message, Throwable cause)
    {
        super(message, cause);
    }
    
    public EMPConnectionException(String message, String errorCode)
    {
        super(message);
        
        this.errorCode = errorCode;
    }

    public String getErrorCode()
    {
        return errorCode;
    }

    public void setErrorCode(String errorCode)
    {
        this.errorCode = errorCode;
    }
}
