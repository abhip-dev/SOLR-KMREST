package com.level3.etl.essbase.dataobjects;

public class EssbaseHierarchyDO
{
    String member;
    String alias;
    String dimension;
    String parent;
    String consolidationType;
    String mbrId;
    int dimensionNumber = -1;
    int levelNumber = -1;
    int generationNumber = -1;
    int memberNumber = -1;
    int id = -1;
    int currentBudget = 0;
    int currentForecast = 0;

    public String getMember()
    {
        return member;
    }
    public void setMember(String member)
    {
        this.member = member;
    }
    public String getAlias()
    {
        return alias;
    }
    public void setAlias(String alias)
    {
        this.alias = alias;
    }
    public String getDimension()
    {
        return dimension;
    }
    public void setDimension(String dimension)
    {
        this.dimension = dimension;
    }
    public String getParent()
    {
        return parent;
    }
    public void setParent(String parent)
    {
        this.parent = parent;
    }
    public String getConsolidationType()
    {
        return consolidationType;
    }
    public void setConsolidationType(String consolidationType)
    {
        this.consolidationType = consolidationType;
    }
    public String getMbrId()
    {
        return mbrId;
    }
    public void setMbrId(String mbrId)
    {
        this.mbrId = mbrId;
    }
    public int getDimensionNumber()
    {
        return dimensionNumber;
    }
    public void setDimensionNumber(int dimensionNumber)
    {
        this.dimensionNumber = dimensionNumber;
    }
    public int getLevelNumber()
    {
        return levelNumber;
    }
    public void setLevelNumber(int levelNumber)
    {
        this.levelNumber = levelNumber;
    }
    public int getGenerationNumber()
    {
        return generationNumber;
    }
    public void setGenerationNumber(int generationNumber)
    {
        this.generationNumber = generationNumber;
    }
    public int getMemberNumber()
    {
        return memberNumber;
    }
    public void setMemberNumber(int memberNumber)
    {
        this.memberNumber = memberNumber;
    }
    public int getId()
    {
        return id;
    }
    public void setId(int id)
    {
        this.id = id;
    }
    public int getCurrentBudget()
    {
        return currentBudget;
    }
    public void setCurrentBudget(int currentBudget)
    {
        this.currentBudget = currentBudget;
    }
    public int getCurrentForecast()
    {
        return currentForecast;
    }
    public void setCurrentForecast(int currentForecast)
    {
        this.currentForecast = currentForecast;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("EssbaseHierarchyDO [member=");
        builder.append(member);
        builder.append(", alias=");
        builder.append(alias);
        builder.append(", dimension=");
        builder.append(dimension);
        builder.append(", parent=");
        builder.append(parent);
        builder.append(", consolidationType=");
        builder.append(consolidationType);
        builder.append(", mbrId=");
        builder.append(mbrId);
        builder.append(", dimensionNumber=");
        builder.append(dimensionNumber);
        builder.append(", levelNumber=");
        builder.append(levelNumber);
        builder.append(", generationNumber=");
        builder.append(generationNumber);
        builder.append(", memberNumber=");
        builder.append(memberNumber);
        builder.append(", id=");
        builder.append(id);
        builder.append(", currentBudget=");
        builder.append(currentBudget);
        builder.append(", currentForecast=");
        builder.append(currentForecast);
        builder.append("]");
        return builder.toString();
    }
}
