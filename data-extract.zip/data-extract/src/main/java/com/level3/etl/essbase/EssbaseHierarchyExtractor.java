package com.level3.etl.essbase;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.essbase.api.base.EssException;
import com.essbase.api.base.IEssIterator;
import com.essbase.api.datasource.IEssCube;
import com.essbase.api.datasource.IEssOlapServer;
import com.essbase.api.domain.IEssDomain;
import com.essbase.api.metadata.IEssDimension;
import com.essbase.api.session.IEssbase;
import com.level3.etl.essbase.dataobjects.EssbaseConnectionDO;
import com.level3.etl.essbase.dataobjects.EssbaseHierarchyDO;

public class EssbaseHierarchyExtractor
{
    private static Logger log = LoggerFactory.getLogger(EssbaseHierarchyExtractor.class); 

    public void getGoatMemberInfo(EssbaseConnectionDO connectionDO, EssbaseHierarchyCallbackIF callback)
    {
        IEssbase ess = null;
        IEssDomain dom;
        IEssOlapServer olapSvr = null;
        IEssCube essCube = null;
        IEssIterator dimensions = null;
        int id = 0;
        EssbaseHierarchyDO essbaseHierarchyDO = null;

        try
        {
            //Setup Essbase Connection
            ess = IEssbase.Home.create(connectionDO.getJapiVersion());
            dom = ess.signOn(connectionDO.getUerName(), connectionDO.getPassword(), false, null, connectionDO.getProviderUrl());
            olapSvr = (IEssOlapServer)dom.getOlapServer(connectionDO.getOlapServerName());
            olapSvr.connect();
            essCube = olapSvr.getApplication(connectionDO.getApplicationName()).getCube(connectionDO.getCubeName());
            
            dimensions = essCube.getDimensions();

            for (int j = 0; j < dimensions.getCount(); j++)
            {
                String dimension = ((IEssDimension)dimensions.getAt(j)).getName();
                log.info("DIMENSION - {}", dimension);
                
                /*
                if(dimension.equalsIgnoreCase("Customer"))
                {
                    continue;
                }
                */
                
                if(! (dimension.equalsIgnoreCase("Entity") ||
                      dimension.equalsIgnoreCase("Profit Center") ||
                      dimension.equalsIgnoreCase("LOB") ||
                      dimension.equalsIgnoreCase("Segment4") ||
                      dimension.equalsIgnoreCase("Account") ||
                      dimension.equalsIgnoreCase("Year") ||
                      dimension.equalsIgnoreCase("Scenario") ||
                      dimension.equalsIgnoreCase("Version") ||
                      dimension.equalsIgnoreCase("Data Type") ||
                      dimension.equalsIgnoreCase("Product") ||
                      dimension.equalsIgnoreCase("Department") ||
                      dimension.equalsIgnoreCase("Period")))
                {
                    continue;
                }

                String memberString =
                   '\t' +
                   essCube.queryMembers("<DESCENDANTSOF \"" + dimension + "\" <FORMAT { ALTNAMES MBRNAMES MBRNUMBERS DIMNUMBERS LEVELNUMBERS GENERATIONS UCALCS MBRID NEWLINESEPARATED} <SORTNONE");

                String[] memberStrings = memberString.split("\n");
                
                List<String> genParents = new ArrayList<String>();

                for (int i = 0; i < 99; i++)
                {
                    genParents.add("-");
                }

                for (int i = 0; i < memberStrings.length; i++)
                {
                    String[] splitString = memberStrings[i].split("\t");

                    String aliasName = splitString[1].replace("'", "''");
                    String memberName = splitString[2].replace("'", "''");
                    int mbrNumber = Integer.parseInt(splitString[3]);
                    int dimNumber = Integer.parseInt(splitString[4]);
                    int lvlNumber = Integer.parseInt(splitString[5]);
                    int genNumber = Integer.parseInt(splitString[6]);
                    String consolidation = splitString[7].replace("'", "''");
                    String MBRID = splitString[8].replace("'", "''");
                    String parent;

                    if (genNumber == 1)
                    {
                        parent = "NULL";
                    }
                    else
                    {
                        parent = genParents.get(genNumber - 1);
                    }

                    genParents.add(genNumber, memberName);

                    essbaseHierarchyDO = new EssbaseHierarchyDO();
                    essbaseHierarchyDO.setMember(memberName);
                    essbaseHierarchyDO.setAlias(aliasName);
                    essbaseHierarchyDO.setDimension(dimension);
                    essbaseHierarchyDO.setParent(parent);
                    essbaseHierarchyDO.setDimensionNumber(dimNumber);
                    essbaseHierarchyDO.setLevelNumber(lvlNumber);
                    essbaseHierarchyDO.setGenerationNumber(genNumber);
                    essbaseHierarchyDO.setMemberNumber(mbrNumber);
                    essbaseHierarchyDO.setConsolidationType(consolidation);
                    essbaseHierarchyDO.setMbrId(MBRID);
                    essbaseHierarchyDO.setId(id);
                    
                    // call callback 
                    callback.receiveEssbaseHierarchyRow(essbaseHierarchyDO);

                    id++;
                }
            }
        }
        catch (EssException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                essCube.clearActive();
            }
            catch (EssException e)
            {
                e.printStackTrace();
            }

            try
            {
                olapSvr.disconnect();
            }
            catch (EssException e)
            {
                e.printStackTrace();
            }

            try
            {
                ess.signOff();
            }
            catch (EssException e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String[] args)
    {
        try
        {
            log.info("Starting process to extract hierarchy from Essbase.");
            EssbaseConnectionDO connectionDO = new EssbaseConnectionDO();
            
            connectionDO.setApplicationName("GCTLWeb");
            connectionDO.setCubeName("GOATCTL");
            connectionDO.setJapiVersion("11.1.2.4");
            connectionDO.setOlapServerName("epmapp-dev1");
            connectionDO.setUerName("WebRpt");
            connectionDO.setPassword("WebRpt_Read!");
            connectionDO.setProviderUrl("http://epmapp-dev1.idc1.level3.com:13080/aps/JAPI");

            EssbaseHierarchyExtractor obj = new EssbaseHierarchyExtractor();
            obj.getGoatMemberInfo(connectionDO,
                    new EssbaseHierarchyCallbackIF()
            {
                
                public void receiveEssbaseHierarchyRow(EssbaseHierarchyDO essbaseHierarchyDO)
                {
                    log.info(essbaseHierarchyDO.toString());
                }
            });

            log.info("Completed process to extract hierarchy from Essbase.");
        }
        catch(Exception ex)
        {
            log.error("caught exception ", ex);
        }
    }
}
