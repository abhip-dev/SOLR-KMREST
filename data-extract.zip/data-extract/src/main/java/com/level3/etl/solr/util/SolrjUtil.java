package com.level3.etl.solr.util;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.etl.exception.IncrementErrorCountException;

public class SolrjUtil
{
    private static Logger log = LoggerFactory.getLogger(SolrjUtil.class); 
    
//    private static final String TZ_STR = "GMT";
	private static final String SOLJ_DATE_FMT = "yyyy-MM-dd'T'HH:mm:ss'Z'" ; 
	private static final String INFA_DATE_FMT = "MM/dd/yyyy HH:mm:ss";
	
//	private static final String REQUEST_PROPERTY_AUTHORIZATION = "Authorization"; 
    private static final String REQUEST_PROPERTY_CONTENT_TYPE = "Content-Type"; 
	
	
    public static String getSolrDate(String dateStr) throws IncrementErrorCountException
    {
        Calendar cal = null;
        
        SimpleDateFormat out = new SimpleDateFormat(SOLJ_DATE_FMT);
        
//        cal = Calendar.getInstance(new SimpleTimeZone(0, TZ_STR));
        cal = Calendar.getInstance();
        
        out.setCalendar(cal);
        
        try
        {
            return out.format(new SimpleDateFormat(INFA_DATE_FMT).parse(dateStr));
        }
        catch (Exception ex)
        {
            log.error("caught exception while trying to convert to Solr compliant date.", ex);
            
            throw new IncrementErrorCountException("caught exception while trying to parse date [" + dateStr + "]", ex);
        }
        
//        return "0000-00-00T00:00:00Z";
    }
    
    public static void addJsonDocument(String urlString, String jsonDoc) throws IncrementErrorCountException
    {
        URL url = null;
        HttpURLConnection connection = null;
        OutputStreamWriter out = null;
        
        String jsonPrefix = "{ \"add\": { \"commitWithin\": 5000, \"doc\": ";
        String jsonSuffix = "}}";
        
        try
        {
	        url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();

//            connection.setRequestProperty(
//                    REQUEST_PROPERTY_AUTHORIZATION, "Basic " + new String(Base64.encode((userName + ":" + password).getBytes() )));

            connection.setRequestProperty(REQUEST_PROPERTY_CONTENT_TYPE, MediaType.APPLICATION_JSON);
            
            connection.setDoOutput(true);

            String jsonToPost = jsonPrefix + jsonDoc + jsonSuffix;
            
            log.debug(jsonToPost);
            
            out = new OutputStreamWriter(connection.getOutputStream());
            out.write(jsonToPost.toCharArray());
            out.close();

            if(HttpURLConnection.HTTP_OK == connection.getResponseCode())
            {
                log.debug("SUCCESS");
            }
            else
            {
                log.debug("FAILED with status " + connection.getResponseCode());
                throw new IncrementErrorCountException("failed to add document to Solr index, error code " + connection.getResponseCode()); 
            }
        }
        catch(Exception ex)
        {
            log.error("caught exception while trying to add document to Solr index.", ex);
            
            throw new IncrementErrorCountException("caught exception while trying to add document to Solr index", ex);
        }
        finally
        {
            try
            {
                connection.disconnect();
            }
            catch(Exception ex)
            {
                
            }
        }
    }
}
