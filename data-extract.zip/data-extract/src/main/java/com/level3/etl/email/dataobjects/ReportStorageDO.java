package com.level3.etl.email.dataobjects;

public class ReportStorageDO
{
    private String reportStagingDir = null;
    private String reportStorageDir = null;
    private String reportFtpDir = null;
    private String customerNumber = null;
    
    public String getReportStorageDir()
    {
        return reportStorageDir;
    }
    public void setReportStorageDir(String reportStorageDir)
    {
        this.reportStorageDir = reportStorageDir;
    }
    public String getReportFtpDir()
    {
        return reportFtpDir;
    }
    public void setReportFtpDir(String reportFtpDir)
    {
        this.reportFtpDir = reportFtpDir;
    }
    public String getCustomerNumber()
    {
        return customerNumber;
    }
    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber = customerNumber;
    }
    public String getReportStagingDir()
    {
        return reportStagingDir;
    }
    public void setReportStagingDir(String reportStagingDir)
    {
        this.reportStagingDir = reportStagingDir;
    }
    
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ReportStorageDO [reportStagingDir=");
        builder.append(reportStagingDir);
        builder.append(", reportStorageDir=");
        builder.append(reportStorageDir);
        builder.append(", reportFtpDir=");
        builder.append(reportFtpDir);
        builder.append(", customerNumber=");
        builder.append(customerNumber);
        builder.append("]");
        return builder.toString();
    }
}
