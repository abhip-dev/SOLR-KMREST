package com.level3.etl.email.dataobjects;

import java.io.File;

import javax.mail.Message;

public class MailMessageDO
{
    private String reportInfoXml = null;
    private MessageStatus status = null;
    private File attachment = null;
    private Message emailMessage = null;
    private String emailMessageBody = null;
    
    public enum MessageStatus 
    { 
        GOOD("", "Good"),
        INVALID_DATA("email does not contain valid data", "Bad - Invalid data"),
        MULTIPLE_ATTACHMENTS("email contains multiple attachments", "Bad - multiple attachments"),
        NO_ATTACHMENTS("email contains zero attachments", "Bad - zero attachments");
        
        private final String description;
        private final String status;
        
        MessageStatus(String desc, String status)
        {
            this.description = desc;
            this.status = status;
        }
        
        public String getDescription()
        {
            return description;
        }
        
        public String getStatus()
        {
            return status;
        }
    }

    public String getReportInfoXml()
    {
        return reportInfoXml;
    }

    public void setReportInfoXml(String reportInfoXml)
    {
        this.reportInfoXml = reportInfoXml;
    }

    public MessageStatus getStatus()
    {
        return status;
    }

    public void setStatus(MessageStatus status)
    {
        this.status = status;
    }

    public File getAttachment()
    {
        return attachment;
    }

    public void setAttachment(File attachment)
    {
        this.attachment = attachment;
    }

    public Message getEmailMessage()
    {
        return emailMessage;
    }

    public void setEmailMessage(Message emailMessage)
    {
        this.emailMessage = emailMessage;
    }

    public String getEmailMessageBody()
    {
        return emailMessageBody;
    }

    public void setEmailMessageBody(String emailMessageBody)
    {
        this.emailMessageBody = emailMessageBody;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("MailMessageDO [reportInfoXml=");
        builder.append(reportInfoXml);
        builder.append(", status=");
        builder.append(status);
        builder.append(", attachment=");
        builder.append(attachment != null ? attachment.getAbsolutePath() : null);
        builder.append(", emailMessage=");
        builder.append(emailMessage);
        builder.append(", emailMessageBody=");
        builder.append(emailMessageBody);
        builder.append("]");
        return builder.toString();
        
    };
}
