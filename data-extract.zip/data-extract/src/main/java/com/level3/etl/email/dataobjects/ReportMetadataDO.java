package com.level3.etl.email.dataobjects;

import java.io.BufferedReader;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.mortbay.log.Log;

public class ReportMetadataDO
{
    private String carrier = null;
    private String reportName = null;
    private String reportType = null;
    private String reportFrequency = null;
    private String reportPeriod = null;
    private String attachmentMimeType = null;
    private String reportUid = null;
    private String customerNumber = null;
    private String reportDate = null;
    private long reportSize = -1L;
    private String messageBodyContent = null;
    
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private static Logger log = LoggerFactory.getLogger(ReportMetadataDO.class);
    
    private static Pattern carrierPattern = Pattern.compile("\\s*Carrier:\\s*(.*)$", Pattern.CASE_INSENSITIVE);
    private static Pattern reportNamePattern = Pattern.compile("\\s*Report Name:\\s*(.*)$", Pattern.CASE_INSENSITIVE);
    private static Pattern reportTypePattern = Pattern.compile("\\s*Report Type:\\s*(.*)$", Pattern.CASE_INSENSITIVE);
    private static Pattern reportFrequencyPattern = Pattern.compile("\\s*Report Frequency:\\s*(.*)$", Pattern.CASE_INSENSITIVE);
    private static Pattern reportPeriodPattern = Pattern.compile("\\s*Report Period:\\s*(.*)$", Pattern.CASE_INSENSITIVE);
    private static Pattern attachmentMimeTypePattern = Pattern.compile("\\s*Attachment Mime Type:\\s*(.*)$", Pattern.CASE_INSENSITIVE);
    
    public ReportMetadataDO()
    {
        reportDate = dateFormat.format(new Date());
    }
    
    public boolean isFilled()
    {
        // check all fields, if not null and not empty, then return true
        if(
                StringUtils.isNotEmpty(this.carrier) &&
                StringUtils.isNotEmpty(this.reportName) &&
                StringUtils.isNotEmpty(this.reportType) &&
                StringUtils.isNotEmpty(this.reportFrequency) &&
                StringUtils.isNotEmpty(this.reportPeriod) &&
                StringUtils.isNotEmpty(this.attachmentMimeType) &&
                StringUtils.isNotEmpty(this.reportUid) &&
                StringUtils.isNotEmpty(this.customerNumber) &&
                reportSize > 0
            )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void populateDataFromString(String inputData)
    {
        // parse the input data for following
        // Carrier:
        // Report Name:
        // Report Type:
        // Report Frequency:
        // Report Period:
        // Attachment Mime Type:
        Matcher carrierMatch = carrierPattern.matcher("");
        Matcher reportNameMatch = reportNamePattern.matcher("");
        Matcher reportTypeMatch = reportTypePattern.matcher("");
        Matcher reportFrequencyMatch = reportFrequencyPattern.matcher("");
        Matcher reportPeriodMatch = reportPeriodPattern.matcher("");
        Matcher attachmentMimeTypeMatch = attachmentMimeTypePattern.matcher("");
        
        String line;
        
        this.messageBodyContent = inputData;
        
        BufferedReader buff = new BufferedReader(new StringReader(inputData));

        try
        {
            while ((line = buff.readLine()) != null)
            {
                if(carrierMatch.reset(line).lookingAt())
                {
                    this.carrier = carrierMatch.group(1);
                }
                else if(reportNameMatch.reset(line).lookingAt())
                {
                    this.reportName = reportNameMatch.group(1);
                }
                else if(reportTypeMatch.reset(line).lookingAt())
                {
                    this.reportType = reportTypeMatch.group(1);
                }
                else if(reportFrequencyMatch.reset(line).lookingAt())
                {
                    this.reportFrequency = reportFrequencyMatch.group(1);
                }
                else if(reportPeriodMatch.reset(line).lookingAt())
                {
                    this.reportPeriod = reportPeriodMatch.group(1);
                }
                else if(attachmentMimeTypeMatch.reset(line).lookingAt())
                {
                    this.attachmentMimeType = attachmentMimeTypeMatch.group(1);
                }
            }
        }
        catch(Exception ex)
        {
            log.warn("caught exception while parsing for meta data.", ex);
        }
    }
    
    public String getCarrier()
    {
        return carrier;
    }
    public void setCarrier(String carrier)
    {
        this.carrier = carrier;
    }
    public String getReportName()
    {
        return reportName;
    }
    public void setReportName(String reportName)
    {
        this.reportName = reportName;
    }
    public String getReportType()
    {
        return reportType;
    }
    public void setReportType(String reportType)
    {
        this.reportType = reportType;
    }
    public String getReportFrequency()
    {
        return reportFrequency;
    }
    public void setReportFrequency(String reportFrequency)
    {
        this.reportFrequency = reportFrequency;
    }
    public String getReportPeriod()
    {
        return reportPeriod;
    }
    public void setReportPeriod(String reportPeriod)
    {
        this.reportPeriod = reportPeriod;
    }
    public String getAttachmentMimeType()
    {
        return attachmentMimeType;
    }
    public void setAttachmentMimeType(String attachmentMimeType)
    {
        this.attachmentMimeType = attachmentMimeType;
    }
    public String getReportUid()
    {
        return reportUid;
    }
    public void setReportUid(String reportUid)
    {
        this.reportUid = reportUid;
    }
    public String getCustomerNumber()
    {
        return customerNumber;
    }
    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber = customerNumber;
    }
    public long getReportSize()
    {
        return reportSize;
    }
    public void setReportSize(long reportSize)
    {
        this.reportSize = reportSize;
    }

    public String getReportDate()
    {
        return reportDate;
    }
    public String getMessageBodyContent()
    {
        return messageBodyContent;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("ReportMetadataDO [carrier=");
        builder.append(carrier);
        builder.append(", reportName=");
        builder.append(reportName);
        builder.append(", reportType=");
        builder.append(reportType);
        builder.append(", reportFrequency=");
        builder.append(reportFrequency);
        builder.append(", reportPeriod=");
        builder.append(reportPeriod);
        builder.append(", attachmentMimeType=");
        builder.append(attachmentMimeType);
        builder.append(", reportUid=");
        builder.append(reportUid);
        builder.append(", accountId=");
        builder.append(customerNumber);
        builder.append(", reportDate=");
        builder.append(reportDate);
        builder.append(", reportSize=");
        builder.append(reportSize);
        builder.append("]");
        return builder.toString();
    }
    
    public String getMetadataAsXml()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        builder.append("<update report-group=\"STARBUCKS\">");
        builder.append("<save>");
        builder.append("<report>");
        builder.append("<report-uid loc=\"");
        builder.append(this.reportUid);
        builder.append("\" />");
        builder.append("<name>");
        builder.append(StringEscapeUtils.escapeXml(this.reportName));
        builder.append("</name>");
        builder.append("<account>");
        builder.append(StringEscapeUtils.escapeXml(this.customerNumber));
        builder.append("</account>");
        builder.append("<type>");
        builder.append(StringEscapeUtils.escapeXml(this.reportType));
        builder.append("</type>");
        builder.append("<period>");
        builder.append(StringEscapeUtils.escapeXml(this.reportFrequency));
        builder.append("</period>");
        builder.append("<date>");
        builder.append(StringEscapeUtils.escapeXml(this.reportDate));
        builder.append("</date>");
        builder.append("<size>");
        builder.append(this.reportSize);
        builder.append("</size>");
        builder.append("<reportperiod>");
        builder.append(StringEscapeUtils.escapeXml(this.reportPeriod));
        builder.append("</reportperiod>");
        builder.append("<carrier>");
        builder.append(StringEscapeUtils.escapeXml(this.carrier));
        builder.append("</carrier>");
        builder.append("</report>");
        builder.append("</save>");
        builder.append("</update>");
        
        return builder.toString();
    }

    /*
    <?xml version="1.0" encoding="UTF-8"?>
    <update report-group="STARBUCKS">
           <save>
                  <report>
                         <report-uid loc="/ftp/PRD/1-5K14R/starbucks/foo/bar/ATT_Monthly_Wireless_Report_09192013.pdf" />
                         <name>ATT_Monthly_Wireless_Report_09192013.pdf</name>
                         <account>1-5K14R</account>
                         <type>Usage</type>
                         <period>Monthly</period>
                         <date>2013-09-19</date>
                         <size>1</size>
                         <reportperiod>08/01/13 – 08/31/13</reportperiod>
                         <carrier>ATT</carrier>
                  </report>
           </save>
           <delete>
                  <report-uid loc="/ftp/PRD/1-5K14R/starbucks/foo/bar/ ATT_Monthly_Wireless_Report_01012012.pdf" />
           </delete>
    </update>
    */

}
