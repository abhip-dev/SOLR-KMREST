package com.level3.etl.cassandra;


import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.etl.cassandra.callback.MultiValueRowCallbackIF;
import com.level3.etl.cassandra.util.ColumnExtract;
import com.level3.etl.exception.IncrementErrorCountException;

/**
 * Uses a JSON Parser to split up a JSON Array if it exists and returns each value found
 * If there is only one object it returns it's value
 * 
 * For example:
 * solrjson:["value1","value2","value3"]
 * Returns:
 * 		value1
 * 		value2
 * 		value3
 * 
 * @author AK018914
 *
 */
public class MultiValueColumnManager 
{
	private String className = "MultiValueColumnManager";
	
	int pageSize = 50;
	String columnValue = null;
	boolean quotedValues = false;

	private static Logger log = LoggerFactory.getLogger(MultiValueColumnManager.class);

    public MultiValueColumnManager(String _columnValue) throws Exception
    {
        this.columnValue = _columnValue;
    }

	/**
	 * Returns each element in JSON Array.  And just the one element should there be on
	 * pullAllRowsWithCallback 
	 * 
	 */
    public void pullAllRowsWithCallback(MultiValueRowCallbackIF callBackObject)
            throws IncrementErrorCountException
    {
        try
        {
            if (columnValue == null)
            {
                return;
            }
            columnValue = columnValue.replace("solrjson:", "");
            // Object obj=JSONValue.parse(columnValue);
            // if (obj == null)
            // {
            // return;
            // }

            // if (obj.getClass().getSimpleName().equals("JSONArray"))
            if (ColumnExtract.isJSONArray(columnValue))
            {
                JSONArray array = new JSONArray(columnValue);

                for (int i = 0; i < array.length(); i++)
                {
                    callBackObject
                            .receiveMultiValueRow(array.get(i).toString());
                }
            }
            else
            {
                callBackObject.receiveMultiValueRow(columnValue);
            }

        }
        catch (Throwable e)
        {
            // log.debug("Exception returning string parts"+ e.getMessage());
            throw new IncrementErrorCountException(
                    ColumnExtract.genClassErrorMsg(className,
                            "pullAllRowsWithCallback")
                            + "Exception returning string parts.  "
                            + e.getMessage());
        }
    }
	
	/**
	 * @param args
	 */
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub

    }
}

