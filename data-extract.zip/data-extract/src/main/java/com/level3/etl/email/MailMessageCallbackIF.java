package com.level3.etl.email;

import com.level3.etl.email.dataobjects.MailMessageDO;

public interface MailMessageCallbackIF
{
    public void receiveMailMessage(MailMessageDO mailMessageDao);
}
