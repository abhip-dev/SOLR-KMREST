package com.level3.etl.essbase;

import com.level3.etl.essbase.dataobjects.EssbaseHierarchyDO;

public interface EssbaseHierarchyCallbackIF
{
    public void receiveEssbaseHierarchyRow(EssbaseHierarchyDO essbaseHierarchyDO);
}
