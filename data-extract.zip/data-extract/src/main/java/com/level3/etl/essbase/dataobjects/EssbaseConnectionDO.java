package com.level3.etl.essbase.dataobjects;

public class EssbaseConnectionDO
{
    String japiVersion = null;
    String uerName = null;
    String password = null;
    String providerUrl = null;
    String olapServerName = null;
    String applicationName = null;
    String cubeName = null;
    
    public String getJapiVersion()
    {
        return japiVersion;
    }
    public void setJapiVersion(String japiVersion)
    {
        this.japiVersion = japiVersion;
    }
    public String getUerName()
    {
        return uerName;
    }
    public void setUerName(String uerName)
    {
        this.uerName = uerName;
    }
    public String getPassword()
    {
        return password;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
    public String getProviderUrl()
    {
        return providerUrl;
    }
    public void setProviderUrl(String providerUrl)
    {
        this.providerUrl = providerUrl;
    }
    public String getOlapServerName()
    {
        return olapServerName;
    }
    public void setOlapServerName(String olapServerName)
    {
        this.olapServerName = olapServerName;
    }
    public String getApplicationName()
    {
        return applicationName;
    }
    public void setApplicationName(String applicationName)
    {
        this.applicationName = applicationName;
    }
    public String getCubeName()
    {
        return cubeName;
    }
    public void setCubeName(String cubeName)
    {
        this.cubeName = cubeName;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("EssbaseConnectionDO [japiVersion=");
        builder.append(japiVersion);
        builder.append(", uerName=");
        builder.append(uerName);
        builder.append(", password=");
        builder.append(password);
        builder.append(", providerUrl=");
        builder.append(providerUrl);
        builder.append(", olapServerName=");
        builder.append(olapServerName);
        builder.append(", applicationName=");
        builder.append(applicationName);
        builder.append(", cubeName=");
        builder.append(cubeName);
        builder.append("]");
        return builder.toString();
    }

}
