package com.level3.etl.email;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.search.FlagTerm;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Entities;
import org.jsoup.safety.Whitelist;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.etl.email.dataobjects.MailMessageDO;
import com.level3.etl.email.dataobjects.MailMessageDO.MessageStatus;
import com.level3.etl.email.dataobjects.MailboxDO;
import com.level3.etl.email.dataobjects.ReportMetadataDO;
import com.level3.etl.email.dataobjects.ReportStorageDO;
import com.level3.etl.exception.FailSessionException;
import com.level3.etl.exception.IncrementErrorCountException;

/**
 * MailMessageProcessor class is used to read mails from a mailbox, download attachments and parse data
 * in the mail. We expect to find the following pieces of data in the mail body
 * 
 * <ul>
 *   <li> Carrier </li>
 *   <li> Report Name </li>
 *   <li> Report Type </li>
 *   <li> Report Frequency </li>
 *   <li> Report Period </li>
 *   <li> Attachment Mime Type </li>
 * </ul>
 * 
 * Once the message is parsed successfully and the attachment is downloaded it will call callback's 
 * receiveMailMessage() with details about the email message.
 * 
 * @author agarwal.nitin
 *
 */
public class MailMessageProcessor
{
    private static final long SIZE_IN_KBS = 1024L;
    private static Logger log = LoggerFactory.getLogger(MailMessageProcessor.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd-HHmmss");
    private static final String DOT_CHAR = ".";
    private static final String DASH_CHAR = "-";
//    private static final String XML_STR = "xml";
    
    private MailboxDO mailboxDO = null;
    private ReportStorageDO reportStorageDO = null;
    
    private Session session = null;
    private Store store = null;
    private Folder inboxFolder = null;
    
    private static final String REPLY_SUBJECT = "RE: Returned %s";
    private static final String REPLY_MESSAGE = "The following email has been returned as %s.  Please review and resubmit. \n\n";
    
    /**
     * This constructor will try and connect to the mail box as specified bu mailboxDO
     * @param mailboxDO
     * @param reportStorageDO
     */
    public MailMessageProcessor(MailboxDO mailboxDO, ReportStorageDO reportStorageDO)
    {
        this.mailboxDO = mailboxDO;
        this.reportStorageDO = reportStorageDO;
        
        log.debug("MailboxDO \n" + this.mailboxDO.toString());
        log.debug("Report Storage DO \n" + this.reportStorageDO.toString());
        // establish connection to mailbox
        init();
    }
    
    /**
     * close out the connections to IMAP store
     */
    public void destroy()
    {
        try
        {
            finalize();
        }
        catch(Throwable t)
        {
            
        }
    }
    
    protected void finalize() throws Throwable
    {
        try
        {
            inboxFolder.close(false);
        }
        catch (MessagingException mex)
        {
            // nothing to do here, we are going down anyway
        }
        
        try
        {
            store.close();
        }
        catch (MessagingException mex)
        {
            // nothing to do here, we are going down anyway
        }
    }
    
    /**
     * Send reply message to all recepients
     * @param message
     * @param sendToAllRecipients - if true will send the response to all recipients on the email.
     */
    public void replyAsRejection(Message message, String messageBody, MessageStatus messageStatus, boolean sendToAllRecipients)
    {
        MimeMessage mimeMessage = null;
        String responseBody = null;
        
        try
        {
            Message replyMessage = message.reply(sendToAllRecipients);
            replyMessage.setSubject(String.format(REPLY_SUBJECT, message.getSubject()));
            
            if(replyMessage instanceof MimeMessage)
            {
                mimeMessage = (MimeMessage)replyMessage;
                
                mimeMessage.setFrom(new InternetAddress(mailboxDO.getMailBox()));
                responseBody = String.format(REPLY_MESSAGE, messageStatus.getDescription()) + messageBody.replaceAll("(?m)^", "> "); 
                mimeMessage.setText(responseBody);
                
                Transport.send(mimeMessage);
            }
        }
        catch (MessagingException mex)
        {
            throw new IncrementErrorCountException("Failed to send a reply message.", mex);
        }
    }
    
    /**
     * processes all unread email's. This call will stop as soon as the first exception is encountered and 
     * will return the control back to the calling code.
     * @param callback
     */
    public void processMessages(MailMessageCallbackIF callback)
    {
        try
        {
            FlagTerm ft = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
            Message[] messageArray = inboxFolder.search(ft);
            
            log.info("Unread message count " + messageArray.length);
            List<Message> messageList = Arrays.asList(messageArray);
            
            processMessages(callback, messageList);
        }
        catch (MessagingException mex)
        {
            throw new IncrementErrorCountException(
               "Exception while trying to query mailbox for unread messages.", mex);
        }
    }
    
    public void processMessages(MailMessageCallbackIF callback, List<Message> messageList)
    {
        MailMessageDO mailMessageDO = null;
        
        if(messageList == null || messageList.size() == 0)
        {
            return;
        }
        
        for(int counter = 0; counter < messageList.size(); ++counter)
        {
            mailMessageDO = processMessage(messageList.get( counter ));

            callback.receiveMailMessage(mailMessageDO);
        }
    }
    
    /**
     * process each unread message, extract data from message body, download attachment and mark message as read.
     * @param message
     * @return MailMessageDO - containing data extracted from message body and a reference to the downloaded
     * attachment
     */
    private MailMessageDO processMessage(Message message)
    {
        MailMessageDO mailMessageDO = null;
        ReportMetadataDO reportMetadataDO = null;
        List<File> attachments = new ArrayList<File>();
        Object messageContent = null;
        File attachmentFile = null;
        File persistedFile = null;
        String reportFileNameWithoutExtension = null;
        String reportFileName = null;
        String urlEncodedReportFileName = null;
        
        try
        {
            mailMessageDO = new MailMessageDO();
            mailMessageDO.setEmailMessage(message);
            // we initially set the status to GOOD, if needed we will switch it later
            mailMessageDO.setStatus(MessageStatus.GOOD);
            
            reportMetadataDO = new ReportMetadataDO();
            reportMetadataDO.setCustomerNumber(reportStorageDO.getCustomerNumber());
            
            // mark this message as read, so that if there are issues with this message, then we will not
            // try to re-read this message.
            message.setFlag(Flag.SEEN, true);

            messageContent = message.getContent();
            
            if (messageContent instanceof Multipart)
            {
                // reportMetadataDO and attachments should get filled when this call returns
                processMultipart(
                        (Multipart)messageContent, reportMetadataDO, attachments);
                
                mailMessageDO.setEmailMessageBody(reportMetadataDO.getMessageBodyContent());
            
                if(attachments.size() == 1)
                {
                    attachmentFile = attachments.get(0);

                    // change the name of attachment to make sure we have unique file names.
                    reportFileNameWithoutExtension = 
                            reportMetadataDO.getReportName() + DASH_CHAR + dateFormat.format(new Date());

                    reportFileName = 
                            reportFileNameWithoutExtension + DOT_CHAR +
                            FilenameUtils.getExtension(attachmentFile.getName());
                    
                    reportFileName = reportFileName.replaceAll("\\s+", "");
                    reportFileName = reportFileName.replaceAll("&", "");
                    
                    urlEncodedReportFileName = URLEncoder.encode(reportFileName, "UTF-8");
                    
                    // report Uid is on ftp server and not local server, so we need to set it appropriately
                    reportMetadataDO.setReportUid(reportStorageDO.getReportFtpDir() + "/" + urlEncodedReportFileName);
                    reportMetadataDO.setReportSize(sizeinKBs(attachmentFile.length()));

                    if(reportMetadataDO.isFilled())
                    {
                        log.debug("metadata successfully parsed and populated.");

                        mailMessageDO.setReportInfoXml(reportMetadataDO.getMetadataAsXml());
                        
                        // everything checks out, move attachment to storage dir as (unique) file name
                        persistedFile = new File(reportStorageDO.getReportStorageDir(), urlEncodedReportFileName);

                        FileUtils.moveFile(attachmentFile, persistedFile);

                        mailMessageDO.setAttachment(persistedFile);
                    }
                    else
                    {
                        mailMessageDO.setStatus(MessageStatus.INVALID_DATA);
                    }
                }
                else
                {
                    if(attachments.size() == 0)
                    {
                        mailMessageDO.setStatus(MessageStatus.NO_ATTACHMENTS);
                    }
                    else
                    {
                        mailMessageDO.setStatus(MessageStatus.MULTIPLE_ATTACHMENTS);
                    }
                }
            }
            else
            {
                // if not Multipart log an exception and send reject message.
                log.debug("NO ATTACHMENT FOUND, BAD MESSAGE.");
                mailMessageDO.setStatus(MessageStatus.NO_ATTACHMENTS);
                
                mailMessageDO.setEmailMessageBody(getMessageContent(message));
            }
            
            log.debug("META DATA \n" + reportMetadataDO.toString());
            log.debug("Metadata as XML \n" + reportMetadataDO.getMetadataAsXml());
        }
        catch (IOException ioe)
        {
            throw new IncrementErrorCountException(
               "Exception while trying to retrieve message contents.", ioe);
        }
        catch (MessagingException mex)
        {
            throw new IncrementErrorCountException(
               "Exception while trying to retrieve message contents.", mex);
        }
        
        return mailMessageDO;
    }
    
    private void processMultipart(
            Multipart multipart, ReportMetadataDO reportMetadataDO, List<File> attachments)
    {
        String output = null;
        File attachment = null;
        boolean processBody = true;
        
        try
        {
            log.debug("COUNT OF MULTIPARTS :" + multipart.getCount());
            
            // process multipart
            for (int index = 0; index < multipart.getCount(); ++index)
            {
                BodyPart bodyPart = multipart.getBodyPart(index);

                // if not PART.ATTACHMENT and file is empty, then this is message body, process message body
                if (!Part.ATTACHMENT.equalsIgnoreCase(bodyPart.getDisposition()) &&
                        !StringUtils.isNotBlank(bodyPart.getFileName()))
                {
                    log.debug(
                        "PART :" + bodyPart.getDisposition() + ", CONTENT TYPE :" + bodyPart.getContentType());
                    
                    if(bodyPart.isMimeType("multipart/*"))
                    {
                        log.debug("MULTIPART MIME TYPE :multipart/*");
                        processMultipart(
                            (Multipart)bodyPart.getContent(), reportMetadataDO, attachments);
                    }
                    // if a message has both text/plain and text/html, typically text/plain will be the first
                    // body part in a multipart/* body part
                    else if(processBody)
                    {
                        processBody = false;
                     
                        output = getMessageContent(bodyPart);
                        
                        // parse and build XML
                        reportMetadataDO.populateDataFromString(output);
                    }
                }
                else
                {
                    log.debug("MULTIPART MIME TYPE :" + bodyPart.getDisposition());
                    attachment = extractAttachment(bodyPart);
                    
                    attachments.add(attachment);
                }
            }
        }
        catch (IOException ioe)
        {
            throw new IncrementErrorCountException(
               "Exception while trying to retrieve contents of body part in a multipart message.", ioe);
        }
        catch (MessagingException mex)
        {
            throw new IncrementErrorCountException(
               "Exception while trying to process body part in a multipart message.", mex);
        }
    }
    
    private File extractAttachment(BodyPart bodyPart)
    {
        InputStream is = null;
        File file = null;
        
        try
        {
            file = new File(reportStorageDO.getReportStagingDir(), bodyPart.getFileName());
            is = bodyPart.getInputStream();
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] buf = new byte[4096];
            int bytesRead;
            while ((bytesRead = is.read(buf)) != -1)
            {
                fileOutputStream.write(buf, 0, bytesRead);
            }
            fileOutputStream.close();
            
            return file;
        }
        catch (IOException ioe)
        {
            throw new IncrementErrorCountException(
               "Exception while trying to retrieve attachment from message.", ioe);
        }
        catch (MessagingException mex)
        {
            throw new IncrementErrorCountException(
               "Exception while trying to retrieve attachment from message.", mex);
        }
    }
    
    private static long sizeinKBs(long value)
    {
        long result = value;

        if(result < 10240L)
        {
            return 1;
        }
        else
        {
            result = result / SIZE_IN_KBS;

            return result;
        }
    }
    
    private String getMessageContent(Part part)
    {
        String output = null;
        
        try
        {
            if (part.isMimeType("text/plain"))
            {
                output = (String) part.getContent();
                log.debug(" text/plain CONTENT :\n" + output);
            }
            else if (part.isMimeType("text/html"))
            {
                String html = (String) part.getContent();

                // strip out html tags and get text
                Document.OutputSettings outputSettings = 
                        new Document.OutputSettings().prettyPrint(false);
                outputSettings.escapeMode(Entities.EscapeMode.xhtml);
                String htmlOutput = Jsoup.clean(html, "", Whitelist.none(), outputSettings);
                output = StringEscapeUtils.unescapeHtml(htmlOutput);
                log.debug("text/html CONTENT :\n" + output);
            }
            else
            {
                output = " ";
            }
        }
        catch (IOException ioe)
        {
            throw new IncrementErrorCountException(
                    "Exception while trying to retrieve contents of body part in a multipart message.", ioe);
        }
        catch (MessagingException mex)
        {
            throw new IncrementErrorCountException(
                    "Exception while trying to process body part in a multipart message.", mex);
        }
        
        return output;
    }
    
    /**
     * Connect to the mailbox using IMAP and initialize SMTP connection to the mail server.
     */
    private void init()
    {
        // get properties
        Properties props = new Properties();

        // set up properties for SMTP mail server
        props.setProperty("mail.smtp.host", mailboxDO.getSmtpServer());
        props.setProperty("mail.smtp.port", mailboxDO.getSmtpPort() == null ? "25" : mailboxDO.getSmtpPort());
        
        if(mailboxDO.getPropertiesMap().size() > 0)
        {
            props.putAll(mailboxDO.getPropertiesMap());
        }
        
//        props.setProperty("mail.smtp.auth", "true");
//        props.setProperty("mail.debug", "true");
//        props.setProperty("mail.smtp.timeout", "30000");
//        props.setProperty("mail.smtp.connectiontimeout", "30000");
//        props.put("mail.smtp.starttls.enable", "true");
        
        props.put("mail.imap.partialfetch", "false");

        session = Session.getInstance(
                props, new ExchangeAuthenticator(mailboxDO.getUserName(), mailboxDO.getPassword()));
//        session.setDebug(true);
//        session = Session.getDefaultInstance(props, null);
        try
        {
            store = session.getStore("imap");
            
            if(!store.isConnected())
            {
                store.connect(mailboxDO.getMailServer(), mailboxDO.getUserName(), mailboxDO.getPassword());
            }
            
            inboxFolder = store.getFolder("INBOX");
            
            inboxFolder.open(Folder.READ_WRITE);
            
            log.debug("Message count :" + inboxFolder.getMessageCount());
        }
        catch (NoSuchProviderException nse)
        {
            throw new FailSessionException(
                "caught exception trying to initialize MailMessageProcessor, could not connect to mailbox.", 
                nse);
        }
        catch (MessagingException mex)
        {
            throw new FailSessionException(
                "caught exception trying to initialize MailMessageProcessor, could not connect to mailbox.", 
                mex);
        }
    }
    
    public static void main(String[] args)
    {
        
        MailboxDO mailboxDO = new MailboxDO();
        
        mailboxDO.setSmtpServer("smtp.level3.com");
        mailboxDO.setSmtpPort("25");
        
        mailboxDO.setMailServer("email.level3.com");
        mailboxDO.setMailBox("starbucksreports@level3.com");
        mailboxDO.setUserName("starbucksreports");
        mailboxDO.setPassword("31arb8ck3!");
        
        ReportStorageDO reportStorageDO = new ReportStorageDO();
        reportStorageDO.setCustomerNumber("1-5K14R");
        
        if(SystemUtils.IS_OS_WINDOWS)
        {
            reportStorageDO.setReportFtpDir("C:/Starbucks");
            reportStorageDO.setReportStorageDir("C:/temp/Starbucks/data");
            reportStorageDO.setReportStagingDir("C:/temp/Starbucks/staging");
        }
        else
        {
            reportStorageDO.setReportFtpDir("/tmp/ftp/Starbucks");
            reportStorageDO.setReportStorageDir("/tmp/Starbucks/data");
            reportStorageDO.setReportStagingDir("/tmp/Starbucks/staging");
        }
        
        final MailMessageProcessor messageProcessor = new MailMessageProcessor(mailboxDO, reportStorageDO);
        
        messageProcessor.processMessages( new MailMessageCallbackIF()
        {
            public void receiveMailMessage(MailMessageDO mailMessageDao)
            {
                log.debug("callback invoked.");
                log.info(mailMessageDao.toString());
                
                if(mailMessageDao.getStatus() != MessageStatus.GOOD)
                {
                    log.debug("BAD EMAIL MESSAGE " + mailMessageDao.getStatus().getDescription());
//                    messageProcessor.replyAsRejection(
//                            mailMessageDao.getEmailMessage(), mailMessageDao.getEmailMessageBody(),
//                            mailMessageDao.getStatus(), false);
                }
                else
                {
                    log.debug("GOOD EMAIL MESSAGE.");
                }
            }
        });
    }
}
