package com.level3.etl.email;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class ExchangeAuthenticator extends Authenticator
{
    PasswordAuthentication passwordAuth = null;
    
    public ExchangeAuthenticator(String userName, String password)
    {
        this.passwordAuth = new PasswordAuthentication(userName, password);
    }
    
    public PasswordAuthentication getPasswordAuthentication()
    {
        return passwordAuth;
    }
}
