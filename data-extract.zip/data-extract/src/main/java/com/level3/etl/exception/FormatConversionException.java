package com.level3.etl.exception;

public class FormatConversionException extends RuntimeException
{
    private static final long serialVersionUID = -5798463163351067684L;
    
    private String errorCode = null;

    public FormatConversionException( final String msg, final String errorCode )
	{
		super(msg);
		
		this.errorCode = errorCode;
	}
	
	public FormatConversionException(final String msg, String errorCode, Throwable e )
	{
		super(msg,e);
		
		this.errorCode = errorCode;
	}

    public String getErrorCode()
    {
        return errorCode;
    }

    public void setErrorCode(String errorCode)
    {
        this.errorCode = errorCode;
    }
}
